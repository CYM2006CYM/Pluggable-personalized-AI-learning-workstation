# C 岗位 W2-D5 V2-3 正式交付报告

## 1. 结论

结论为 `V2-3_BINDING_PASS / C_D5_DELIVERY_READY`。

D4 完整 V2-3 已绑定正式 Git 提交 `fa26097e46a72a2826d960a7e1934a8885098112`。本次补交只完善可重复执行工具、C 作者测试、正式报告和交接清单；未修改 B 资产，未修改正式仓库，未提交、未推送。

## 2. 正式绑定结果

| 检查项 | 结果 |
|---|---|
| 合同 | `W2-C2/W2-R5` |
| 正式提交 | `fa26097e46a72a2826d960a7e1934a8885098112` |
| 冻结文件 | 67/67 一致，缺失 0，不一致 0 |
| 资产树 SHA-256 | `07fb50caf5cfd646654cedf5c038f836bbbede912c6034f4e3523deaf77183ab` |
| `final-60` SHA-256 | `b77ba4902003ba20bc5b233c4797838eb26325d1b38fd02bc68ba02206cb1d1c` |
| manifest JCS SHA-256 | `39a16ca7e2d7af92b327f7417d0732e79a30ea16826b08c44bf3b26c3b4ddc3b` |
| 诊断摘要 JCS SHA-256 | `a6000080559dbc9a12f269f8d0bd8b10d9dfd1835cdf57fda0c33939ece11e88` |
| D4 报告规范化 SHA-256 | `d945c2456d001f4e62252d3e425b96df1c5f34dc4e161a9d56fd3932760ad014` |

## 3. D4 完整 V2-3 原始执行链

以下命令按 D4 整改复审报告原记录保留，用于证明当时完整执行范围；`audit-tools`、`audit-input` 和 `audit-output` 是 D4 仓库外审计工作目录，不是当前 Git 依赖。

```powershell
python .\audit-tools\audit_manifest.py --outer .\audit-input\received-package.zip --extract-root .\audit-input\candidate --output .\audit-output\manifest-audit.json --expected-manifest-jcs 39a16ca7e2d7af92b327f7417d0732e79a30ea16826b08c44bf3b26c3b4ddc3b
python -m unittest discover -s .\audit-tools -p 'test_*.py'
python .\audit-tools\audit_v23.py --profile-root .\audit-input\candidate\pi-study-helper\fixtures\profiles\pandas-cleaning-v2-draft --manifest-audit .\audit-output\manifest-audit.json --output .\audit-output\v23-audit.json
python .\audit-tools\compare_remediation.py --old-root ..\C-W2-D4-audit-f343a6c-20260801-144142\audit-input\candidate --new-root .\audit-input\candidate --old-v23 ..\C-W2-D4-audit-f343a6c-20260801-144142\audit-output\v23-audit.json --new-v23 .\audit-output\v23-audit.json --candidate-evidence .\audit-input\candidate\pi-study-helper\fixtures\profiles\pandas-cleaning-v2-draft\quality\c-execution-evidence.json --rerun-evidence .\audit-output\b-candidate-evidence-rerun.json --output .\audit-output\remediation-comparison.json
python .\audit-input\candidate\pi-study-helper\fixtures\profiles\pandas-cleaning-v2-draft\quality\run-candidate-evidence.py --output .\audit-output\b-candidate-evidence-rerun.json
npm.cmd test -- tests/pandas-cleaning-v2-assets.test.ts --maxWorkers=1
```

| D4 检查 | 退出码 | 真实结果 |
|---|---:|---|
| manifest/资产树复算 | 0 | 6 项载体、67 项候选全部通过 |
| C 作者测试 | 0 | 11/11 |
| 完整 V2-3 | 0 | 33 次参考执行、9 次完整清洗、21 次错误矩阵 |
| 新旧整改差异 | 0 | 仅 3 项变化；数据与结果不变；敏感扫描 0 命中 |
| B v5 候选证据重跑 | 0 | 11 组基线稳定；错误实现全部拒绝 |
| B 资产作者测试 | 0 | 1 文件、10/10 |

## 4. 当前稳定复现命令

以下命令从副本仓库根执行。D4 载体和 D4 报告继续作为仓库外只读输入，两个 JSON 输出到仓库外证据目录，不属于 Git 交付。

```powershell
$evidenceDir = '..\C-W2-D5-evidence-fa26097e-remediation'
python .\pi-study-helper\scripts\w2-data-validation\bind_formal_commit.py --repo-root . --commit fa26097e46a72a2826d960a7e1934a8885098112 --carrier <D4整改审计载体.zip> --d4-report <D4整改复审报告.md> --output "$evidenceDir\formal-binding.json"
python .\pi-study-helper\scripts\w2-data-validation\audit_v23.py --profile-root .\pi-study-helper\fixtures\profiles\pandas-cleaning-v2-draft --manifest-audit "$evidenceDir\formal-binding.json" --output "$evidenceDir\v23-formal.json"
python -m unittest discover -s .\pi-study-helper\scripts\w2-data-validation -p "test_*.py" -v
```

正式绑定命令退出码 0，67/67 一致。D5 最小 V2-3 命令退出码 0：公开 CSV 1 份、私有变体 2 份各运行 3 次，共 9 次完整清洗；33 次参考执行稳定；5 份已知错误实现、21 次 fixture/repeat 检查和 27 次测试拒绝全部通过。

## 5. 作者测试与受影响回归

| 命令 | 退出码 | 结果 |
|---|---:|---|
| `node .\pi-study-helper\scripts\w2-data-validation\matrix-self-check.mjs` | 0 | PASS |
| `python -m unittest discover -s .\pi-study-helper\scripts\w2-data-validation -p "test_*.py" -v` | 0 | 22/22 |
| `npm.cmd test -- tests/pandas-cleaning-v2-assets.test.ts --maxWorkers=1` | 0 | 1 文件、10/10 |
| `npm.cmd run verify` | 0 | 37 文件、389/389；typecheck、文档链接、extension smoke、release check 通过 |

npm 命令在 `pi-study-helper` 包目录执行。

## 6. 环境、分类与限制

- 实测环境：Python 3.13.7、pandas 3.0.5、Windows 11 build 26100。
- `b_asset_defect`：无。
- `c_validator_defect`：补交阶段发现并修复 Windows URL 路径处理及诊断摘要浮点 JCS 处理；作者测试和正式复算已覆盖。
- `windows_environment_noise`：不改变本次数据唯一性结论。
- `deferred_prototype_item`：最终环境锁和 dtype 原型仍待后续裁决。

本报告不替代 V2-2，不授予 Profile active，不覆盖 V2-7、V2-8、gold 冻结或真实 Python 沙箱。本次未修改 B 的 CSV、Profile、参考实现、错误实现、测试、manifest 或诊断资产。
