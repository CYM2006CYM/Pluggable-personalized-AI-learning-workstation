# E 岗位 W2-D7 CLOSEOUT-1 交付清单

交付根目录已完全位于 Git 仓库外。`NOT_COMMITTED`；`NOT_PUSHED`；未申请上传锁。

## 目录与内容

| 目录 | 内容 |
| --- | --- |
| `01-正式文档/` | W2 验证记录、最终 handoff、七件工具哈希清单、双封存资格登记和 V2-7 证据索引。|
| `02-V2-7证据/` | 历史两输入原件、新六输入 manifest/机器结果、ordinary log、安全 export、全部规定 sidecar 与 D7 复验记录。|
| `03-原始标注与封存/` | 原始 `e-first-20.jsonl` 与 E 封存声明；只随审计包提供，不自行上传。|
| `04-七件工具候选/` | 七件 E 验证工具候选，与正式工具清单逐文件哈希一致。|
| `05-运行原始输出/` | 最新 HEAD verify、V2-2/V2-4/V2-5/V2-6、V2-7 自检的原始输出。|
| `06-机械差异清单/` | 签署后生成的 20 行 B/E 机械差异清单及 SHA-256 sidecar；不含协商、裁决或 gold。|
| `07-代负责人签署与授权交付/` | E 依据用户授权代负责人签署的四项资格记录，以及 W2-D7-E-3 授权执行记录。|

## 关键可复算事实

- 实际验证 HEAD / `origin/main`：`98977c1f21b78e8866f90497c8b51c88e4411b27`。
- 最新 `npm.cmd run verify`：exit `0`，37 个测试文件、389 项通过；原始输出 SHA-256 `66c6f93c01a8b043812eadeb9c13a55d3ab924b1cd0485bd2ca9d9025bfc12d5`。
- V2-3：`OWNER_NO_LOWERING_CONFIRMATION / V2-3=PASS / 真实六输入作者测试=26/26 PASS`。
- V2-7 新六输入结果：exit `0`、`inputCount=6`、五类表面齐全、所有输入及汇总的六类命中均为 0、`status=PASS`；result SHA-256 `8863ca31716347366f7821260ce87ac895a289abdc4b2cbad624a1b90366d321`。
- V2-7 历史两输入原件继续保留：canary SHA-256 `59018cc6734d09eddbb0271bac0ab9e9de9f2823b77f4eafc9554d58735f38e1`；旧机器结果 SHA-256 `3ee729099433c8c396f538e0d3f14a638c1adbd8c88ff924431b01e67bf2a1fd`。
- 双封存资格：E 已依据用户授权于 `2026-08-05 21:07:00 +08:00` 代负责人签署四项 `PASS`，结论 `DOUBLE_SEAL_QUALIFICATION_PASS`。
- V2-8：`PENDING_OWNER_ADJUDICATION`。已附 20 行机械差异清单及其 SHA-256，等待负责人直接逐案终裁和正式 gold 生成。
- 机械差异清单：20 行、`MATCH=0`、`DIFFERENT=20`，SHA-256 `d3a42f49d03ca1af7e2aa7fb7d12bd72780575c53c776e4ddd330a1311fdf12c`；每行只机械比较 `nodeConstraints`、`requiredRemediationKnowledgePointIds`、`forbiddenActions`、`notes`，协商状态固定为 `SKIPPED_BY_W2-D7-CLOSEOUT-1`。

## 交付边界

本包不含正式 gold，也未修改 A/B/C/D 产物、原始 B/E 标注、依赖、锁文件或 `allowScripts`。获负责人上传锁前，不得将包内任一候选写入 Git。
