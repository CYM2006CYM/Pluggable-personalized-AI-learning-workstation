# E 岗位 W2-D7 七件验证工具 SHA-256 清单

> 以下为获负责人上传锁后应使用的规范仓库路径；当前候选文件位于仓库外，未 commit、未 push。

| 规范仓库路径 | SHA-256 |
| --- | --- |
| `evaluation/claims/claim-split-template.md` | `e0b5828397bf11a9337b6d99bd0cf8668ac14057a8673c9bf9259ace16c7f440` |
| `pi-study-helper/scripts/evaluation-metrics.mjs` | `d621db3b0487bff66164c7b4fddb523c9e5c8b59c0d389182abcb04504a07a78` |
| `pi-study-helper/scripts/w2-verification/v2-6-preconditions.mjs` | `1da8639ce3013897d6ab76ba522cd8f84025345b5765c045aa98c13d6713280a` |
| `pi-study-helper/scripts/w2-verification/v2-6-preconditions.test.mjs` | `b9292ecd0b60d21a07eee80384e3b21bbddfd08b582ab8aeaa4ad1a2e18e0708` |
| `pi-study-helper/scripts/w2-verification/v2-7-asset-isolation.mjs` | `7f05a22dac831c45e731ab419503ab64435efedd787b53d174e887c1cd501fb0` |
| `pi-study-helper/scripts/w2-verification/v2-comprehensive-verification.mjs` | `77bc838ce328cf53e72f6cfc0b0128473a20627b4f8c7c9da71909be388fc226` |
| `pi-study-helper/scripts/w2-verification/v2-comprehensive-verification.test.mjs` | `e35b48160ed5e81d75b2563cfe02a8a3d6489501e8a2b15ce88dd2930d65730b` |

文件内容清单和哈希均按仓库外候选文件复算。`NOT_COMMITTED`；`NOT_PUSHED`。
