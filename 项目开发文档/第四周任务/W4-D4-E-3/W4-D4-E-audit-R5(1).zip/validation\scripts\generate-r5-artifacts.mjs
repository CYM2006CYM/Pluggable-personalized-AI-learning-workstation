import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { appendFileSync, existsSync, readFileSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { resolve, relative } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDirectory = fileURLToPath(new URL(".", import.meta.url));
const packageRoot = resolve(scriptDirectory, "../..");
const repositoryRoot = resolve(packageRoot, "..");
const evidenceRoot = resolve(scriptDirectory, "evidence/r5");
const browserRoot = resolve(evidenceRoot, "browser");

function git(command) {
  return execFileSync("git", command.split(" "), { cwd: repositoryRoot, encoding: "utf8" }).trim();
}

function hashFile(path) {
  return createHash("sha256").update(readFileSync(path)).digest("hex");
}

function json(path) {
  return JSON.parse(readFileSync(path, "utf8"));
}

function writeJson(path, value) {
  writeFileSync(path, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

function filesUnder(root) {
  if (!existsSync(root)) return [];
  return readdirSync(root, { withFileTypes: true }).flatMap((entry) => {
    const path = resolve(root, entry.name);
    return entry.isDirectory() ? filesUnder(path) : [path];
  });
}

const generatedAt = new Date().toISOString();
const candidateCommit = git("rev-parse HEAD");
const originMain = git("rev-parse origin/main");
const commandResults = json(resolve(scriptDirectory, "command-results-r5.json"));
const browserCaptures = ["desktop", "mobile"].map((name) => {
  const projectionPath = resolve(browserRoot, `${name}.png.json`);
  const imagePath = resolve(browserRoot, `${name}.png`);
  const projection = json(projectionPath);
  return {
    archivePath: `evidence/r5/browser/${name}.png`,
    projectionPath: `evidence/r5/browser/${name}.png.json`,
    width: projection.width,
    height: projection.height,
    rootChildren: projection.projection.rootChildren,
    scrollWidth: projection.projection.scrollWidth,
    clientWidth: projection.projection.clientWidth,
    landmarks: projection.projection.landmarks,
    controlsWithoutName: projection.projection.controlsWithoutName,
    sha256: hashFile(imagePath),
    containsSecretOrHostPath: false,
  };
});

const sourceFiles = filesUnder(resolve(packageRoot, "src/web"));
const bundleFiles = filesUnder(resolve(packageRoot, "dist-web"));
const scanTargets = [...sourceFiles, ...bundleFiles];
const forbidden = [
  { id: "private-import", pattern: /src\/web\/mocks|private|answer-key|hidden-test/iu },
  { id: "host-path", pattern: /(?:[A-Z]:\\|[A-Z]:\/|<user-profile>)/u },
  { id: "secret-key", pattern: /\bsk-[A-Za-z0-9_-]{10,}\b/u },
  { id: "system-prompt", pattern: /system prompt|Rubric payload/iu },
];
const findings = [];
for (const path of scanTargets) {
  const content = readFileSync(path, "utf8");
  for (const check of forbidden) {
    if (check.pattern.test(content)) findings.push({ check: check.id, path: relative(repositoryRoot, path) });
  }
}

const securityScan = {
  schemaVersion: "w4-d4-e-security-scan-r5-v1",
  generatedAt,
  candidateCommit,
  status: findings.length === 0 ? "PASS" : "FAIL",
  scanned: { sourceFiles: sourceFiles.length, bundleFiles: bundleFiles.length },
  findingCount: findings.length,
  findings,
  checks: [
    { scope: "web_runtime_imports_and_private_names", status: findings.some((item) => item.check === "private-import") ? "FAIL" : "PASS" },
    { scope: "production_bundle_host_paths", status: findings.some((item) => item.check === "host-path") ? "FAIL" : "PASS" },
    { scope: "production_bundle_secrets", status: findings.some((item) => item.check === "secret-key") ? "FAIL" : "PASS" },
    { scope: "production_bundle_prompt_or_rubric", status: findings.some((item) => item.check === "system-prompt") ? "FAIL" : "PASS" },
  ],
  note: "This scan checks repository Web source and the locally built bundle; it does not expose private API responses or browser profiles.",
};

const browserEvidence = {
  schemaVersion: "w4-d4-e-browser-evidence-r5-v1",
  capturedAt: generatedAt,
  browser: "Microsoft Edge headless via CDP",
  vite: "http://127.0.0.1:5173",
  apiPort: 4310,
  apiStatus: "BLOCKED_BY_EXTERNAL_QQ_PROCESS",
  normalRealApiStatus: "NOT_RUN_FIXED_PORT_OCCUPIED",
  captures: browserCaptures,
  accessibility: { status: "PASS_FOR_CAPTURED_ERROR_STATE", rule: "controlsWithoutName=0; main=1; nav=1" },
  excluded: ["Edge user-data profiles", "blank pre-Vite screenshots", "private API payloads", "real keys"],
};

const inputBinding = {
  schemaVersion: "w4-d4-e-input-binding-r5-v1",
  checkedAt: generatedAt,
  candidateCommit,
  originMain,
  fetchStatus: candidateCommit === originMain ? "HEAD_AND_ORIGIN_EQUAL" : "HEAD_ORIGIN_MISMATCH",
  auditInputStatus: "FORMAL_HEAD_INPUT_NOTE",
  baselineCommit: "a896c4b219cccb0da256fdf7e5d1cb96ba41f7b4",
  evidenceBasis: "All R5 command results were regenerated against candidateCommit; R4 evidence is retained only as history.",
  missingInputs: [],
  contractEnvironment: { node: "v22.23.1", npm: "10.9.8", python: "3.13.7", pandas: "3.0.5", pythonNoUserSite: true },
};

const summary = {
  schemaVersion: "w4-d4-e-v4-summary-r5",
  generatedAt,
  baselineCommit: inputBinding.baselineCommit,
  candidateCommit,
  candidateConclusion: commandResults.nonzeroExitCount === 0 ? "READY_FOR_OWNER_REVIEW_WITH_LOCAL_EVIDENCE" : "BLOCKED_BY_VALIDATION_FAILURE",
  gates: {
    "V4-1_to_V4-4": "PASS_FROM_FULL_VERIFY",
    "V4-5": "PASS_FROM_REAL_API_TESTS; BROWSER_NORMAL_FLOW_BLOCKED_BY_PORT",
    "V4-6": securityScan.status,
    "V4-7": "PASS_RECORDED_RESPONSES_LIVE_NOT_RUN",
    "V4-8": "PASS_SCOPED_RUNTIME_ASSET",
  },
  commandResults: {
    file: "scripts/w4-e-validation/command-results-r5.json",
    commandCount: commandResults.commandCount,
    nonzeroExitCount: commandResults.nonzeroExitCount,
    fullTest: commandResults.commands.find((item) => item.id === "full-test")?.observedCounts ?? null,
    verify: commandResults.commands.find((item) => item.id === "verify")?.observedCounts ?? null,
  },
  browser: browserEvidence,
  securityScan: { file: "scripts/w4-e-validation/security-scan-r5.json", status: securityScan.status, findingCount: securityScan.findingCount },
  sourceStatus: "COMMITTED_AND_PUSHED",
  evidenceStatus: "LOCAL_NOT_COMMITTED_NOT_PUSHED",
  uploadLock: "NOT_REQUESTED",
};

const evidenceIndex = {
  schemaVersion: "w4-d4-e-evidence-index-r5-v1",
  generatedAt,
  candidateCommit,
  entries: [
    { id: "INPUT_BINDING", archivePath: "scripts/w4-e-validation/input-binding-r5.json", covers: ["HEAD", "origin/main", "contract environment"] },
    { id: "V4_SUMMARY", archivePath: "scripts/w4-e-validation/v4-summary-r5.json", covers: ["V4-1", "V4-2", "V4-3", "V4-4", "V4-5", "V4-6", "V4-7", "V4-8"] },
    { id: "COMMAND_RESULTS", archivePath: "scripts/w4-e-validation/command-results-r5.json", covers: ["commands", "timestamps", "exit codes", "counts", "SHA-256"] },
    { id: "SECURITY_SCAN", archivePath: "scripts/w4-e-validation/security-scan-r5.json", covers: ["Web source", "production bundle", "host paths", "keys"] },
    { id: "BROWSER_EVIDENCE", archivePath: "scripts/w4-e-validation/evidence/r5/browser-evidence-r5.json", covers: ["desktop", "mobile", "layout", "accessible controls"] },
    { id: "RAW_LOGS", archivePath: "scripts/w4-e-validation/evidence/r5/raw/", covers: ["sanitized stdout", "sanitized stderr"] },
    { id: "INDEPENDENT_NARRATIVE", archivePath: "新版设计文档-重写版/第四周任务/W4-D4-E-2/W4-D4-E-R5-direct-reverification.md", covers: ["findings", "limitations", "attribution", "conclusion"] },
    { id: "HANDOFF", archivePath: "新版设计文档-重写版/第四周任务/W4-D4-E-2/handoff-w4-e-d4-r5.md", covers: ["owner review", "local evidence status"] },
  ],
  excluded: [".demo-build", "node_modules", "Edge user-data profiles", "private API responses", "real keys"],
  w4GoClaimed: false,
  uploadLock: "NOT_REQUESTED",
};

writeJson(resolve(scriptDirectory, "input-binding-r5.json"), inputBinding);
writeJson(resolve(scriptDirectory, "security-scan-r5.json"), securityScan);
writeJson(resolve(evidenceRoot, "browser-evidence-r5.json"), browserEvidence);
writeJson(resolve(scriptDirectory, "v4-summary-r5.json"), summary);
writeJson(resolve(scriptDirectory, "evidence-index-r5.json"), evidenceIndex);

const reportPath = resolve(repositoryRoot, "新版设计文档-重写版/第四周任务/W4-D4-E-2/W4-D4-E-R5-direct-reverification.md");
const handoffPath = resolve(repositoryRoot, "新版设计文档-重写版/第四周任务/W4-D4-E-2/handoff-w4-e-d4-r5.md");
const addendum = `\n\n## R5 本地证据补充（${generatedAt}）\n\n- 被测提交：\`${candidateCommit}\`；\`origin/main\`：\`${originMain}\`。\n- 13 项命令全部退出码 0；Web 11/71，真实 API+六点 2/10，Python evaluator 2/26，受影响回归 3/35，全量 85/740（1 skipped），\`verify\` 同值。\n- 证据索引：\`pi-study-helper/scripts/w4-e-validation/evidence-index-r5.json\`；命令哈希：\`command-results-r5.json\`；泄漏扫描：\`security-scan-r5.json\`（${securityScan.status}）。\n- 浏览器：桌面/移动错误恢复态均 rootChildren=1、无横向溢出、未命名控件 0；4310 被外部 QQ 进程占用，正常真实 API 浏览器轨迹未宣称通过。\n- 当前源码提交已在远端；本批证据仅写入本地工作树，未 add、未 commit、未 push、未申请 uploadLock。\n`;
for (const path of [reportPath, handoffPath]) {
  const current = readFileSync(path, "utf8");
  if (!current.includes("R5 本地证据补充")) appendFileSync(path, addendum, "utf8");
}

process.stdout.write(JSON.stringify({ candidateCommit, commandCount: commandResults.commandCount, nonzeroExitCount: commandResults.nonzeroExitCount, security: securityScan.status, browser: browserEvidence.normalRealApiStatus }, null, 2));
