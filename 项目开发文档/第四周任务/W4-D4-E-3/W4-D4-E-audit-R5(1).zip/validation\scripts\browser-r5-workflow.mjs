import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const [url = "http://127.0.0.1:5174/", outputDirectory = "scripts/w4-e-validation/evidence/r5/browser-workflow"] = process.argv.slice(2);
const outputRoot = resolve(outputDirectory);
await mkdir(outputRoot, { recursive: true });
const edgePath = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const debugPort = 9231;
const profileRoot = resolve(`${outputRoot}/.profile`);
const { spawn } = await import("node:child_process");
const browser = spawn(edgePath, ["--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run", "--disable-extensions", `--remote-debugging-port=${debugPort}`, `--user-data-dir=${profileRoot}`, "about:blank"], { windowsHide: true, stdio: ["ignore", "ignore", "ignore"] });
const pause = (ms) => new Promise((resolvePause) => setTimeout(resolvePause, ms));
async function target() {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    try {
      const targets = await fetch(`http://127.0.0.1:${debugPort}/json/list`).then((response) => response.json());
      const page = targets.find((item) => item.type === "page");
      if (page?.webSocketDebuggerUrl) return page;
    } catch { /* wait for Edge */ }
    await pause(100);
  }
  throw new Error("edge_debug_target_timeout");
}
const page = await target();
const socket = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((resolveOpen, rejectOpen) => { socket.addEventListener("open", resolveOpen, { once: true }); socket.addEventListener("error", rejectOpen, { once: true }); });
let sequence = 0;
const pending = new Map();
socket.addEventListener("message", (event) => {
  const message = JSON.parse(String(event.data));
  const operation = pending.get(message.id);
  if (operation === undefined) return;
  pending.delete(message.id);
  if (message.error === undefined) operation.resolve(message.result); else operation.reject(new Error(message.error.message));
});
function send(method, params = {}) {
  const id = ++sequence;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolveSend, rejectSend) => pending.set(id, { resolve: resolveSend, reject: rejectSend }));
}
async function evaluate(expression) {
  const result = await send("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true });
  if (result.exceptionDetails !== undefined) throw new Error(result.exceptionDetails.text ?? "browser_evaluation_failed");
  return result.result?.value;
}
async function waitFor(predicate, label, timeout = 15000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    const value = await evaluate(`(${predicate})()`);
    if (value) return value;
    await pause(150);
  }
  throw new Error(`browser_wait_timeout:${label}`);
}
async function projection(label) {
  const value = await evaluate(`JSON.stringify({label: ${JSON.stringify(label)}, url: location.href, title: document.title, text: document.body.innerText.slice(0, 1600), rootChildren: document.querySelector('#root')?.childElementCount ?? 0, scrollWidth: document.documentElement.scrollWidth, clientWidth: document.documentElement.clientWidth, landmarks: {main: document.querySelectorAll('main').length, nav: document.querySelectorAll('nav').length}, controlsWithoutName: [...document.querySelectorAll('button,input,select,textarea,a[href]')].filter((node) => !(node.getAttribute('aria-label') || node.getAttribute('title') || node.textContent?.trim() || node.getAttribute('name'))).length})`);
  return JSON.parse(value);
}
async function clickText(text) {
  const expression = `(function(){const node=[...document.querySelectorAll('button')].find((item)=>item.textContent?.includes(${JSON.stringify(text)})); if(!node) return false; node.click(); return true;})()`;
  if (!(await evaluate(expression))) throw new Error(`button_not_found:${text}`);
}
async function selectValue(label, value) {
  const expression = `(function(){const node=document.querySelector(${JSON.stringify(`select[aria-label="${label}"]`)}); if(!node) return false; const setter=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set; setter.call(node,${JSON.stringify(String(value))}); node.dispatchEvent(new Event('change',{bubbles:true})); return true;})()`;
  if (!(await evaluate(expression))) throw new Error(`select_not_found:${label}`);
}
async function clickFirstRadio() {
  const result = await evaluate(`(function(){const nodes=[...document.querySelectorAll('input')]; const node=nodes.find((item)=>item.name === 'diagnostic-answer' || item.type === 'radio'); if(!node) return { clicked:false, inputCount:nodes.length, names:nodes.map((item)=>item.name) }; node.click(); return { clicked:true, inputCount:nodes.length };})()`);
  if (!result?.clicked) throw new Error(`diagnostic_radio_not_found:${JSON.stringify(result)}`);
}
async function saveProjection(label) {
  const value = await projection(label);
  await writeFile(resolve(outputRoot, `${label}.json`), `${JSON.stringify(value, null, 2)}\n`, "utf8");
  return value;
}

const observations = [];
try {
  await send("Page.enable");
  await send("Runtime.enable");
  await send("Emulation.setDeviceMetricsOverride", { width: 1440, height: 1000, deviceScaleFactor: 1, mobile: false });
  await send("Page.navigate", { url });
  await waitFor("() => document.readyState === 'complete' && (document.querySelector('#root')?.childElementCount ?? 0) > 0", "start");
  observations.push(await saveProjection("01-start-recommended"));
  await waitFor("() => document.querySelector('select[aria-label=\"可用时间\"]') !== null", "start-bootstrap-ready");
  await selectValue("可用时间", 400);
  await clickText("开始学习");
  await waitFor("() => location.pathname.includes('/diagnostic/')", "recommended-diagnostic");
  observations.push(await saveProjection("02-recommended-diagnostic-draft"));
  await waitFor("() => document.querySelector('input[type=radio]') !== null || document.body.innerText.includes('完成诊断')", "recommended-diagnostic-ready");
  for (let step = 0; step < 20; step += 1) {
    const hasSave = await evaluate("(() => [...document.querySelectorAll('button')].some((item)=>item.textContent?.includes('保存并继续')))()" );
    if (!hasSave) break;
    await clickFirstRadio();
    await clickText("保存并继续");
    await pause(250);
  }
  await clickText("完成诊断");
  await waitFor("() => location.pathname.includes('/path/')", "recommended-path");
  observations.push(await saveProjection("03-recommended-path"));
  await waitFor("() => document.body.innerText.includes('确认路径') || document.body.innerText.includes('进入学习')", "recommended-path-ready");
  await clickText("确认路径");
  await waitFor("() => document.body.innerText.includes('进入学习')", "recommended-path-confirm");
  await send("Page.reload");
  await waitFor("() => location.pathname.includes('/path/') && (document.querySelector('#root')?.childElementCount ?? 0) > 0 && document.querySelectorAll('main').length > 0 && !document.body.innerText.includes('正在加载路径') && !document.body.innerText.includes('从本地服务读取安全快照')", "path-refresh");
  observations.push(await saveProjection("04-recommended-path-refresh"));
  if (observations.at(-1).text.includes("确认路径")) {
    await clickText("确认路径");
    await waitFor("() => document.body.innerText.includes('进入学习')", "recommended-path-refresh-confirm");
  }
  await clickText("进入学习");
  await waitFor("() => location.pathname.includes('/learn/')", "recommended-learn");
  observations.push(await saveProjection("05-learning-card"));
  const cardText = observations.at(-1).text;
  if (!/目标|分步理解|示例|常见误区|来源依据/u.test(cardText)) throw new Error("learning_card_fields_missing");
  await clickText("进入练习活动");
  await waitFor("() => location.pathname.includes('/activity/')", "recommended-activity");
  const firstActivity = await saveProjection("06-activity-open");
  if (/correctAnswer|answerKey|答案解释/iu.test(firstActivity.text)) throw new Error("answer_leak_before_submit");
  const firstAttempt = firstActivity.text.match(/Attempt\s+([^\s]+)/u)?.[1] ?? null;
  await send("Page.reload");
  await waitFor("() => location.pathname.includes('/activity/') && document.body.innerText.includes('Attempt')", "activity-refresh");
  const activityRefresh = await saveProjection("07-activity-refresh");
  const refreshedAttempt = activityRefresh.text.match(/Attempt\s+([^\s]+)/u)?.[1] ?? null;
  observations.push({ label: "attempt_identity", firstAttempt, refreshedAttempt, stable: firstAttempt !== null && firstAttempt === refreshedAttempt });
  const questionCount = await evaluate("(() => new Set([...document.querySelectorAll('input[type=radio]')].map((node)=>node.name)).size)()" );
  await evaluate("(() => { const groups=[...new Set([...document.querySelectorAll('input[type=radio]')].map((node)=>node.name))]; for(const name of groups){document.querySelector(`input[type=radio][name=\"${name}\"]`)?.click();} return true; })()" );
  await clickText("提交完整题组");
  await waitFor("() => document.body.innerText.includes('SERVER VERDICT')", "first-submit");
  const firstResult = await saveProjection("08-first-submit");
  const retryVisible = /开始新 Attempt 重试/u.test(firstResult.text);
  observations.push({ label: "first_result", questionCount, retryVisible });
  if (retryVisible) {
    await clickText("开始新 Attempt 重试");
    await waitFor("() => location.pathname.includes('/activity/') && document.body.innerText.includes('Attempt')", "new-attempt");
    const retryOpen = await saveProjection("09-retry-open");
    observations.push({ label: "retry_attempt", firstAttempt, retryAttempt: retryOpen.text.match(/Attempt\s+([^\s]+)/u)?.[1] ?? null });
  }
  await send("Page.navigate", { url });
  await waitFor("() => location.pathname === '/'", "chapter-start");
  await evaluate("(() => { const radio=[...document.querySelectorAll('input[type=radio][name=entry]')].find((node)=>node.parentElement?.textContent?.includes('按章节学习')); if(!radio) return false; radio.click(); return true; })()" );
  await selectValue("可用时间", 400);
  await clickText("开始学习");
  await waitFor("() => location.pathname.includes('/diagnostic/') && document.body.innerText.includes('完成问卷并生成路径')", "chapter-diagnostic");
  observations.push(await saveProjection("10-chapter-diagnostic"));
  await clickText("完成问卷并生成路径");
  await waitFor("() => location.pathname.includes('/path/')", "chapter-path");
  await clickText("确认路径");
  await waitFor("() => document.body.innerText.includes('进入学习')", "chapter-confirm");
  await clickText("进入学习");
  await waitFor("() => location.pathname.includes('/learn/')", "chapter-learn");
  observations.push(await saveProjection("11-chapter-learning-card"));
  await writeFile(resolve(outputRoot, "observations.json"), `${JSON.stringify({ generatedAt: new Date().toISOString(), url, observations }, null, 2)}\n`, "utf8");
  process.stdout.write(JSON.stringify({ status: "PASS_SCOPED_TEMP_PORT", observationCount: observations.length }, null, 2));
} finally {
  socket.close();
  if (!browser.killed) browser.kill();
}
