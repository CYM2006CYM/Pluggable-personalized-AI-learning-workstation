import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDirectory = fileURLToPath(new URL(".", import.meta.url));
const packageRoot = resolve(scriptDirectory, "../..");
const repositoryRoot = resolve(packageRoot, "..");
const auditRoot = resolve(process.argv[2] ?? "");
const nodeRoot = resolve(auditRoot, "toolchains/node-v22.23.1-win-x64");
const pythonExecutable = resolve(auditRoot, "toolchains/python-3.13.7/python.exe");
const evidenceRoot = resolve(scriptDirectory, "evidence/r5/raw");

mkdirSync(evidenceRoot, { recursive: true });

const inheritedPath = Object.entries(process.env).find(([key]) => key.toLowerCase() === "path")?.[1] ?? "";
const environment = Object.fromEntries(Object.entries(process.env).filter(([key]) => key.toLowerCase() !== "path"));
environment.PATH = `${nodeRoot};${dirname(pythonExecutable)};${inheritedPath}`;
environment.PYTHONNOUSERSITE = "1";
environment.PI_PYTHON_EXECUTABLE = pythonExecutable;

const commands = [
  { id: "environment-contract", command: "node scripts/w4-e-validation/environment-probe.mjs", cwd: packageRoot },
  { id: "test-web", command: "npm.cmd run test:web -- --maxWorkers=1", cwd: packageRoot },
  {
    id: "real-api-and-six-point",
    command: "npm.cmd test -- --run tests/web/real-api.test.ts tests/web/v4-six-point.test.ts --maxWorkers=1",
    cwd: packageRoot,
  },
  {
    id: "python-evaluator",
    command: "npm.cmd test -- --run tests/python-process-evaluation.test.ts tests/python-process-evaluation-r2.test.ts --maxWorkers=1",
    cwd: packageRoot,
  },
  {
    id: "affected-regression",
    command: "npm.cmd test -- --run tests/path-runtime.test.ts tests/web/pages.test.tsx tests/web/state.test.ts --maxWorkers=1",
    cwd: packageRoot,
  },
  { id: "full-test", command: "npm.cmd test -- --run --maxWorkers=1", cwd: packageRoot },
  { id: "typecheck", command: "npm.cmd run typecheck", cwd: packageRoot },
  { id: "check-docs", command: "npm.cmd run check:docs", cwd: packageRoot },
  { id: "build-web", command: "npm.cmd run build:web", cwd: packageRoot },
  { id: "smoke-extension", command: "npm.cmd run smoke:extension", cwd: packageRoot },
  { id: "check-release", command: "npm.cmd run check:release", cwd: packageRoot },
  { id: "verify", command: "npm.cmd run verify", cwd: packageRoot },
  { id: "git-diff-check", command: "git diff --check", cwd: repositoryRoot },
];

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
}

function redact(value) {
  const replacements = [
    [packageRoot, "<package-root>"],
    [repositoryRoot, "<repository-root>"],
    [auditRoot, "<audit-root>"],
    [process.env.USERPROFILE ?? "", "<user-profile>"],
  ].filter(([source]) => source.length > 0);
  let output = value;
  for (const [source, replacement] of replacements) {
    const variants = new Set([source, source.replaceAll("\\", "/")]);
    for (const variant of variants) output = output.replace(new RegExp(escapeRegExp(variant), "giu"), replacement);
  }
  return output.replace(/\bsk-[A-Za-z0-9_-]{10,}\b/gu, "<redacted-key>");
}

function observedCounts(output) {
  const files = output.match(/Test Files\s+(?:(\d+) failed\s*\|\s*)?(\d+) passed/iu);
  const tests = output.match(/Tests\s+(?:(\d+) failed\s*\|\s*)?(\d+) passed(?:\s*\|\s*(\d+) skipped)?/iu);
  const markdown = output.match(/Validated (\d+) Markdown/iu);
  return {
    testFilesFailed: files?.[1] === undefined ? 0 : Number(files[1]),
    testFilesPassed: files?.[2] === undefined ? null : Number(files[2]),
    testsFailed: tests?.[1] === undefined ? 0 : Number(tests[1]),
    testsPassed: tests?.[2] === undefined ? null : Number(tests[2]),
    testsSkipped: tests?.[3] === undefined ? 0 : Number(tests[3]),
    markdownFilesValidated: markdown?.[1] === undefined ? null : Number(markdown[1]),
  };
}

function gitOutput(command) {
  const result = spawnSync("cmd.exe", ["/d", "/s", "/c", command], {
    cwd: repositoryRoot,
    encoding: "utf8",
    windowsHide: true,
  });
  if (result.status !== 0) throw new Error(result.stderr || `Command failed: ${command}`);
  return (result.stdout ?? "").trim();
}

const results = [];
for (const item of commands) {
  const startedAt = new Date();
  const run = spawnSync("cmd.exe", ["/d", "/s", "/c", item.command], {
    cwd: item.cwd,
    encoding: "utf8",
    windowsHide: true,
    env: environment,
    maxBuffer: 64 * 1024 * 1024,
  });
  const completedAt = new Date();
  const stdout = redact(run.stdout ?? "");
  const stderr = redact(`${run.stderr ?? ""}${run.error === undefined ? "" : `${run.error.stack ?? run.error.message}\n`}`);
  const stdoutPath = resolve(evidenceRoot, `${item.id}.stdout.txt`);
  const stderrPath = resolve(evidenceRoot, `${item.id}.stderr.txt`);
  writeFileSync(stdoutPath, stdout, "utf8");
  writeFileSync(stderrPath, stderr, "utf8");
  results.push({
    id: item.id,
    command: item.command,
    workingDirectory: item.cwd === packageRoot ? "pi-study-helper" : ".",
    startedAt: startedAt.toISOString(),
    completedAt: completedAt.toISOString(),
    durationMs: completedAt.getTime() - startedAt.getTime(),
    exitCode: run.status ?? 1,
    observedCounts: observedCounts(`${stdout}\n${stderr}`),
    stdoutSha256: sha256(stdout),
    stderrSha256: sha256(stderr),
    rawEvidence: [
      `evidence/r5/raw/${item.id}.stdout.txt`,
      `evidence/r5/raw/${item.id}.stderr.txt`,
    ],
  });
  process.stdout.write(`${item.id}: exit ${run.status ?? 1}\n`);
}

const output = {
  schemaVersion: "w4-d4-e-command-results-r5-v1",
  generatedAt: new Date().toISOString(),
  baselineCommit: gitOutput("git rev-parse HEAD"),
  originMain: gitOutput("git rev-parse origin/main"),
  commandCount: results.length,
  nonzeroExitCount: results.filter((item) => item.exitCode !== 0).length,
  commands: results,
};

writeFileSync(resolve(scriptDirectory, "command-results-r5.json"), `${JSON.stringify(output, null, 2)}\n`, "utf8");
process.stdout.write(`${JSON.stringify({ commandCount: output.commandCount, nonzeroExitCount: output.nonzeroExitCount })}\n`);
