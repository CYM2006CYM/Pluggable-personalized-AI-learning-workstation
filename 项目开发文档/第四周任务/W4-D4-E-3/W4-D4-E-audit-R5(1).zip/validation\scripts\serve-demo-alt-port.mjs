import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createDemoRuntime } from "../../.demo-build/demo/composition-root.js";
import { startHttpServer } from "../../.demo-build/demo/http-server.js";

const packageRoot = resolve(fileURLToPath(new URL("../..", import.meta.url)));
const port = Number(process.argv[2] ?? 4311);
const dataRoot = resolve(process.argv[3] ?? resolve(packageRoot, "scripts/w4-e-validation/evidence/r5/alt-data"));
const fixturesRoot = resolve(packageRoot, "fixtures/profiles");
const runtime = createDemoRuntime({ dataRoot, fixturesRoot, pythonExecutable: process.env.PI_PYTHON_EXECUTABLE });
const handle = startHttpServer(runtime, port);
await handle.ready;
process.stdout.write(`API_READY ${port}\n`);
const close = () => { void handle.close().finally(() => process.exit(0)); };
process.once("SIGINT", close);
process.once("SIGTERM", close);
await new Promise(() => undefined);
