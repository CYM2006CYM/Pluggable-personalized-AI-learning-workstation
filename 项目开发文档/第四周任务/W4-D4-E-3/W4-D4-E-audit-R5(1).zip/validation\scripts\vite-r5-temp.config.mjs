import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import { fileURLToPath } from "node:url";

const packageRoot = fileURLToPath(new URL("../..", import.meta.url));
const webRoot = fileURLToPath(new URL("../../src/web", import.meta.url));
const contractsRoot = fileURLToPath(new URL("../../src/contracts", import.meta.url));
const apiPort = Number(process.env.R5_API_PORT ?? 4311);
const vitePort = Number(process.env.R5_VITE_PORT ?? 5174);

export default defineConfig({
  root: webRoot,
  plugins: [react()],
  server: {
    host: "127.0.0.1",
    port: vitePort,
    strictPort: true,
    proxy: {
      "^/api/(?:bootstrap(?:\\?|$)|sessions(?:/|$)|activities(?:/|$))": {
        target: `http://127.0.0.1:${apiPort}`,
        changeOrigin: false,
      },
    },
    fs: {
      strict: true,
      allow: [webRoot, contractsRoot, packageRoot],
      deny: ["**/mocks/**", "**/fixtures/profiles/**", "**/fixtures/model-*/**", "**/private/**", "**/rubrics/**", "**/reference-solutions/**", "**/hidden/**"],
    },
  },
});
