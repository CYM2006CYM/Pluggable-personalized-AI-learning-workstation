# W4-D4 E R5 浏览器阻塞报告

状态：`BLOCKED_BY_SOURCE_LOGIC_FAILURE / NOT_COMMITTED / NOT_PUSHED`

## 失败分类

- 类型：源码逻辑失败（E Web 路由恢复）
- 非环境版本失败：Node 22.23.1、npm 10.9.8、Python 3.13.7、Pandas 3.0.5 已绑定。
- 非 API 合同失败：临时 API `4311` 的服务端 Bootstrap 返回 `stage=learning`、`path.status=active`。
- 非外部进程终止：正式 API `4310` 仍被 `QQ.exe` PID 8980 占用，未结束。

## 复现

1. 临时诊断环境使用 API `127.0.0.1:4311`、Vite `127.0.0.1:5174`，正式源码端口未修改。
2. 推荐模式 400 分钟完成诊断并生成路径。
3. 首次确认路径后刷新 `/path/:sessionId`。
4. Bootstrap 返回当前会话 `stage=learning`、`sessionVersion=4`、`path.status=active`、`pathVersion=1`。
5. 页面仍显示 `candidate` 和“确认路径”，未显示“进入学习”。再次确认未在 15 秒内进入学习，工作流退出码 1。

## 证据

- 页面投影：`evidence-r5/browser-workflow/04-recommended-path-refresh.json`
- 原始 stdout/stderr：`evidence-r5/browser-workflow/path-refresh-blocker.log`
- 日志 SHA-256：`a87ddcf8fc9870c1b982390efd0d7690bef722589ad17d11cfeea29d29b569ee`
- 起止时间：`2026-08-17T12:29:56.0922491+08:00` 至 `2026-08-17T12:30:14.6341764+08:00`

## 初步归因

`PathPage` 在刷新后仍优先使用历史 `location.state.candidate`，覆盖了服务端已经确认的 `session.path`。需要负责人修复或确认刷新恢复合同后，才能继续依赖该路径的学习卡片、题组、Attempt 和提交后推进浏览器步骤。

## 结论

定向 API/页面测试仍为 PASS，但本轮真实浏览器路径刷新复验失败；根据任务要求停止依赖它的后续浏览器测试，不把局部 PASS 写成整体 PASS，不提交、不推送、不申请上传锁。
