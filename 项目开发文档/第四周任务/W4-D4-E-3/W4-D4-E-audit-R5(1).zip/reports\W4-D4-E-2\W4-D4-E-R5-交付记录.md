# W4-D4-E R5 交付记录

## 交付状态

- 复验结论：`BLOCKED_BY_SOURCE_LOGIC_FAILURE`
- 基线提交：`d98a55d0da87d9faccf49d21e56bd8b12e6ba456`
- `main` 与 `origin/main` 一致。
- 本轮未执行 `git add`、`commit`、`push` 或上传锁申请。
- 不声明 W4 GO。

## 已完成验证

- 合同环境：Node `v22.23.1`、npm `10.9.8`、Python `3.13.7`、Pandas `3.0.5`、`PYTHONNOUSERSITE=1`。
- 精确定向跨岗位测试：4 个文件、40 个测试，全部通过。
- Web 测试：11 个文件、71 个测试通过。
- 真实 API 与六点测试：2 个文件、10 个测试通过。
- Python evaluator：2 个文件、26 个测试通过。
- 全量测试：85 个文件、740 passed、1 skipped、0 failed。
- `verify`、`typecheck`、`build:web`、`check:docs`、`smoke:extension`、`check:release` 和 `git diff --check` 通过。

## 阻塞问题

路径确认后刷新时，服务端 Bootstrap 已返回 `stage=learning`、`path.status=active`，但前端 `PathPage` 仍优先使用历史 `location.state.candidate`，页面继续显示“确认路径”，未进入学习页。该问题属于源码逻辑失败，依赖此路径的教学卡片、题组、Attempt 和提交浏览器步骤按要求停止。

正式 API 端口 `127.0.0.1:4310` 由外部 `QQ.exe` PID `8980` 占用，未结束外部进程；临时诊断端口 `4311/5174` 已释放。

## 交付物

- 本目录下的 R5 报告、阻塞报告、交接说明、端口记录及 `evidence-r5/`。
- 仓库外 `D:/.A_C_code/PPALW/W4-D4/W4-D4-E-audit-R5.zip`。
- 对应的 `W4-D4-E-R5-Manifest.json`、`W4-D4-E-R5-files.sha256` 和 ZIP SHA-256 sidecar。
- ZIP 内共 68 个归档条目，对应 67 个文件；不含浏览器 profile、`node_modules`、`.demo-build`、ZIP 和 sidecar。

## 负责人后续动作

修复 `PathPage` 刷新恢复逻辑，使服务端已确认的 `session.path` 优先于历史候选状态；修复后重新执行被阻塞的浏览器流程，并重新生成 R5 证据包。当前证据不得改写为整体 PASS。
