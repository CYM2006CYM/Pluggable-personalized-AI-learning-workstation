# W4-D4 E R5 直接复验记录

状态：`READY_FOR_OWNER_REVIEW_WITH_LOCAL_EVIDENCE`

| 项目 | 结果 |
|---|---|
| 合同环境 | Node 22.23.1 / npm 10.9.8 / Python 3.13.7 / Pandas 3.0.5 |
| Python evaluator | 2 files / 26 tests PASS |
| A/E 受影响回归 | 3 files / 35 tests PASS |
| Web | 11 files / 71 tests PASS |
| 两种入口真实 API + 六点运行时 | 2 files / 10 tests PASS |
| `npm.cmd run verify` | 85 files / 740 passed / 1 skipped / 0 failed |
| `npm.cmd run build:web` | PASS |
| docs / extension / release / diff | PASS |
| 固定 Demo 4310/5173 | 历史 R5 记录为正常轨迹 PASS；本轮复验因 4310 被外部 QQ 占用，未运行正常真实 API 浏览器态 |

历史 R5 记录已证明：诊断草稿刷新恢复、400 分钟路径生成、首次 insufficient 后新 Attempt 重试、第二次结果后推进、教学卡片显示、卡片与活动联合打开、4 题 fixed 组及同 Attempt 刷新恢复。本轮新增的浏览器证据只覆盖固定端口阻塞下的安全错误恢复态，详见 R5 本地证据补充。

R4 历史证据不覆盖。本轮证据未 add、未 commit、未 push、未申请 uploadLock。

## 本轮负责人指令复验阻塞（2026-08-17）

- 精确定向跨岗位命令：4 files / 40 tests PASS。
- 临时端口 `4311/5174` 的浏览器流程在“路径确认后刷新”处发现源码逻辑失败：后端已为 `stage=learning/path=active`，页面仍使用历史 candidate 状态显示“确认路径”。
- 浏览器工作流退出码 1，后续依赖路径的卡片、题组、Attempt 和提交推进步骤按规则停止。
- 阻塞报告：`W4-D4-E-R5-browser-blocker.md`；原始日志和哈希位于 `evidence-r5/browser-workflow/`。
- 当前结论：`BLOCKED_BY_SOURCE_LOGIC_FAILURE`，不声明整体 PASS、不申请上传锁。


## R5 本地证据补充（2026-08-17T03:19:05.814Z）

- 被测提交：`d98a55d0da87d9faccf49d21e56bd8b12e6ba456`；`origin/main`：`d98a55d0da87d9faccf49d21e56bd8b12e6ba456`。
- 13 项命令全部退出码 0；Web 11/71，真实 API+六点 2/10，Python evaluator 2/26，受影响回归 3/35，全量 85/740（1 skipped），`verify` 同值。
- 证据索引：`pi-study-helper/scripts/w4-e-validation/evidence-index-r5.json`；命令哈希：`command-results-r5.json`；泄漏扫描：`security-scan-r5.json`（PASS）。
- 浏览器：桌面/移动错误恢复态均 rootChildren=1、无横向溢出、未命名控件 0；4310 被外部 QQ 进程占用，正常真实 API 浏览器轨迹未宣称通过。
- 当前源码提交已在远端；本批证据仅写入本地工作树，未 add、未 commit、未 push、未申请 uploadLock。
