# W4 B D1 revision 3 remediation candidate handoff

## Candidate identity

- Contract/schedule: `W4-C2 / W4-R1`
- B start HEAD / `origin/main`: `00037c1aa995a0ec2aec70b097fc680e193ed08a`
- A formal upstream: `4c52eb7c78fa80007aa9a8ab4e00768d71d3f3f5`
- Candidate directory: `pi-study-helper/fixtures/profiles/pandas-cleaning-revision-3-draft/`
- Candidate seal tree SHA-256: `2b9434577a3f682abb95b5b1e58696149ecda26a619d0c8f0ea6146c816468d4`
- State: `NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`

## Remediation audit inputs

- Owner-only complete audit directory: `C:\Users\Lenovo\Documents\Codex\2026-08-12\la\outputs\W4-D1-B-remediation-owner-audit-v1\`.
  It contains all 79 candidate file bodies, including server-only private answers and frozen private inputs, plus the revision 2 baseline, B validation script, A Schema/seal verification build, full-file SHA-256 manifest and audit instructions.
- Ordinary transport ZIP is a public-safe subset only. It never carries private answer bodies, hidden tests, Rubrics, reference solutions or private CSV content. It carries the public candidate, all cryptographic inventories and an audit-access record that binds it to the owner-only directory.
- `candidate-full-file-sha256.json`, `candidate-private-manifest.json` and `quality/revision-seal.json` bind the public transport material to the complete owner audit input. The owner audit directory is the source for private-answer review; the ordinary ZIP is not.

## B delivery

- Revision 3 retains Schema 2 and sets `revision=3`, `revisionOf=2`, and `status=draft`.
- Six target knowledge points have `all_in_order`, positive content estimates, exactly one safe fixed card, one group-MCQ activity, a four-question fixed group, and one supplemental question.
- `basic-python` remains an auxiliary prerequisite. Cards are not activities; no card ID appears in `activityIds`. `goal.requiredActivityIds` contains only `act-practical`.
- Public question groups expose only question surfaces. Private answers, explanations and source mappings are in the server-only private answer-key asset. Supplemental questions only complete eligible dynamic candidates; they are not a complete retry group.
- Revision 2 immutability, source coverage, public/private isolation and file inventory reports are in revision 3 `quality/`.

## Downstream consumption

- A: recompute and validate `quality/revision-seal.json` before any draft activation. Do not alter B assets while validating.
- C: use only the candidate directory and repository-returned seal/tree identity during later activation; do not copy or recalculate Profile content.
- D: use fixed cards, question groups and source-safe summaries only; never ingest `assessments/private/quiz-answer-key.json` into Agent context.
- E: consume cards and opened quiz safe DTOs only. Correct answers, explanations and private source mappings are available only after formal submit through A/C safe projections.

## Known limits

The candidate does not claim activation, HTTP/API, Web, Agent, live-model, or W4 GO success.

- First environment fact retained: the original candidate ran under system Python `3.14.4` and produced `670 passed / 20 failed / 1 skipped`; that is recorded as `ENVIRONMENT_MISMATCH`, not rewritten as a pass.
- Remediation environment: external Node `v22.23.1` and the independently created `C:\Users\Lenovo\AppData\Local\Temp\w4-d1-b-python313\Scripts\python.exe`, Python `3.13.7`, Pandas `3.0.5`.
- In that locked environment, B public Python tests, B validation, A Schema/seal entrypoints, affected Python evaluator tests, full tests and `verify` are recorded in the remediation command results. The full `verify` run exits `0` with `70` test files passed, `690` tests passed and `1` skipped.
- No upload lock has been requested. D/C/E must not consume this candidate as a formal upstream until the owner independently reviews the complete audit directory and explicitly grants an upload lock.
