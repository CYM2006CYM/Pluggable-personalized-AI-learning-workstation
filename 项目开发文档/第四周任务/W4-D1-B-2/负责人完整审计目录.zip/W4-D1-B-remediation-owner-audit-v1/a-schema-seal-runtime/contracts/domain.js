// Browser-safe deterministic domain contracts. Runtime modules depend on this leaf.
export {};
