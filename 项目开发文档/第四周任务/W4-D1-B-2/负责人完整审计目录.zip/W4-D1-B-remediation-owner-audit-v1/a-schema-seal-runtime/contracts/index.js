export * from "./facade.js";
export * from "./domain.js";
export function createDeterministicContentPort() {
    return {
        async prepareCard() { return { status: "unavailable" }; },
        async prepareQuiz() { return { status: "unavailable" }; },
    };
}
export function createEmptyCapabilityTaskPort() {
    return { async enqueue() { return { taskStatus: "not_updated" }; } };
}
