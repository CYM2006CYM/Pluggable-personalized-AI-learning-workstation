import type { KnowledgeState } from "../domain/v2-types.js";
import { type PathEngineProfile } from "../domain/path-engine.js";
import type { InternalPathSessionPort, InternalPersistedPathSnapshot } from "../repositories/internal-path-session-port.js";
import type { SessionSnapshot } from "../repositories/learning-session-repository.js";
export interface ActivityPathSuffixReplanner {
    replan(input: {
        snapshot: SessionSnapshot;
        knowledgeStates: KnowledgeState[];
        evidenceVersion: number;
        trigger: "knowledge_state_changed" | "skip_eligibility_changed" | "error_remediation";
    }): Promise<{
        path?: InternalPersistedPathSnapshot;
        changeReasons: string[];
    }>;
}
export interface ActivityPathSuffixReplannerOptions {
    sessions: InternalPathSessionPort;
    profile: {
        load(subjectId: string, profileRevision: number): Promise<PathEngineProfile>;
    };
    now?: () => Date;
}
/** Reuses PathEngine's frozen suffix algorithm inside an activity commit. */
export declare function createActivityPathSuffixReplanner(options: ActivityPathSuffixReplannerOptions): ActivityPathSuffixReplanner;
