import { type DiagnosticAnswerKeyAsset, type DiagnosticBlueprintAsset } from "../domain/diagnostic.js";
import type { KnowledgePointDefinition } from "../domain/v2-types.js";
import { type DiagnosticDraftSessionPort, type LearningSessionRepository, type SessionBindingReader } from "../repositories/learning-session-repository.js";
import type { CompleteDiagnosticInput, DiagnosticAnswerOutput, DiagnosticCompleteOutput, DiagnosticDraftOutput, LearningRuntimeFacade, SaveDiagnosticDraftInput, SubmitDiagnosticAnswerInput } from "./learning-runtime-facade.js";
import type { RuntimeCommitContext } from "./runtime-commit-context.js";
export interface DiagnosticRuntimeAssets {
    blueprint: DiagnosticBlueprintAsset;
    answerKey: DiagnosticAnswerKeyAsset;
    knowledgePoints?: readonly Pick<KnowledgePointDefinition, "id" | "requiresCodeEvidence">[];
}
export type DiagnosticAssetsLoader = (subjectId: string, profileRevision: number) => Promise<DiagnosticRuntimeAssets>;
export type DiagnosticSubmissionInput = SubmitDiagnosticAnswerInput;
export interface DiagnosticRuntimeOptions {
    repository: LearningSessionRepository & DiagnosticDraftSessionPort & SessionBindingReader;
    loadAssets: DiagnosticAssetsLoader;
    dataRoot?: string;
    now?: () => Date;
}
export declare class DiagnosticRuntime implements Pick<LearningRuntimeFacade, "saveDiagnosticDraft" | "submitDiagnosticAnswer" | "completeDiagnostic"> {
    private readonly repository;
    private readonly loadAssets;
    private readonly familiesRoot;
    private readonly now;
    constructor(options: DiagnosticRuntimeOptions);
    private sessionDirectory;
    private snapshot;
    saveDiagnosticDraft(input: SaveDiagnosticDraftInput): Promise<DiagnosticDraftOutput>;
    submitDiagnosticAnswer(input: DiagnosticSubmissionInput): Promise<DiagnosticAnswerOutput>;
    completeDiagnostic(input: CompleteDiagnosticInput): Promise<DiagnosticCompleteOutput>;
    completeDiagnosticWithContext(input: CompleteDiagnosticInput): Promise<RuntimeCommitContext<DiagnosticCompleteOutput>>;
}
export declare function createProfileDirectoryDiagnosticLoader(profileDirectoryFor: (subjectId: string, profileRevision: number) => string): DiagnosticAssetsLoader;
