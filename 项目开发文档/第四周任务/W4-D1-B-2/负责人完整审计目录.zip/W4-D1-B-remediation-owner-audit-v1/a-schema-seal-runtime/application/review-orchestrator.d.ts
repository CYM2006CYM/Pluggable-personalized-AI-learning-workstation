import type { ActivitySafeView } from "./learning-runtime-facade.js";
import type { ModelExecutionPort, ModelExecutionStatus } from "../infrastructure/model-execution-port.js";
import { type DefenderOutput, type GeneratorOutput, type HunterOutput, type JudgeOutput, type ReviewGraphId, type ReviewSafeContext } from "../graphs/v2-learning-graphs.js";
export interface ReviewOrchestratorInput {
    requestId: string;
    attemptId: string;
    runId: string;
    profileRevision: number;
    modelId: string;
    promptVersion: string;
    activity: Pick<ActivitySafeView, "activityId" | "activityVersion" | "kind" | "title" | "primaryKnowledgePointId" | "supportingKnowledgePointIds">;
    currentResult: {
        safeFeedback: string;
    };
}
export interface ReviewSafeSourceProjection {
    sourceIds: string[];
    sourceSummary: string;
}
export interface ReviewSafeSourceProvider {
    getProjection(input: {
        profileRevision: number;
        activityId: string;
    }): Promise<ReviewSafeSourceProjection>;
}
export interface ReviewOrchestratorOptions {
    modelExecutionPort: ModelExecutionPort;
    sourceProvider: ReviewSafeSourceProvider;
    checkpointStore?: ReviewCheckpointStore;
    maxAttemptsPerRole?: number;
    timeoutMs?: number;
    maxTokens?: number;
    now?: () => Date;
}
export interface ReviewStageCheckpoint<Output = unknown> {
    graphId: ReviewGraphId;
    attempts: number;
    status: "ok";
    runId: string;
    modelRunId: string;
    profileRevision: number;
    inputSummaryHash: string;
    modelId: string;
    promptVersion: string;
    sourceRefs: string[];
    traceSummary: string;
    durationMs?: number;
    completedAt: string;
    output: Output;
}
export interface ReviewAttemptRecord {
    graphId: ReviewGraphId;
    attempt: number;
    modelRunId: string;
    status: ModelExecutionStatus | "cancelled";
    errorCode?: string;
    modelId: string;
    promptVersion: string;
    durationMs?: number;
    traceSummary: string;
    completedAt: string;
}
export interface ReviewRunCheckpoint {
    runId: string;
    requestId: string;
    attemptId: string;
    profileRevision: number;
    inputSummaryHash: string;
    inputBindingHash: string;
    modelId: string;
    promptVersion: string;
    redactions: string[];
    createdAt: string;
    stageAttempts: Partial<Record<ReviewGraphId, ReviewAttemptRecord[]>>;
    generator?: ReviewStageCheckpoint<GeneratorOutput>;
    hunter?: ReviewStageCheckpoint<HunterOutput>;
    defender?: ReviewStageCheckpoint<DefenderOutput>;
    judge?: ReviewStageCheckpoint<JudgeOutput>;
    finalStatus?: ReviewOrchestratorResult["status"];
    finalSafeFeedback?: string;
    finalSummary?: string;
    finalBlockedIssueIds?: string[];
    finalErrorCode?: string;
    finalFailedGraphId?: ReviewGraphId;
    finalCause?: "judge" | "technical_fallback" | "technical_failed";
    usedFallback?: boolean;
    finalizedAt?: string;
}
export interface ReviewCheckpointStore {
    load(runId: string): Promise<ReviewRunCheckpoint | undefined>;
    save(checkpoint: ReviewRunCheckpoint): Promise<void>;
}
export interface ReviewOrchestratorResult {
    status: "accepted" | "fallback" | "failed";
    finalSafeFeedback: string;
    summary: string;
    blockedIssueIds: string[];
    usedFallback: boolean;
    errorCode?: string;
}
interface SafeContextBuildResult {
    context: ReviewSafeContext;
    safeContextSummary: string;
    redactions: string[];
    inputBindingHash: string;
    inputSummaryHash: string;
}
export declare function buildSafeReviewContext(input: ReviewOrchestratorInput, projection: ReviewSafeSourceProjection): SafeContextBuildResult;
export declare class InMemoryReviewCheckpointStore implements ReviewCheckpointStore {
    #private;
    load(runId: string): Promise<ReviewRunCheckpoint | undefined>;
    save(checkpoint: ReviewRunCheckpoint): Promise<void>;
}
export declare class ReviewOrchestrator {
    #private;
    constructor(options: ReviewOrchestratorOptions);
    run(input: ReviewOrchestratorInput, signal: AbortSignal): Promise<ReviewOrchestratorResult>;
}
export {};
