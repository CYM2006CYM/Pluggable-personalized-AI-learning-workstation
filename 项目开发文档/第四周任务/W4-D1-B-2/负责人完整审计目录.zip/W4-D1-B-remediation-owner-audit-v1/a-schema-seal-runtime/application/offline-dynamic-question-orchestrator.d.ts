import type { ModelExecutionPort } from "../infrastructure/model-execution-port.js";
export type DynamicQuestion = {
    artifactId: string;
    kind: "single_choice";
    prompt: string;
    options: string[];
    sourceAnchorIds: string[];
    rationale: string;
} | {
    artifactId: string;
    kind: "judgment";
    prompt: string;
    sourceAnchorIds: string[];
    rationale: string;
};
export type OfflineDynamicQuestionReason = "recorded_response_accepted" | "permission_denied" | "invalid_output" | "timeout" | "provider_error";
export interface OfflineDynamicQuestionInput {
    runId: string;
    profileRevision: number;
    promptVersion: string;
    safeContext: Readonly<Record<string, unknown>>;
}
export interface OfflineDynamicQuestionResult {
    status: "accepted" | "fallback";
    reasonCode: OfflineDynamicQuestionReason;
    question: DynamicQuestion;
    usedFallback: boolean;
}
export declare function containsAgentAuthorityViolation(value: unknown, depth?: number): boolean;
export declare function isDynamicQuestion(value: unknown): value is DynamicQuestion;
export declare function fixedDynamicQuestionFallback(): DynamicQuestion;
export declare class OfflineDynamicQuestionOrchestrator {
    #private;
    constructor(modelExecutionPort: ModelExecutionPort);
    run(input: OfflineDynamicQuestionInput, signal: AbortSignal): Promise<OfflineDynamicQuestionResult>;
}
