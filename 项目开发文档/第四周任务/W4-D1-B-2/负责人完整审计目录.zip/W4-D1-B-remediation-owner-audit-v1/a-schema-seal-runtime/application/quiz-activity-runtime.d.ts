import type { ActivityAttemptSafeView, ActivitySubmissionOutput, OpenActivityInput, QuizActivityDraftOutput } from "../contracts/facade.js";
import type { AdaptiveContentPort, QuizQuestionPrivate, QuizSubmitActivityInput } from "../contracts/index.js";
import { type QuizActivityDefinition } from "../domain/quiz-runtime.js";
import type { KnowledgePointDefinition } from "../domain/v2-types.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";
import { type LearningSessionRepository, type QuizAttemptSessionPort, type SessionBindingReader } from "../repositories/learning-session-repository.js";
import type { ActivityPathSuffixReplanner } from "./activity-path-suffix.js";
import type { RuntimeCommitContext } from "./runtime-commit-context.js";
export interface QuizActivityAssets {
    activity: QuizActivityDefinition;
    knowledgePoint: Pick<KnowledgePointDefinition, "id" | "requiresCodeEvidence" | "sourceAnchorIds">;
    knowledgePoints?: Array<Pick<KnowledgePointDefinition, "id" | "requiresCodeEvidence">>;
    fixedQuestions: QuizQuestionPrivate[];
    supplementalQuestions: QuizQuestionPrivate[];
}
export interface QuizActivityRuntimeOptions {
    sessions: LearningSessionRepository & QuizAttemptSessionPort & SessionBindingReader;
    content: AdaptiveContentPort;
    loadAssets(subjectId: string, profileRevision: number, activityId: string): Promise<QuizActivityAssets>;
    pathSuffix: ActivityPathSuffixReplanner;
    now?: () => Date;
}
export declare class QuizActivityRuntime {
    private readonly options;
    private readonly now;
    constructor(options: QuizActivityRuntimeOptions);
    openActivity(input: OpenActivityInput): Promise<QuizActivityDraftOutput>;
    submitActivity(input: QuizSubmitActivityInput): Promise<ActivitySubmissionOutput>;
    submitActivityWithContext(input: QuizSubmitActivityInput): Promise<RuntimeCommitContext<ActivitySubmissionOutput>>;
    getAttempt(input: {
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        activityId: string;
        attemptId: string;
    }): Promise<ActivityAttemptSafeView>;
    private openOutput;
    private safeActivity;
}
/** Reads B's sealed question groups by the immutable session revision. */
export declare class ProfileFamilyQuizActivityAssetResolver {
    private readonly profiles;
    constructor(profiles: ProfileFamilyRepository);
    loadAssets(subjectId: string, profileRevision: number, activityId: string): Promise<QuizActivityAssets>;
}
