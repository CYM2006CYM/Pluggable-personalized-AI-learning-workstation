/**
 * D3 session entry point. Profile revision is deliberately resolved by the
 * server-side repository rather than accepted from a browser or TUI request.
 */
export class ProfileBoundSessionRuntime {
    dependencies;
    constructor(dependencies) {
        this.dependencies = dependencies;
    }
    async startSession(input) {
        const active = await this.dependencies.profiles.loadActiveProfileV2(input.subjectId);
        const view = await this.dependencies.sessions.create({
            requestId: input.requestId,
            subjectId: input.subjectId,
            mode: input.mode,
            goalId: input.goalId,
            ...(input.chapterId === undefined ? {} : { chapterId: input.chapterId }),
            availableMinutes: input.availableMinutes,
            profileRevision: active.revision,
            diagnosticRequired: active.capabilities.diagnostic,
        });
        return { ...view, requestId: input.requestId };
    }
    async resolveSessionProfile(input) {
        const snapshot = await this.dependencies.sessions.getBoundSnapshot(input.sessionId);
        if (input.sessionVersion !== undefined && input.sessionVersion !== snapshot.sessionVersion) {
            throw new Error("session_version_conflict");
        }
        return this.dependencies.profiles.loadProfileV2Revision(snapshot.view.subjectId, snapshot.profileRevision);
    }
}
