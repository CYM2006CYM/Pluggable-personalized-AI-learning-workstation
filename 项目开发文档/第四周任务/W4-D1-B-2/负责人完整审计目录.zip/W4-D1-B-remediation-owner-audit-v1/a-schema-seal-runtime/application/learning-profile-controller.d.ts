import type { StudyControllerUi } from "./study-session-controller.js";
import type { LearningProfile } from "../domain/types.js";
import type { IsolatedGraphExecutor } from "../graphs/isolated-graph-executor.js";
import { type StudyWalkingSkeletonGraphs } from "../graphs/study-walking-skeleton.js";
import type { PrivateMemoryRepository } from "../repositories/private-memory-repository.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";
export interface LearningProfileControllerDependencies {
    profiles: ProfileFamilyRepository;
    memory: PrivateMemoryRepository;
    graphs: StudyWalkingSkeletonGraphs;
    executeGraph: IsolatedGraphExecutor;
    ui: StudyControllerUi;
    now?: () => Date;
}
export type LearningProfileUpdateResult = {
    status: "none" | "cancelled";
} | {
    status: "completed";
    subjectId: string;
    batchIds: string[];
    profile: LearningProfile;
} | {
    status: "failed";
    error: string;
};
export declare function renderLearningProfilePreview(profile: LearningProfile): string;
export declare class LearningProfileController {
    private readonly profiles;
    private readonly memory;
    private readonly graphs;
    private readonly executeGraph;
    private readonly ui;
    private readonly now;
    constructor(dependencies: LearningProfileControllerDependencies);
    run(args: string): Promise<LearningProfileUpdateResult>;
}
