import type { StartSessionInput, StartSessionOutput } from "./learning-runtime-facade.js";
import type { ProfileManifestV2 } from "../domain/v2-types.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";
import type { LearningSessionRepository, SessionBindingReader } from "../repositories/learning-session-repository.js";
export interface ProfileBoundSessionRuntimeDependencies {
    profiles: ProfileFamilyRepository;
    sessions: LearningSessionRepository & SessionBindingReader;
}
/**
 * D3 session entry point. Profile revision is deliberately resolved by the
 * server-side repository rather than accepted from a browser or TUI request.
 */
export declare class ProfileBoundSessionRuntime {
    private readonly dependencies;
    constructor(dependencies: ProfileBoundSessionRuntimeDependencies);
    startSession(input: StartSessionInput): Promise<StartSessionOutput>;
    resolveSessionProfile(input: {
        sessionId: string;
        sessionVersion?: number;
    }): Promise<ProfileManifestV2>;
}
