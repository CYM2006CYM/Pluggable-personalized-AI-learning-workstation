import type { Attempt, StudySession } from "../domain/types.js";
import type { IsolatedGraphExecutor } from "../graphs/isolated-graph-executor.js";
import { type StudyWalkingSkeletonGraphs } from "../graphs/study-walking-skeleton.js";
import type { PrivateMemoryRepository } from "../repositories/private-memory-repository.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";
import { type StudyUiPort } from "../tui/study-tui-gateway.js";
export interface StudyControllerUi extends StudyUiPort {
    notify(message: string, level?: "info" | "warning" | "error"): void;
    setStatus(key: string, text: string | undefined): void;
}
export interface StudySessionControllerDependencies {
    profiles: ProfileFamilyRepository;
    memory: PrivateMemoryRepository;
    graphs: StudyWalkingSkeletonGraphs;
    executeGraph: IsolatedGraphExecutor;
    ui: StudyControllerUi;
    now?: () => Date;
    createId?: () => string;
}
export type StudyRunResult = {
    status: "cancelled";
} | {
    status: "completed";
    subjectId: string;
    batchId: string;
    session: StudySession;
} | {
    status: "interrupted";
    subjectId: string;
    batchId: string;
    session: StudySession;
    error: string;
} | {
    status: "failed";
    error: string;
};
export type StudyRecoveryResult = {
    status: "none" | "cancelled";
} | {
    status: "completed" | "interrupted";
    subjectId: string;
    batchId: string;
} | {
    status: "failed";
    subjectId?: string;
    batchId?: string;
    error: string;
};
export declare function isRecoverableStudyBatch(batch: {
    session: Pick<StudySession, "status">;
    attempts: readonly Attempt[];
    summaryMarkdown?: string;
}): boolean;
export declare class StudySessionController {
    private readonly profiles;
    private readonly memory;
    private readonly graphs;
    private readonly executeGraph;
    private readonly ui;
    private readonly now;
    private readonly createId;
    constructor(dependencies: StudySessionControllerDependencies);
    private nowIso;
    private recoveryCandidates;
    countRunningSessions(): Promise<number>;
    countRecoverableSessions(): Promise<number>;
    recoverRunningSession(): Promise<StudyRecoveryResult>;
    run(args: string): Promise<StudyRunResult>;
}
