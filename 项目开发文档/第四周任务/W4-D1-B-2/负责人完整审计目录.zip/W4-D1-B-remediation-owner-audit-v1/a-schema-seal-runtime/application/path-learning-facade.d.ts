import type { LearningRuntimeFacade } from "./learning-runtime-facade.js";
import { type PathEngineProfile } from "../domain/path-engine.js";
import { type LearningSessionRepository, type SessionBindingReader } from "../repositories/learning-session-repository.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";
import type { LearningCardSafeView } from "../contracts/index.js";
import type { AdaptiveContentPort } from "../contracts/index.js";
import { type InternalPathSessionPort } from "../repositories/internal-path-session-port.js";
export interface PathProfileResolver {
    load(subjectId: string, profileRevision: number): Promise<PathEngineProfile>;
    loadCard?(subjectId: string, profileRevision: number, knowledgePointId: string): Promise<LearningCardSafeView | undefined>;
}
/** Uses the revision bound to the session; it never silently follows current active. */
export declare class ProfileFamilyPathResolver implements PathProfileResolver {
    private readonly profiles;
    constructor(profiles: ProfileFamilyRepository);
    load(subjectId: string, profileRevision: number): Promise<PathEngineProfile>;
    loadCard(subjectId: string, profileRevision: number, knowledgePointId: string): Promise<LearningCardSafeView | undefined>;
}
export interface PathRuntimeOptions {
    sessions: LearningSessionRepository & InternalPathSessionPort & SessionBindingReader;
    profile: PathProfileResolver;
    now?: () => Date;
    content?: AdaptiveContentPort;
    cardPreparationTimeoutMs?: number;
}
type PathMethods = Pick<LearningRuntimeFacade, "buildPath" | "confirmPath" | "getNextStep" | "replanPath" | "recoverSession">;
/** The main LearningRuntimeFacade composes these methods; this helper creates no second public Facade contract. */
export declare function createPathRuntimeMethods(options: PathRuntimeOptions): PathMethods;
export {};
