import type { NodeActivityProgress, PathNodeSafeView } from "../contracts/index.js";
/** Projects display state from the authoritative activity progress without changing path structure. */
export declare function projectPathNodes<T extends PathNodeSafeView>(nodes: readonly T[], activityProgress: readonly NodeActivityProgress[]): T[];
