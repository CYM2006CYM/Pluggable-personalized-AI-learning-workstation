import type { ActivityAttemptSafeView, ActivityDraftOutput, ActivityRecoveryOutput, ActivitySubmissionOutput, CodeActivitySafeView, GetActivityAttemptInput, OpenActivityInput, PrepareActivityRunInput, PreparedActivityOutput, RecoverActivityInput, SaveActivityDraftInput, CodeSubmitActivityInput } from "../contracts/facade.js";
import type { KnowledgePointDefinition } from "../domain/v2-types.js";
import type { EvaluationActivityProjection, EvaluationEnvironmentProjection } from "../infrastructure/code-evaluation-port.js";
import type { ActivityAssignment, ActivityDraftRecoveryReader, ActivityRepository } from "../repositories/activity-repository.js";
import type { LearningSessionRepository, SessionBindingReader } from "../repositories/learning-session-repository.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";
import { ActivityRuntimeService } from "./activity-runtime-service.js";
import type { ActivityPathSuffixReplanner } from "./activity-path-suffix.js";
import type { RuntimeCommitContext } from "./runtime-commit-context.js";
type CodeActivityKind = "code_completion" | "coding_practical" | "debug";
export interface CodeActivityAssets {
    activity: CodeActivitySafeView & {
        kind: CodeActivityKind;
        templateVersion: string;
        environmentRef: string;
    };
    knowledgePoint: Pick<KnowledgePointDefinition, "id" | "requiresCodeEvidence">;
    knowledgePoints?: Array<Pick<KnowledgePointDefinition, "id" | "requiresCodeEvidence">>;
    assignment: Omit<ActivityAssignment, "assignmentId">;
    evaluationActivity: EvaluationActivityProjection;
    taskVersion: string;
    environment: EvaluationEnvironmentProjection;
    assetBundleHash: string;
    publicDatasetFiles: PreparedActivityOutput["publicDatasetFiles"];
    publicTestSources: string[];
}
export interface CodeActivityAssetResolver {
    load(subjectId: string, profileRevision: number, activityId: string): Promise<CodeActivityAssets>;
}
interface CodeActivityFacadeAdapterOptions {
    sessions: LearningSessionRepository & SessionBindingReader;
    activities: ActivityRepository & ActivityDraftRecoveryReader;
    runtime: ActivityRuntimeService;
    assets: CodeActivityAssetResolver;
    pathSuffix: ActivityPathSuffixReplanner;
    now?: () => Date;
}
/** Bridges the W3 code evaluator/repository into A's six public Activity methods. */
export declare class CodeActivityFacadeAdapter {
    private readonly options;
    private readonly now;
    constructor(options: CodeActivityFacadeAdapterOptions);
    openActivity(input: OpenActivityInput): Promise<ActivityDraftOutput>;
    saveActivityDraft(input: SaveActivityDraftInput): Promise<ActivityDraftOutput>;
    prepareActivityRun(input: PrepareActivityRunInput): Promise<PreparedActivityOutput>;
    submitActivity(input: CodeSubmitActivityInput): Promise<ActivitySubmissionOutput>;
    submitActivityWithContext(input: CodeSubmitActivityInput): Promise<RuntimeCommitContext<ActivitySubmissionOutput>>;
    getActivityAttempt(input: GetActivityAttemptInput): Promise<ActivityAttemptSafeView>;
    recoverActivity(input: RecoverActivityInput): Promise<ActivityRecoveryOutput>;
    private draftOutput;
}
/** Strict revision-bound resolver. It reads private bindings but emits only public assets. */
export declare class ProfileFamilyCodeActivityAssetResolver implements CodeActivityAssetResolver {
    private readonly profiles;
    constructor(profiles: ProfileFamilyRepository);
    load(subjectId: string, profileRevision: number, activityId: string): Promise<CodeActivityAssets>;
}
export {};
