import type { CodeEvaluationPort, EvaluationActivityProjection, EvaluationEnvironmentProjection, PreparedEvaluation } from "../infrastructure/code-evaluation-port.js";
import type { ActivityRepository, FormalActivityCommitInput, PrepareActivityRunInput, PreparedActivityRun, RecordActivityResultInput, DerivedFormalActivityCommitInput } from "../repositories/activity-repository.js";
import type { LearningSessionRepository } from "../repositories/learning-session-repository.js";
import type { ActivitySubmissionOutput } from "./learning-runtime-facade.js";
import type { RuntimeCommitContext } from "./runtime-commit-context.js";
export interface ActivityRunPreparationInput extends PrepareActivityRunInput {
    activity: EvaluationActivityProjection;
    taskVersion: string;
    environment: EvaluationEnvironmentProjection;
    assetBundleHash: string;
}
export interface PreparedFormalActivityRun extends PreparedActivityRun {
    prepared: PreparedEvaluation;
}
export interface ActivitySubmissionInput extends RecordActivityResultInput {
    prepared: PreparedEvaluation;
}
export interface FormalActivitySubmissionInput extends Omit<ActivitySubmissionInput, "result"> {
    sessionRepository: LearningSessionRepository;
    knowledgeStates: FormalActivityCommitInput["knowledgeStates"];
    pathCandidate?: FormalActivityCommitInput["pathCandidate"];
    nextStage?: FormalActivityCommitInput["nextStage"];
}
/** Application boundary between C's public evaluator port and A's repository. */
export declare class ActivityRuntimeService {
    private readonly repository;
    private readonly evaluator;
    constructor(repository: ActivityRepository, evaluator: CodeEvaluationPort);
    prepareActivityRun(input: ActivityRunPreparationInput): Promise<PreparedFormalActivityRun>;
    submitActivity(input: ActivitySubmissionInput, signal: AbortSignal): Promise<Awaited<ReturnType<ActivityRepository["recordResult"]>>>;
    /** Runs C's public result through A's formal session transaction and returns only the facade DTO. */
    submitFormalActivity(input: FormalActivitySubmissionInput, signal: AbortSignal): Promise<ActivitySubmissionOutput>;
    /** Same formal transaction, with all session facts derived after C returns its result. */
    submitDerivedFormalActivity(input: Omit<ActivitySubmissionInput, "result"> & {
        sessionRepository: LearningSessionRepository;
        deriveCandidate: DerivedFormalActivityCommitInput["deriveCandidate"];
    }, signal: AbortSignal): Promise<ActivitySubmissionOutput>;
    submitDerivedFormalActivityWithContext(input: Omit<ActivitySubmissionInput, "result"> & {
        sessionRepository: LearningSessionRepository;
        deriveCandidate: DerivedFormalActivityCommitInput["deriveCandidate"];
    }, signal: AbortSignal): Promise<RuntimeCommitContext<ActivitySubmissionOutput>>;
    private runEvaluation;
    /** Converts preparation failures into non-graded failure records. */
    recordPreparationFailure(input: RecordActivityResultInput, error: unknown): Promise<Awaited<ReturnType<ActivityRepository["recordResult"]>>>;
}
