import type { StudyControllerUi } from "./study-session-controller.js";
import type { IsolatedGraphExecutor } from "../graphs/isolated-graph-executor.js";
import { type StudyWalkingSkeletonGraphs } from "../graphs/study-walking-skeleton.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";
export interface ProfileRevisionControllerDependencies {
    profiles: ProfileFamilyRepository;
    graphs: StudyWalkingSkeletonGraphs;
    executeGraph: IsolatedGraphExecutor;
    ui: StudyControllerUi;
}
export type ProfileRevisionResult = {
    status: "cancelled";
} | {
    status: "enabled" | "kept_draft" | "discarded";
    subjectId: string;
} | {
    status: "failed";
    subjectId?: string;
    error: string;
};
export declare class ProfileRevisionController {
    private readonly profiles;
    private readonly graphs;
    private readonly executeGraph;
    private readonly ui;
    constructor(dependencies: ProfileRevisionControllerDependencies);
    run(args: string): Promise<ProfileRevisionResult>;
}
