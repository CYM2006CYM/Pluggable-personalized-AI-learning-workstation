import type { LearningCardSafeView, QuizQuestionPrivate } from "../contracts/index.js";
export interface QuizContentSelectionInput {
    dynamic: readonly QuizQuestionPrivate[];
    supplemental: readonly QuizQuestionPrivate[];
    fixed: readonly QuizQuestionPrivate[];
    excludedQuestionIds: readonly string[];
    allowedSourceAnchorIds?: readonly string[];
}
export interface QuizContentSelection {
    source: "dynamic" | "supplemental" | "fixed" | "insufficient";
    questions: QuizQuestionPrivate[];
}
export declare function selectDeterministicCard(input: {
    dynamic?: LearningCardSafeView;
    fixed?: LearningCardSafeView;
    knowledgePointId: string;
    contentEstimatedMinutes: number;
    allowedSourceAnchorIds: readonly string[];
}): {
    source: "dynamic" | "fixed" | "unavailable";
    card?: LearningCardSafeView;
};
export declare function selectDeterministicQuizContent(input: QuizContentSelectionInput): QuizContentSelection;
