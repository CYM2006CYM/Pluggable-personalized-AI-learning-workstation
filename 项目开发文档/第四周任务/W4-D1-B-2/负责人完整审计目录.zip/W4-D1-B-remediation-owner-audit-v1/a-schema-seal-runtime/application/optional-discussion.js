function failureReason(result) {
    const reason = result.status === "completed" ? "" : result.failure.message;
    return reason.trim() !== ""
        ? reason
        : `图 ${result.graphId} 未正常完成（${result.status}）`;
}
/** 可选讨论最多重试一次；失败不能升级为整场学习中断。 */
export async function executeOptionalDiscussion(executeGraph, graph, input) {
    const reasons = [];
    for (let completionAttempt = 1; completionAttempt <= 2; completionAttempt += 1) {
        try {
            const result = await executeGraph(graph, { ...input, completionAttempt });
            if (result.status === "completed") {
                return { status: "ok", result: result.output };
            }
            reasons.push(failureReason(result));
        }
        catch (error) {
            reasons.push(error instanceof Error ? error.message : String(error));
        }
    }
    return { status: "unavailable", reasons };
}
