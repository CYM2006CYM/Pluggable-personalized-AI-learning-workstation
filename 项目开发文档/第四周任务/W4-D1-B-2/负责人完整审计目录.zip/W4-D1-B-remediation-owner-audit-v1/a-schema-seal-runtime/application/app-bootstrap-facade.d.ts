import type { AppBootstrapFacade, AppBootstrapSafeView } from "../contracts/index.js";
import type { LearningSessionCatalogPort, SessionBindingReader } from "../repositories/learning-session-repository.js";
import type { InternalPathSessionPort } from "../repositories/internal-path-session-port.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";
export interface FileAppBootstrapFacadeOptions {
    profiles: Pick<ProfileFamilyRepository, "listActiveProfileV2Manifests" | "readActiveProfileV2File">;
    sessions: LearningSessionCatalogPort & SessionBindingReader & InternalPathSessionPort;
}
/** Read-only bootstrap projection. Every nested DTO is built from a field allowlist. */
export declare class FileAppBootstrapFacade implements AppBootstrapFacade {
    private readonly options;
    constructor(options: FileAppBootstrapFacadeOptions);
    getBootstrap(input: {
        recoverSessionId?: string;
    }): Promise<AppBootstrapSafeView>;
}
