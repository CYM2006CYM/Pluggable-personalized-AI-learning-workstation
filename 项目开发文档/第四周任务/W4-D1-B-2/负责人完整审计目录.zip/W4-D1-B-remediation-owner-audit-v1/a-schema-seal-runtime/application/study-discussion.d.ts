import type { GradeResult, ReviewQuestion } from "../domain/types.js";
export interface DiscussionAgentInput extends Record<string, unknown> {
    question: Record<string, unknown>;
    grade: Record<string, unknown>;
    userAnswer: string;
    userMessage: string;
    revealAnswer: boolean;
}
/**
 * 订正前只投影安全题面；题目结束后才允许参考答案和解析进入讨论 Agent。
 */
export declare function buildDiscussionAgentInput(question: ReviewQuestion & {
    question_id: string;
}, grade: GradeResult | undefined, userAnswer: string, userMessage: string, revealAnswer: boolean): DiscussionAgentInput;
