import type { ActivityAttemptSafeView, ActivityDraftOutput, ActivityRecoveryOutput, ActivitySubmissionOutput, CompleteSessionInput, CompleteSessionOutput, ContextAnswerOutput, ContextQuestionInput, GetActivityAttemptInput, LearningRuntimeFacade, OpenActivityInput, PrepareActivityRunInput, PreparedActivityOutput, RecoverActivityInput, SaveActivityDraftInput, SubmitActivityInput } from "../contracts/facade.js";
import type { CapabilityTaskPort } from "../contracts/index.js";
import { type LearningSessionRepository } from "../repositories/learning-session-repository.js";
import type { PathEngineProfile } from "../domain/path-engine.js";
import type { RuntimeCommitContext } from "./runtime-commit-context.js";
type SessionMethods = Pick<LearningRuntimeFacade, "startSession">;
type DiagnosticMethods = Pick<LearningRuntimeFacade, "saveDiagnosticDraft" | "submitDiagnosticAnswer" | "completeDiagnostic"> & {
    completeDiagnosticWithContext?(input: Parameters<LearningRuntimeFacade["completeDiagnostic"]>[0]): Promise<RuntimeCommitContext<Awaited<ReturnType<LearningRuntimeFacade["completeDiagnostic"]>>>>;
};
type PathMethods = Pick<LearningRuntimeFacade, "recoverSession" | "buildPath" | "confirmPath" | "getNextStep" | "replanPath">;
type ActivityMethods = Pick<LearningRuntimeFacade, "openActivity" | "saveActivityDraft" | "prepareActivityRun" | "submitActivity" | "getActivityAttempt" | "recoverActivity"> & {
    submitActivityWithContext?(input: SubmitActivityInput): Promise<RuntimeCommitContext<ActivitySubmissionOutput>>;
};
export interface ComposedLearningRuntimeFacadeOptions {
    session: SessionMethods;
    diagnostic: DiagnosticMethods;
    path: PathMethods;
    codeActivity: ActivityMethods;
    quizActivity: Pick<ActivityMethods, "openActivity" | "submitActivity" | "getActivityAttempt" | "submitActivityWithContext">;
    sessions: LearningSessionRepository;
    profile: {
        load(subjectId: string, profileRevision: number): Promise<PathEngineProfile>;
    };
    capabilityTasks?: CapabilityTaskPort;
    resolveActivityKind(input: {
        sessionId: string;
        profileRevision: number;
        activityId: string;
    }): Promise<"code" | "quiz">;
    now?: () => Date;
}
/** Importable A composition root. HTTP and web adapters only call this contract. */
export declare class ComposedLearningRuntimeFacade implements LearningRuntimeFacade {
    private readonly options;
    private readonly now;
    constructor(options: ComposedLearningRuntimeFacadeOptions);
    startSession: LearningRuntimeFacade["startSession"];
    recoverSession: LearningRuntimeFacade["recoverSession"];
    saveDiagnosticDraft: LearningRuntimeFacade["saveDiagnosticDraft"];
    submitDiagnosticAnswer: LearningRuntimeFacade["submitDiagnosticAnswer"];
    completeDiagnostic: LearningRuntimeFacade["completeDiagnostic"];
    buildPath: LearningRuntimeFacade["buildPath"];
    confirmPath: LearningRuntimeFacade["confirmPath"];
    getNextStep: LearningRuntimeFacade["getNextStep"];
    replanPath: LearningRuntimeFacade["replanPath"];
    openActivity(input: OpenActivityInput): Promise<ActivityDraftOutput>;
    saveActivityDraft(input: SaveActivityDraftInput): Promise<ActivityDraftOutput>;
    prepareActivityRun(input: PrepareActivityRunInput): Promise<PreparedActivityOutput>;
    submitActivity(input: SubmitActivityInput): Promise<ActivitySubmissionOutput>;
    getActivityAttempt(input: GetActivityAttemptInput): Promise<ActivityAttemptSafeView>;
    recoverActivity(input: RecoverActivityInput): Promise<ActivityRecoveryOutput>;
    completeSession(input: CompleteSessionInput): Promise<CompleteSessionOutput>;
    askContextQuestion(input: ContextQuestionInput): Promise<ContextAnswerOutput>;
    private enqueueCompletedNode;
}
export {};
