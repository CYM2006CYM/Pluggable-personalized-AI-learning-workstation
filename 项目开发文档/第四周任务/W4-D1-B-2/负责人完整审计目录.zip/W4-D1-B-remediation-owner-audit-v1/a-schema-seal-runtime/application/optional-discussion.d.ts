import type { Graph } from "pi-loop-graph-sdk";
import type { IsolatedGraphExecutor } from "../graphs/isolated-graph-executor.js";
export type OptionalDiscussionResult = {
    status: "ok";
    result: Record<string, unknown>;
} | {
    status: "unavailable";
    reasons: string[];
};
/** 可选讨论最多重试一次；失败不能升级为整场学习中断。 */
export declare function executeOptionalDiscussion(executeGraph: IsolatedGraphExecutor, graph: Graph, input: Record<string, unknown>): Promise<OptionalDiscussionResult>;
