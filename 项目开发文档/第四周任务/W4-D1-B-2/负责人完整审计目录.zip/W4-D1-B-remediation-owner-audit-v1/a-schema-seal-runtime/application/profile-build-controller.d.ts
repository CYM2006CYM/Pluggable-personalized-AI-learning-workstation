import type { StudyControllerUi } from "./study-session-controller.js";
import type { IsolatedGraphExecutor } from "../graphs/isolated-graph-executor.js";
import { type StudyWalkingSkeletonGraphs } from "../graphs/study-walking-skeleton.js";
import type { ProfileBuildJobRepository } from "../repositories/profile-build-job-repository.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";
export interface ProfileBuildControllerDependencies {
    profiles: ProfileFamilyRepository;
    jobs: ProfileBuildJobRepository;
    graphs: StudyWalkingSkeletonGraphs;
    executeGraph: IsolatedGraphExecutor;
    ui: StudyControllerUi;
}
export type ProfileBuildResult = {
    status: "cancelled";
} | {
    status: "enabled" | "kept_draft" | "discarded";
    jobId: string;
    subjectId: string;
} | {
    status: "failed";
    jobId?: string;
    error: string;
};
export declare class ProfileBuildController {
    private readonly profiles;
    private readonly jobs;
    private readonly graphs;
    private readonly executeGraph;
    private readonly ui;
    constructor(dependencies: ProfileBuildControllerDependencies);
    run(args: string): Promise<ProfileBuildResult>;
}
