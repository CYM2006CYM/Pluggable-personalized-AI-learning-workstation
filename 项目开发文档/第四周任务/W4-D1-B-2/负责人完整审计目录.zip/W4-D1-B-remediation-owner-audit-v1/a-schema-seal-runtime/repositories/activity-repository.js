export class ActivityRepositoryError extends Error {
    errorCode;
    constructor(errorCode, message) {
        super(message);
        this.errorCode = errorCode;
        this.name = "ActivityRepositoryError";
    }
}
export async function commitFormalActivity(input) {
    return new LearningSessionUnitOfWork(input.repository, input.sessionRepository).commit(input);
}
/** Coordinates A's candidate with the single formal session fact source. */
export class LearningSessionUnitOfWork {
    activityRepository;
    sessionRepository;
    constructor(activityRepository, sessionRepository) {
        this.activityRepository = activityRepository;
        this.sessionRepository = sessionRepository;
    }
    async commit(input) {
        return this.commitRecorded(input.activity, async () => ({
            knowledgeStates: input.knowledgeStates,
            ...(input.pathCandidate === undefined ? {} : { pathCandidate: input.pathCandidate }),
            ...(input.nextStage === undefined ? {} : { nextStage: input.nextStage }),
        }));
    }
    async commitDerived(input) {
        return this.commitRecorded(input.activity, ({ record, evidence }) => input.deriveCandidate({ record, evidence }));
    }
    async commitRecorded(activity, deriveCandidate) {
        const recorded = await this.activityRepository.recordResult(activity);
        if ("errorCode" in recorded && !("attempt" in recorded))
            return recorded;
        const resultRecord = recorded;
        const evidence = activityResultToEvidence(resultRecord.attempt, resultRecord.result);
        if (!evidence || evidence.impact === "none")
            return resultRecord;
        let committed;
        try {
            const derived = await deriveCandidate({ record: resultRecord, evidence });
            committed = await this.sessionRepository.commit({
                requestId: activity.requestId,
                sessionId: activity.sessionId,
                sessionVersion: activity.sessionVersion,
                profileRevision: activity.profileRevision,
                candidate: {
                    requestId: activity.requestId,
                    evidenceCandidate: evidence,
                    ...derived,
                    activityAttemptId: activity.attemptId,
                },
            });
        }
        catch (error) {
            const recoverable = await this.hasRecoverableCandidate(activity.sessionId, activity.requestId);
            if (!recoverable)
                await this.activityRepository.discardAttempt({
                    subjectId: activity.subjectId,
                    sessionId: activity.sessionId,
                    activityId: activity.activityId,
                    attemptId: activity.attemptId,
                }).catch(() => undefined);
            throw error;
        }
        await this.activityRepository.markCommitted({
            subjectId: activity.subjectId,
            sessionId: activity.sessionId,
            activityId: activity.activityId,
            attemptId: activity.attemptId,
        });
        return committed;
    }
    async recover(input) {
        let recovered;
        try {
            recovered = await this.sessionRepository.recover({
                requestId: input.requestId,
                sessionId: input.sessionId,
                sessionVersion: input.sessionVersion,
                profileRevision: input.profileRevision,
            });
            const committedAttempt = recovered.evidence.some((item) => item.attemptId === input.attemptId);
            if (committedAttempt) {
                await this.activityRepository.markCommitted({
                    subjectId: input.subjectId,
                    sessionId: input.sessionId,
                    activityId: input.activityId,
                    attemptId: input.attemptId,
                });
            }
            return recovered;
        }
        catch (error) {
            // recover() may already have published the session facts before the
            // cross-repository markCommitted callback fails. In that state the
            // Attempt is the durable retry handle and must not be deleted.
            const sessionFactPublished = recovered?.evidence.some((item) => item.attemptId === input.attemptId) ?? false;
            const recoverable = await this.hasRecoverableCandidate(input.sessionId, input.requestId);
            if (!sessionFactPublished && !recoverable)
                await this.activityRepository.discardAttempt({
                    subjectId: input.subjectId,
                    sessionId: input.sessionId,
                    activityId: input.activityId,
                    attemptId: input.attemptId,
                }).catch(() => undefined);
            throw error;
        }
    }
    async hasRecoverableCandidate(sessionId, requestId) {
        const reader = this.sessionRepository;
        if (typeof reader.hasRecoverableActivityCommit !== "function")
            return false;
        return reader.hasRecoverableActivityCommit({ sessionId, requestId }).catch(() => false);
    }
}
export function activityResultToEvidence(attempt, result) {
    if (result.errorKind === "evaluator" || result.verdict === "not_graded" || result.executionStatus !== "completed")
        return undefined;
    if (result.score === undefined || !Number.isFinite(result.score) || result.score < 0 || result.score > 1) {
        throw new ActivityRepositoryError("submission_contract_error", "A graded ActivityResult must carry a score in 0..1");
    }
    const outcome = result.verdict === "pass" ? "correct" : result.verdict === "partial" ? "partial" : "incorrect";
    const source = attempt.kind === "coding_practical" ? "practical_rubric" : "code_submit";
    const form = attempt.kind === "coding_practical" ? "practical_rubric" : "code_execution";
    const independence = attempt.highestAssistance;
    return {
        evidenceId: `evidence-${attempt.attemptId}`,
        requestId: attempt.requestId,
        sessionId: attempt.sessionId,
        knowledgePointId: attempt.primaryKnowledgePointId,
        profileRevision: attempt.profileRevision,
        kind: attempt.kind,
        source,
        form,
        impact: independence === "answer_exposed" ? "none" : "mastery",
        outcome,
        score: result.score,
        independence,
        activityId: attempt.activityId,
        attemptId: attempt.attemptId,
        evaluatorVersion: result.evaluatorVersion,
        createdAt: attempt.createdAt,
    };
}
