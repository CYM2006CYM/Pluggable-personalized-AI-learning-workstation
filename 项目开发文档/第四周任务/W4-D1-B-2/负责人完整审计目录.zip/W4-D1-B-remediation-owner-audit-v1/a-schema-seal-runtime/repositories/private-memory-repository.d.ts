import type { Attempt, LearningProfile, LearningRecordBatch, StudySession } from "../domain/types.js";
export interface PrivateMemoryRepositoryOptions {
    dataRoot?: string;
    now?: () => Date;
    /** @internal 测试归档事务回滚；生产默认使用 node:fs rename。 */
    renamePath?: (from: string, to: string) => Promise<void>;
}
export interface PendingLearningRecordBatch extends LearningRecordBatch {
    session: StudySession;
    attempts: Attempt[];
    summaryMarkdown?: string;
}
export declare class PrivateMemoryRepository {
    readonly dataRoot: string;
    readonly familiesRoot: string;
    private readonly now;
    private readonly renamePath;
    constructor(options?: PrivateMemoryRepositoryOptions);
    private userDirectory;
    private pendingDirectory;
    private archivedDirectory;
    private batchDirectory;
    createPendingBatch(session: StudySession): Promise<LearningRecordBatch>;
    saveAttempt(subjectId: string, batchId: string, attempt: Attempt): Promise<void>;
    saveRunningSession(subjectId: string, batchId: string, runningSession: StudySession): Promise<void>;
    completeSession(subjectId: string, batchId: string, completedSession: StudySession, summaryMarkdown: string): Promise<void>;
    interruptSession(subjectId: string, batchId: string, interruptedSession: StudySession): Promise<void>;
    loadPendingBatch(subjectId: string, batchId: string): Promise<PendingLearningRecordBatch>;
    listPendingBatches(subjectId: string): Promise<PendingLearningRecordBatch[]>;
    loadLearningProfile(subjectId: string): Promise<LearningProfile | null>;
    private uniqueArchivedBatchPath;
    /** 写入画像成功后才消费批次；任一移动失败时恢复画像与已移动批次。 */
    saveLearningProfileAndArchive(subjectId: string, profile: LearningProfile, batchIds: string[]): Promise<void>;
}
