import type { ActivityAttemptCandidate, ActivityDraft, ActivityRecoveryReport, ActivityRepository, EvaluationFailureRecord, OpenActivityInput, PrepareActivityRunInput, PreparedActivityRun, RecordActivityResultInput, SaveActivityDraftInput, ActivityResultRecord, ActivityDraftRecoveryReader } from "./activity-repository.js";
interface FileActivityRepositoryOptions {
    dataRoot?: string;
    now?: () => Date;
    beforePublish?: (stage: "draft" | "result" | "commit", requestId: string) => Promise<void> | void;
}
export declare class FileActivityRepository implements ActivityRepository, ActivityDraftRecoveryReader {
    private readonly dataRoot;
    private readonly familiesRoot;
    private readonly now;
    private readonly beforePublish?;
    private readonly locks;
    constructor(options?: FileActivityRepositoryOptions);
    private activityDirectory;
    private sessionLock;
    private withLock;
    private iso;
    openActivity(input: OpenActivityInput): Promise<ActivityDraft>;
    saveDraft(input: SaveActivityDraftInput): Promise<ActivityDraft>;
    prepareRun(input: PrepareActivityRunInput): Promise<PreparedActivityRun>;
    recordResult(input: RecordActivityResultInput): Promise<ActivityResultRecord | EvaluationFailureRecord>;
    getAttempt(input: {
        subjectId: string;
        sessionId: string;
        activityId: string;
        attemptId: string;
    }): Promise<ActivityResultRecord | undefined>;
    getDraft(input: {
        subjectId: string;
        sessionId: string;
        activityId: string;
        attemptId: string;
    }): Promise<ActivityDraft | undefined>;
    getEvaluationFailure(input: {
        subjectId: string;
        sessionId: string;
        activityId: string;
        attemptId: string;
    }): Promise<EvaluationFailureRecord | undefined>;
    markCommitted(input: {
        subjectId: string;
        sessionId: string;
        activityId: string;
        attemptId: string;
        committedAt?: string;
    }): Promise<ActivityAttemptCandidate>;
    discardAttempt(input: {
        subjectId: string;
        sessionId: string;
        activityId: string;
        attemptId: string;
    }): Promise<void>;
    recover(input: {
        subjectId: string;
        sessionId: string;
    }): Promise<ActivityRecoveryReport>;
    private readDraft;
}
export {};
