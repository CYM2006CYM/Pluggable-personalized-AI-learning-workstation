import type { QuizAttemptSnapshot } from "../domain/quiz-runtime.js";
import type { CommitLearningSessionInput, CommittedSessionSnapshot, CreateLearningSessionRecord, GetSessionSnapshotInput, LearningSessionRepository, RecoverySnapshot, RecoverLearningSessionInput, SessionSnapshot, SessionBindingReader, RecoverableActivityCommitReader, DiagnosticDraftSessionPort, QuizAttemptSessionPort, LearningSessionCatalogPort, StoredDiagnosticAnswerState } from "./learning-session-repository.js";
import { type InternalPathSessionPort, type InternalPersistedPathSnapshot } from "./internal-path-session-port.js";
export interface FileLearningSessionRepositoryOptions {
    dataRoot?: string;
    now?: () => Date;
    /** Deterministic fault-injection hook; published readers remain behind latest.json. */
    beforePublish?: (sessionId: string, requestId: string, stage: FileLearningSessionPublishStage) => Promise<void> | void;
}
export type FileLearningSessionPublishStage = "candidate_written" | "attempt_written" | "evidence_written" | "knowledge_state_written" | "path_written" | "progress_written" | "checkpoint_written";
export declare class FileLearningSessionRepository implements LearningSessionRepository, InternalPathSessionPort, SessionBindingReader, RecoverableActivityCommitReader, DiagnosticDraftSessionPort, QuizAttemptSessionPort, LearningSessionCatalogPort {
    readonly dataRoot: string;
    readonly familiesRoot: string;
    private readonly now;
    private readonly beforePublish?;
    private readonly locks;
    constructor(options?: FileLearningSessionRepositoryOptions);
    private withLock;
    private sessionsRoot;
    private sessionDirectory;
    private findSessionDirectory;
    private loadStoredSnapshot;
    private publicSnapshot;
    private prepareTransaction;
    private validatePreparedTransaction;
    create(input: CreateLearningSessionRecord): Promise<import("../contracts/facade.js").SessionSafeView | {
        availableMinutes: number;
        status: "active";
        stage: "diagnostic" | "path";
        diagnosticRequired: boolean;
        chapterId?: string | undefined;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        subjectId: string;
        mode: import("../contracts/facade.js").LearningEntryMode;
        goalId: string;
    }>;
    getSnapshot(input: GetSessionSnapshotInput): Promise<SessionSnapshot>;
    getBoundSnapshot(sessionId: string): Promise<SessionSnapshot>;
    listBoundSnapshots(): Promise<SessionSnapshot[]>;
    getQuizAttempt(input: GetSessionSnapshotInput & {
        activityId: string;
        attemptId: string;
    }): Promise<QuizAttemptSnapshot | undefined>;
    saveDiagnosticDraftState(input: {
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        diagnosticDraftVersion: number;
        draft: Record<string, unknown>;
        background?: unknown;
    }): Promise<{
        diagnosticDraftVersion: number;
    }>;
    saveDiagnosticAnswerState(input: {
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        diagnosticDraftVersion: number;
        answer: StoredDiagnosticAnswerState;
    }): Promise<{
        diagnosticDraftVersion: number;
        output: import("../contracts/facade.js").DiagnosticAnswerOutput;
    }>;
    hasRecoverableActivityCommit(input: {
        sessionId: string;
        requestId: string;
    }): Promise<boolean>;
    /** Internal A port; full path metadata never crosses the public 21号 snapshot DTO. */
    getInternalPathSnapshot(input: GetSessionSnapshotInput): Promise<InternalPersistedPathSnapshot | undefined>;
    getBoundLearningCards(input: GetSessionSnapshotInput): Promise<import("./learning-session-repository.js").BoundLearningCardSnapshot[]>;
    commit(input: CommitLearningSessionInput): Promise<CommittedSessionSnapshot>;
    commitInternalPath(input: CommitLearningSessionInput, path: InternalPersistedPathSnapshot): Promise<CommittedSessionSnapshot>;
    private commitWithPath;
    private publishPrepared;
    recover(input: RecoverLearningSessionInput): Promise<RecoverySnapshot>;
}
