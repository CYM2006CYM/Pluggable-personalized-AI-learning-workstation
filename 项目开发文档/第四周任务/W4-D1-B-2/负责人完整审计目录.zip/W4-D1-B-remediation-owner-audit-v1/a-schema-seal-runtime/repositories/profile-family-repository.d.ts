import { type RevisionSeal } from "../domain/profile-revision-seal.js";
import type { ProfileManifestV2 } from "../domain/v2-types.js";
import type { LearningCardSafeView, QuizQuestionGroupAsset } from "../contracts/index.js";
import type { Profile } from "../domain/types.js";
import type { ProfileRevisionChange, ProfileFileSnapshot } from "../domain/profile-revision.js";
export interface ProfileFamilyRepositoryOptions {
    dataRoot?: string;
    fixturesRoot?: string;
    now?: () => Date;
    /** D3 fault-injection hook; production callers leave this undefined. */
    beforeV2ActivationStage?: (stage: "candidate_validated" | "active_manifest_written" | "archive_manifest_written" | "archive_prepared" | "old_archived" | "active_published") => Promise<void> | void;
}
export interface CreateDraftProfileInput {
    subjectId: string;
    name: string;
    subjectMarkdown?: string;
}
export interface ProfileRevisionCandidate {
    subjectId: string;
    name: string;
    hasActive: boolean;
    hasDraft: boolean;
    activeRevision?: number;
    draftRevision?: number;
}
export interface ActivatedRevision3Profile {
    manifest: ProfileManifestV2;
    seal: RevisionSeal;
    activation: "activated" | "reused";
}
export declare class ProfileFamilyRepository {
    readonly dataRoot: string;
    readonly familiesRoot: string;
    readonly fixturesRoot: string;
    private readonly now;
    private readonly beforeV2ActivationStage?;
    constructor(options?: ProfileFamilyRepositoryOptions);
    familyDirectory(subjectId: string): string;
    private slotDirectory;
    private ensureFamilyScaffold;
    seedDemoProfile(): Promise<Profile>;
    listActiveProfiles(): Promise<Profile[]>;
    loadActiveProfile(subjectId: string): Promise<Profile>;
    /** D1 read-only v2 projection. It does not alter the v1 Profile API. */
    loadActiveProfileV2(subjectId: string): Promise<ProfileManifestV2>;
    listActiveProfileV2Manifests(): Promise<ProfileManifestV2[]>;
    /** Read a v2 asset without exposing the profile directory to callers. */
    readActiveProfileV2File(subjectId: string, relativePath: string): Promise<string>;
    /** Resolves the immutable revision bound to a formal session from active or archived assets only. */
    profileV2RevisionDirectory(subjectId: string, revision: number): Promise<string>;
    loadProfileV2Revision(subjectId: string, revision: number): Promise<ProfileManifestV2>;
    readProfileV2RevisionFile(subjectId: string, revision: number, relativePath: string): Promise<string>;
    loadProfileV2RevisionCards(subjectId: string, revision: number): Promise<LearningCardSafeView[]>;
    loadProfileV2RevisionQuizGroups(subjectId: string, revision: number): Promise<QuizQuestionGroupAsset>;
    loadDraftProfile(subjectId: string): Promise<Profile>;
    /**
     * D3-only v2 activation. The candidate is read from the immutable fixture
     * slot, while runtime state is published under the user's Profile family.
     * No caller may mutate status or move active directories by hand.
     */
    activateV2Draft(subjectId: string): Promise<ProfileManifestV2>;
    /** W4 strict activation. It never auto-migrates an existing active revision. */
    activateRevision3Draft(subjectId: string): Promise<ActivatedRevision3Profile>;
    listRevisionCandidates(): Promise<ProfileRevisionCandidate[]>;
    /** active 只读出口；代码节点可读取资料，但仓库不提供 active 写入能力。 */
    readActiveFile(subjectId: string, relativePath: string): Promise<string>;
    createDraftProfile(input: CreateDraftProfileInput): Promise<Profile>;
    createRevisionDraft(subjectId: string): Promise<Profile>;
    writeDraftFile(subjectId: string, relativePath: string, content: string): Promise<void>;
    readDraftFile(subjectId: string, relativePath: string): Promise<string>;
    listDraftFiles(subjectId: string): Promise<ProfileFileSnapshot[]>;
    listActiveFiles(subjectId: string): Promise<ProfileFileSnapshot[]>;
    applyDraftChanges(subjectId: string, changes: readonly ProfileRevisionChange[]): Promise<Profile>;
    private nextArchiveDirectory;
    enableDraft(subjectId: string): Promise<Profile>;
    discardDraft(subjectId: string): Promise<void>;
}
