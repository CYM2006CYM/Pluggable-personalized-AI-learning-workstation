import { mkdir, readFile, readdir } from "node:fs/promises";
import { resolve } from "node:path";
import { resolveStudyDataRoot } from "../config/data-paths.js";
import { assertSafeFileComponent, assertSafeSubjectId, resolveInside, timestampForPath, writeJsonAtomic, } from "../infrastructure/safe-files.js";
function parseJson(raw, label) {
    try {
        return JSON.parse(raw);
    }
    catch {
        throw new Error(`${label} is not valid JSON`);
    }
}
export class ProfileBuildJobRepository {
    dataRoot;
    jobsRoot;
    now;
    constructor(options = {}) {
        this.dataRoot = resolveStudyDataRoot(options.dataRoot);
        this.jobsRoot = resolve(this.dataRoot, "profile_build_jobs");
        this.now = options.now ?? (() => new Date());
    }
    jobDirectory(jobId) {
        assertSafeFileComponent(jobId, "jobId");
        return resolveInside(this.jobsRoot, jobId);
    }
    async createJob(input) {
        assertSafeSubjectId(input.subjectId);
        if (input.subjectName.trim() === "")
            throw new Error("Profile subject name must not be empty");
        if (input.batches.length === 0)
            throw new Error("Profile build job requires source batches");
        const unfinished = (await this.listJobs()).find((job) => job.subjectId === input.subjectId
            && ["extracting", "draft_ready", "failed"].includes(job.status));
        if (unfinished)
            throw new Error(`Unfinished Profile build job already exists: ${unfinished.jobId}`);
        const now = this.now();
        const jobId = `${timestampForPath(now)}_${input.subjectId}_${crypto.randomUUID().slice(0, 8)}`;
        const directory = this.jobDirectory(jobId);
        await mkdir(resolve(directory, "fragments"), { recursive: true });
        const job = {
            jobId,
            subjectId: input.subjectId,
            subjectName: input.subjectName.trim(),
            sourceRoot: input.inventory.root,
            inventory: input.inventory,
            batches: input.batches,
            nextBatchIndex: 0,
            status: "extracting",
            createdAt: now.toISOString(),
            updatedAt: now.toISOString(),
        };
        await writeJsonAtomic(resolve(directory, "job.json"), job);
        return job;
    }
    async loadJob(jobId) {
        return parseJson(await readFile(resolve(this.jobDirectory(jobId), "job.json"), "utf8"), "profile build job");
    }
    async listJobs() {
        await mkdir(this.jobsRoot, { recursive: true });
        const entries = await readdir(this.jobsRoot, { withFileTypes: true });
        const jobs = [];
        for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
            if (!entry.isDirectory())
                continue;
            try {
                jobs.push(await this.loadJob(entry.name));
            }
            catch {
                // 损坏 job 由显式 doctor 处理，不阻断其他构建任务。
            }
        }
        return jobs;
    }
    async listUnfinishedJobs() {
        return (await this.listJobs()).filter((job) => ["extracting", "draft_ready", "failed"].includes(job.status));
    }
    async saveFragment(jobId, batchIndex, fragment) {
        const job = await this.loadJob(jobId);
        if (job.status !== "extracting")
            throw new Error("Profile build job is not extracting");
        if (batchIndex !== job.nextBatchIndex)
            throw new Error(`Expected batch ${job.nextBatchIndex}, received ${batchIndex}`);
        await writeJsonAtomic(resolve(this.jobDirectory(jobId), "fragments", `${String(batchIndex).padStart(4, "0")}.json`), fragment);
        return this.updateJob({
            ...job,
            nextBatchIndex: batchIndex + 1,
            updatedAt: this.now().toISOString(),
        });
    }
    async loadFragments(jobId) {
        const directory = resolve(this.jobDirectory(jobId), "fragments");
        const entries = await readdir(directory, { withFileTypes: true });
        const fragments = [];
        for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
            if (!entry.isFile() || !entry.name.endsWith(".json"))
                continue;
            fragments.push(parseJson(await readFile(resolve(directory, entry.name), "utf8"), entry.name));
        }
        return fragments;
    }
    async setStatus(jobId, status, error) {
        const job = await this.loadJob(jobId);
        const updated = {
            ...job,
            status,
            updatedAt: this.now().toISOString(),
        };
        if (error === undefined)
            delete updated.error;
        else
            updated.error = error;
        return this.updateJob(updated);
    }
    async updateJob(job) {
        await writeJsonAtomic(resolve(this.jobDirectory(job.jobId), "job.json"), job);
        return job;
    }
}
