export class LearningSessionRepositoryError extends Error {
    errorCode;
    constructor(errorCode, message) {
        super(message);
        this.errorCode = errorCode;
        this.name = "LearningSessionRepositoryError";
    }
}
