import type { ProfileBuildFragment } from "../domain/profile-build.js";
import type { SourceBatch, SourceInventory } from "../domain/source-inventory.js";
export type ProfileBuildJobStatus = "extracting" | "draft_ready" | "enabled" | "kept_draft" | "discarded" | "failed";
export interface ProfileBuildJob {
    jobId: string;
    subjectId: string;
    subjectName: string;
    sourceRoot: string;
    inventory: SourceInventory;
    batches: SourceBatch[];
    nextBatchIndex: number;
    status: ProfileBuildJobStatus;
    createdAt: string;
    updatedAt: string;
    error?: string;
}
export interface ProfileBuildJobRepositoryOptions {
    dataRoot?: string;
    now?: () => Date;
}
export declare class ProfileBuildJobRepository {
    readonly dataRoot: string;
    readonly jobsRoot: string;
    private readonly now;
    constructor(options?: ProfileBuildJobRepositoryOptions);
    private jobDirectory;
    createJob(input: {
        subjectId: string;
        subjectName: string;
        inventory: SourceInventory;
        batches: SourceBatch[];
    }): Promise<ProfileBuildJob>;
    loadJob(jobId: string): Promise<ProfileBuildJob>;
    listJobs(): Promise<ProfileBuildJob[]>;
    listUnfinishedJobs(): Promise<ProfileBuildJob[]>;
    saveFragment(jobId: string, batchIndex: number, fragment: ProfileBuildFragment): Promise<ProfileBuildJob>;
    loadFragments(jobId: string): Promise<ProfileBuildFragment[]>;
    setStatus(jobId: string, status: ProfileBuildJobStatus, error?: string): Promise<ProfileBuildJob>;
    private updateJob;
}
