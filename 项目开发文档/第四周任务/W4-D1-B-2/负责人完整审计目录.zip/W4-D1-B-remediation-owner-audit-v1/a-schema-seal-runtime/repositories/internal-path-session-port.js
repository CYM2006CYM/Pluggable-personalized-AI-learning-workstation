export function toPathSafeSnapshot(path) {
    return {
        pathId: path.pathId,
        pathVersion: path.pathVersion,
        status: path.status,
        goalId: path.goalId,
        mode: path.mode,
        nodes: path.nodes.map((node) => ({
            nodeId: node.nodeId,
            knowledgePointId: node.knowledgePointId,
            activityIds: [...node.activityIds],
            status: node.status,
            estimatedMinutes: node.estimatedMinutes,
            reasonCodes: [...node.reasonCodes],
            difficulty: node.difficulty,
            scaffold: node.scaffold,
            required: node.required,
            positionLocked: node.positionLocked,
        })),
    };
}
