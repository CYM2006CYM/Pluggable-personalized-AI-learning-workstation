import type { ActivityResult, Evidence } from "../domain/v2-types.js";
import type { CommittedSessionSnapshot, CommitLearningSessionInput, LearningSessionRepository, RecoverySnapshot } from "./learning-session-repository.js";
export type ActivityTaskSource = "fixed" | "ai_generated" | "fallback";
export type AssistanceLevel = "independent" | "hinted" | "worked_example" | "answer_exposed";
export interface ActivityAssignment {
    assignmentId: string;
    activityId: string;
    activityVersion: number;
    profileRevision: number;
    primaryKnowledgePointId: string;
    kind: "code_completion" | "coding_practical" | "debug";
    source: ActivityTaskSource;
    assetBundleHash: string;
    environmentId: string;
}
export interface HintEvent {
    hintId: string;
    level: Exclude<AssistanceLevel, "independent">;
    occurredAt: string;
}
export interface ActivityDraft {
    sessionId: string;
    activityId: string;
    activityVersion: number;
    profileRevision: number;
    attemptId: string;
    draftVersion: number;
    code: string;
    codeHash: string;
    hintEvents: HintEvent[];
    updatedAt: string;
}
export interface OpenActivityInput {
    subjectId: string;
    sessionId: string;
    requestId: string;
    assignment: ActivityAssignment;
    attemptId?: string;
    now?: string;
}
export interface SaveActivityDraftInput {
    subjectId: string;
    sessionId: string;
    requestId: string;
    activityId: string;
    attemptId: string;
    activityVersion: number;
    profileRevision: number;
    draftVersion: number;
    code: string;
    hintEvents?: readonly HintEvent[];
    now?: string;
}
export interface PrepareActivityRunInput {
    subjectId: string;
    sessionId: string;
    requestId: string;
    activityId: string;
    attemptId: string;
    activityVersion: number;
    profileRevision: number;
    draftVersion: number;
    mode: "preview" | "submit";
    now?: string;
}
export interface PreparedActivityRun {
    runId: string;
    sessionId: string;
    activityId: string;
    attemptId: string;
    draftVersion: number;
    mode: "preview" | "submit";
    codeHash: string;
    createdAt: string;
}
export interface RecordActivityResultInput {
    subjectId: string;
    sessionId: string;
    sessionVersion: number;
    requestId: string;
    attemptId: string;
    activityId: string;
    activityVersion: number;
    profileRevision: number;
    assignment: ActivityAssignment;
    draftVersion: number;
    code: string;
    highestAssistance?: AssistanceLevel;
    result: ActivityResult;
    now?: string;
}
export interface ActivityAttemptCandidate {
    attemptId: string;
    requestId: string;
    sessionId: string;
    activityId: string;
    activityVersion: number;
    assignmentId: string;
    primaryKnowledgePointId: string;
    kind: ActivityAssignment["kind"];
    profileRevision: number;
    source: ActivityTaskSource;
    assetBundleHash: string;
    submissionRef: string;
    codeHash: string;
    highestAssistance: AssistanceLevel;
    resultRef: string;
    attemptStatus: "completed";
    createdAt: string;
    committedAt?: string;
}
export interface EvaluationFailureRecord {
    requestId: string;
    attemptId: string;
    sessionId: string;
    activityId: string;
    assignmentId: string;
    errorCode: NonNullable<ActivityResult["errorCode"]>;
    stage: "prepare" | "user_code" | "public_tests" | "hidden_tests" | "rubric" | "commit";
    environmentHash: string;
    createdAt: string;
}
export interface ActivityResultRecord {
    attempt: ActivityAttemptCandidate;
    result: ActivityResult;
}
export interface ActivityRepository {
    openActivity(input: OpenActivityInput): Promise<ActivityDraft>;
    saveDraft(input: SaveActivityDraftInput): Promise<ActivityDraft>;
    prepareRun(input: PrepareActivityRunInput): Promise<PreparedActivityRun>;
    recordResult(input: RecordActivityResultInput): Promise<ActivityResultRecord | EvaluationFailureRecord>;
    getAttempt(input: {
        subjectId: string;
        sessionId: string;
        activityId: string;
        attemptId: string;
    }): Promise<ActivityResultRecord | undefined>;
    markCommitted(input: {
        subjectId: string;
        sessionId: string;
        activityId: string;
        attemptId: string;
        committedAt?: string;
    }): Promise<ActivityAttemptCandidate>;
    discardAttempt(input: {
        subjectId: string;
        sessionId: string;
        activityId: string;
        attemptId: string;
    }): Promise<void>;
    recover(input: {
        subjectId: string;
        sessionId: string;
    }): Promise<ActivityRecoveryReport>;
}
/** Read-only recovery projection kept separate from the W3 write repository. */
export interface ActivityDraftRecoveryReader {
    getDraft(input: {
        subjectId: string;
        sessionId: string;
        activityId: string;
        attemptId: string;
    }): Promise<ActivityDraft | undefined>;
    getEvaluationFailure(input: {
        subjectId: string;
        sessionId: string;
        activityId: string;
        attemptId: string;
    }): Promise<EvaluationFailureRecord | undefined>;
}
export interface ActivityRecoveryReport {
    publishedCandidates: string[];
    quarantinedCandidates: string[];
    removedOrphanResults: string[];
}
export declare class ActivityRepositoryError extends Error {
    readonly errorCode: "activity_not_found" | "activity_version_conflict" | "attempt_not_found" | "draft_version_conflict" | "idempotency_conflict" | "submission_contract_error" | "environment_mismatch" | "storage_error";
    constructor(errorCode: "activity_not_found" | "activity_version_conflict" | "attempt_not_found" | "draft_version_conflict" | "idempotency_conflict" | "submission_contract_error" | "environment_mismatch" | "storage_error", message: string);
}
export interface FormalActivityCommitInput {
    repository: ActivityRepository;
    sessionRepository: LearningSessionRepository;
    activity: RecordActivityResultInput;
    knowledgeStates: CommitLearningSessionInput["candidate"]["knowledgeStates"];
    pathCandidate?: CommitLearningSessionInput["candidate"]["pathCandidate"];
    nextStage?: CommitLearningSessionInput["candidate"]["nextStage"];
}
export interface DerivedFormalActivityCommitInput {
    repository: ActivityRepository;
    sessionRepository: LearningSessionRepository;
    activity: RecordActivityResultInput;
    deriveCandidate(input: {
        record: ActivityResultRecord;
        evidence: Evidence;
    }): Promise<Omit<CommitLearningSessionInput["candidate"], "requestId" | "evidenceCandidate">>;
}
export declare function commitFormalActivity(input: FormalActivityCommitInput): Promise<CommittedSessionSnapshot | EvaluationFailureRecord | ActivityResultRecord>;
export interface RecoverFormalActivityInput {
    subjectId: string;
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    requestId: string;
    activityId: string;
    attemptId: string;
}
/** Coordinates A's candidate with the single formal session fact source. */
export declare class LearningSessionUnitOfWork {
    private readonly activityRepository;
    private readonly sessionRepository;
    constructor(activityRepository: ActivityRepository, sessionRepository: LearningSessionRepository);
    commit(input: FormalActivityCommitInput): Promise<CommittedSessionSnapshot | EvaluationFailureRecord | ActivityResultRecord>;
    commitDerived(input: DerivedFormalActivityCommitInput): Promise<CommittedSessionSnapshot | EvaluationFailureRecord | ActivityResultRecord>;
    private commitRecorded;
    recover(input: RecoverFormalActivityInput): Promise<RecoverySnapshot>;
    private hasRecoverableCandidate;
}
export declare function activityResultToEvidence(attempt: ActivityAttemptCandidate, result: ActivityResult): Evidence | undefined;
