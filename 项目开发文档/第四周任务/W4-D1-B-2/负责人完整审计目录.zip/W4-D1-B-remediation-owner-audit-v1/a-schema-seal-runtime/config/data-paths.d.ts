export declare const STUDY_DATA_ENV = "PI_STUDY_DATA";
/**
 * 获取运行数据根目录。显式参数优先，之后是环境变量，最后落在用户目录。
 * 返回绝对路径，调用方不需要依赖当前工作目录。
 */
export declare function resolveStudyDataRoot(explicitRoot?: string): string;
export declare function profileFamiliesRoot(dataRoot: string): string;
