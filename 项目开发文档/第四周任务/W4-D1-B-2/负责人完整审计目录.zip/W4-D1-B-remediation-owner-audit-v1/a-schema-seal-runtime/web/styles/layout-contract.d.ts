export declare const STABLE_LAYOUT: {
    readonly statePanelMinHeight: "430px";
    readonly activityStageMinHeight: "476px";
    readonly pathNodeMinHeight: "72px";
    readonly activityTabsHeight: "44px";
    readonly desktopSidebarWidth: "232px";
    readonly tabletBreakpoint: "980px";
    readonly mobileBreakpoint: "700px";
};
