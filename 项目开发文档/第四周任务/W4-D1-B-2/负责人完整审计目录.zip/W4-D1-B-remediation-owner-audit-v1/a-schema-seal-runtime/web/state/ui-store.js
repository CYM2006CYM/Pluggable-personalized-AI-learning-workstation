import { create } from "zustand";
import { activityDraftMock } from "../mocks/safe-dtos.js";
export const PAGE_VIEW_STATES = ["ready", "empty", "error", "conflict", "recovery"];
export const ACTIVITY_VIEW_MODES = ["draft", "running", "submitted", "safe_feedback"];
const INITIAL_STATE = {
    pageViewState: "ready",
    activityViewMode: "draft",
    activityDraft: activityDraftMock.userText,
};
export const useUiStore = create((set) => ({
    ...INITIAL_STATE,
    setPageViewState: (pageViewState) => set({ pageViewState }),
    setActivityViewMode: (activityViewMode) => set({ activityViewMode }),
    setActivityDraft: (activityDraft) => set({ activityDraft }),
    reset: () => set(INITIAL_STATE),
}));
