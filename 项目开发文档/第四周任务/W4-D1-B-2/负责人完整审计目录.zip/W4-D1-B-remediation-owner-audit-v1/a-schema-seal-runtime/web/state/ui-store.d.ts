export declare const PAGE_VIEW_STATES: readonly ["ready", "empty", "error", "conflict", "recovery"];
export type PageViewState = (typeof PAGE_VIEW_STATES)[number];
export declare const ACTIVITY_VIEW_MODES: readonly ["draft", "running", "submitted", "safe_feedback"];
export type ActivityViewMode = (typeof ACTIVITY_VIEW_MODES)[number];
interface UiState {
    pageViewState: PageViewState;
    activityViewMode: ActivityViewMode;
    activityDraft: string;
    setPageViewState: (state: PageViewState) => void;
    setActivityViewMode: (mode: ActivityViewMode) => void;
    setActivityDraft: (draft: string) => void;
    reset: () => void;
}
export declare const useUiStore: import("zustand").UseBoundStore<import("zustand").StoreApi<UiState>>;
export {};
