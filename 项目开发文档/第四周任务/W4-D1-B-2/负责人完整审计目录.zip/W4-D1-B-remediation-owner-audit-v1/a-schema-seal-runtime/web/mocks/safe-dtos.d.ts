export interface ProfileDisplayFixture {
    subjectId: string;
    name: string;
    revision: number;
    status: "active";
    modalities: Array<"reading" | "quiz" | "code" | "practice">;
}
export interface DiagnosticQuestionDisplayFixture {
    diagnosticId: string;
    diagnosticVersion: number;
    questionId: string;
    kind: "single_choice";
    prompt: string;
    options: string[];
    knowledgePointTitle: string;
    current: number;
    total: number;
    skippable: boolean;
}
export interface LearningCardDisplayFixture {
    artifactId: string;
    title: string;
    objective: string;
    reason: string;
    estimatedMinutes: number;
    explanation: string[];
    example: string;
    commonMistake: string;
    sourceAnchorIds: string[];
    reviewStatus: "cached_reviewed" | "profile_fallback";
}
export declare const profileDisplayFixture: {
    subjectId: string;
    name: string;
    revision: number;
    status: "active";
    modalities: ("reading" | "quiz" | "code" | "practice")[];
};
export declare const startSessionMock: {
    requestId: string;
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    subjectId: string;
    mode: "recommended";
    goalId: string;
    availableMinutes: number;
    status: "active";
    stage: "diagnostic";
    diagnosticRequired: true;
    pathVersion: number;
};
export declare const sessionConflictMock: {
    sessionVersion: number;
    errorCode: "session_version_conflict";
    sessionId: string;
    profileRevision: number;
    subjectId: string;
    mode: "recommended";
    goalId: string;
    availableMinutes: number;
    status: "active";
    stage: "diagnostic";
    diagnosticRequired: true;
    pathVersion: number;
};
export declare const recoverSessionMock: {
    requestId: string;
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    view: {
        sessionVersion: number;
        status: "recoverable";
        stage: "learning";
        sessionId: string;
        profileRevision: number;
        subjectId: string;
        mode: "recommended";
        goalId: string;
        availableMinutes: number;
        diagnosticRequired: true;
        pathVersion: number;
    };
    recoveryAction: "rebuilt_derived_state";
};
export declare const diagnosticQuestionDisplayFixture: {
    diagnosticId: string;
    diagnosticVersion: number;
    questionId: string;
    kind: "single_choice";
    prompt: string;
    options: string[];
    knowledgePointTitle: string;
    current: number;
    total: number;
    skippable: true;
};
export declare const diagnosticCompleteMock: {
    requestId: string;
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    diagnosticId: string;
    evidenceVersion: number;
    capabilityProfileRevision: number;
    diagnosticDraftVersion: number;
    insufficientKnowledgePointIds: string[];
    knowledgeStates: ({
        knowledgePointId: string;
        profileRevision: number;
        evidenceVersion: number;
        aggregationVersion: "knowledge-state-v1";
        mastery: number;
        confidence: number;
        status: "mastered";
        validEvidenceCount: number;
        evidenceFormCount: number;
        evidenceIds: string[];
        consideredEvidenceIds: string[];
        asOf: string;
        skipEligible: true;
        lastUpdatedAt: string;
    } | {
        knowledgePointId: string;
        profileRevision: number;
        evidenceVersion: number;
        aggregationVersion: "knowledge-state-v1";
        mastery: number;
        confidence: number;
        status: "learning";
        validEvidenceCount: number;
        evidenceFormCount: number;
        evidenceIds: string[];
        consideredEvidenceIds: string[];
        asOf: string;
        skipEligible: false;
        lastUpdatedAt: string;
    } | {
        knowledgePointId: string;
        profileRevision: number;
        evidenceVersion: number;
        aggregationVersion: "knowledge-state-v1";
        mastery: null;
        confidence: number;
        status: "unverified";
        validEvidenceCount: number;
        evidenceFormCount: number;
        evidenceIds: never[];
        consideredEvidenceIds: never[];
        asOf: string;
        skipEligible: false;
        lastUpdatedAt: string;
    })[];
};
export declare const pathCandidateMock: {
    requestId: string;
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    status: "candidate";
    pathId: string;
    pathVersion: number;
    missingPrerequisiteIds: never[];
    minimumRequiredMinutes: number;
    nodes: ({
        nodeId: string;
        knowledgePointId: string;
        activityIds: string[];
        status: "completed";
        estimatedMinutes: number;
        reasonCodes: string[];
        difficulty: "S-R";
        scaffold: "none";
        required: true;
        positionLocked: true;
    } | {
        nodeId: string;
        knowledgePointId: string;
        activityIds: string[];
        status: "available";
        estimatedMinutes: number;
        reasonCodes: string[];
        difficulty: "M-U";
        scaffold: "hint";
        required: true;
        positionLocked: false;
    } | {
        nodeId: string;
        knowledgePointId: string;
        activityIds: string[];
        status: "locked";
        estimatedMinutes: number;
        reasonCodes: string[];
        difficulty: "M-A";
        scaffold: "worked_example";
        required: true;
        positionLocked: false;
    } | {
        nodeId: string;
        knowledgePointId: string;
        activityIds: string[];
        status: "locked";
        estimatedMinutes: number;
        reasonCodes: string[];
        difficulty: "C-A";
        scaffold: "none";
        required: true;
        positionLocked: true;
    })[];
};
export declare const nextStepMock: {
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    pathVersion: number;
    completed: false;
    node: {
        nodeId: string;
        knowledgePointId: string;
        activityIds: string[];
        status: "completed";
        estimatedMinutes: number;
        reasonCodes: string[];
        difficulty: "S-R";
        scaffold: "none";
        required: true;
        positionLocked: true;
    } | {
        nodeId: string;
        knowledgePointId: string;
        activityIds: string[];
        status: "available";
        estimatedMinutes: number;
        reasonCodes: string[];
        difficulty: "M-U";
        scaffold: "hint";
        required: true;
        positionLocked: false;
    } | {
        nodeId: string;
        knowledgePointId: string;
        activityIds: string[];
        status: "locked";
        estimatedMinutes: number;
        reasonCodes: string[];
        difficulty: "M-A";
        scaffold: "worked_example";
        required: true;
        positionLocked: false;
    } | {
        nodeId: string;
        knowledgePointId: string;
        activityIds: string[];
        status: "locked";
        estimatedMinutes: number;
        reasonCodes: string[];
        difficulty: "C-A";
        scaffold: "none";
        required: true;
        positionLocked: true;
    };
    activity: {
        activityId: string;
        activityVersion: number;
        kind: "code_completion";
        title: string;
        prompt: string;
        primaryKnowledgePointId: string;
        supportingKnowledgePointIds: string[];
        starterCode: string;
    };
};
export declare const learningCardDisplayFixture: {
    artifactId: string;
    title: string;
    objective: string;
    reason: string;
    estimatedMinutes: number;
    explanation: string[];
    example: string;
    commonMistake: string;
    sourceAnchorIds: string[];
    reviewStatus: "cached_reviewed";
};
export declare const contextAnswerMock: {
    requestId: string;
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    answer: string;
    sourceAnchorIds: string[];
    softEvidenceId: string;
};
export declare const activityDraftMock: {
    kind: "code";
    requestId: string;
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    attemptId: string;
    draftVersion: number;
    activity: {
        activityId: string;
        activityVersion: number;
        kind: "code_completion";
        title: string;
        prompt: string;
        primaryKnowledgePointId: string;
        supportingKnowledgePointIds: string[];
        starterCode: string;
    };
    userText: string;
};
export declare const preparedActivityMock: {
    requestId: string;
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    runId: string;
    mode: "preview";
    environmentId: string;
    starterCodeHash: string;
    publicDatasetFiles: {
        name: string;
        content: string;
        hash: string;
    }[];
    publicTestSources: string[];
    expiresAt: string;
    bundleHash: string;
};
export declare const activitySubmissionMock: {
    kind: "code";
    requestId: string;
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    attemptId: string;
    committed: true;
    evidenceId: string;
    evidenceVersion: number;
    result: {
        executionStatus: "completed";
        verdict: "partial";
        errorKind: "learner";
        errorCode: "test_failed";
        score: number;
        dimensionResults: {
            structure: number;
            missing_values: number;
            stability: number;
        };
        safeFeedback: string;
        durationMs: number;
        evaluatorVersion: string;
        environmentHash: string;
        assetBundleHash: string;
    };
};
export declare const evaluatorFeedbackMock: {
    kind: "code";
    requestId: string;
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    attemptId: string;
    committed: false;
    result: {
        executionStatus: "failed";
        verdict: "not_graded";
        errorKind: "evaluator";
        errorCode: "evaluator_timeout";
        safeFeedback: string;
        evaluatorVersion: string;
        environmentHash: string;
        assetBundleHash: string;
    };
};
export declare const activityRecoveryMock: {
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    attempt: {
        kind: "code";
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        activityId: string;
        attemptId: string;
        status: "draft";
        draftVersion: number;
        codeHash: string;
    };
    draftVersion: number;
    userText: string;
    recoveryAction: "resume_draft";
};
export declare const completeSessionMock: {
    requestId: string;
    sessionId: string;
    sessionVersion: number;
    profileRevision: number;
    completedAt: string;
    summary: string;
    nextRecommendation: string;
};
export declare const FACADE_DTO_MOCKS: {
    readonly activityDraft: {
        kind: "code";
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        attemptId: string;
        draftVersion: number;
        activity: {
            activityId: string;
            activityVersion: number;
            kind: "code_completion";
            title: string;
            prompt: string;
            primaryKnowledgePointId: string;
            supportingKnowledgePointIds: string[];
            starterCode: string;
        };
        userText: string;
    };
    readonly activityRecovery: {
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        attempt: {
            kind: "code";
            sessionId: string;
            sessionVersion: number;
            profileRevision: number;
            activityId: string;
            attemptId: string;
            status: "draft";
            draftVersion: number;
            codeHash: string;
        };
        draftVersion: number;
        userText: string;
        recoveryAction: "resume_draft";
    };
    readonly activitySubmission: {
        kind: "code";
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        attemptId: string;
        committed: true;
        evidenceId: string;
        evidenceVersion: number;
        result: {
            executionStatus: "completed";
            verdict: "partial";
            errorKind: "learner";
            errorCode: "test_failed";
            score: number;
            dimensionResults: {
                structure: number;
                missing_values: number;
                stability: number;
            };
            safeFeedback: string;
            durationMs: number;
            evaluatorVersion: string;
            environmentHash: string;
            assetBundleHash: string;
        };
    };
    readonly completeSession: {
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        completedAt: string;
        summary: string;
        nextRecommendation: string;
    };
    readonly contextAnswer: {
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        answer: string;
        sourceAnchorIds: string[];
        softEvidenceId: string;
    };
    readonly diagnosticComplete: {
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        diagnosticId: string;
        evidenceVersion: number;
        capabilityProfileRevision: number;
        diagnosticDraftVersion: number;
        insufficientKnowledgePointIds: string[];
        knowledgeStates: ({
            knowledgePointId: string;
            profileRevision: number;
            evidenceVersion: number;
            aggregationVersion: "knowledge-state-v1";
            mastery: number;
            confidence: number;
            status: "mastered";
            validEvidenceCount: number;
            evidenceFormCount: number;
            evidenceIds: string[];
            consideredEvidenceIds: string[];
            asOf: string;
            skipEligible: true;
            lastUpdatedAt: string;
        } | {
            knowledgePointId: string;
            profileRevision: number;
            evidenceVersion: number;
            aggregationVersion: "knowledge-state-v1";
            mastery: number;
            confidence: number;
            status: "learning";
            validEvidenceCount: number;
            evidenceFormCount: number;
            evidenceIds: string[];
            consideredEvidenceIds: string[];
            asOf: string;
            skipEligible: false;
            lastUpdatedAt: string;
        } | {
            knowledgePointId: string;
            profileRevision: number;
            evidenceVersion: number;
            aggregationVersion: "knowledge-state-v1";
            mastery: null;
            confidence: number;
            status: "unverified";
            validEvidenceCount: number;
            evidenceFormCount: number;
            evidenceIds: never[];
            consideredEvidenceIds: never[];
            asOf: string;
            skipEligible: false;
            lastUpdatedAt: string;
        })[];
    };
    readonly evaluatorFeedback: {
        kind: "code";
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        attemptId: string;
        committed: false;
        result: {
            executionStatus: "failed";
            verdict: "not_graded";
            errorKind: "evaluator";
            errorCode: "evaluator_timeout";
            safeFeedback: string;
            evaluatorVersion: string;
            environmentHash: string;
            assetBundleHash: string;
        };
    };
    readonly nextStep: {
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        pathVersion: number;
        completed: false;
        node: {
            nodeId: string;
            knowledgePointId: string;
            activityIds: string[];
            status: "completed";
            estimatedMinutes: number;
            reasonCodes: string[];
            difficulty: "S-R";
            scaffold: "none";
            required: true;
            positionLocked: true;
        } | {
            nodeId: string;
            knowledgePointId: string;
            activityIds: string[];
            status: "available";
            estimatedMinutes: number;
            reasonCodes: string[];
            difficulty: "M-U";
            scaffold: "hint";
            required: true;
            positionLocked: false;
        } | {
            nodeId: string;
            knowledgePointId: string;
            activityIds: string[];
            status: "locked";
            estimatedMinutes: number;
            reasonCodes: string[];
            difficulty: "M-A";
            scaffold: "worked_example";
            required: true;
            positionLocked: false;
        } | {
            nodeId: string;
            knowledgePointId: string;
            activityIds: string[];
            status: "locked";
            estimatedMinutes: number;
            reasonCodes: string[];
            difficulty: "C-A";
            scaffold: "none";
            required: true;
            positionLocked: true;
        };
        activity: {
            activityId: string;
            activityVersion: number;
            kind: "code_completion";
            title: string;
            prompt: string;
            primaryKnowledgePointId: string;
            supportingKnowledgePointIds: string[];
            starterCode: string;
        };
    };
    readonly pathCandidate: {
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        status: "candidate";
        pathId: string;
        pathVersion: number;
        missingPrerequisiteIds: never[];
        minimumRequiredMinutes: number;
        nodes: ({
            nodeId: string;
            knowledgePointId: string;
            activityIds: string[];
            status: "completed";
            estimatedMinutes: number;
            reasonCodes: string[];
            difficulty: "S-R";
            scaffold: "none";
            required: true;
            positionLocked: true;
        } | {
            nodeId: string;
            knowledgePointId: string;
            activityIds: string[];
            status: "available";
            estimatedMinutes: number;
            reasonCodes: string[];
            difficulty: "M-U";
            scaffold: "hint";
            required: true;
            positionLocked: false;
        } | {
            nodeId: string;
            knowledgePointId: string;
            activityIds: string[];
            status: "locked";
            estimatedMinutes: number;
            reasonCodes: string[];
            difficulty: "M-A";
            scaffold: "worked_example";
            required: true;
            positionLocked: false;
        } | {
            nodeId: string;
            knowledgePointId: string;
            activityIds: string[];
            status: "locked";
            estimatedMinutes: number;
            reasonCodes: string[];
            difficulty: "C-A";
            scaffold: "none";
            required: true;
            positionLocked: true;
        })[];
    };
    readonly preparedActivity: {
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        runId: string;
        mode: "preview";
        environmentId: string;
        starterCodeHash: string;
        publicDatasetFiles: {
            name: string;
            content: string;
            hash: string;
        }[];
        publicTestSources: string[];
        expiresAt: string;
        bundleHash: string;
    };
    readonly recoverSession: {
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        view: {
            sessionVersion: number;
            status: "recoverable";
            stage: "learning";
            sessionId: string;
            profileRevision: number;
            subjectId: string;
            mode: "recommended";
            goalId: string;
            availableMinutes: number;
            diagnosticRequired: true;
            pathVersion: number;
        };
        recoveryAction: "rebuilt_derived_state";
    };
    readonly sessionConflict: {
        sessionVersion: number;
        errorCode: "session_version_conflict";
        sessionId: string;
        profileRevision: number;
        subjectId: string;
        mode: "recommended";
        goalId: string;
        availableMinutes: number;
        status: "active";
        stage: "diagnostic";
        diagnosticRequired: true;
        pathVersion: number;
    };
    readonly startSession: {
        requestId: string;
        sessionId: string;
        sessionVersion: number;
        profileRevision: number;
        subjectId: string;
        mode: "recommended";
        goalId: string;
        availableMinutes: number;
        status: "active";
        stage: "diagnostic";
        diagnosticRequired: true;
        pathVersion: number;
    };
};
export declare const PAGE_DISPLAY_FIXTURES: {
    readonly diagnosticQuestion: {
        diagnosticId: string;
        diagnosticVersion: number;
        questionId: string;
        kind: "single_choice";
        prompt: string;
        options: string[];
        knowledgePointTitle: string;
        current: number;
        total: number;
        skippable: true;
    };
    readonly learningCard: {
        artifactId: string;
        title: string;
        objective: string;
        reason: string;
        estimatedMinutes: number;
        explanation: string[];
        example: string;
        commonMistake: string;
        sourceAnchorIds: string[];
        reviewStatus: "cached_reviewed";
    };
    readonly profile: {
        subjectId: string;
        name: string;
        revision: number;
        status: "active";
        modalities: ("reading" | "quiz" | "code" | "practice")[];
    };
};
