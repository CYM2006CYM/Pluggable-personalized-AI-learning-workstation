function parseKnowledgeIndex(raw) {
    const value = JSON.parse(raw);
    if (typeof value.chapters !== "object" || value.chapters === null || Array.isArray(value.chapters)) {
        throw new Error("knowledge_index.json does not contain canonical chapters");
    }
    return value;
}
export async function listStudyScopes(repository, subjectId) {
    const profile = await repository.loadActiveProfile(subjectId);
    const index = parseKnowledgeIndex(await repository.readActiveFile(subjectId, profile.paths.knowledgeIndex));
    return Object.values(index.chapters).map((chapter) => {
        const knowledgePoints = chapter.knowledge_points ?? [];
        const sections = (chapter.sections ?? []).flatMap((section) => {
            if (typeof section.path !== "string")
                return [];
            return [{
                    id: section.id,
                    label: `${section.section} · ${section.title}`,
                    path: section.path,
                    knowledgePointIds: knowledgePoints
                        .filter((point) => point.section === section.section)
                        .map((point) => point.id),
                }];
        });
        const cards = knowledgePoints.flatMap((point) => {
            if (!point.card_id)
                return [];
            return [{
                    id: point.id,
                    label: point.name,
                    path: `${profile.paths.cards}/${point.card_id}.md`,
                }];
        });
        const paths = new Set();
        for (const section of sections)
            paths.add(section.path);
        for (const card of cards)
            paths.add(card.path);
        return {
            id: `chapter:${chapter.id}`,
            label: `第 ${chapter.id} 章 · ${chapter.title}`,
            chapterId: chapter.id,
            knowledgePointIds: knowledgePoints.map((point) => point.id),
            materialPaths: [...paths],
            cards,
            sections,
        };
    });
}
export async function loadActiveStudyTargetContext(repository, subjectId, scopeId, targetKind, targetId, maxCharacters = 30_000) {
    const profile = await repository.loadActiveProfile(subjectId);
    const scopes = await listStudyScopes(repository, subjectId);
    const scope = scopes.find((item) => item.id === scopeId);
    if (!scope)
        throw new Error(`Unknown study scope: ${scopeId}`);
    let target;
    let paths;
    if (targetKind === "card") {
        const card = scope.cards.find((item) => item.id === targetId);
        if (!card)
            throw new Error(`Unknown study card: ${targetId}`);
        target = { kind: "card", id: card.id, label: card.label, knowledgePointIds: [card.id] };
        paths = [card.path];
    }
    else if (targetKind === "section") {
        const section = scope.sections.find((item) => item.id === targetId);
        if (!section)
            throw new Error(`Unknown study section: ${targetId}`);
        target = {
            kind: "section",
            id: section.id,
            label: section.label,
            knowledgePointIds: section.knowledgePointIds,
        };
        paths = [section.path];
    }
    else {
        target = {
            kind: "scope",
            id: scope.id,
            label: scope.label,
            knowledgePointIds: scope.knowledgePointIds,
        };
        paths = scope.materialPaths;
    }
    const chunks = [];
    if (targetKind === "scope")
        chunks.push(await repository.readActiveFile(subjectId, profile.paths.subject));
    for (const path of paths) {
        try {
            chunks.push(`\n\n--- 资料：${path} ---\n${await repository.readActiveFile(subjectId, path)}`);
        }
        catch (error) {
            if (error.code !== "ENOENT")
                throw error;
        }
    }
    return { profile, scope, target, material: chunks.join("").slice(0, maxCharacters) };
}
export async function loadActiveStudyContext(repository, subjectId, scopeId, maxCharacters = 30_000) {
    const context = await loadActiveStudyTargetContext(repository, subjectId, scopeId, "scope", scopeId, maxCharacters);
    return { profile: context.profile, scope: context.scope, material: context.material };
}
