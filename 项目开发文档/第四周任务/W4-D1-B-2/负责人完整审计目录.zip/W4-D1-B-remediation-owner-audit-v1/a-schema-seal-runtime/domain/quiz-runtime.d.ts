import type { Evidence } from "./v2-types.js";
import type { QuizActivityResult, QuizAnswerInput, QuizActivitySafeView, QuizQuestionPrivate } from "../contracts/index.js";
export interface QuizActivityDefinition {
    activityId: string;
    activityVersion: number;
    profileRevision: number;
    title: string;
    prompt: string;
    primaryKnowledgePointId: string;
    supportingKnowledgePointIds: string[];
}
export interface QuizAttemptSnapshot {
    attemptId: string;
    sessionId: string;
    activityId: string;
    activityVersion: number;
    profileRevision: number;
    title: string;
    prompt: string;
    primaryKnowledgePointId: string;
    supportingKnowledgePointIds: string[];
    retryNumber: 0 | 1;
    questions: QuizQuestionPrivate[];
    status: "draft" | "submitted";
    result?: QuizActivityResult;
    openedRequestId?: string;
    submissionRequestId?: string;
    submissionHash?: string;
    submittedAt?: string;
}
export interface QuizSubmission {
    requestId: string;
    sessionId: string;
    profileRevision: number;
    activity: QuizActivityDefinition;
    attemptId: string;
    answers: QuizAnswerInput[];
    knowledgePointId: string;
    now?: string;
}
export interface QuizSubmissionCommit {
    result: QuizActivityResult;
    evidence?: Evidence;
    attempt: QuizAttemptSnapshot;
}
export declare class QuizRuntimeError extends Error {
    readonly errorCode: "attempt_not_found" | "submission_contract_error" | "idempotency_conflict" | "activity_version_conflict";
    constructor(errorCode: "attempt_not_found" | "submission_contract_error" | "idempotency_conflict" | "activity_version_conflict", message: string);
}
export declare class DeterministicQuizRuntime {
    private readonly attempts;
    private readonly submissions;
    open(input: {
        sessionId: string;
        profileRevision: number;
        activity: QuizActivityDefinition;
        questions: QuizQuestionPrivate[];
        retryNumber: 0 | 1;
        excludedQuestionIds?: string[];
        requestId?: string;
    }): {
        attemptId: string;
        activity: QuizActivitySafeView;
    };
    getAttempt(attemptId: string): QuizAttemptSnapshot;
    restore(attempt: QuizAttemptSnapshot): void;
    submit(input: QuizSubmission): QuizSubmissionCommit;
}
