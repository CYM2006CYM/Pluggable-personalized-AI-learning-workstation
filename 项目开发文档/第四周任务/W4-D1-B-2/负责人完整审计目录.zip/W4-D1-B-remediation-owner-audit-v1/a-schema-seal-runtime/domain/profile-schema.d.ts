import type { Profile, ProfilePaths, ProfileSlot } from "./types.js";
export declare const CANONICAL_PROFILE_PATHS: ProfilePaths;
export declare class ProfileValidationError extends Error {
    readonly issues: string[];
    constructor(issues: string[]);
}
export declare function parseProfileManifest(raw: string, expectedSubjectId?: string, expectedSlot?: ProfileSlot): Profile;
export declare function validateCanonicalProfileDirectory(directory: string, expectedSubjectId?: string, expectedSlot?: ProfileSlot): Promise<Profile>;
