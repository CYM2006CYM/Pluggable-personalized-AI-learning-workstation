import type { DifficultyLevel, ReviewMode } from "./types.js";
/** 由代码维护的难度语义。Agent 不得自行猜测难度缩写。 */
export interface DifficultyPolicy {
    readonly level: DifficultyLevel;
    readonly label: string;
    readonly learningGoal: string;
    readonly questionConstraints: readonly string[];
}
/** 不同学习方式的确定性产品策略。 */
export interface ReviewModePolicy {
    readonly mode: ReviewMode;
    readonly label: string;
    readonly entryBehavior: string;
    readonly questionConstraints: readonly string[];
    readonly answerGuidance: {
        readonly style: string;
        readonly recommendedLength: string;
    };
}
export declare const DIFFICULTY_POLICIES: Readonly<Record<DifficultyLevel, DifficultyPolicy>>;
export declare const REVIEW_MODE_POLICIES: Readonly<Record<ReviewMode, ReviewModePolicy>>;
/** 获取固定难度策略；外部输入不在支持列表时立即失败。 */
export declare function getDifficultyPolicy(level: string): DifficultyPolicy;
/** 获取固定学习方式策略；外部输入不在支持列表时立即失败。 */
export declare function getReviewModePolicy(mode: string): ReviewModePolicy;
