import { createHash } from "node:crypto";
export class PathEngineError extends Error {
    errorCode;
    constructor(errorCode, message) {
        super(message);
        this.errorCode = errorCode;
        this.name = "PathEngineError";
    }
}
const DIFFICULTIES = ["S-R", "S-U", "M-U", "M-A", "C-A"];
const SCAFFOLDS = ["none", "hint", "worked_example"];
function stableJson(value) {
    if (value === null || typeof value !== "object")
        return JSON.stringify(value);
    if (Array.isArray(value))
        return `[${value.map(stableJson).join(",")}]`;
    const record = value;
    return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableJson(record[key])}`).join(",")}}`;
}
function hash(value) {
    return createHash("sha256").update(stableJson(value)).digest("hex").slice(0, 24);
}
function assertPositiveInteger(value, label) {
    if (!Number.isInteger(value) || value < 1)
        throw new PathEngineError("path_infeasible", `${label} must be a positive integer`);
}
function compareIds(left, right) {
    return left.localeCompare(right, "en");
}
function isLowMastery(state) {
    return state?.mastery !== null && state?.mastery !== undefined && state.mastery < 0.6;
}
function canSkip(_point, state) {
    // KnowledgeState 聚合器是 skipEligible 的唯一权威来源。PathEngine 不得
    // 根据 mastery、confidence 或代码证据字段再次推导跳过资格。
    return state?.skipEligible === true;
}
function difficultyRange(state) {
    switch (state?.status) {
        case "support_needed": return [0, 1];
        case "learning": return [1, 2];
        case "ready": return [2, 3];
        case "mastered": return [3, 4];
        default: return [0, 1];
    }
}
function scaffoldPreference(state) {
    switch (state?.status) {
        case "support_needed": return ["worked_example", "hint", "none"];
        case "learning": return ["hint", "worked_example", "none"];
        case "ready":
        case "mastered": return ["none", "hint", "worked_example"];
        default: return ["worked_example", "hint", "none"];
    }
}
function activityMinutes(activity) {
    return Number.isInteger(activity.estimatedMinutes) && activity.estimatedMinutes > 0
        ? activity.estimatedMinutes
        : 10;
}
function contentMinutes(point) {
    return Number.isInteger(point.contentEstimatedMinutes) && point.contentEstimatedMinutes > 0
        ? point.contentEstimatedMinutes
        : 0;
}
function activityDifficulty(activity) {
    return activity.difficulty && DIFFICULTIES.includes(activity.difficulty) ? activity.difficulty : "S-U";
}
function addReasons(target, ...reasons) {
    for (const reason of reasons)
        if (!target.includes(reason))
            target.push(reason);
}
export class PathEngine {
    profile;
    constructor(profile) {
        this.profile = profile;
        if (!Number.isInteger(profile.profileRevision) || profile.profileRevision < 1) {
            throw new PathEngineError("invalid_profile", "profileRevision must be a positive integer");
        }
        const pointIds = new Set();
        for (const point of profile.knowledgePoints) {
            if (pointIds.has(point.id))
                throw new PathEngineError("invalid_profile", `Duplicate knowledge point: ${point.id}`);
            pointIds.add(point.id);
        }
        const activityIds = new Set();
        for (const activity of profile.activities) {
            if (activityIds.has(activity.activityId))
                throw new PathEngineError("invalid_profile", `Duplicate activity: ${activity.activityId}`);
            activityIds.add(activity.activityId);
        }
        const goalIds = new Set();
        for (const goal of profile.goals) {
            if (goalIds.has(goal.goalId))
                throw new PathEngineError("invalid_profile", `Duplicate goal: ${goal.goalId}`);
            goalIds.add(goal.goalId);
            for (const pointId of goal.targetKnowledgePointIds) {
                if (!pointIds.has(pointId))
                    throw new PathEngineError("invalid_profile", `Goal ${goal.goalId} references missing point: ${pointId}`);
            }
            for (const activityId of goal.requiredActivityIds) {
                if (!activityIds.has(activityId))
                    throw new PathEngineError("invalid_profile", `Goal ${goal.goalId} references missing activity: ${activityId}`);
            }
            if (goal.finalActivityId !== undefined && !activityIds.has(goal.finalActivityId)) {
                throw new PathEngineError("invalid_profile", `Goal ${goal.goalId} references missing final activity: ${goal.finalActivityId}`);
            }
        }
        for (const point of profile.knowledgePoints) {
            for (const prerequisite of point.prerequisiteIds) {
                if (!pointIds.has(prerequisite))
                    throw new PathEngineError("invalid_profile", `Point ${point.id} references missing prerequisite: ${prerequisite}`);
            }
            for (const activityId of point.activityIds) {
                if (!activityIds.has(activityId))
                    throw new PathEngineError("invalid_profile", `Point ${point.id} references missing activity: ${activityId}`);
            }
        }
        for (const activity of profile.activities) {
            if (!pointIds.has(activity.primaryKnowledgePointId)) {
                throw new PathEngineError("invalid_profile", `Activity ${activity.activityId} references missing primary point`);
            }
            if (activity.supportingKnowledgePointIds.includes(activity.primaryKnowledgePointId)) {
                throw new PathEngineError("invalid_profile", `Activity ${activity.activityId} repeats its primary point as supporting point`);
            }
            for (const pointId of [...activity.supportingKnowledgePointIds]) {
                if (!pointIds.has(pointId))
                    throw new PathEngineError("invalid_profile", `Activity ${activity.activityId} references missing supporting point: ${pointId}`);
            }
            for (const goalId of activity.goalIds) {
                if (!goalIds.has(goalId))
                    throw new PathEngineError("invalid_profile", `Activity ${activity.activityId} references missing goal: ${goalId}`);
            }
        }
        this.assertAcyclicProfilePrerequisites();
    }
    assertAcyclicProfilePrerequisites() {
        const points = new Map(this.profile.knowledgePoints.map((point) => [point.id, point]));
        const visited = new Set();
        const visiting = new Set();
        const visit = (id) => {
            if (visited.has(id))
                return;
            if (visiting.has(id))
                throw new PathEngineError("invalid_profile", `Prerequisite cycle at ${id}`);
            visiting.add(id);
            for (const prerequisite of points.get(id)?.prerequisiteIds ?? [])
                visit(prerequisite);
            visiting.delete(id);
            visited.add(id);
        };
        for (const point of this.profile.knowledgePoints)
            visit(point.id);
    }
    build(input) {
        return this.buildInternal(input, new Set());
    }
    replan(input) {
        const completedIds = new Set(input.previousPath.nodes.filter((node) => node.status === "completed").map((node) => node.knowledgePointId));
        const result = this.buildInternal({ ...input, pathVersion: input.previousPath.pathVersion + 1 }, completedIds);
        if (result.status === "infeasible")
            return result;
        const fixed = new Map();
        input.previousPath.nodes.forEach((node, index) => {
            if (node.status === "completed" || node.status === "in_progress" || node.positionLocked || input.lockedNodeIds.includes(node.nodeId)) {
                fixed.set(node.nodeId, { index, node: structuredClone(node) });
            }
        });
        const mutable = result.path.nodes.filter((node) => !fixed.has(node.nodeId));
        const merged = [];
        for (const item of fixed.values())
            merged[item.index] = item.node;
        let cursor = 0;
        for (let index = 0; index < Math.max(merged.length, result.path.nodes.length); index += 1) {
            if (merged[index] !== undefined)
                continue;
            const next = mutable[cursor++];
            if (next)
                merged[index] = next;
        }
        for (; cursor < mutable.length; cursor += 1)
            merged.push(mutable[cursor]);
        result.path.nodes = merged.filter((node) => node !== undefined);
        result.path.estimatedMinutes = result.path.nodes.filter((node) => node.status !== "skipped")
            .reduce((total, node) => total + node.estimatedMinutes, 0);
        result.path.positionLockedNodeIds = result.path.nodes.filter((node) => node.positionLocked).map((node) => node.nodeId);
        const finalFailure = this.validateReplannedPath(result.path, input, fixed);
        if (finalFailure !== undefined)
            return { status: "infeasible", failure: finalFailure };
        result.path.changeReasons = this.changeReasons(input.previousPath, result.path, input);
        return result;
    }
    buildInternal(input, completedIds) {
        this.validateInput(input);
        const goal = this.profile.goals.find((item) => item.goalId === input.goalId);
        if (!goal)
            throw new PathEngineError("invalid_profile", `Unknown goal: ${input.goalId}`);
        const points = new Map(this.profile.knowledgePoints.map((point) => [point.id, point]));
        const activities = new Map(this.profile.activities.map((activity) => [activity.activityId, activity]));
        const requiredActivityIds = this.requiredActivityIds(goal);
        const targetIds = new Set(goal.targetKnowledgePointIds);
        for (const activityId of requiredActivityIds)
            targetIds.add(activities.get(activityId).primaryKnowledgePointId);
        const closure = this.prerequisiteClosure(targetIds, points);
        const selectedIds = new Set(input.selectedKnowledgePointIds);
        const unsupportedSelections = [...selectedIds].filter((id) => !closure.has(id));
        if (unsupportedSelections.length > 0)
            return this.failure(unsupportedSelections, 0, "change_goal");
        const states = new Map(input.knowledgeStates.map((state) => [state.knowledgePointId, state]));
        const missingPrerequisiteIds = [...closure].filter((id) => !targetIds.has(id) && !this.isPrerequisiteSatisfied(id, states, points, completedIds));
        const orderedIds = this.stableTopologicalOrder([...closure], points, targetIds, new Set(missingPrerequisiteIds));
        const nodes = [];
        for (const pointId of orderedIds) {
            const point = points.get(pointId);
            const state = states.get(pointId);
            const required = targetIds.has(pointId) || selectedIds.has(pointId) || (!canSkip(point, state) && this.isRequiredForTarget(pointId, targetIds, points));
            const pointActivityIds = point.activityIds.filter((id) => activities.has(id));
            const nodeActivities = this.selectNodeActivities(pointId, pointActivityIds, requiredActivityIds, activities, state, targetIds.has(pointId) || selectedIds.has(pointId));
            if (nodeActivities.length === 0)
                throw new PathEngineError("invalid_profile", `Knowledge point ${pointId} has no usable activity`);
            const reasons = [];
            if (required)
                addReasons(reasons, "goal_required");
            if (missingPrerequisiteIds.includes(pointId))
                addReasons(reasons, "prerequisite_gap");
            if (isLowMastery(state))
                addReasons(reasons, "low_mastery");
            if (!state || state.status === "unverified")
                addReasons(reasons, "evidence_insufficient");
            if (selectedIds.has(pointId))
                addReasons(reasons, "user_selected");
            const skipped = !required && canSkip(point, state);
            const status = skipped ? "skipped" : completedIds.has(pointId) ? "completed" : this.initialStatus(point, closure, states, points, completedIds);
            nodes.push({
                nodeId: `node-${pointId}`, knowledgePointId: pointId,
                activityIds: nodeActivities.map((activity) => activity.activityId), status,
                positionLocked: input.lockedNodeIds.includes(`node-${pointId}`) || input.lockedNodeIds.includes(pointId),
                required, difficulty: nodeActivities.map(activityDifficulty).sort((left, right) => DIFFICULTIES.indexOf(right) - DIFFICULTIES.indexOf(left))[0],
                scaffold: this.chooseNodeScaffold(nodeActivities, state),
                estimatedMinutes: contentMinutes(point) + nodeActivities.reduce((total, activity) => total + activityMinutes(activity), 0), reasonCodes: reasons,
            });
        }
        let estimatedMinutes = nodes.filter((node) => node.status !== "skipped").reduce((total, node) => total + node.estimatedMinutes, 0);
        if (estimatedMinutes > input.availableMinutes) {
            // 只压缩真实 Profile 活动中、且不属于 required/final 的可选活动。
            // 节点本身仍保留；必做节点、最终活动和不可跳过先修不可删除。
            const mandatoryActivityIds = new Set(requiredActivityIds);
            const optionalNodes = nodes.filter((node) => node.status !== "skipped" && node.required
                && this.profile.knowledgePoints.find((point) => point.id === node.knowledgePointId)?.activityPolicy !== "all_in_order")
                .map((node) => ({ node, optionalIds: node.activityIds.filter((id) => !mandatoryActivityIds.has(id)) }))
                .filter((item) => item.optionalIds.length > 0)
                .reverse();
            for (const { node, optionalIds } of optionalNodes) {
                const retained = node.activityIds.filter((id) => !optionalIds.includes(id));
                if (retained.length === 0)
                    continue;
                const selected = retained.map((id) => activities.get(id)).filter((activity) => activity !== undefined);
                const before = node.estimatedMinutes;
                node.activityIds = retained;
                node.estimatedMinutes = contentMinutes(this.profile.knowledgePoints.find((point) => point.id === node.knowledgePointId))
                    + selected.reduce((total, activity) => total + activityMinutes(activity), 0);
                node.difficulty = selected.map(activityDifficulty).sort((left, right) => DIFFICULTIES.indexOf(right) - DIFFICULTIES.indexOf(left))[0];
                node.scaffold = this.chooseNodeScaffold(selected, states.get(node.knowledgePointId));
                addReasons(node.reasonCodes, "time_compressed");
                estimatedMinutes -= before - node.estimatedMinutes;
                if (estimatedMinutes <= input.availableMinutes)
                    break;
            }
        }
        if (estimatedMinutes > input.availableMinutes)
            return this.failure(missingPrerequisiteIds, estimatedMinutes, "increase_time");
        const canonicalInput = { sessionId: input.sessionId, profileRevision: input.profileRevision, evidenceVersion: input.evidenceVersion, goalId: input.goalId, mode: input.mode, chapterId: input.chapterId, availableMinutes: input.availableMinutes, selectedKnowledgePointIds: [...input.selectedKnowledgePointIds].sort(compareIds), lockedNodeIds: [...input.lockedNodeIds].sort(compareIds), knowledgeStates: [...input.knowledgeStates].map((state) => ({ knowledgePointId: state.knowledgePointId, mastery: state.mastery, status: state.status, skipEligible: state.skipEligible, evidenceVersion: state.evidenceVersion })).sort((a, b) => compareIds(a.knowledgePointId, b.knowledgePointId)) };
        return { status: "ok", path: { pathId: `path-${hash(canonicalInput)}`, sessionId: input.sessionId, profileRevision: input.profileRevision, evidenceVersion: input.evidenceVersion, pathVersion: input.pathVersion ?? 1, engineVersion: "path-engine-v1", status: "draft", mode: input.mode, goalId: input.goalId, availableMinutes: input.availableMinutes, estimatedMinutes, nodes, positionLockedNodeIds: nodes.filter((node) => node.positionLocked).map((node) => node.nodeId), changeReasons: [], createdAt: input.createdAt ?? "1970-01-01T00:00:00.000Z" } };
    }
    validateInput(input) {
        if (!input.sessionId || input.profileRevision !== this.profile.profileRevision) {
            throw new PathEngineError("invalid_profile", "Session or profile revision is invalid");
        }
        assertPositiveInteger(input.availableMinutes, "availableMinutes");
        if (!Number.isInteger(input.evidenceVersion) || input.evidenceVersion < 0) {
            throw new PathEngineError("path_infeasible", "evidenceVersion must be a non-negative integer");
        }
        if (input.mode === "chapter" && (!input.chapterId || !this.profile.knowledgePoints.some((point) => point.chapterId === input.chapterId))) {
            throw new PathEngineError("invalid_profile", "chapterId is not present in the bound Profile");
        }
        const points = new Set(this.profile.knowledgePoints.map((point) => point.id));
        for (const id of [...input.selectedKnowledgePointIds, ...input.lockedNodeIds.map((item) => item.replace(/^node-/u, ""))]) {
            if (!points.has(id))
                throw new PathEngineError("invalid_profile", `Unknown knowledge point constraint: ${id}`);
        }
    }
    prerequisiteClosure(targetIds, points) {
        const closure = new Set();
        const visiting = new Set();
        const visit = (id) => {
            if (closure.has(id))
                return;
            if (visiting.has(id))
                throw new PathEngineError("invalid_profile", `Prerequisite cycle at ${id}`);
            const point = points.get(id);
            if (!point)
                throw new PathEngineError("invalid_profile", `Unknown knowledge point: ${id}`);
            visiting.add(id);
            for (const prerequisite of point.prerequisiteIds)
                visit(prerequisite);
            visiting.delete(id);
            closure.add(id);
        };
        for (const id of targetIds)
            visit(id);
        return closure;
    }
    isRequiredForTarget(id, targets, points) {
        for (const target of targets) {
            const seen = new Set();
            const walk = (current) => {
                if (current === id)
                    return true;
                if (seen.has(current))
                    return false;
                seen.add(current);
                return (points.get(current)?.prerequisiteIds ?? []).some(walk);
            };
            if (walk(target))
                return true;
        }
        return false;
    }
    stableTopologicalOrder(ids, points, targets, gaps) {
        const declaration = new Map(this.profile.knowledgePoints.map((point, index) => [point.id, index]));
        const remaining = new Set(ids);
        const result = [];
        while (remaining.size > 0) {
            const ready = [...remaining].filter((id) => (points.get(id)?.prerequisiteIds ?? []).every((prerequisite) => !remaining.has(prerequisite)));
            if (ready.length === 0)
                throw new PathEngineError("invalid_profile", "Prerequisite graph contains a cycle");
            ready.sort((left, right) => {
                const lp = points.get(left);
                const rp = points.get(right);
                const targetCompare = Number(targets.has(right)) - Number(targets.has(left));
                if (targetCompare !== 0)
                    return targetCompare;
                const gapCompare = Number(gaps.has(right)) - Number(gaps.has(left));
                if (gapCompare !== 0)
                    return gapCompare;
                const importanceCompare = rp.importance - lp.importance;
                if (importanceCompare !== 0)
                    return importanceCompare;
                return (declaration.get(left) ?? Number.MAX_SAFE_INTEGER) - (declaration.get(right) ?? Number.MAX_SAFE_INTEGER)
                    || compareIds(left, right);
            });
            for (const id of ready) {
                remaining.delete(id);
                result.push(id);
            }
        }
        return result;
    }
    requiredActivityIds(goal) {
        const ids = [...goal.requiredActivityIds];
        if (goal.finalActivityId !== undefined && !ids.includes(goal.finalActivityId))
            ids.push(goal.finalActivityId);
        return ids;
    }
    selectNodeActivities(pointId, pointActivityIds, requiredActivityIds, activities, state, allowOptional) {
        const point = this.profile.knowledgePoints.find((item) => item.id === pointId);
        if (point?.activityPolicy === "all_in_order") {
            const orderedIds = [...pointActivityIds];
            for (const requiredId of requiredActivityIds) {
                const required = activities.get(requiredId);
                if (required?.primaryKnowledgePointId === pointId && !orderedIds.includes(requiredId))
                    orderedIds.push(requiredId);
            }
            return orderedIds
                .map((id) => activities.get(id))
                .filter((activity) => activity !== undefined);
        }
        const required = requiredActivityIds
            .map((id) => activities.get(id))
            .filter((activity) => activity !== undefined && activity.primaryKnowledgePointId === pointId);
        if (required.length > 0) {
            if (!allowOptional)
                return required;
            const declaration = new Map(this.profile.activities.map((activity, index) => [activity.activityId, index]));
            const optional = pointActivityIds.map((id) => activities.get(id))
                .filter((activity) => activity !== undefined && !required.some((item) => item.activityId === activity.activityId));
            const [minimum, maximum] = difficultyRange(state);
            const distance = (activity) => {
                const rank = DIFFICULTIES.indexOf(activityDifficulty(activity));
                return rank < minimum ? minimum - rank : rank > maximum ? rank - maximum : 0;
            };
            optional.sort((left, right) => distance(left) - distance(right)
                || (declaration.get(left.activityId) ?? Number.MAX_SAFE_INTEGER) - (declaration.get(right.activityId) ?? Number.MAX_SAFE_INTEGER)
                || compareIds(left.activityId, right.activityId));
            return optional[0] === undefined ? required : [...required, optional[0]];
        }
        const declaration = new Map(this.profile.activities.map((activity, index) => [activity.activityId, index]));
        const candidates = pointActivityIds.map((id) => activities.get(id)).filter((activity) => activity !== undefined);
        const [minimum, maximum] = difficultyRange(state);
        const distance = (activity) => {
            const rank = DIFFICULTIES.indexOf(activityDifficulty(activity));
            return rank < minimum ? minimum - rank : rank > maximum ? rank - maximum : 0;
        };
        const fallback = candidates.sort((left, right) => distance(left) - distance(right)
            || (declaration.get(left.activityId) ?? Number.MAX_SAFE_INTEGER) - (declaration.get(right.activityId) ?? Number.MAX_SAFE_INTEGER)
            || compareIds(left.activityId, right.activityId))[0];
        return fallback === undefined ? [] : [fallback];
    }
    chooseNodeScaffold(activities, state) {
        const allowedSets = activities.map((activity) => new Set(activity.allowedScaffolds?.filter((item) => SCAFFOLDS.includes(item)) ?? ["none"]));
        const common = SCAFFOLDS.filter((level) => allowedSets.every((allowed) => allowed.has(level)));
        if (common.length === 0)
            throw new PathEngineError("invalid_profile", "Required activities do not share an allowed scaffold");
        return scaffoldPreference(state).find((item) => common.includes(item)) ?? common[0];
    }
    initialStatus(point, closure, states, points, completedIds) {
        const blocked = point.prerequisiteIds.some((id) => closure.has(id) && !this.isPrerequisiteSatisfied(id, states, points, completedIds));
        return blocked ? "locked" : "available";
    }
    isPrerequisiteSatisfied(id, states, points, completedIds) {
        return completedIds.has(id) || canSkip(points.get(id), states.get(id));
    }
    validateReplannedPath(path, input, fixed) {
        const points = new Map(this.profile.knowledgePoints.map((point) => [point.id, point]));
        const activities = new Map(this.profile.activities.map((activity) => [activity.activityId, activity]));
        const goal = this.profile.goals.find((item) => item.goalId === path.goalId);
        if (goal === undefined)
            throw new PathEngineError("invalid_profile", `Unknown goal: ${path.goalId}`);
        const required = this.requiredActivityIds(goal);
        const nodeIds = new Set();
        const pointIds = new Set();
        const positions = new Map();
        let estimatedMinutes = 0;
        for (const [index, node] of path.nodes.entries()) {
            if (nodeIds.has(node.nodeId) || pointIds.has(node.knowledgePointId))
                return this.failureDetails([], path.estimatedMinutes, "change_goal");
            nodeIds.add(node.nodeId);
            pointIds.add(node.knowledgePointId);
            positions.set(node.knowledgePointId, index);
            const point = points.get(node.knowledgePointId);
            if (!point || node.activityIds.length === 0)
                return this.failureDetails([], path.estimatedMinutes, "change_goal");
            const selected = node.activityIds.map((id) => activities.get(id));
            if (selected.some((activity) => activity === undefined || activity.primaryKnowledgePointId !== node.knowledgePointId)) {
                return this.failureDetails([], path.estimatedMinutes, "change_goal");
            }
            const actualMinutes = contentMinutes(point) + selected.reduce((total, activity) => total + activityMinutes(activity), 0);
            if (node.estimatedMinutes !== actualMinutes)
                return this.failureDetails([], path.estimatedMinutes, "change_goal");
            if (node.status !== "skipped")
                estimatedMinutes += node.estimatedMinutes;
            if (point.prerequisiteIds.some((id) => (positions.get(id) ?? Number.MAX_SAFE_INTEGER) >= index)) {
                return this.failureDetails([], path.estimatedMinutes, "change_goal");
            }
        }
        for (const [nodeId, item] of fixed) {
            const node = path.nodes[item.index];
            if (node?.nodeId !== nodeId || stableJson(node) !== stableJson(item.node)) {
                return this.failureDetails([], path.estimatedMinutes, "change_goal");
            }
        }
        if (required.some((activityId) => !path.nodes.some((node) => node.activityIds.includes(activityId)))) {
            return this.failureDetails([], path.estimatedMinutes, "change_goal");
        }
        const states = new Map(input.knowledgeStates.map((state) => [state.knowledgePointId, state]));
        const completed = new Set(path.nodes.filter((node) => node.status === "completed").map((node) => node.knowledgePointId));
        for (const node of path.nodes) {
            const point = points.get(node.knowledgePointId);
            const prerequisitesSatisfied = point.prerequisiteIds.every((id) => this.isPrerequisiteSatisfied(id, states, points, completed));
            if (node.status === "locked" && prerequisitesSatisfied)
                return this.failureDetails([], path.estimatedMinutes, "change_goal");
            if ((node.status === "available" || node.status === "in_progress") && !prerequisitesSatisfied) {
                return this.failureDetails([], path.estimatedMinutes, "change_goal");
            }
            if (node.status === "skipped" && !canSkip(point, states.get(point.id)) && !completed.has(point.id)) {
                return this.failureDetails([], path.estimatedMinutes, "change_goal");
            }
        }
        if (estimatedMinutes !== path.estimatedMinutes || path.estimatedMinutes > input.availableMinutes) {
            const missing = path.nodes.filter((node) => node.reasonCodes.includes("prerequisite_gap")).map((node) => node.knowledgePointId);
            return this.failureDetails(missing, estimatedMinutes, "increase_time");
        }
        return undefined;
    }
    changeReasons(previous, next, input) {
        const pathChanged = stableJson(previous.nodes) !== stableJson(next.nodes)
            || previous.estimatedMinutes !== next.estimatedMinutes
            || previous.availableMinutes !== next.availableMinutes;
        if (!pathChanged)
            return [];
        const oldCodes = new Set(previous.nodes.flatMap((node) => node.reasonCodes));
        const newCodes = new Set(next.nodes.flatMap((node) => node.reasonCodes));
        const symmetric = (reason) => oldCodes.has(reason) !== newCodes.has(reason);
        const optionalActivityRemoved = previous.nodes.some((oldNode) => {
            const nextNode = next.nodes.find((candidate) => candidate.nodeId === oldNode.nodeId);
            return nextNode !== undefined
                && oldNode.required
                && oldNode.activityIds.some((id) => !nextNode.activityIds.includes(id))
                && nextNode.reasonCodes.includes("time_compressed");
        });
        const actualBudgetCompression = input.availableMinutes < previous.availableMinutes
            && optionalActivityRemoved
            && newCodes.has("time_compressed");
        const prerequisiteAvailabilityChanged = previous.nodes.some((oldNode) => {
            const nextNode = next.nodes.find((candidate) => candidate.nodeId === oldNode.nodeId);
            return nextNode !== undefined && (oldNode.status === "locked") !== (nextNode.status === "locked");
        });
        const reasons = [];
        const candidates = [
            ["error_remediation", input.trigger === "error_remediation" && pathChanged],
            ["time_compressed", actualBudgetCompression],
            ["user_selected", symmetric("user_selected")],
            ["evidence_insufficient", symmetric("evidence_insufficient")],
            ["low_mastery", symmetric("low_mastery")],
            ["prerequisite_gap", symmetric("prerequisite_gap") || prerequisiteAvailabilityChanged],
        ];
        for (const [reason, enabled] of candidates)
            if (enabled)
                reasons.push(reason);
        return reasons;
    }
    failure(missingPrerequisiteIds, minimumRequiredMinutes, preferred) {
        return { status: "infeasible", failure: this.failureDetails(missingPrerequisiteIds, minimumRequiredMinutes, preferred) };
    }
    failureDetails(missingPrerequisiteIds, minimumRequiredMinutes, preferred) {
        return {
            code: "path_infeasible",
            missingPrerequisiteIds: [...new Set(missingPrerequisiteIds)].sort(compareIds),
            minimumRequiredMinutes,
            suggestions: [preferred, preferred === "increase_time" ? "change_goal" : "increase_time", "run_probe"],
        };
    }
}
