import type { ActivityReferenceDefinition, Difficulty, KnowledgePointDefinition, KnowledgeState, LearningGoalDefinition } from "./v2-types.js";
import type { ScaffoldLevel } from "../contracts/domain.js";
export type { ScaffoldLevel } from "../contracts/domain.js";
export type PathMode = "chapter" | "recommended";
export type PathStatus = "draft" | "confirmed" | "superseded";
export type PathNodeStatus = "locked" | "available" | "in_progress" | "completed" | "skipped";
export type PathReasonCode = "prerequisite_gap" | "low_mastery" | "goal_required" | "review_due" | "user_selected" | "error_remediation" | "time_compressed" | "evidence_insufficient";
export interface PathActivityDefinition extends ActivityReferenceDefinition {
    title?: string;
    prompt?: string;
    difficulty?: Difficulty;
    estimatedMinutes?: number;
    allowedScaffolds?: ScaffoldLevel[];
    kind?: "mcq" | "code_completion" | "coding_practical" | "explain" | "debug";
    starterCode?: string;
    profileRevision?: number;
}
export interface PathEngineProfile {
    subjectId?: string;
    profileRevision: number;
    goals: LearningGoalDefinition[];
    knowledgePoints: KnowledgePointDefinition[];
    activities: PathActivityDefinition[];
}
export interface LearningPathNode {
    nodeId: string;
    knowledgePointId: string;
    activityIds: string[];
    status: PathNodeStatus;
    positionLocked: boolean;
    required: boolean;
    difficulty: Difficulty;
    scaffold: ScaffoldLevel;
    estimatedMinutes: number;
    reasonCodes: PathReasonCode[];
}
export interface LearningPath {
    pathId: string;
    sessionId: string;
    profileRevision: number;
    evidenceVersion: number;
    pathVersion: number;
    engineVersion: "path-engine-v1";
    status: PathStatus;
    mode: PathMode;
    goalId: string;
    availableMinutes: number;
    estimatedMinutes: number;
    nodes: LearningPathNode[];
    positionLockedNodeIds: string[];
    changeReasons: PathReasonCode[];
    createdAt: string;
}
export interface PathFailure {
    code: "path_infeasible";
    missingPrerequisiteIds: string[];
    minimumRequiredMinutes: number;
    suggestions: Array<"increase_time" | "change_goal" | "run_probe">;
}
export type PathBuildResult = {
    status: "ok";
    path: LearningPath;
} | {
    status: "infeasible";
    failure: PathFailure;
};
export interface PathEngineInput {
    sessionId: string;
    profileRevision: number;
    evidenceVersion: number;
    goalId: string;
    mode: PathMode;
    chapterId?: string;
    availableMinutes: number;
    selectedKnowledgePointIds: string[];
    lockedNodeIds: string[];
    knowledgeStates: KnowledgeState[];
    pathVersion?: number;
    createdAt?: string;
}
export interface PathEngineReplanInput extends PathEngineInput {
    previousPath: LearningPath;
    trigger: "knowledge_state_changed" | "skip_eligibility_changed" | "error_remediation" | "user_constraint_changed";
}
export declare class PathEngineError extends Error {
    readonly errorCode: "invalid_profile" | "path_infeasible";
    constructor(errorCode: "invalid_profile" | "path_infeasible", message: string);
}
export declare class PathEngine {
    readonly profile: PathEngineProfile;
    constructor(profile: PathEngineProfile);
    private assertAcyclicProfilePrerequisites;
    build(input: PathEngineInput): PathBuildResult;
    replan(input: PathEngineReplanInput): PathBuildResult;
    private buildInternal;
    private validateInput;
    private prerequisiteClosure;
    private isRequiredForTarget;
    private stableTopologicalOrder;
    private requiredActivityIds;
    private selectNodeActivities;
    private chooseNodeScaffold;
    private initialStatus;
    private isPrerequisiteSatisfied;
    private validateReplannedPath;
    private changeReasons;
    private failure;
    private failureDetails;
}
