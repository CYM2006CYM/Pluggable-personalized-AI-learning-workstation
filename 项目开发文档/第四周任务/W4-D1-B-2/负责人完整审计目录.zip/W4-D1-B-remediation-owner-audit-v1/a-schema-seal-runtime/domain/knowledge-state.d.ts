import type { Evidence, EvidenceIndependence, EvidenceSource, KnowledgeState, LearningRuntimeErrorCode } from "./v2-types.js";
export declare const KNOWLEDGE_AGGREGATION_VERSION: "knowledge-state-v1";
export declare const EVIDENCE_SOURCE_WEIGHTS: Readonly<Record<EvidenceSource, number>>;
export declare const EVIDENCE_INDEPENDENCE_WEIGHTS: Readonly<Record<EvidenceIndependence, number>>;
export declare class KnowledgeStateCalculationError extends Error {
    readonly errorCode: LearningRuntimeErrorCode;
    constructor(message: string);
}
export interface CalculateKnowledgeStateInput {
    knowledgePointId: string;
    profileRevision: number;
    evidenceVersion: number;
    evidence: readonly Evidence[];
    asOf: string | Date;
    requiresCodeEvidence?: boolean;
    nonSkippable?: boolean;
}
export declare function calculateKnowledgeState(input: CalculateKnowledgeStateInput): KnowledgeState;
export interface CalculateKnowledgeStatesInput {
    knowledgePoints: ReadonlyArray<{
        id: string;
        requiresCodeEvidence?: boolean;
        nonSkippable?: boolean;
    }>;
    profileRevision: number;
    evidenceVersion: number;
    evidence: readonly Evidence[];
    asOf: string | Date;
}
export declare function calculateKnowledgeStates(input: CalculateKnowledgeStatesInput): KnowledgeState[];
