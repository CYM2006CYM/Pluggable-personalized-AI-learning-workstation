import type { Profile } from "./types.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";
export interface StudyScopeOption {
    id: string;
    label: string;
    chapterId: string;
    knowledgePointIds: string[];
    materialPaths: string[];
    cards: StudyCardOption[];
    sections: StudySectionOption[];
}
export interface StudyCardOption {
    id: string;
    label: string;
    path: string;
}
export interface StudySectionOption {
    id: string;
    label: string;
    path: string;
    knowledgePointIds: string[];
}
export interface ActiveStudyContext {
    profile: Profile;
    scope: StudyScopeOption;
    material: string;
}
export type StudyTargetKind = "scope" | "card" | "section";
export interface ActiveStudyTargetContext extends ActiveStudyContext {
    target: {
        kind: StudyTargetKind;
        id: string;
        label: string;
        knowledgePointIds: string[];
    };
}
export declare function listStudyScopes(repository: ProfileFamilyRepository, subjectId: string): Promise<StudyScopeOption[]>;
export declare function loadActiveStudyTargetContext(repository: ProfileFamilyRepository, subjectId: string, scopeId: string, targetKind: StudyTargetKind, targetId: string, maxCharacters?: number): Promise<ActiveStudyTargetContext>;
export declare function loadActiveStudyContext(repository: ProfileFamilyRepository, subjectId: string, scopeId: string, maxCharacters?: number): Promise<ActiveStudyContext>;
