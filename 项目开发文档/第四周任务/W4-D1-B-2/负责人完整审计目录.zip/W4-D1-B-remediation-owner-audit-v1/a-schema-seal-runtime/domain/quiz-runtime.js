import { createHash, randomUUID } from "node:crypto";
export class QuizRuntimeError extends Error {
    errorCode;
    constructor(errorCode, message) {
        super(message);
        this.errorCode = errorCode;
        this.name = "QuizRuntimeError";
    }
}
function hash(value) {
    return createHash("sha256").update(JSON.stringify(value), "utf8").digest("hex").slice(0, 24);
}
function safeQuestion(question) {
    return {
        questionId: question.questionId,
        kind: question.kind,
        prompt: question.prompt,
        options: [...question.options],
    };
}
function validatePrivateQuestions(questions) {
    const ids = new Set();
    for (const question of questions) {
        if (!question.questionId || ids.has(question.questionId))
            throw new QuizRuntimeError("submission_contract_error", "Quiz question IDs must be unique");
        ids.add(question.questionId);
        if (question.kind !== "single_choice" && question.kind !== "judgment")
            throw new QuizRuntimeError("submission_contract_error", "Quiz question kind is invalid");
        if (!question.prompt || !Array.isArray(question.options))
            throw new QuizRuntimeError("submission_contract_error", "Quiz question safe shape is invalid");
        if (question.kind === "single_choice" && (typeof question.correctAnswer !== "string" || !question.options.includes(question.correctAnswer))) {
            throw new QuizRuntimeError("submission_contract_error", "Quiz answer key does not match options");
        }
        if (question.kind === "judgment" && typeof question.correctAnswer !== "boolean")
            throw new QuizRuntimeError("submission_contract_error", "Judgment answer must be boolean");
    }
}
export class DeterministicQuizRuntime {
    attempts = new Map();
    submissions = new Map();
    open(input) {
        if (input.activity.profileRevision !== input.profileRevision)
            throw new QuizRuntimeError("activity_version_conflict", "Activity revision does not match session");
        validatePrivateQuestions(input.questions);
        const excluded = new Set(input.excludedQuestionIds ?? []);
        const questions = input.questions.filter((question) => !excluded.has(question.questionId));
        const attemptId = input.requestId === undefined
            ? `attempt-${randomUUID()}`
            : `attempt-${hash(`${input.sessionId}:${input.activity.activityId}:${input.requestId}`)}`;
        const snapshot = {
            attemptId,
            sessionId: input.sessionId,
            activityId: input.activity.activityId,
            activityVersion: input.activity.activityVersion,
            profileRevision: input.profileRevision,
            title: input.activity.title,
            prompt: input.activity.prompt,
            primaryKnowledgePointId: input.activity.primaryKnowledgePointId,
            supportingKnowledgePointIds: [...input.activity.supportingKnowledgePointIds],
            retryNumber: input.retryNumber,
            questions: structuredClone(questions),
            status: "draft",
            ...(input.requestId === undefined ? {} : { openedRequestId: input.requestId }),
        };
        this.attempts.set(attemptId, snapshot);
        return {
            attemptId,
            activity: {
                activityId: input.activity.activityId,
                activityVersion: input.activity.activityVersion,
                kind: "mcq",
                title: input.activity.title,
                prompt: input.activity.prompt,
                primaryKnowledgePointId: input.activity.primaryKnowledgePointId,
                supportingKnowledgePointIds: [...input.activity.supportingKnowledgePointIds],
                questions: questions.map(safeQuestion),
                retryNumber: input.retryNumber,
            },
        };
    }
    getAttempt(attemptId) {
        const attempt = this.attempts.get(attemptId);
        if (!attempt)
            throw new QuizRuntimeError("attempt_not_found", "Quiz attempt does not exist");
        return structuredClone(attempt);
    }
    restore(attempt) {
        validatePrivateQuestions(attempt.questions);
        this.attempts.set(attempt.attemptId, structuredClone(attempt));
    }
    submit(input) {
        const attempt = this.attempts.get(input.attemptId);
        if (!attempt)
            throw new QuizRuntimeError("attempt_not_found", "Quiz attempt does not exist");
        if (attempt.sessionId !== input.sessionId || attempt.profileRevision !== input.profileRevision || attempt.activityId !== input.activity.activityId || attempt.activityVersion !== input.activity.activityVersion) {
            throw new QuizRuntimeError("activity_version_conflict", "Quiz attempt binding does not match");
        }
        const identity = { ...input, now: undefined };
        const submissionHash = hash(identity);
        const existing = this.submissions.get(`${input.requestId}:${input.attemptId}`);
        if (existing) {
            if (existing.hash !== submissionHash)
                throw new QuizRuntimeError("idempotency_conflict", "Quiz requestId has different content");
            return structuredClone(existing.commit);
        }
        if (attempt.status === "submitted") {
            if (attempt.submissionRequestId !== input.requestId || attempt.submissionHash !== submissionHash || attempt.result === undefined) {
                throw new QuizRuntimeError("idempotency_conflict", "Quiz Attempt was submitted with different content");
            }
            const replay = {
                result: structuredClone(attempt.result),
                attempt: structuredClone(attempt),
                ...(attempt.result.verdict === "insufficient" ? {} : { evidence: createEvidence(input, attempt.result) }),
            };
            this.submissions.set(`${input.requestId}:${input.attemptId}`, { hash: submissionHash, commit: structuredClone(replay) });
            return replay;
        }
        const expected = new Map(attempt.questions.map((question) => [question.questionId, question]));
        if (input.answers.length !== expected.size)
            throw new QuizRuntimeError("submission_contract_error", "Quiz submission must cover every question exactly once");
        const seen = new Set();
        let correctCount = 0;
        const review = [];
        for (const answer of input.answers) {
            if (typeof answer !== "object" || answer === null || Array.isArray(answer)
                || Object.keys(answer).some((key) => key !== "questionId" && key !== "answer")) {
                throw new QuizRuntimeError("submission_contract_error", "Quiz answer contains unsupported fields");
            }
            const question = expected.get(answer.questionId);
            if (!question || seen.has(answer.questionId))
                throw new QuizRuntimeError("submission_contract_error", "Quiz submission contains an unknown or duplicate question");
            seen.add(answer.questionId);
            const validType = question.kind === "single_choice" ? typeof answer.answer === "string" && question.options.includes(answer.answer) : typeof answer.answer === "boolean";
            if (!validType)
                throw new QuizRuntimeError("submission_contract_error", "Quiz answer type does not match the question");
            const correct = answer.answer === question.correctAnswer;
            if (correct)
                correctCount += 1;
            review.push({ questionId: question.questionId, correct, correctAnswer: question.correctAnswer, explanation: question.explanation, sourceAnchorIds: [...question.sourceAnchorIds] });
        }
        const totalCount = expected.size;
        const requiredCorrectCount = Math.ceil(totalCount * 0.75);
        const verdict = totalCount < 4 ? "insufficient" : correctCount >= requiredCorrectCount ? "pass" : correctCount === 0 ? "fail" : "partial";
        const result = {
            kind: "quiz",
            verdict,
            correctCount,
            totalCount,
            requiredCorrectCount,
            retryAllowed: verdict !== "pass" && attempt.retryNumber === 0,
            safeFeedback: verdict === "pass" ? "题组已通过。" : verdict === "insufficient" ? "当前题组不足以形成确定性判定。" : "本次结果已记录，可进行一次重试。",
            answerReview: review,
        };
        attempt.status = "submitted";
        attempt.result = structuredClone(result);
        attempt.submissionRequestId = input.requestId;
        attempt.submissionHash = submissionHash;
        attempt.submittedAt = input.now ?? new Date().toISOString();
        const commit = {
            result,
            attempt: structuredClone(attempt),
            ...(verdict === "insufficient" ? {} : {
                evidence: createEvidence(input, result),
            }),
        };
        this.submissions.set(`${input.requestId}:${input.attemptId}`, { hash: submissionHash, commit: structuredClone(commit) });
        return commit;
    }
}
function createEvidence(input, result) {
    return {
        evidenceId: `evidence-${hash(`${input.sessionId}:${input.attemptId}`)}`,
        requestId: input.requestId,
        sessionId: input.sessionId,
        knowledgePointId: input.knowledgePointId,
        profileRevision: input.profileRevision,
        kind: "mcq",
        source: "deterministic_quiz",
        form: "selected_response",
        impact: "mastery",
        outcome: result.verdict === "pass" ? "correct" : result.verdict === "partial" ? "partial" : "incorrect",
        score: result.totalCount === 0 ? 0 : result.correctCount / result.totalCount,
        independence: "independent",
        activityId: input.activity.activityId,
        attemptId: input.attemptId,
        createdAt: input.now ?? new Date().toISOString(),
    };
}
