export interface SourceInventoryLimits {
    maxFiles: number;
    maxFileBytes: number;
    maxTotalBytes: number;
    batchCharacters: number;
}
export declare const DEFAULT_SOURCE_INVENTORY_LIMITS: SourceInventoryLimits;
export interface SourceFileInventory {
    sourceId: string;
    relativePath: string;
    sha256: string;
    bytes: number;
    characters: number;
}
export interface SourceInventory {
    root: string;
    files: SourceFileInventory[];
    totalBytes: number;
    totalCharacters: number;
}
export interface SourceBatch {
    index: number;
    files: Array<SourceFileInventory & {
        startCharacter?: number;
        endCharacter?: number;
    }>;
    characters: number;
}
export interface LoadedSourceBatch {
    index: number;
    sources: Array<SourceFileInventory & {
        content: string;
    }>;
}
export declare function inventorySourceDirectory(sourceRoot: string, limits?: SourceInventoryLimits): Promise<SourceInventory>;
export declare function createSourceBatches(inventory: SourceInventory, batchCharacters?: number): SourceBatch[];
export declare function loadSourceBatch(inventory: SourceInventory, batch: SourceBatch): Promise<LoadedSourceBatch>;
