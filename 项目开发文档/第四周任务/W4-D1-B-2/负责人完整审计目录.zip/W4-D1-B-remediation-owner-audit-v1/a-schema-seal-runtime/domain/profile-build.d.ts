import type { DifficultyLevel, QuestionType } from "./types.js";
import type { SourceInventory } from "./source-inventory.js";
export interface ProfileBuildKnowledgePoint {
    id: string;
    name: string;
    aliases: string[];
    tags: string[];
    definition: string;
    key_points: string[];
    common_misconceptions: string[];
    related: string[];
    question_types: Array<Exclude<QuestionType, "multi_choice">>;
    difficulty_baseline: DifficultyLevel;
    source_ids: string[];
}
export interface ProfileBuildSection {
    title: string;
    markdown: string;
    source_ids: string[];
    knowledge_points: ProfileBuildKnowledgePoint[];
}
export interface ProfileBuildChapter {
    title: string;
    source_ids: string[];
    sections: ProfileBuildSection[];
}
export interface ProfileBuildFragment {
    subject_overview: string;
    chapters: ProfileBuildChapter[];
    warnings: string[];
}
export interface CanonicalProfileBuild {
    files: Map<string, string>;
    metrics: {
        chapters: number;
        sections: number;
        knowledgePoints: number;
        cards: number;
        examPoints: number;
        mappedSources: number;
        warnings: string[];
    };
}
export declare function assembleCanonicalProfile(subjectName: string, inventory: SourceInventory, fragments: readonly ProfileBuildFragment[]): CanonicalProfileBuild;
