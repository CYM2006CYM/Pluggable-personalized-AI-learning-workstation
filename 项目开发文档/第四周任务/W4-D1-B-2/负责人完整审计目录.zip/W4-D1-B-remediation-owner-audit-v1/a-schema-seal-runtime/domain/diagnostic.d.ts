import type { Difficulty, JsonValue, LearningRuntimeErrorCode } from "./v2-types.js";
export type DiagnosticQuestionKind = "single_choice" | "judgment";
export interface DiagnosticBlueprintAsset {
    blueprintId: string;
    profileRevision: number;
    goalIds: string[];
    estimatedMinutes: number;
    minimumCoverage: number;
    questions: DiagnosticQuestionAsset[];
    scoringVersion: string;
    [extensionName: `x-${string}`]: JsonValue;
}
export interface DiagnosticQuestionAsset {
    questionId: string;
    knowledgePointId: string;
    kind: DiagnosticQuestionKind;
    difficulty: Difficulty;
    prompt: string;
    options?: string[];
    maxScore: number;
    required: boolean;
    evaluatorRef: string;
    sourceAnchorIds: string[];
}
export interface DiagnosticAnswerKeyAsset {
    blueprintId: string;
    evaluatorVersion: string;
    answers: DiagnosticAnswerKeyEntry[];
}
export type DiagnosticAnswerKeyEntry = {
    questionId: string;
    kind: "single_choice";
    correctAnswer: string;
} | {
    questionId: string;
    kind: "judgment";
    correctAnswer: boolean;
};
export interface DiagnosticAnswerRecord {
    questionId: string;
    requestId: string;
    status: "answered" | "skipped";
    submittedAnswer?: string | boolean;
    normalizedScore?: number;
    evidenceId?: string;
    evaluatorVersion?: string;
    createdAt: string;
}
export declare class DiagnosticValidationError extends Error {
    readonly errorCode: LearningRuntimeErrorCode;
    constructor(errorCode: LearningRuntimeErrorCode, message: string);
}
export declare function parseDiagnosticBlueprint(value: unknown): DiagnosticBlueprintAsset;
export declare function parseDiagnosticAnswerKey(value: unknown, blueprint: DiagnosticBlueprintAsset): DiagnosticAnswerKeyAsset;
