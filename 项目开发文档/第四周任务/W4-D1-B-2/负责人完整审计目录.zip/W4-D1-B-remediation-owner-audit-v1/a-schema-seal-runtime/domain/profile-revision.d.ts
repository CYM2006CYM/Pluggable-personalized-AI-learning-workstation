export type ProfileRevisionOperation = "create" | "update" | "delete";
export interface ProfileRevisionPlanItem {
    path: string;
    operation: ProfileRevisionOperation;
    reason: string;
}
export interface ProfileRevisionPlan {
    summary: string;
    requires_clarification: boolean;
    clarification_question: string;
    operations: ProfileRevisionPlanItem[];
    warnings: string[];
}
export interface ProfileRevisionChange extends ProfileRevisionPlanItem {
    content?: string;
}
export interface ProfileRevisionPatch {
    summary: string;
    changes: ProfileRevisionChange[];
    unresolved: string[];
}
export interface ProfileRevisionQualityReview {
    report_markdown: string;
    blocking_issues: string[];
    warnings: string[];
    recommendation: "enable" | "revise";
}
export interface ProfileFileSnapshot {
    path: string;
    content: string;
}
export interface ProfileStructureInspection {
    blockingIssues: string[];
    warnings: string[];
    metrics: {
        files: number;
        chapters: number;
        sections: number;
        knowledgePoints: number;
        cards: number;
        examPoints: number;
    };
}
export interface ProfileContentDifference {
    path: string;
    before: string | null;
    after: string | null;
}
export declare function isMutableProfileContentPath(path: string): boolean;
export declare function assertValidRevisionPlan(plan: ProfileRevisionPlan, existingPaths: readonly string[]): void;
export declare function assertValidRevisionPatch(patch: ProfileRevisionPatch, plan: ProfileRevisionPlan): void;
export declare function inspectProfileStructure(files: readonly ProfileFileSnapshot[]): ProfileStructureInspection;
export declare function profileContentDifferences(beforeFiles: readonly ProfileFileSnapshot[], afterFiles: readonly ProfileFileSnapshot[], ignoredPaths?: readonly string[]): ProfileContentDifference[];
export declare function plannedContentDifferences(beforeFiles: readonly ProfileFileSnapshot[], changes: readonly ProfileRevisionChange[]): ProfileContentDifference[];
