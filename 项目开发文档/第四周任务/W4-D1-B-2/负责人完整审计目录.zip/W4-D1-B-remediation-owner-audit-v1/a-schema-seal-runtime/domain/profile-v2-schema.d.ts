import type { ProfileManifestV2, ProfileStatus } from "./v2-types.js";
export declare function parseProfileManifestV2(raw: string, expectedStatus?: ProfileStatus): ProfileManifestV2;
/**
 * Validates the W1-C3 manifest, conditional assets, containment, the three core
 * JSON assets, and their frozen cross-file closure. Professional validation of
 * sources, datasets, tests, rubrics, reference solutions, and environments is
 * intentionally owned by their later contracts and is not performed here.
 */
export declare function validateProfileV2Directory(directory: string, expectedStatus?: ProfileStatus): Promise<ProfileManifestV2>;
