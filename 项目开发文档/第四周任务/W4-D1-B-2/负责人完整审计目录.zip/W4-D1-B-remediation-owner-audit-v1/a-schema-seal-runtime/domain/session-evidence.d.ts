import type { Attempt, DifficultyLevel, QuestionType, ReviewMode, SessionStatus, StudySession } from "./types.js";
export declare const SESSION_EVIDENCE_LIMITS: {
    readonly identifier: 160;
    readonly timestamp: 64;
    readonly scope: 120;
    readonly questionExcerpt: 240;
    readonly knowledgePoint: 80;
    readonly knowledgePoints: 12;
    readonly clarifiedPoint: 200;
    readonly clarifiedPoints: 5;
};
export interface ScopeEvidence {
    scope_id: string;
    scope_label: string;
}
export interface SessionScopeEvidence extends ScopeEvidence {
    entered_at: string;
}
export interface AttemptObservation {
    evidence_id: string;
    attempt_id: string;
    scope: ScopeEvidence;
    target: {
        kind: "scope" | "card" | "section";
        id: string;
        label: string;
    };
    occurred_at: string;
    difficulty: DifficultyLevel;
    type: QuestionType;
    question_excerpt: string;
    knowledge_points: string[];
    outcome: "correct" | "gave_up";
    submission_count: number;
    incorrect_submissions: number;
    discussion_occurred: boolean;
    clarified_points: string[];
}
export interface MasteryEvidence {
    evidence_id: string;
    attempt_id: string;
    scope: ScopeEvidence;
    knowledge_points: string[];
    basis: "final_answer_accepted";
    question_excerpt: string;
    revisions_before_correct: number;
}
export interface UnverifiedTopic {
    evidence_id: string;
    attempt_id: string;
    scope: ScopeEvidence;
    knowledge_points: string[];
    reason: "gave_up_without_correct_answer";
    question_excerpt: string;
}
export interface SessionEvidence {
    session: {
        session_id: string;
        subject_id: string;
        mode: ReviewMode;
        status: SessionStatus;
        started_at: string;
        ended_at?: string;
        scope_history: SessionScopeEvidence[];
    };
    totals: {
        questions: number;
        correct: number;
        gave_up: number;
        submissions: number;
        revisions: number;
        discussed_questions: number;
    };
    scopes: Array<{
        scope: ScopeEvidence;
        questions: number;
        correct: number;
        gave_up: number;
    }>;
    observed_facts: AttemptObservation[];
    mastery_evidence: MasteryEvidence[];
    unverified_topics: UnverifiedTopic[];
}
/** Normalize whitespace and truncate by Unicode code point rather than UTF-16 code unit. */
export declare function truncateEvidenceText(value: string, maxCharacters: number): string;
export declare function boundedUniqueStrings(values: readonly string[] | undefined, options: {
    maxItems: number;
    maxCharacters: number;
}): string[];
/**
 * Projects persisted learning records into the only context the summary Agent may consume.
 * Raw answers, answer text history, self-corrections, reference answers and explanations are
 * deliberately never read into the returned object.
 */
export declare function buildSessionEvidence(session: StudySession, attempts: readonly Attempt[]): SessionEvidence;
