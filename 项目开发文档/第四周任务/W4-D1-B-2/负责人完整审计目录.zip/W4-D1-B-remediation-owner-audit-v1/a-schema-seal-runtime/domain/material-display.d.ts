/** 将 canonical Markdown 转为用户学习视图，移除内部元数据和出题提示。 */
export declare function prepareMaterialForDisplay(material: string): string;
