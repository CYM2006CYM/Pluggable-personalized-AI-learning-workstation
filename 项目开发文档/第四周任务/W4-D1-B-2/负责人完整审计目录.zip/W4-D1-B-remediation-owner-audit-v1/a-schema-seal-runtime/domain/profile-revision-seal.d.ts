export declare const REVISION_SEAL_PATH = "quality/revision-seal.json";
export declare const RAW_REVISION_HASH_MODE: "raw-binary";
export declare const PROFILE_REVISION_HASH_MODE: "utf8-json-keys-sorted-arrays-preserved-no-whitespace-v1";
import type { RevisionSeal } from "../contracts/domain.js";
export type { RevisionSeal, RevisionSealEntry } from "../contracts/domain.js";
export declare function calculateRevisionSeal(directory: string): Promise<Pick<RevisionSeal, "entries" | "assetTreeSha256">>;
export declare function validateRevisionSeal(directory: string, subjectId: string): Promise<RevisionSeal>;
