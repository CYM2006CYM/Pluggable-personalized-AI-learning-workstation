export class DiagnosticValidationError extends Error {
    errorCode;
    constructor(errorCode, message) {
        super(message);
        this.errorCode = errorCode;
        this.name = "DiagnosticValidationError";
    }
}
const STABLE_ID = /^[A-Za-z0-9][A-Za-z0-9._-]*$/u;
const DIFFICULTIES = new Set(["S-R", "S-U", "M-U", "M-A", "C-A"]);
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function assertKeys(value, allowed, label, extensions = false) {
    const set = new Set(allowed);
    for (const key of Object.keys(value)) {
        if (!set.has(key) && !(extensions && key.startsWith("x-"))) {
            throw new DiagnosticValidationError("invalid_profile", `${label}.${key} is an unknown field`);
        }
    }
}
function stableId(value, label) {
    if (typeof value !== "string" || !STABLE_ID.test(value)) {
        throw new DiagnosticValidationError("invalid_profile", `${label} must be a stable ASCII identifier`);
    }
}
function uniqueStrings(value, label, nonEmpty = false) {
    if (!Array.isArray(value) || value.some((item) => typeof item !== "string" || item.trim() === "")) {
        throw new DiagnosticValidationError("invalid_profile", `${label} must be an array of non-empty strings`);
    }
    if ((nonEmpty && value.length === 0) || new Set(value).size !== value.length) {
        throw new DiagnosticValidationError("invalid_profile", `${label} must be non-empty and unique`);
    }
}
export function parseDiagnosticBlueprint(value) {
    if (!isRecord(value))
        throw new DiagnosticValidationError("invalid_profile", "Diagnostic blueprint must be an object");
    assertKeys(value, [
        "blueprintId", "profileRevision", "goalIds", "estimatedMinutes", "minimumCoverage", "questions", "scoringVersion",
    ], "diagnostic", true);
    stableId(value.blueprintId, "diagnostic.blueprintId");
    stableId(value.scoringVersion, "diagnostic.scoringVersion");
    if (!Number.isInteger(value.profileRevision) || value.profileRevision < 1) {
        throw new DiagnosticValidationError("invalid_profile", "diagnostic.profileRevision must be a positive integer");
    }
    uniqueStrings(value.goalIds, "diagnostic.goalIds", true);
    if (!Number.isInteger(value.estimatedMinutes) || value.estimatedMinutes < 1 || value.estimatedMinutes > 10) {
        throw new DiagnosticValidationError("invalid_profile", "diagnostic.estimatedMinutes must be an integer from 1 to 10");
    }
    if (typeof value.minimumCoverage !== "number" || value.minimumCoverage <= 0 || value.minimumCoverage > 1) {
        throw new DiagnosticValidationError("invalid_profile", "diagnostic.minimumCoverage must be in (0, 1]");
    }
    if (!Array.isArray(value.questions) || value.questions.length === 0) {
        throw new DiagnosticValidationError("invalid_profile", "diagnostic.questions must be non-empty");
    }
    const seen = new Set();
    for (const [index, raw] of value.questions.entries()) {
        if (!isRecord(raw))
            throw new DiagnosticValidationError("invalid_profile", `diagnostic.questions[${index}] must be an object`);
        assertKeys(raw, [
            "questionId", "knowledgePointId", "kind", "difficulty", "prompt", "options", "maxScore", "required", "evaluatorRef", "sourceAnchorIds",
        ], `diagnostic.questions[${index}]`);
        stableId(raw.questionId, `diagnostic.questions[${index}].questionId`);
        stableId(raw.knowledgePointId, `diagnostic.questions[${index}].knowledgePointId`);
        if (seen.has(raw.questionId))
            throw new DiagnosticValidationError("invalid_profile", "Diagnostic question IDs must be unique");
        seen.add(raw.questionId);
        if (raw.kind !== "single_choice" && raw.kind !== "judgment") {
            throw new DiagnosticValidationError("invalid_profile", `diagnostic.questions[${index}].kind is unsupported`);
        }
        if (typeof raw.difficulty !== "string" || !DIFFICULTIES.has(raw.difficulty)) {
            throw new DiagnosticValidationError("invalid_profile", `diagnostic.questions[${index}].difficulty is unsupported`);
        }
        if (typeof raw.prompt !== "string" || raw.prompt.trim() === "") {
            throw new DiagnosticValidationError("invalid_profile", `diagnostic.questions[${index}].prompt is required`);
        }
        if (raw.kind === "single_choice") {
            uniqueStrings(raw.options, `diagnostic.questions[${index}].options`, true);
            if (raw.options.length < 3 || raw.options.length > 5) {
                throw new DiagnosticValidationError("invalid_profile", "Single-choice questions require 3 to 5 options");
            }
        }
        else if (raw.options !== undefined) {
            throw new DiagnosticValidationError("invalid_profile", "Judgment questions must omit options");
        }
        if (raw.maxScore !== 1 || typeof raw.required !== "boolean") {
            throw new DiagnosticValidationError("invalid_profile", "Diagnostic maxScore must be 1 and required must be boolean");
        }
        if (raw.evaluatorRef !== `private/answer-key.json#${raw.questionId}`) {
            throw new DiagnosticValidationError("invalid_profile", "Diagnostic evaluatorRef must use the private answer key");
        }
        uniqueStrings(raw.sourceAnchorIds, `diagnostic.questions[${index}].sourceAnchorIds`, true);
    }
    return value;
}
export function parseDiagnosticAnswerKey(value, blueprint) {
    if (!isRecord(value))
        throw new DiagnosticValidationError("invalid_profile", "Diagnostic answer key must be an object");
    assertKeys(value, ["blueprintId", "evaluatorVersion", "answers"], "answerKey");
    stableId(value.blueprintId, "answerKey.blueprintId");
    stableId(value.evaluatorVersion, "answerKey.evaluatorVersion");
    if (value.blueprintId !== blueprint.blueprintId || !Array.isArray(value.answers)) {
        throw new DiagnosticValidationError("invalid_profile", "Answer key does not match diagnostic blueprint");
    }
    const byQuestion = new Map(blueprint.questions.map((question) => [question.questionId, question]));
    const seen = new Set();
    for (const [index, raw] of value.answers.entries()) {
        if (!isRecord(raw))
            throw new DiagnosticValidationError("invalid_profile", `answerKey.answers[${index}] must be an object`);
        assertKeys(raw, ["questionId", "kind", "correctAnswer"], `answerKey.answers[${index}]`);
        stableId(raw.questionId, `answerKey.answers[${index}].questionId`);
        if (seen.has(raw.questionId))
            throw new DiagnosticValidationError("invalid_profile", "Answer key question IDs must be unique");
        seen.add(raw.questionId);
        const question = byQuestion.get(raw.questionId);
        if (question === undefined || raw.kind !== question.kind) {
            throw new DiagnosticValidationError("invalid_profile", "Answer key must close exactly over the blueprint");
        }
        if (question.kind === "single_choice") {
            if (typeof raw.correctAnswer !== "string" || !question.options?.includes(raw.correctAnswer)) {
                throw new DiagnosticValidationError("invalid_profile", "Single-choice correct answer must equal an option");
            }
        }
        else if (typeof raw.correctAnswer !== "boolean") {
            throw new DiagnosticValidationError("invalid_profile", "Judgment correct answer must be boolean");
        }
    }
    if (seen.size !== blueprint.questions.length) {
        throw new DiagnosticValidationError("invalid_profile", "Answer key must contain exactly one answer per question");
    }
    return value;
}
