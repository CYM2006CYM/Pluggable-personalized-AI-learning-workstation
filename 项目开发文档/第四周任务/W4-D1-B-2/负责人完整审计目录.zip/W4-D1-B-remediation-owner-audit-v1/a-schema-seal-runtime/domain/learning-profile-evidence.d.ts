import type { PendingLearningRecordBatch } from "../repositories/private-memory-repository.js";
import type { LearningProfile } from "./types.js";
import { buildSessionEvidence } from "./session-evidence.js";
export interface LearningProfileBatchEvidence {
    batch_id: string;
    session_id: string;
    status: "completed" | "interrupted";
    summary_excerpt: string;
    session_evidence: ReturnType<typeof buildSessionEvidence>;
}
export interface LearningProfileEvidence {
    subject_id: string;
    existing_profile: LearningProfile | null;
    selected_batches: LearningProfileBatchEvidence[];
    deterministic_totals: {
        previous_questions: number;
        previous_correct: number;
        selected_questions: number;
        selected_correct: number;
        total_questions: number;
        total_correct: number;
        accuracy: number;
    };
}
export interface LearningProfileCandidate {
    profile_summary: string;
    weak_points: string[];
    strengths: string[];
    unverified_topics: string[];
    recommendations: string[];
}
export declare function buildLearningProfileEvidence(subjectId: string, existingProfile: LearningProfile | null, batches: readonly PendingLearningRecordBatch[]): LearningProfileEvidence;
export declare function assembleLearningProfile(evidence: LearningProfileEvidence, candidate: LearningProfileCandidate, updatedAt: string): LearningProfile;
