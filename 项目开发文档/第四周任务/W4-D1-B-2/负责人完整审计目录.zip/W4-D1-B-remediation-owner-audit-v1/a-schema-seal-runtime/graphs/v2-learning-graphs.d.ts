import type { ActivitySafeView } from "../application/learning-runtime-facade.js";
export type ReviewGraphId = "generator" | "hunter" | "defender" | "judge";
export interface ReviewActivityContext {
    activityId: string;
    activityVersion: number;
    kind: ActivitySafeView["kind"];
    title: string;
    primaryKnowledgePointId: string;
    supportingKnowledgePointIds: string[];
}
export interface ReviewSafeContext {
    activity: ReviewActivityContext;
    safeFeedback: string;
    sourceIds: string[];
    sourceSummary: string;
}
export interface GeneratorInput {
    context: ReviewSafeContext;
    allowedSourcesSummary: string;
}
export interface GeneratorOutput {
    artifactId: string;
    candidateFeedback: string;
    rationale: string;
    citedSourceIds: string[];
    riskFlags: string[];
}
export interface HunterIssue {
    issueId: string;
    severity: "low" | "medium" | "high";
    message: string;
    disputed: boolean;
}
export interface HunterInput {
    context: ReviewSafeContext;
    generator: GeneratorOutput;
}
export interface HunterOutput {
    issues: HunterIssue[];
    requiresDefender: boolean;
    recommendedVerdict: "accepted" | "revise";
}
export interface DefenderInput {
    context: ReviewSafeContext;
    generator: GeneratorOutput;
    hunter: HunterOutput;
}
export interface DefenderOutput {
    defenseSummary: string;
    acceptedIssueIds: string[];
    rebuttedIssueIds: string[];
    residualRisks: string[];
}
export interface JudgeInput {
    context: ReviewSafeContext;
    generator: GeneratorOutput;
    hunter: HunterOutput;
    defender?: DefenderOutput;
}
export interface JudgeOutput {
    verdict: "accepted" | "revise" | "rejected";
    finalSafeFeedback: string;
    summary: string;
    blockedIssueIds: string[];
}
export interface ReviewRoleDefinition<Input, Output> {
    graphId: ReviewGraphId;
    validateInput(value: unknown): value is Input;
    validateOutput(value: unknown): value is Output;
    buildSystemPrompt(input: Input): string;
}
export interface StudyReviewGraphs {
    generator: ReviewRoleDefinition<GeneratorInput, GeneratorOutput>;
    hunter: ReviewRoleDefinition<HunterInput, HunterOutput>;
    defender: ReviewRoleDefinition<DefenderInput, DefenderOutput>;
    judge: ReviewRoleDefinition<JudgeInput, JudgeOutput>;
}
export declare function createStudyReviewGraphs(): StudyReviewGraphs;
