function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isNonEmptyString(value) {
    return typeof value === "string" && value.trim().length > 0;
}
function isStringArray(value) {
    return Array.isArray(value) && value.every(isNonEmptyString);
}
function hasOnlyKeys(value, required, optional = []) {
    const allowed = new Set([...required, ...optional]);
    const keys = Object.keys(value);
    return keys.every((key) => allowed.has(key)) && required.every((key) => key in value);
}
function isActivityContext(value) {
    if (!isRecord(value))
        return false;
    return hasOnlyKeys(value, [
        "activityId",
        "activityVersion",
        "kind",
        "title",
        "primaryKnowledgePointId",
        "supportingKnowledgePointIds",
    ])
        && isNonEmptyString(value.activityId)
        && typeof value.activityVersion === "number"
        && isNonEmptyString(value.kind)
        && isNonEmptyString(value.title)
        && isNonEmptyString(value.primaryKnowledgePointId)
        && isStringArray(value.supportingKnowledgePointIds);
}
function isReviewSafeContext(value) {
    if (!isRecord(value))
        return false;
    return hasOnlyKeys(value, [
        "activity",
        "safeFeedback",
        "sourceIds",
        "sourceSummary",
    ])
        && isActivityContext(value.activity)
        && isNonEmptyString(value.safeFeedback)
        && isStringArray(value.sourceIds)
        && isNonEmptyString(value.sourceSummary);
}
function isGeneratorInput(value) {
    return isRecord(value)
        && hasOnlyKeys(value, ["context", "allowedSourcesSummary"])
        && isReviewSafeContext(value.context)
        && isNonEmptyString(value.allowedSourcesSummary);
}
function isGeneratorOutput(value) {
    return isRecord(value)
        && hasOnlyKeys(value, ["artifactId", "candidateFeedback", "rationale", "citedSourceIds", "riskFlags"])
        && isNonEmptyString(value.artifactId)
        && isNonEmptyString(value.candidateFeedback)
        && isNonEmptyString(value.rationale)
        && isStringArray(value.citedSourceIds)
        && isStringArray(value.riskFlags);
}
function isHunterIssue(value) {
    return isRecord(value)
        && hasOnlyKeys(value, ["issueId", "severity", "message", "disputed"])
        && isNonEmptyString(value.issueId)
        && (value.severity === "low" || value.severity === "medium" || value.severity === "high")
        && isNonEmptyString(value.message)
        && (value.disputed === true || value.disputed === false);
}
function isHunterInput(value) {
    return isRecord(value)
        && hasOnlyKeys(value, ["context", "generator"])
        && isReviewSafeContext(value.context)
        && isGeneratorOutput(value.generator);
}
function isHunterOutput(value) {
    return isRecord(value)
        && hasOnlyKeys(value, ["issues", "requiresDefender", "recommendedVerdict"])
        && Array.isArray(value.issues)
        && value.issues.every(isHunterIssue)
        && (value.requiresDefender === true || value.requiresDefender === false)
        && (value.recommendedVerdict === "accepted" || value.recommendedVerdict === "revise");
}
function isDefenderInput(value) {
    return isRecord(value)
        && hasOnlyKeys(value, ["context", "generator", "hunter"])
        && isReviewSafeContext(value.context)
        && isGeneratorOutput(value.generator)
        && isHunterOutput(value.hunter);
}
function isDefenderOutput(value) {
    return isRecord(value)
        && hasOnlyKeys(value, ["defenseSummary", "acceptedIssueIds", "rebuttedIssueIds", "residualRisks"])
        && isNonEmptyString(value.defenseSummary)
        && isStringArray(value.acceptedIssueIds)
        && isStringArray(value.rebuttedIssueIds)
        && isStringArray(value.residualRisks);
}
function isJudgeInput(value) {
    return isRecord(value)
        && hasOnlyKeys(value, ["context", "generator", "hunter"], ["defender"])
        && isReviewSafeContext(value.context)
        && isGeneratorOutput(value.generator)
        && isHunterOutput(value.hunter)
        && (value.defender === undefined || isDefenderOutput(value.defender));
}
function isJudgeOutput(value) {
    return isRecord(value)
        && hasOnlyKeys(value, ["verdict", "finalSafeFeedback", "summary", "blockedIssueIds"])
        && (value.verdict === "accepted" || value.verdict === "revise" || value.verdict === "rejected")
        && isNonEmptyString(value.finalSafeFeedback)
        && isNonEmptyString(value.summary)
        && isStringArray(value.blockedIssueIds);
}
function generatorPrompt(input) {
    return [
        "Generator role in the serial review chain.",
        "Use only the supplied safe context and allowed sources.",
        "Do not mention hidden tests, raw learner answers, reference solutions, or host paths.",
        `sources=${input.allowedSourcesSummary}`,
    ].join("\n");
}
function hunterPrompt(input) {
    return [
        "Hunter role in the serial review chain.",
        "Find concrete defects, leakage risks, and boundary problems.",
        "Do not change score or rewrite the candidate.",
        `generator=${input.generator.artifactId}`,
    ].join("\n");
}
function defenderPrompt(input) {
    return [
        "Defender role in the serial review chain.",
        "Respond only to disputed Hunter issues using the safe context.",
        "Do not invent facts from hidden assets.",
        `issues=${input.hunter.issues.length}`,
    ].join("\n");
}
function judgePrompt(input) {
    return [
        "Judge role in the serial review chain.",
        "Choose accepted, revise, or rejected from the provided evidence.",
        "Do not modify rubric, path, or answers.",
        `recommended=${input.hunter.recommendedVerdict}`,
        `defender=${input.defender ? "yes" : "no"}`,
    ].join("\n");
}
export function createStudyReviewGraphs() {
    return {
        generator: {
            graphId: "generator",
            validateInput: isGeneratorInput,
            validateOutput: isGeneratorOutput,
            buildSystemPrompt: generatorPrompt,
        },
        hunter: {
            graphId: "hunter",
            validateInput: isHunterInput,
            validateOutput: isHunterOutput,
            buildSystemPrompt: hunterPrompt,
        },
        defender: {
            graphId: "defender",
            validateInput: isDefenderInput,
            validateOutput: isDefenderOutput,
            buildSystemPrompt: defenderPrompt,
        },
        judge: {
            graphId: "judge",
            validateInput: isJudgeInput,
            validateOutput: isJudgeOutput,
            buildSystemPrompt: judgePrompt,
        },
    };
}
