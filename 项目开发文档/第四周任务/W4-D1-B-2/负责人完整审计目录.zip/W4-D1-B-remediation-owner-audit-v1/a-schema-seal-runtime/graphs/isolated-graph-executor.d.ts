import type { ExtensionCommandContext } from "@earendil-works/pi-coding-agent";
import { type CreatePiGraphHostOptions, type Graph, type GraphHost, type GraphRunResult, type LoopGraphLimits, type RecordingMode } from "pi-loop-graph-sdk";
export type IsolatedGraphExecutor = (graph: Graph, input: Record<string, unknown>) => Promise<GraphRunResult>;
export interface IsolatedGraphExecutorOptions {
    /** Root/Child 步数与 Agent Run 超时；0.2 由 Host 统一持有。 */
    limits?: LoopGraphLimits;
    /** SDK 0.2的运行记录模式和持久化存储。 */
    recording?: RecordingMode;
    runStore?: CreatePiGraphHostOptions["runStore"];
    /** 允许被 GraphRef 解析的图；单图执行时可省略。 */
    graphs?: readonly Graph[];
}
/** @internal 仅用于替换 Host 构造，以便测试生命周期契约。 */
export interface IsolatedGraphExecutorDependencies {
    createHost?: (options: CreatePiGraphHostOptions) => Promise<GraphHost> | GraphHost;
}
/**
 * 为业务命令创建隔离图执行器。
 *
 * 每次执行都会创建并释放一个新的 in-memory AgentSession，图内的模型消息、
 * completion 工具反馈和 SDK 完成通知不会进入产品主会话。
 */
export declare function createIsolatedGraphExecutor(ctx: ExtensionCommandContext, options?: IsolatedGraphExecutorOptions, dependencies?: IsolatedGraphExecutorDependencies): IsolatedGraphExecutor;
