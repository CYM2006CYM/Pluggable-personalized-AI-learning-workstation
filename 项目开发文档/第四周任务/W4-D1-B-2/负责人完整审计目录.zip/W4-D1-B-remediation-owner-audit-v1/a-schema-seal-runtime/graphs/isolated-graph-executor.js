import { createPiGraphHost, } from "pi-loop-graph-sdk";
/**
 * Graph Input 会被 Runtime 按 Graph input 契约校验，且必须是 JSON 兼容值。
 * 业务对象里可能带 `undefined` 字段，这里统一做一次 JSON 归一化。
 */
function toGraphInput(input) {
    return JSON.parse(JSON.stringify(input ?? {}));
}
/**
 * 为业务命令创建隔离图执行器。
 *
 * 每次执行都会创建并释放一个新的 in-memory AgentSession，图内的模型消息、
 * completion 工具反馈和 SDK 完成通知不会进入产品主会话。
 */
export function createIsolatedGraphExecutor(ctx, options = {}, dependencies = {}) {
    const model = ctx.model;
    if (!model)
        throw new Error("请先选择可用模型再开始学习");
    const createHost = dependencies.createHost ?? createPiGraphHost;
    const hostOptions = {
        cwd: ctx.cwd,
        authStorage: ctx.modelRegistry.authStorage,
        modelRegistry: ctx.modelRegistry,
        model,
        thinkingLevel: "off",
        limits: options.limits,
        recording: options.recording ?? "replay",
        runStore: options.runStore,
        graphs: options.graphs,
    };
    return async (graph, input) => {
        const host = await createHost(hostOptions);
        try {
            return await host.execute(graph, toGraphInput(input), { signal: ctx.signal });
        }
        finally {
            await host.dispose();
        }
    };
}
