import type { AgentRunRequest, Graph, JsonSchema, NodeCompletion } from "pi-loop-graph-sdk";
import type { DifficultyLevel, GradeResult, ReviewQuestion } from "../domain/types.js";
import type { LearningProfileCandidate } from "../domain/learning-profile-evidence.js";
import type { ProfileBuildFragment } from "../domain/profile-build.js";
import type { ProfileRevisionPatch, ProfileRevisionPlan, ProfileRevisionQualityReview } from "../domain/profile-revision.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";
/**
 * 0.1 由 SDK 导出的业务校验结果类型；0.2 不再提供 `CompletionValidationResult`，
 * 由本包自己定义并在 Code Node 内驱动 Agent 重试。
 */
export interface CompletionValidationResult {
    readonly isValid: boolean;
    readonly reason?: string;
}
export declare function validateQuestionResult(result: Record<string, unknown>): CompletionValidationResult;
export declare function validateQuestionResultForRequest(result: Record<string, unknown>, expectedDifficulty: string, expectedType: string, allowedKnowledgePointIds?: readonly string[], exactKnowledgePointId?: string): CompletionValidationResult;
export declare function validateGradeResult(result: Record<string, unknown>): CompletionValidationResult;
export declare function validateSummaryResult(result: Record<string, unknown>): CompletionValidationResult;
export declare function validateDiscussionResult(result: Record<string, unknown>): CompletionValidationResult;
export declare function validateLearningProfileResult(result: Record<string, unknown>): CompletionValidationResult;
export declare function validateProfileBuildFragment(result: Record<string, unknown>, allowedSourceIds?: readonly string[]): CompletionValidationResult;
export declare function validateProfileRevisionPlan(result: Record<string, unknown>, existingPaths: readonly string[]): CompletionValidationResult;
export declare function validateProfileRevisionPatch(result: Record<string, unknown>, plan: ProfileRevisionPlan): CompletionValidationResult;
export declare function validateProfileRevisionQuality(result: Record<string, unknown>): CompletionValidationResult;
/** Code Node 内的 Agent Run 网关：0.2 用 runAgent + 业务校验重试替代 0.1 的 validateCompletion。 */
export declare const AGENT_VALIDATION_ATTEMPTS = 3;
interface ValidatedAgentRun {
    readonly runAgent: (request: AgentRunRequest) => Promise<NodeCompletion>;
    readonly prompt: string;
    readonly output: JsonSchema;
    readonly validate: (result: Record<string, unknown>) => CompletionValidationResult;
    readonly attempts?: number;
}
export declare function runValidatedAgent(run: ValidatedAgentRun): Promise<Record<string, unknown>>;
export interface StudyWalkingSkeletonGraphs {
    generateQuestion: Graph;
    gradeAnswer: Graph;
    discussQuestion: Graph;
    summarizeSession: Graph;
    updateLearningProfile: Graph;
    buildProfileFragment: Graph;
    planProfileRevision: Graph;
    reviseProfileDraft: Graph;
    reviewProfileDraft: Graph;
}
export declare function createStudyWalkingSkeletonGraphs(profiles: ProfileFamilyRepository): StudyWalkingSkeletonGraphs;
export declare function asReviewQuestion(result: Record<string, unknown>): ReviewQuestion & {
    question_id: string;
};
export declare function asGradeResult(result: Record<string, unknown>): GradeResult;
export declare function asLearningProfileCandidate(result: Record<string, unknown>): LearningProfileCandidate;
export declare function asProfileBuildFragment(result: Record<string, unknown>, allowedSourceIds: readonly string[]): ProfileBuildFragment;
export declare function asProfileRevisionPlan(result: Record<string, unknown>, existingPaths: readonly string[]): ProfileRevisionPlan;
export declare function asProfileRevisionPatch(result: Record<string, unknown>, plan: ProfileRevisionPlan): ProfileRevisionPatch;
export declare function asProfileRevisionQuality(result: Record<string, unknown>): ProfileRevisionQualityReview;
export declare function difficultyFrom(value: string): DifficultyLevel;
export {};
