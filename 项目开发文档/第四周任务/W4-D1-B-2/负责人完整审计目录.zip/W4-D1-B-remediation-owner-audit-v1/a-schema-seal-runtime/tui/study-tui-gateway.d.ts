import type { DifficultyLevel, ReviewMode } from "../domain/types.js";
export type QuestionViewType = "short_answer" | "choice" | "judgment";
export type QuestionViewPhase = "first_attempt" | "revision";
/**
 * Deliberately contains presentation-only fields. In particular, answer,
 * explanation and source fields do not cross the TUI boundary.
 */
export interface QuestionViewModel {
    questionId: string;
    questionNumber: number;
    totalQuestions?: number;
    scope: string;
    mode: ReviewMode;
    difficulty: DifficultyLevel;
    type: QuestionViewType;
    questionText: string;
    options?: readonly string[];
    phase: QuestionViewPhase;
    attemptNumber: number;
}
export type AnswerAction = {
    kind: "submitted";
    answer: string;
} | {
    kind: "gave_up";
} | {
    kind: "cancelled";
};
export type MaterialTargetKind = "card" | "section" | "scope";
/** Safe, presentation-only metadata for Profile material. */
export interface MaterialTargetMetadata {
    kind: MaterialTargetKind;
    id: string;
    label: string;
    position?: number;
    total?: number;
}
/**
 * Deliberately accepts Profile material only. Question, grade, answer and
 * explanation data do not belong in this boundary.
 */
export interface MaterialViewModel {
    title: string;
    body: string;
    target: MaterialTargetMetadata;
}
/** Card-front prompt shown before the card body is revealed. */
export interface RecallPromptViewModel {
    title: string;
    target: MaterialTargetMetadata & {
        kind: "card";
    };
}
export type MaterialViewAction = {
    kind: "start";
} | {
    kind: "cancelled";
};
export type RecallPromptAction = {
    kind: "view_material";
} | {
    kind: "start";
} | {
    kind: "cancelled";
};
/** The small subset of Pi UI used by the study flow and its test doubles. */
export interface StudyUiPort {
    setWidget(key: string, content: string[] | undefined, options?: {
        placement?: "aboveEditor" | "belowEditor";
    }): void;
    input(title: string, placeholder?: string): Promise<string | undefined>;
    select(title: string, options: string[]): Promise<string | undefined>;
}
/** Normalize newline variants and guarantee one widget row per array item. */
export declare function normalizeMaterialLines(body: string): string[];
export declare function renderMaterialWidget(view: MaterialViewModel, pageIndex?: number): {
    lines: string[];
    pageIndex: number;
    pageCount: number;
};
export declare function renderRecallPromptWidget(view: RecallPromptViewModel): string[];
export declare function renderQuestionWidget(view: QuestionViewModel): string[];
export declare class StudyTuiGateway {
    private readonly ui;
    constructor(ui: StudyUiPort);
    showRecallPrompt(view: RecallPromptViewModel): Promise<RecallPromptAction>;
    browseMaterial(view: MaterialViewModel): Promise<MaterialViewAction>;
    presentQuestion(view: QuestionViewModel): void;
    updateRevision(view: QuestionViewModel): void;
    collectAnswer(view: QuestionViewModel): Promise<AnswerAction>;
    clearQuestion(): void;
    clearMaterial(): void;
}
