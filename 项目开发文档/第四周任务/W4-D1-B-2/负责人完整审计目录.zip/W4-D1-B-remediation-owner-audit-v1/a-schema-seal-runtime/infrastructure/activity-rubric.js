function roundScore(value) {
    return Number(value.toFixed(12));
}
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function weightSumIsOne(weights) {
    const sum = weights.reduce((total, weight) => total + weight, 0);
    return Math.abs(sum - 1) <= Number.EPSILON * Math.max(1, weights.length);
}
export function validateRubricDefinition(value, tests) {
    if (!isRecord(value)
        || typeof value.passThreshold !== "number"
        || !Number.isFinite(value.passThreshold)
        || value.passThreshold < 0
        || value.passThreshold > 1
        || !Array.isArray(value.dimensions)
        || value.dimensions.length === 0
        || !isRecord(value.dimensionTestMap)
        || tests.length === 0)
        return false;
    const dimensions = value.dimensions;
    const dimensionIds = new Set();
    const weights = [];
    for (const dimension of dimensions) {
        if (!isRecord(dimension)
            || typeof dimension.dimensionId !== "string"
            || dimension.dimensionId.length === 0
            || dimensionIds.has(dimension.dimensionId)
            || typeof dimension.weight !== "number"
            || !Number.isFinite(dimension.weight)
            || dimension.weight <= 0
            || dimension.weight > 1
            || typeof dimension.blocking !== "boolean"
            || !Array.isArray(dimension.safeFeedbackCodes)
            || !dimension.safeFeedbackCodes.every((code) => typeof code === "string"))
            return false;
        dimensionIds.add(dimension.dimensionId);
        weights.push(dimension.weight);
    }
    if (!weightSumIsOne(weights))
        return false;
    const testIds = new Set();
    for (const test of tests) {
        if (typeof test.testId !== "string"
            || test.testId.length === 0
            || testIds.has(test.testId)
            || typeof test.dimensionId !== "string"
            || !dimensionIds.has(test.dimensionId)
            || typeof test.blocking !== "boolean")
            return false;
        testIds.add(test.testId);
    }
    const mappedTests = new Set();
    const mapKeys = Object.keys(value.dimensionTestMap);
    if (mapKeys.length !== dimensionIds.size || mapKeys.some((key) => !dimensionIds.has(key)))
        return false;
    for (const dimensionId of dimensionIds) {
        const mapped = value.dimensionTestMap[dimensionId];
        if (!Array.isArray(mapped) || mapped.length === 0)
            return false;
        for (const testId of mapped) {
            const test = tests.find((candidate) => candidate.testId === testId);
            if (typeof testId !== "string"
                || mappedTests.has(testId)
                || !test
                || test.dimensionId !== dimensionId)
                return false;
            mappedTests.add(testId);
        }
    }
    return mappedTests.size === testIds.size;
}
export function summarizeRubric(input) {
    if (!validateRubricDefinition(input.rubric, input.tests)
        || !input.tests.every((test) => typeof test.passed === "boolean")) {
        throw new TypeError("invalid rubric summary input");
    }
    const dimensionResults = {};
    let rawScore = 0;
    let blockingPassed = true;
    for (const dimension of input.rubric.dimensions) {
        const tests = input.tests.filter((test) => test.dimensionId === dimension.dimensionId);
        const dimensionScore = tests.length === 0
            ? 0
            : tests.filter((test) => test.passed).length / tests.length;
        dimensionResults[dimension.dimensionId] = roundScore(dimensionScore);
        rawScore += dimensionScore * dimension.weight;
        if (dimension.blocking && dimensionScore < 1)
            blockingPassed = false;
    }
    if (input.tests.some((test) => test.blocking && !test.passed))
        blockingPassed = false;
    const scoreTolerance = Number.EPSILON * Math.max(1, input.rubric.dimensions.length);
    if (!Number.isFinite(rawScore) || rawScore < -scoreTolerance || rawScore > 1 + scoreTolerance) {
        throw new TypeError("rubric score is outside 0..1");
    }
    const boundedScore = Math.min(1, Math.max(0, rawScore));
    const passed = boundedScore >= input.rubric.passThreshold && blockingPassed;
    const normalizedScore = roundScore(boundedScore);
    const verdict = passed ? "pass" : normalizedScore > 0 ? "partial" : "fail";
    return {
        executionStatus: "completed",
        verdict,
        ...(passed ? {} : { errorKind: "learner", errorCode: "test_failed" }),
        score: normalizedScore,
        dimensionResults,
        safeFeedback: passed
            ? "All deterministic checks passed."
            : "One or more deterministic checks did not pass.",
        evaluatorVersion: input.evaluatorVersion,
        environmentHash: input.environmentHash,
        assetBundleHash: input.assetBundleHash,
    };
}
export function learnerFailure(input) {
    return {
        executionStatus: "completed",
        verdict: "fail",
        errorKind: "learner",
        errorCode: input.errorCode,
        score: 0,
        safeFeedback: input.safeFeedback,
        evaluatorVersion: input.evaluatorVersion,
        environmentHash: input.environmentHash,
        assetBundleHash: input.assetBundleHash,
    };
}
export function evaluatorFailure(input) {
    return {
        executionStatus: "failed",
        verdict: "not_graded",
        errorKind: "evaluator",
        errorCode: input.errorCode,
        safeFeedback: input.safeFeedback,
        evaluatorVersion: input.evaluatorVersion,
        environmentHash: input.environmentHash,
        assetBundleHash: input.assetBundleHash,
    };
}
