export const EVALUATOR_STAGE_ORDER = [
    "prepare",
    "user_code",
    "public_tests",
    "hidden_tests",
    "summarize",
];
const FIXTURE_KEYS = ["assetHash", "fileRef", "fixtureId", "format", "visibility"];
const TEST_CASE_KEYS = [
    "assetHash",
    "blocking",
    "dimensionId",
    "fileRef",
    "fixtureRefs",
    "testId",
    "visibility",
];
const REQUEST_KEYS = [
    "deterministicSeed",
    "entryPoint",
    "executionId",
    "fixtureRefs",
    "output",
    "protocolVersion",
    "stage",
];
const RESPONSE_KEYS = [
    "assetBundleHash",
    "attemptId",
    "dimensionResults",
    "durationMs",
    "environmentHash",
    "errorCode",
    "errorKind",
    "outputSummary",
    "protocolVersion",
    "runId",
    "score",
    "stage",
    "status",
];
const ENVIRONMENT_LOCK_KEYS = [
    "allowedLibraries",
    "capabilityFlags",
    "createdAt",
    "environmentHash",
    "environmentId",
    "evaluatorVersion",
    "executionConstraints",
    "limits",
    "nodeVersion",
    "pandasVersion",
    "platform",
    "prototypeEvidenceRef",
    "prototypeMeasurements",
    "pyodideVersion",
    "pythonVersion",
    "schemaVersion",
    "status",
    "validationStatus",
];
const EXECUTION_CONSTRAINT_KEYS = [
    "cleanup",
    "environmentVariables",
    "hiddenAssetsInUserDirectory",
    "hiddenAssetsOwner",
    "outputHandling",
    "processIsolation",
    "shell",
    "temporaryDirectory",
    "timeoutAction",
    "workingDirectory",
];
const PROTOTYPE_MEASUREMENT_KEYS = [
    "constraint",
    "evidenceRef",
    "ownerDecision",
    "questionId",
    "status",
];
const REQUIRED_PROTOTYPE_QUESTION_IDS = [
    "temporary-directory-cleanup",
    "public-hidden-process-isolation",
    "hidden-asset-ownership",
    "shell-working-directory",
    "minimal-environment",
    "process-tree-timeout",
    "output-truncation-escaping",
    "runtime-versions-dtype",
    "resource-limits",
    "network-memory-capabilities",
];
const LEARNER_EVALUATION_ERROR_CODES = new Set([
    "syntax_error",
    "runtime_error",
    "test_failed",
    "timeout",
    "output_limit",
    "disallowed_import",
    "submission_contract_error",
]);
const EVALUATOR_ERROR_CODES = new Set([
    "environment_mismatch",
    "evaluator_error",
    "evaluator_start_failed",
    "evaluator_timeout",
    "dependency_missing",
    "test_asset_invalid",
    "result_protocol_invalid",
    "runner_crash",
]);
const SHA256_PATTERN = /^sha256:[a-f0-9]{64}$/u;
const HOST_PATH_PATTERN = /(?:[A-Za-z]:[\\/]|\\\\[^\\/\s]+[\\/][^\\/\s]+|(?:^|[\s"'(])\/[^\s"'()]+|AppData)/u;
function success(value) {
    return { ok: true, value };
}
function failure(errorCode, message) {
    return { ok: false, errorCode, message };
}
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function allValuesAreNull(value, keys) {
    return isRecord(value)
        && hasExactKeys(value, keys)
        && keys.every((key) => value[key] === null);
}
function hasExactKeys(value, expected) {
    const actual = Object.keys(value).sort();
    const sortedExpected = [...expected].sort();
    return actual.length === sortedExpected.length
        && actual.every((key, index) => key === sortedExpected[index]);
}
function isNonEmptyString(value) {
    return typeof value === "string" && value.trim().length > 0;
}
function isUniqueStringArray(value) {
    return Array.isArray(value)
        && value.every(isNonEmptyString)
        && new Set(value).size === value.length;
}
function isSafeRelativePath(value) {
    if (value.includes("\\") || value.startsWith("/") || /^[A-Za-z]:/u.test(value))
        return false;
    const parts = value.split("/");
    return parts.length > 0 && parts.every((part) => part !== "" && part !== "." && part !== "..");
}
function hasRuntimeAssetContext(value) {
    return isRecord(value)
        && value.fileHashes instanceof Map
        && value.symlinkPaths instanceof Set;
}
function isStage(value) {
    return typeof value === "string" && EVALUATOR_STAGE_ORDER.includes(value);
}
function isExecutableStage(value) {
    return value === "user_code" || value === "public_tests" || value === "hidden_tests";
}
function stableUnion(items) {
    const seen = new Set();
    const result = [];
    for (const test of items) {
        for (const fixtureRef of test.fixtureRefs) {
            if (!seen.has(fixtureRef)) {
                seen.add(fixtureRef);
                result.push(fixtureRef);
            }
        }
    }
    return result;
}
function validateFixture(input, context) {
    if (!isRecord(input) || !hasExactKeys(input, FIXTURE_KEYS)) {
        return failure("test_asset_invalid", "Dataset fixture fields do not match W1-C5.");
    }
    if (!isNonEmptyString(input.fixtureId)) {
        return failure("test_asset_invalid", "Dataset fixture ID must be non-empty.");
    }
    if (input.visibility !== "public" && input.visibility !== "private") {
        return failure("test_asset_invalid", "Dataset fixture visibility is invalid.");
    }
    if (!isNonEmptyString(input.fileRef) || !isSafeRelativePath(input.fileRef)) {
        return failure("test_asset_invalid", "Dataset fixture path is not a safe relative path.");
    }
    const expectedPrefix = input.visibility === "public" ? "datasets/public/" : "datasets/private/";
    if (!input.fileRef.startsWith(expectedPrefix)) {
        return failure("test_asset_invalid", "Dataset fixture path does not match its visibility.");
    }
    if (input.format !== "csv" || !isNonEmptyString(input.assetHash) || !SHA256_PATTERN.test(input.assetHash)) {
        return failure("test_asset_invalid", "Dataset fixture format or hash is invalid.");
    }
    if (context.symlinkPaths?.has(input.fileRef)) {
        return failure("test_asset_invalid", "Dataset fixture resolves through a symbolic link.");
    }
    const actualHash = context.fileHashes?.get(input.fileRef);
    if (context.fileHashes && actualHash !== input.assetHash) {
        return failure("test_asset_invalid", "Dataset fixture is missing or its hash changed.");
    }
    return success(input);
}
export function validateDatasetFixturesAsset(input, context = {}) {
    if (!isRecord(input) || !hasExactKeys(input, ["fixtures"]) || !Array.isArray(input.fixtures)) {
        return failure("test_asset_invalid", "Dataset fixture asset must contain only a fixtures array.");
    }
    const fixtures = [];
    const fixtureIds = new Set();
    for (const candidate of input.fixtures) {
        const validated = validateFixture(candidate, context);
        if (!validated.ok)
            return validated;
        if (fixtureIds.has(validated.value.fixtureId)) {
            return failure("test_asset_invalid", "Dataset fixture IDs must be unique.");
        }
        fixtureIds.add(validated.value.fixtureId);
        fixtures.push(validated.value);
    }
    return success({ fixtures });
}
function validateTestCase(input, expectedVisibility, context) {
    if (!isRecord(input) || !hasExactKeys(input, TEST_CASE_KEYS)) {
        return failure("test_asset_invalid", "Test case fields do not match W1-C5.");
    }
    if (!isNonEmptyString(input.testId) || !isNonEmptyString(input.dimensionId)) {
        return failure("test_asset_invalid", "Test case identifiers must be non-empty.");
    }
    if (input.visibility !== expectedVisibility) {
        return failure("test_asset_invalid", "Test case visibility does not match its collection.");
    }
    if (!isNonEmptyString(input.fileRef) || !isSafeRelativePath(input.fileRef)) {
        return failure("test_asset_invalid", "Test case path is not a safe relative path.");
    }
    const expectedPrefix = expectedVisibility === "public"
        ? "assessments/public/tests/"
        : "assessments/private/tests/";
    if (!input.fileRef.startsWith(expectedPrefix)) {
        return failure("test_asset_invalid", "Test case path does not match its visibility.");
    }
    if (input.blocking !== true && input.blocking !== false) {
        return failure("test_asset_invalid", "Test case blocking must be boolean.");
    }
    if (!isNonEmptyString(input.assetHash) || !SHA256_PATTERN.test(input.assetHash)) {
        return failure("test_asset_invalid", "Test case hash is invalid.");
    }
    if (!isUniqueStringArray(input.fixtureRefs)) {
        return failure("test_asset_invalid", "Test fixture references must be a unique string array.");
    }
    if (context.symlinkPaths?.has(input.fileRef)) {
        return failure("test_asset_invalid", "Test case resolves through a symbolic link.");
    }
    const actualHash = context.fileHashes?.get(input.fileRef);
    if (context.fileHashes && actualHash !== input.assetHash) {
        return failure("test_asset_invalid", "Test case is missing or its hash changed.");
    }
    return success(input);
}
export function validateEvaluationBindings(input) {
    const rawInput = input;
    if (!isRecord(rawInput) || !hasRuntimeAssetContext(rawInput.assetContext)) {
        return failure("test_asset_invalid", "Runtime asset hashes and symbolic-link inspection context are required.");
    }
    const fixtureAsset = validateDatasetFixturesAsset(input.fixtureAsset, input.assetContext);
    if (!fixtureAsset.ok)
        return fixtureAsset;
    if (!isUniqueStringArray(input.activityDatasetRefs)) {
        return failure("test_asset_invalid", "Activity dataset references must be unique.");
    }
    if (input.argumentFixtureIds !== undefined && !isUniqueStringArray(input.argumentFixtureIds)) {
        return failure("test_asset_invalid", "Argument fixture references must be unique.");
    }
    if (!Array.isArray(input.publicTests) || !Array.isArray(input.hiddenTests)) {
        return failure("test_asset_invalid", "Public and hidden tests must be arrays.");
    }
    const fixtureById = new Map(fixtureAsset.value.fixtures.map((fixture) => [fixture.fixtureId, fixture]));
    const allowed = new Set(input.activityDatasetRefs);
    for (const fixtureId of allowed) {
        if (!fixtureById.has(fixtureId)) {
            return failure("test_asset_invalid", "Activity references an unknown dataset fixture.");
        }
    }
    const argumentFixtures = input.argumentFixtureIds === undefined
        ? undefined
        : new Set(input.argumentFixtureIds);
    if (argumentFixtures) {
        for (const fixtureId of argumentFixtures) {
            if (!allowed.has(fixtureId)) {
                return failure("test_asset_invalid", "Function argument fixture is not allowed by the activity.");
            }
        }
    }
    const publicTests = [];
    const hiddenTests = [];
    const testIds = new Set();
    for (const [candidates, visibility, output] of [
        [input.publicTests, "public", publicTests],
        [input.hiddenTests, "hidden", hiddenTests],
    ]) {
        for (const candidate of candidates) {
            const validated = validateTestCase(candidate, visibility, input.assetContext);
            if (!validated.ok)
                return validated;
            if (testIds.has(validated.value.testId)) {
                return failure("test_asset_invalid", "Test case IDs must be unique.");
            }
            testIds.add(validated.value.testId);
            for (const fixtureId of validated.value.fixtureRefs) {
                const fixture = fixtureById.get(fixtureId);
                if (!fixture || !allowed.has(fixtureId) || (argumentFixtures && !argumentFixtures.has(fixtureId))) {
                    return failure("test_asset_invalid", "Test case references an unavailable dataset fixture.");
                }
                if (visibility === "public" && fixture.visibility !== "public") {
                    return failure("test_asset_invalid", "Public tests cannot reference private dataset fixtures.");
                }
            }
            output.push(validated.value);
        }
    }
    return success({
        prepare: [],
        user_code: [],
        public_tests: stableUnion(publicTests),
        hidden_tests: stableUnion(hiddenTests),
        summarize: [],
    });
}
export function validateStageSequence(stages) {
    if (stages.length !== EVALUATOR_STAGE_ORDER.length
        || stages.some((stage, index) => stage !== EVALUATOR_STAGE_ORDER[index])) {
        return failure("result_protocol_invalid", "Evaluator stages must follow the complete frozen order.");
    }
    return success(EVALUATOR_STAGE_ORDER);
}
export function validateEvaluatorRequestEnvelope(input, expectedFixtureRefs) {
    if (!isRecord(input) || !hasExactKeys(input, REQUEST_KEYS)) {
        return failure("result_protocol_invalid", "Evaluator request fields are invalid.");
    }
    if (!isNonEmptyString(input.protocolVersion)
        || !isNonEmptyString(input.executionId)
        || !isExecutableStage(input.stage)
        || !isRecord(input.entryPoint)
        || !isRecord(input.output)
        || !isUniqueStringArray(input.fixtureRefs)
        || typeof input.deterministicSeed !== "number"
        || !Number.isSafeInteger(input.deterministicSeed)) {
        return failure("result_protocol_invalid", "Evaluator request values are invalid.");
    }
    if (expectedFixtureRefs
        && (input.fixtureRefs.length !== expectedFixtureRefs.length
            || input.fixtureRefs.some((value, index) => value !== expectedFixtureRefs[index]))) {
        return failure("result_protocol_invalid", "Evaluator request fixture authorization is invalid.");
    }
    return success(input);
}
export function validateExecutionBoundaryFixture(input) {
    if (!isRecord(input) || !hasExactKeys(input, ENVIRONMENT_LOCK_KEYS)) {
        return failure("test_asset_invalid", "Environment lock template fields are invalid.");
    }
    if (input.schemaVersion !== 1
        || input.status !== "draft_pending_C_prototype"
        || !isNonEmptyString(input.environmentId)
        || input.nodeVersion !== null
        || input.pythonVersion !== null
        || input.pandasVersion !== null
        || input.pyodideVersion !== null
        || input.platform !== null
        || input.evaluatorVersion !== null
        || input.createdAt !== null
        || input.prototypeEvidenceRef !== "pending_C_prototype"
        || input.environmentHash !== "pending_C_prototype"
        || input.validationStatus !== "intentionally_invalid_for_formal_submit") {
        return failure("test_asset_invalid", "Environment lock measurements must remain pending.");
    }
    if (!Array.isArray(input.allowedLibraries)
        || input.allowedLibraries.length !== 1
        || !isRecord(input.allowedLibraries[0])
        || !hasExactKeys(input.allowedLibraries[0], ["name", "version"])
        || input.allowedLibraries[0].name !== "pandas"
        || input.allowedLibraries[0].version !== null
        || !allValuesAreNull(input.limits, [
            "datasetBytes",
            "memoryBytes",
            "sourceBytes",
            "stderrBytes",
            "stdoutBytes",
            "wallClockMs",
        ])) {
        return failure("test_asset_invalid", "Environment versions and limits cannot be fabricated.");
    }
    if (!isRecord(input.capabilityFlags)
        || !hasExactKeys(input.capabilityFlags, [
            "networkIsolation",
            "processTreeTermination",
            "reliableMemoryLimit",
        ])
        || Object.values(input.capabilityFlags).some((value) => value !== false)) {
        return failure("test_asset_invalid", "Unmeasured environment capabilities must remain false.");
    }
    const constraints = input.executionConstraints;
    if (!isRecord(constraints)
        || !hasExactKeys(constraints, EXECUTION_CONSTRAINT_KEYS)
        || constraints.temporaryDirectory !== "unique_per_run"
        || constraints.cleanup !== "always_on_success_failure_cancel"
        || constraints.processIsolation !== "separate_clean_public_hidden_processes"
        || constraints.hiddenAssetsOwner !== "node_parent_only"
        || constraints.hiddenAssetsInUserDirectory !== false
        || constraints.workingDirectory !== "fixed_per_run"
        || constraints.environmentVariables !== "minimal_allowlist"
        || constraints.shell !== false
        || constraints.timeoutAction !== "terminate_process_tree"
        || constraints.outputHandling !== "truncate_escape_stdout_stderr") {
        return failure("test_asset_invalid", "Runner execution constraints are invalid.");
    }
    if (!Array.isArray(input.prototypeMeasurements)
        || input.prototypeMeasurements.length !== REQUIRED_PROTOTYPE_QUESTION_IDS.length) {
        return failure("test_asset_invalid", "Prototype measurement questions are incomplete.");
    }
    const questionIds = new Set();
    for (const item of input.prototypeMeasurements) {
        if (!isRecord(item)
            || !hasExactKeys(item, PROTOTYPE_MEASUREMENT_KEYS)
            || !isNonEmptyString(item.questionId)
            || !isNonEmptyString(item.constraint)
            || item.status !== "pending_C_prototype"
            || item.evidenceRef !== null
            || item.ownerDecision !== "pending_after_prototype_evidence"
            || questionIds.has(item.questionId)) {
            return failure("test_asset_invalid", "Prototype measurement question is invalid.");
        }
        questionIds.add(item.questionId);
    }
    if (REQUIRED_PROTOTYPE_QUESTION_IDS.some((questionId) => !questionIds.has(questionId))) {
        return failure("test_asset_invalid", "Required prototype measurement question is missing.");
    }
    return success({
        executionConstraints: constraints,
        prototypeMeasurements: input.prototypeMeasurements,
    });
}
function validDimensionResults(value) {
    return isRecord(value)
        && Object.entries(value).every(([key, score]) => key.trim() !== ""
            && typeof score === "number"
            && Number.isFinite(score)
            && score >= 0
            && score <= 1);
}
export function validateEvaluatorResponseEnvelope(input) {
    if (!isRecord(input) || !Object.keys(input).every((key) => RESPONSE_KEYS.includes(key))) {
        return failure("result_protocol_invalid", "Evaluator response contains unknown fields.");
    }
    const required = [
        "protocolVersion",
        "runId",
        "attemptId",
        "stage",
        "status",
        "outputSummary",
        "environmentHash",
        "assetBundleHash",
    ];
    if (!required.every((key) => Object.hasOwn(input, key))) {
        return failure("result_protocol_invalid", "Evaluator response is missing required fields.");
    }
    if (!isNonEmptyString(input.protocolVersion)
        || !isNonEmptyString(input.runId)
        || !isNonEmptyString(input.attemptId)
        || !isStage(input.stage)
        || (input.status !== "ok" && input.status !== "failed" && input.status !== "evaluator_error")
        || typeof input.outputSummary !== "string"
        || !isNonEmptyString(input.environmentHash)
        || !isNonEmptyString(input.assetBundleHash)
        || HOST_PATH_PATTERN.test(input.outputSummary)
        || HOST_PATH_PATTERN.test(input.environmentHash)
        || HOST_PATH_PATTERN.test(input.assetBundleHash)) {
        return failure("result_protocol_invalid", "Evaluator response values are invalid.");
    }
    if (input.score !== undefined
        && (typeof input.score !== "number" || !Number.isFinite(input.score) || input.score < 0 || input.score > 1)) {
        return failure("result_protocol_invalid", "Evaluator score must be between zero and one.");
    }
    if (input.dimensionResults !== undefined && !validDimensionResults(input.dimensionResults)) {
        return failure("result_protocol_invalid", "Evaluator dimension scores are invalid.");
    }
    if (input.durationMs !== undefined
        && (typeof input.durationMs !== "number" || !Number.isFinite(input.durationMs) || input.durationMs < 0)) {
        return failure("result_protocol_invalid", "Evaluator duration must be non-negative.");
    }
    if ((input.score !== undefined || input.dimensionResults !== undefined) && input.stage !== "summarize") {
        return failure("result_protocol_invalid", "Scores are only valid during summarize.");
    }
    if (input.status === "ok") {
        if (input.errorKind !== undefined || input.errorCode !== undefined) {
            return failure("result_protocol_invalid", "Successful responses cannot contain errors.");
        }
    }
    else if (input.status === "failed") {
        if (input.errorKind !== "learner"
            || !isNonEmptyString(input.errorCode)
            || !LEARNER_EVALUATION_ERROR_CODES.has(input.errorCode)) {
            return failure("result_protocol_invalid", "Learner failures require a learner evaluation error code.");
        }
    }
    else if (input.errorKind !== "evaluator"
        || !isNonEmptyString(input.errorCode)
        || !EVALUATOR_ERROR_CODES.has(input.errorCode)
        || input.score !== undefined
        || input.dimensionResults !== undefined) {
        return failure("result_protocol_invalid", "Evaluator errors cannot be scored or attributed to the learner.");
    }
    return success(input);
}
