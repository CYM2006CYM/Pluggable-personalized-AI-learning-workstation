import type { ActivityResult } from "../domain/v2-types.js";
import { type CodeEvaluationPort, type PrepareEvaluationInput, type PreparedEvaluation, type RunEvaluationInput } from "./code-evaluation-port.js";
export interface MeasuredNodeEnvironment {
    environmentId: string;
    schemaVersion: 1;
    status: "measured_node_submit";
    nodeVersion: string;
    pythonVersion: string;
    pandasVersion: string;
    platform: string;
    evaluatorVersion: string;
    environmentHash: string;
    allowedLibraries: readonly {
        name: string;
        version: string;
    }[];
    limits: {
        wallClockMs: number;
        stdoutBytes: number;
        stderrBytes: number;
        sourceBytes: number;
        datasetBytes: number;
    };
    capabilityFlags: {
        reliableMemoryLimit: boolean;
        networkIsolation: boolean;
        processTreeTermination: boolean;
    };
    pyodideVersion: null;
    prototypeEvidenceRef: string;
    createdAt: string;
}
export interface PythonProcessCodeEvaluationAdapterOptions {
    profileRoot: string;
    pythonExecutable: string;
    runnerScript?: string;
    now?: () => Date;
    preparedTtlMs?: number;
}
export declare function isRuntimePlatformCompatible(environment: Pick<MeasuredNodeEnvironment, "capabilityFlags">, platform: string, arch: string): boolean;
export declare class PythonProcessCodeEvaluationAdapter implements CodeEvaluationPort {
    #private;
    constructor(options: PythonProcessCodeEvaluationAdapterOptions);
    prepare(input: PrepareEvaluationInput): Promise<PreparedEvaluation>;
    run(input: RunEvaluationInput, signal: AbortSignal): Promise<ActivityResult>;
}
