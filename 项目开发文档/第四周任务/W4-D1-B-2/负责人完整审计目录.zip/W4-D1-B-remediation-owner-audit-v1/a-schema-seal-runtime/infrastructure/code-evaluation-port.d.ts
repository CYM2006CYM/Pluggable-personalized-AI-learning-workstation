import type { ActivityResult, LearningRuntimeErrorCode } from "../domain/v2-types.js";
export type EvaluationMode = "preview" | "submit";
export interface EvaluationActivityProjection {
    activityId: string;
    kind: "code_completion" | "coding_practical" | "debug";
    profileRevision: number;
    templateVersion: string;
    environmentRef: string;
}
export interface EvaluationEnvironmentProjection {
    environmentId: string;
    status: "measured" | "measured_node_submit" | "draft_pending_C_prototype";
    environmentHash: string | null;
    prototypeEvidenceRef: string;
}
export interface PrepareEvaluationInput {
    activity: EvaluationActivityProjection;
    profileRevision: number;
    taskVersion: string;
    mode: EvaluationMode;
    environment: EvaluationEnvironmentProjection;
    assetBundleHash: string;
}
export interface PreparedEvaluation {
    preparedId: string;
    mode: EvaluationMode;
    activityId: string;
    profileRevision: number;
    environmentHash: string;
    assetBundleHash: string;
    expiresAt: string;
}
export interface RunEvaluationInput {
    requestId: string;
    attemptId: string;
    prepared: PreparedEvaluation;
    code: string;
}
export interface CodeEvaluationPort {
    prepare(input: PrepareEvaluationInput): Promise<PreparedEvaluation>;
    run(input: RunEvaluationInput, signal: AbortSignal): Promise<ActivityResult>;
}
type PreparationErrorCode = Extract<LearningRuntimeErrorCode, "profile_revision_conflict" | "activity_version_conflict" | "environment_mismatch" | "submission_contract_error" | "test_asset_invalid">;
type RunErrorCode = Extract<LearningRuntimeErrorCode, "idempotency_conflict">;
export declare class EvaluationPreparationError extends Error {
    readonly errorCode: PreparationErrorCode;
    constructor(errorCode: PreparationErrorCode, message: string);
}
export declare class EvaluationRunError extends Error {
    readonly errorCode: RunErrorCode;
    constructor(errorCode: RunErrorCode, message: string);
}
export interface FixtureCodeEvaluationAdapterOptions {
    resultsByActivityId: Readonly<Record<string, ActivityResult>>;
    evaluatorVersion?: string;
    now?: () => Date;
    preparedTtlMs?: number;
}
export declare class FixtureCodeEvaluationAdapter implements CodeEvaluationPort {
    #private;
    constructor(options: FixtureCodeEvaluationAdapterOptions);
    prepare(input: PrepareEvaluationInput): Promise<PreparedEvaluation>;
    run(input: RunEvaluationInput, signal: AbortSignal): Promise<ActivityResult>;
}
export {};
