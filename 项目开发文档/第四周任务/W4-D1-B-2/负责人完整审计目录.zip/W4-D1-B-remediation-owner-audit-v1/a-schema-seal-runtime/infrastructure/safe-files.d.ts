export declare function assertSafeSubjectId(subjectId: string): void;
export declare function assertSafeFileComponent(value: string, label: string): void;
export declare function assertPathInside(root: string, candidate: string): string;
export declare function resolveInside(root: string, ...segments: string[]): string;
export declare function assertSafeRelativePath(path: string): void;
export declare function writeJsonAtomic(path: string, value: unknown): Promise<void>;
export declare function writeTextAtomic(path: string, content: string): Promise<void>;
export declare function timestampForPath(date: Date): string;
