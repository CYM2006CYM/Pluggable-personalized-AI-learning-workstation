import type { Graph } from "pi-loop-graph-sdk";
import type { IsolatedGraphExecutor } from "../graphs/isolated-graph-executor.js";
export type ModelExecutionStatus = "ok" | "invalid_output" | "timeout" | "provider_error";
export interface ModelExecutionBudget {
    timeoutMs: number;
    maxTokens?: number;
}
export interface ModelExecutionInput {
    graphId: string;
    runId: string;
    profileRevision: number;
    promptVersion: string;
    safeContext: Readonly<Record<string, unknown>>;
    budget: ModelExecutionBudget;
}
export interface ModelExecutionResult {
    status: ModelExecutionStatus;
    payload?: unknown;
    errorCode?: string;
    sourceRefs: string[];
    traceSummary: string;
    modelId: string;
    promptVersion: string;
    durationMs?: number;
}
export interface ModelExecutionPort {
    execute(input: ModelExecutionInput, signal: AbortSignal): Promise<ModelExecutionResult>;
}
export interface RecordedModelResponseFixture {
    graphId: string;
    runId: string;
    status: ModelExecutionStatus;
    payload?: unknown;
    errorCode?: string;
    sourceRefs?: string[];
    traceSummary?: string;
    modelId?: string;
    promptVersion?: string;
    durationMs?: number;
}
export interface RecordedModelExecutionAdapterOptions {
    fixtures: readonly RecordedModelResponseFixture[];
    defaultModelId?: string;
}
export interface RecordedExecutionHistoryEntry {
    input: ModelExecutionInput;
    signalAborted: boolean;
}
export interface PiGraphModelExecutionAdapterOptions {
    executor: IsolatedGraphExecutor;
    graphs: readonly Graph[];
    modelId: string;
}
export declare function loadRecordedModelResponseFixtures(raw: string): RecordedModelResponseFixture[];
/** Converts SDK results at the infrastructure boundary; SDK objects never escape this adapter. */
export declare class PiGraphModelExecutionAdapter implements ModelExecutionPort {
    #private;
    constructor(options: PiGraphModelExecutionAdapterOptions);
    execute(input: ModelExecutionInput, signal: AbortSignal): Promise<ModelExecutionResult>;
}
export declare class RecordedModelExecutionAdapter implements ModelExecutionPort {
    #private;
    constructor(options: RecordedModelExecutionAdapterOptions);
    get history(): readonly RecordedExecutionHistoryEntry[];
    execute(input: ModelExecutionInput, signal: AbortSignal): Promise<ModelExecutionResult>;
}
