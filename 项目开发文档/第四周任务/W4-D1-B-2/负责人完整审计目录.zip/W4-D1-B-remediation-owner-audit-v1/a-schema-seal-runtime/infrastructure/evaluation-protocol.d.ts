import type { LearningRuntimeErrorCode } from "../domain/v2-types.js";
export declare const EVALUATOR_STAGE_ORDER: readonly ["prepare", "user_code", "public_tests", "hidden_tests", "summarize"];
export type EvaluatorStage = (typeof EVALUATOR_STAGE_ORDER)[number];
export type EvaluatorExecutableStage = Extract<EvaluatorStage, "user_code" | "public_tests" | "hidden_tests">;
export interface DatasetFixturesAsset {
    fixtures: DatasetFixtureRef[];
}
export interface DatasetFixtureRef {
    fixtureId: string;
    visibility: "public" | "private";
    fileRef: string;
    format: "csv";
    assetHash: string;
}
export interface TestCaseRef {
    testId: string;
    visibility: "public" | "hidden";
    fileRef: string;
    dimensionId: string;
    blocking: boolean;
    assetHash: string;
    fixtureRefs: string[];
}
export interface EvaluatorRequestEnvelope {
    protocolVersion: string;
    executionId: string;
    stage: EvaluatorExecutableStage;
    entryPoint: Record<string, unknown>;
    output: Record<string, unknown>;
    fixtureRefs: string[];
    deterministicSeed: number;
}
export interface EvaluatorResponseEnvelope {
    protocolVersion: string;
    runId: string;
    attemptId: string;
    stage: EvaluatorStage;
    status: "ok" | "failed" | "evaluator_error";
    errorKind?: "learner" | "evaluator";
    errorCode?: LearningRuntimeErrorCode;
    score?: number;
    dimensionResults?: Record<string, number>;
    outputSummary: string;
    environmentHash: string;
    assetBundleHash: string;
    durationMs?: number;
}
export type ProtocolValidationErrorCode = Extract<LearningRuntimeErrorCode, "test_asset_invalid" | "result_protocol_invalid">;
export type ProtocolValidationResult<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    errorCode: ProtocolValidationErrorCode;
    message: string;
};
export interface EvaluationAssetContext {
    fileHashes: ReadonlyMap<string, string>;
    symlinkPaths: ReadonlySet<string>;
}
export interface EvaluationBindingInput {
    fixtureAsset: unknown;
    activityDatasetRefs: unknown;
    argumentFixtureIds?: unknown;
    publicTests: unknown;
    hiddenTests: unknown;
    assetContext: EvaluationAssetContext;
}
export interface ExecutionBoundaryContract {
    temporaryDirectory: "unique_per_run";
    cleanup: "always_on_success_failure_cancel";
    processIsolation: "separate_clean_public_hidden_processes";
    hiddenAssetsOwner: "node_parent_only";
    hiddenAssetsInUserDirectory: false;
    workingDirectory: "fixed_per_run";
    environmentVariables: "minimal_allowlist";
    shell: false;
    timeoutAction: "terminate_process_tree";
    outputHandling: "truncate_escape_stdout_stderr";
}
export interface PrototypeMeasurementQuestion {
    questionId: string;
    constraint: string;
    status: "pending_C_prototype";
    evidenceRef: null;
    ownerDecision: "pending_after_prototype_evidence";
}
export interface ExecutionBoundaryFixture {
    executionConstraints: ExecutionBoundaryContract;
    prototypeMeasurements: PrototypeMeasurementQuestion[];
}
export type FixtureRefsByStage = Readonly<Record<EvaluatorStage, readonly string[]>>;
export declare function validateDatasetFixturesAsset(input: unknown, context?: Partial<EvaluationAssetContext>): ProtocolValidationResult<DatasetFixturesAsset>;
export declare function validateEvaluationBindings(input: EvaluationBindingInput): ProtocolValidationResult<FixtureRefsByStage>;
export declare function validateStageSequence(stages: readonly unknown[]): ProtocolValidationResult<readonly EvaluatorStage[]>;
export declare function validateEvaluatorRequestEnvelope(input: unknown, expectedFixtureRefs?: readonly string[]): ProtocolValidationResult<EvaluatorRequestEnvelope>;
export declare function validateExecutionBoundaryFixture(input: unknown): ProtocolValidationResult<ExecutionBoundaryFixture>;
export declare function validateEvaluatorResponseEnvelope(input: unknown): ProtocolValidationResult<EvaluatorResponseEnvelope>;
