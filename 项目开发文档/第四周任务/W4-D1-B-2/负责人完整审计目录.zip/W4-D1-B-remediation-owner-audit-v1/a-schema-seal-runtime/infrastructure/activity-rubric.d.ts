import type { ActivityResult, LearningRuntimeErrorCode } from "../domain/v2-types.js";
export interface RubricDimensionDefinition {
    dimensionId: string;
    weight: number;
    blocking: boolean;
    safeFeedbackCodes: readonly string[];
}
export interface ActivityRubricDefinition {
    passThreshold: number;
    dimensions: readonly RubricDimensionDefinition[];
    dimensionTestMap: Readonly<Record<string, readonly string[]>>;
}
export interface RubricTestBinding {
    testId: string;
    dimensionId: string;
    blocking: boolean;
}
export interface InternalTestResult extends RubricTestBinding {
    passed: boolean;
}
export interface RubricSummaryInput {
    rubric: ActivityRubricDefinition;
    tests: readonly InternalTestResult[];
    evaluatorVersion: string;
    environmentHash: string;
    assetBundleHash: string;
}
export interface LearnerFailureInput {
    errorCode: Extract<LearningRuntimeErrorCode, "syntax_error" | "runtime_error" | "test_failed" | "timeout" | "output_limit" | "disallowed_import" | "submission_contract_error">;
    evaluatorVersion: string;
    environmentHash: string;
    assetBundleHash: string;
    safeFeedback: string;
}
export interface EvaluatorFailureInput {
    errorCode: Extract<LearningRuntimeErrorCode, "environment_mismatch" | "evaluator_error" | "evaluator_start_failed" | "evaluator_timeout" | "dependency_missing" | "test_asset_invalid" | "result_protocol_invalid" | "runner_crash">;
    evaluatorVersion: string;
    environmentHash: string;
    assetBundleHash: string;
    safeFeedback: string;
}
export declare function validateRubricDefinition(value: unknown, tests: readonly RubricTestBinding[]): value is ActivityRubricDefinition;
export declare function summarizeRubric(input: RubricSummaryInput): ActivityResult;
export declare function learnerFailure(input: LearnerFailureInput): ActivityResult;
export declare function evaluatorFailure(input: EvaluatorFailureInput): ActivityResult;
