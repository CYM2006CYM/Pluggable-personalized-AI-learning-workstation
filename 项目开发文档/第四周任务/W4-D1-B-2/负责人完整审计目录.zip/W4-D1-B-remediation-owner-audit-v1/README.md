# Owner-only complete audit input

This directory contains all candidate file bodies, including private answers and frozen private inputs. Do not distribute it as the public transport ZIP. Start with `audit-input.json`.
