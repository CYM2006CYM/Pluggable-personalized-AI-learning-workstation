import { createHash } from "node:crypto";
import { readFile, readdir, stat, writeFile } from "node:fs/promises";
import { relative, resolve } from "node:path";

const profileRoot = resolve(process.argv[2] ?? "fixtures/profiles/pandas-cleaning-revision-3-draft");
const revision2Root = resolve(process.argv[3] ?? "fixtures/profiles/pandas-cleaning-v2-draft");
const qualityRoot = resolve(profileRoot, "quality");
const sha256 = (value) => createHash("sha256").update(value).digest("hex");

async function files(root) {
  const result = [];
  for (const entry of await readdir(root, { withFileTypes: true })) {
    const absolute = resolve(root, entry.name);
    if (entry.isDirectory()) result.push(...await files(absolute));
    else if (entry.isFile()) result.push(absolute);
  }
  return result;
}

async function inventory(root, exclude = new Set()) {
  const entries = [];
  for (const absolute of await files(root)) {
    const path = relative(root, absolute).replaceAll("\\", "/");
    if (exclude.has(path)) continue;
    const bytes = await readFile(absolute);
    entries.push({ path, sha256: sha256(bytes), byteLength: (await stat(absolute)).size });
  }
  entries.sort((a, b) => Buffer.compare(Buffer.from(a.path), Buffer.from(b.path)));
  return entries;
}

const revision2Entries = await inventory(revision2Root);
const revision2TreeSha256 = sha256(revision2Entries.map((entry) => `${entry.path}\0raw-binary\0${entry.sha256}\0${entry.byteLength}\n`).join(""));
const revision3Entries = await inventory(profileRoot, new Set(["quality/revision-seal.json"]));
const privatePrefixes = [
  "assessments/private/", "assessments/diagnostic/private/", "assessments/quiz-fallback/private/",
  "datasets/private/", "rubrics/", "reference-solutions/",
];
const privateEntries = revision3Entries.filter((entry) => privatePrefixes.some((prefix) => entry.path.startsWith(prefix)));
const publicEntries = revision3Entries.filter((entry) => !privatePrefixes.some((prefix) => entry.path.startsWith(prefix)));
const coverage = {
  status: "candidate",
  coreKnowledgePointCount: 6,
  coreKnowledgePoints: [
    ["pandas.clean.read-csv", "card-w4-read-csv", "act-read-csv", "w4-fixed-read-csv-v1", "w4-supplemental-read-csv-v1"],
    ["pandas.clean.inspect-dataframe", "card-w4-inspect-dataframe", "act-quiz-inspect-dataframe", "w4-fixed-inspect-dataframe-v1", "w4-supplemental-inspect-dataframe-v1"],
    ["pandas.clean.missing-values", "card-w4-missing-values", "act-quiz-missing-values", "w4-fixed-missing-values-v1", "w4-supplemental-missing-values-v1"],
    ["pandas.clean.duplicate-orders", "card-w4-duplicate-orders", "act-quiz-duplicate-orders", "w4-fixed-duplicate-orders-v1", "w4-supplemental-duplicate-orders-v1"],
    ["pandas.clean.type-format", "card-w4-type-format", "act-quiz-type-format", "w4-fixed-type-format-v1", "w4-supplemental-type-format-v1"],
    ["pandas.clean.validate-result", "card-w4-validate-result", "act-quiz-validate-result", "w4-fixed-validate-result-v1", "w4-supplemental-validate-result-v1"],
  ].map(([knowledgePointId, cardId, activityId, fixedQuestionGroupId, supplementalQuestionGroupId]) => ({ knowledgePointId, cardId, activityId, fixedQuestionGroupId, supplementalQuestionGroupId })),
  excludedAuxiliaryKnowledgePointIds: ["basic-python"],
  fixedQuestionCountPerGroup: 4,
  supplementalQuestionCountPerGroup: 1,
  supplementalPurpose: "dynamic candidate completion only; never a complete fixed retry group",
};
const isolation = {
  status: "candidate",
  publicAssets: ["cards/learning-cards.json", "assessments/question-groups.json"],
  privateAssets: privateEntries,
  privatePrefixes,
  ownerAuditRequirement: "Private asset bodies are excluded from ordinary transport ZIPs, but must be supplied in a responsible-person-readable complete audit directory that is bound by this report, the full file manifest and the revision seal.",
  prohibitedPublicTokens: ["correctAnswer", "privateAnswerRef", "referenceSolution", "hiddenTest", "rubric", "orders-variant"],
  conclusion: "Public card and quiz assets contain no answer keys, explanations, private answer references, rubrics, hidden-test references, reference solutions, or private CSV identifiers.",
};
const immutability = {
  status: "candidate",
  sourceRevision: 2,
  sourceDirectory: "fixtures/profiles/pandas-cleaning-v2-draft",
  fileCount: revision2Entries.length,
  treeSha256: revision2TreeSha256,
  algorithm: "relative POSIX path sorted by UTF-8 bytes; raw-binary SHA-256 and byte length",
  entries: revision2Entries,
};
const assetInventory = {
  status: "candidate",
  profileDirectory: "fixtures/profiles/pandas-cleaning-revision-3-draft",
  excludesRevisionSeal: true,
  fileCount: revision3Entries.length,
  entries: revision3Entries,
};
await Promise.all([
  writeFile(resolve(qualityRoot, "w4-b-coverage-matrix.json"), `${JSON.stringify(coverage, null, 2)}\n`),
  writeFile(resolve(qualityRoot, "w4-b-answer-isolation-report.json"), `${JSON.stringify(isolation, null, 2)}\n`),
  writeFile(resolve(qualityRoot, "w4-b-revision-2-immutability.json"), `${JSON.stringify(immutability, null, 2)}\n`),
  writeFile(resolve(qualityRoot, "w4-b-asset-inventory.json"), `${JSON.stringify(assetInventory, null, 2)}\n`),
]);
console.log(JSON.stringify({ status: "PASS", revision2TreeSha256, revision2FileCount: revision2Entries.length, revision3InventoryCount: revision3Entries.length, privateAssetCount: privateEntries.length }, null, 2));
