# W4-B-D1 asset validation

`validate-w4-b-d1.mjs` validates only B-owned revision 3 assets: core coverage, cards, MCQ group shape, ordered private keys, source anchors, public leakage, and the frozen revision 2 asset tree.

`generate-delivery-evidence.mjs` writes the candidate inventory, revision 2 immutability proof, six-point coverage matrix, and answer-isolation report beneath the revision 3 `quality/` directory. Run it before final seal generation. `generate-revision-seal.mjs` then creates the seal with A's W4-C2 algorithm; rerun the validator and the generator after any content-byte change.
