# W4-B-D1 scope audit

Allowed candidate paths only:

- `fixtures/profiles/pandas-cleaning-revision-3-draft/`
- `scripts/w4-b-validation/`
- `../../新版设计文档-重写版/第四周任务/handoff-w4-b-d1.md`

No `src/`, HTTP, Agent, Web, SDK, dependency, lockfile, revision 2, formal gold, Rubric, hidden-test, TaskBundle, reference-solution, or W3 environment-lock file is modified. Revision 3 preserves copied frozen code-evaluation assets; `quality/w4-b-revision-2-immutability.json` records the original revision 2 tree independently.

Candidate state: `NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`.
