# W4-D1-B remediation transport package

This ordinary transport package is public-safe. It intentionally withholds private candidate bodies. The responsible-person-readable complete candidate audit input is identified in `owner-audit-access.json` and bound by the full manifest and revision seal.
