# W4-D2-D-3 整改后验证报告

状态：`D_REMEDIATION_PASS / FULL_VERIFY_BLOCKED_BY_PREEXISTING_V2_6_TIMEOUT`

## 已确认基线

- 实际 `HEAD` 与 `origin/main`：`6b8d87541919ffba64bcc2845bfad47ffffcdf0a`，两者一致。
- A 正式提交：`4c52eb7c78fa80007aa9a8ab4e00768d71d3f3f5`，祖先检查退出 0。
- B 正式提交：`56398ab5f44283e9c10b6d66ec2f0732cc043790`，祖先检查退出 0。
- B 之后仅有负责人第四周审计文档索引提交 `6b8d875`；未出现额外源码、合同或 Profile 修改。
- revision 3 独立读取正式 seal：78 entries，`e118fd65c4583821f686cba4faab5990a81d2149a8f73cf89af2c376ba15b352`。

## 实现结论

- `AdaptiveContentService` 只实现 A 冻结的 `AdaptiveContentPort`，仅返回候选或 `unavailable`。
- quiz 与 card 使用独立 `artifactKind`、稳定运行键、checkpoint 和私有缓存。
- 低风险 quiz 仅执行 Generator；高风险 quiz 执行 Generator → Hunter → 条件 Defender → Judge；所有 card 进入完整审核链。
- Hunter/Judge 不接收动态题的 `correctAnswer` 或 `explanation`；任何额外 authority 字段、私有资产请求、绝对路径或凭据形态内容均拒绝。
- 15 秒返回 `unavailable`；15–60 秒合格晚到结果仅进入私有缓存；到达 60 秒的结果丢弃。
- `CapabilityTaskService` 只接受两个冻结触发器，异步生成五维 `complete/partial/unverified` 快照；任务状态与快照状态分离，失败保留旧快照。
- `SessionCapabilityEvidenceProvider` 只依赖 A 的 `SessionBindingReader` 只读正式快照，校验 session/revision/evidenceVersion/evidenceId/knowledgePointId，并用字段白名单生成 safeSummary。
- 当前会话版本允许绑定该版本之前的全部累积正式 Evidence；会话最新版本仍必须等于任务版本，Evidence归属、版本上界和ID唯一性仍严格校验。
- 画像更新保留同一Profile revision下上一快照的已验证维度，仅替换本次模型实际返回的维度；失败、过期和无证据不会清空旧画像。
- revision 3使用D所有、显式版本化的保守可观察维度映射表；映射只使用公开的Profile revision、knowledgePointId、activityId和Evidence form，未知组合返回空映射，不根据答对答错或分数猜测维度。
- CapabilityScorer提示词、Graph提示词、录制响应和程序校验均要求画像理由包含简体中文。
- `createW4DModelGraphs()` 提供 C 可注册的 `generator/hunter/defender/judge/capability-scorer` 五个 D Graph；未知 graphId 通过 `PiGraphModelExecutionAdapter` 返回 `graph=unavailable`。
- 所有 checkpoint、缓存、轨迹、画像快照和画像任务状态的文件实现均限定在 Profile 族 `_user/w4-d/`。
- 没有接入在线模型、真实 Key 或运行时 CIDPP。状态为 `LIVE_NOT_RUN`。

## 验证结果

- 官方 Node v22.23.1 便携包 SHA-256 与 Node 官方 `SHASUMS256.txt` 一致；合同环境 npm 为 10.9.8。
- 仓库外 Python v3.13.7 / Pandas 3.0.5 环境完成预检，且正式测试禁用用户 site-packages。
- `npm run typecheck`：PASS。
- D 定向/回归：7 files、37 tests，全部 PASS。
- A/D 受影响回归：11 files、83 tests，全部 PASS。
- 六类录制响应：14 条，覆盖与敏感扫描 PASS；capability-scorer 绑定 A 正式 session 轨迹；`LIVE_NOT_RUN`。
- `npm run check:docs`、`npm run smoke:extension`、`npm run check:release`：PASS。
- 合同环境 `npm run verify`：最终 `r2` 与 `r3` 均为 77 files、726 passed、1 failed、1 skipped，退出 1；失败均为既有 W2 V2-6 固定 30 秒外层 wrapper 超时，不得写作全量 PASS。
- 独立 V2-6 direct runner 在候选和干净基线中均完成 development=20、final=60 并退出 0；该对照支持“基础设施/既有门禁时序问题”归因，不构成 `npm run verify` 的 PASS。
- 合同 Node v22.23.1 / Python 3.13.7 / Pandas 3.0.5 下，Python 评测相关 2 files、26 tests 全部 PASS。
- 本轮每条最终命令均保存实际开始/结束时间、退出码、项数以及stdout/stderr SHA-256；原始日志保存在仓库外临时目录，不进入Git候选。
- 历史首次失败不被改写；本轮 `r2-*` 与 `r3-*` 结果逐条保留在唯一 `command-results.json` 中。D未修改W2验证器、A/B/C实现或依赖锁文件。

## 发布状态

`NOT_COMMITTED`、`NOT_PUSHED`、`uploadLock=NOT_REQUESTED`。未进行持久 Profile 激活，未修改 HTTP/Web，未签发 C 开工或 W4 GO。
