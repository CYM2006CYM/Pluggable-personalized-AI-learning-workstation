import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import type { ActivityDraftOutput, ActivitySubmissionOutput, QuizAnswerInput } from "../../contracts/index.js";
import { api, isApiError, isEvaluatorFailure, newRequestId, quizScore, type EvaluatorFailureView } from "../api/client.js";
import { useBootstrap } from "../api/use-bootstrap.js";
import { PageFrame } from "../components/PageFrame.js";
import { PageStatePanel } from "../components/PageStatePanel.js";
import { useUiStore } from "../state/ui-store.js";
import { STABLE_LAYOUT } from "../styles/layout-contract.js";

type SubmitResult = ActivitySubmissionOutput | EvaluatorFailureView;

export function ActivityPage() {
  const { sessionId = "", activityId = "" } = useParams<{ sessionId: string; activityId: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const bootstrap = useBootstrap(sessionId);
  const [opened, setOpened] = useState<ActivityDraftOutput | undefined>((location.state as { opened?: ActivityDraftOutput } | null)?.opened);
  const [result, setResult] = useState<SubmitResult>();
  const [preparedText, setPreparedText] = useState<string>();
  const [answers, setAnswers] = useState<Record<string, string | boolean>>({});
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<Error>();
  const [recovering, setRecovering] = useState(false);
  const [recoveryAttempted, setRecoveryAttempted] = useState(false);
  const drafts = useUiStore((state) => state.activityDrafts);
  const setDraft = useUiStore((state) => state.setActivityDraft);
  const session = bootstrap.data?.session;
  const localDraft = opened?.kind === "code" ? drafts[opened.attemptId] ?? opened.userText : "";

  useEffect(() => {
    if (opened?.kind === "code" && drafts[opened.attemptId] === undefined) setDraft(opened.attemptId, opened.userText);
  }, [drafts, opened, setDraft]);

  useEffect(() => {
    const attempt = session?.currentAttempt;
    if (bootstrap.loading || opened !== undefined || recoveryAttempted || session === undefined || attempt?.activityId !== activityId || session.path === undefined) return;
    const { sessionVersion, profileRevision } = session.view;
    const pathVersion = session.path.pathVersion;
    setRecoveryAttempted(true);
    setRecovering(true);
    api.getNextStep({
      sessionId,
      sessionVersion,
      profileRevision,
      pathVersion,
    }).then((next) => {
      if (next.activity?.activityId !== activityId) throw new Error("activity_safe_view_incomplete");
      return api.openActivity({
        requestId: newRequestId("web-recover-attempt"),
        sessionId,
        sessionVersion: next.sessionVersion,
        profileRevision: next.profileRevision,
        activityId,
        activityVersion: next.activity.activityVersion,
        pathVersion: next.pathVersion,
        ...(next.card === undefined ? {} : { acknowledgedCardId: next.card.cardId }),
      });
    }).then((recovered) => {
      if (recovered.attemptId !== attempt.attemptId) throw new Error("attempt_identity_changed_during_recovery");
      setOpened(recovered);
    }).catch((error: unknown) => {
      setActionError(error instanceof Error ? error : new Error("activity_recovery_failed"));
    }).finally(() => setRecovering(false));
  }, [activityId, bootstrap.loading, opened, recoveryAttempted, session, sessionId]);

  const completeAnswers = useMemo<QuizAnswerInput[]>(() => opened?.kind !== "quiz" ? [] : opened.activity.questions.flatMap((question) => answers[question.questionId] === undefined ? [] : [{ questionId: question.questionId, answer: answers[question.questionId]! }]), [answers, opened]);

  const saveCodeDraft = async () => {
    if (opened?.kind !== "code") return;
    setBusy(true); setActionError(undefined);
    try {
      const saved = await api.saveActivityDraft({ requestId: newRequestId("web-save-code"), sessionId, sessionVersion: opened.sessionVersion, profileRevision: opened.profileRevision, activityId, activityVersion: opened.activity.activityVersion, attemptId: opened.attemptId, draftVersion: opened.draftVersion, userText: localDraft });
      setOpened(saved);
    } catch (error) { setActionError(error instanceof Error ? error : new Error("draft_save_failed")); }
    finally { setBusy(false); }
  };

  const preview = async () => {
    if (opened?.kind !== "code") return;
    setBusy(true); setActionError(undefined);
    try {
      const prepared = await api.prepareActivityRun({ requestId: newRequestId("web-preview"), sessionId, sessionVersion: opened.sessionVersion, profileRevision: opened.profileRevision, activityId, activityVersion: opened.activity.activityVersion, attemptId: opened.attemptId, draftVersion: opened.draftVersion, mode: "preview" });
      setPreparedText(`${prepared.environmentId} · ${prepared.publicTestSources.length} 项公开检查`);
    } catch (error) { setActionError(error instanceof Error ? error : new Error("preview_failed")); }
    finally { setBusy(false); }
  };

  const submit = async () => {
    if (opened === undefined) return;
    setBusy(true); setActionError(undefined);
    try {
      const submitted = await api.submitActivity(opened.kind === "quiz" ? {
        requestId: newRequestId("web-submit-quiz"), sessionId, sessionVersion: opened.sessionVersion, profileRevision: opened.profileRevision,
        kind: "quiz", activityId, activityVersion: opened.activity.activityVersion, attemptId: opened.attemptId, answers: completeAnswers,
      } : {
        requestId: newRequestId("web-submit-code"), sessionId, sessionVersion: opened.sessionVersion, profileRevision: opened.profileRevision,
        kind: "code", activityId, activityVersion: opened.activity.activityVersion, attemptId: opened.attemptId, draftVersion: opened.draftVersion, userText: localDraft,
      });
      setResult(submitted); await bootstrap.reload();
    } catch (error) { setActionError(error instanceof Error ? error : new Error("activity_submit_failed")); }
    finally { setBusy(false); }
  };

  const advance = async (retry: boolean) => {
    setBusy(true); setActionError(undefined);
    try {
      const fresh = await api.getBootstrap(sessionId);
      if (fresh.session?.path === undefined) throw new Error("path_not_recoverable");
      const next = await api.getNextStep({ sessionId, sessionVersion: fresh.session.view.sessionVersion, profileRevision: fresh.session.view.profileRevision, pathVersion: fresh.session.path.pathVersion });
      if (next.completed || next.node === undefined || next.activity === undefined) { navigate(`/summary/${sessionId}`); return; }
      if (retry) {
        const nextOpened = await api.openActivity({ requestId: newRequestId("web-open-retry"), sessionId, sessionVersion: next.sessionVersion, profileRevision: next.profileRevision, activityId: next.activity.activityId, activityVersion: next.activity.activityVersion, pathVersion: next.pathVersion, ...(next.card === undefined ? {} : { acknowledgedCardId: next.card.cardId }) });
        setOpened(nextOpened); setResult(undefined); setAnswers({}); navigate(`/activity/${sessionId}/${next.activity.activityId}`, { replace: true, state: { opened: nextOpened, nodeId: next.node.nodeId } });
      } else navigate(`/learn/${sessionId}/${next.node.nodeId}`, { state: { next } });
    } catch (error) { setActionError(error instanceof Error ? error : new Error("advance_failed")); }
    finally { setBusy(false); }
  };

  const error = actionError ?? bootstrap.error;
  const submittedProgress = session?.activityProgress.flatMap((node) => node.activities).find((activity) => activity.activityId === activityId && activity.status !== "pending" && activity.status !== "in_progress");
  const refreshBlocked = !bootstrap.loading && !recovering && error === undefined && opened === undefined && session?.currentAttempt?.activityId === activityId;
  const title = opened?.activity.title ?? "活动恢复";
  const summary = opened?.activity.prompt ?? "从服务端 Attempt 安全视图恢复当前活动。";
  return <PageFrame eyebrow={opened?.kind === "quiz" ? "客观题组" : "代码活动"} title={title} summary={summary} actions={<span className="header-badge">{opened?.kind ?? session?.currentAttempt?.kind ?? "loading"}</span>}>
    {bootstrap.loading || recovering ? <PageStatePanel page="activity" state="loading" /> : null}
    {!bootstrap.loading && !recovering && error ? <PageStatePanel page="activity" state={isApiError(error) && error.status === 409 ? "conflict" : "error"} code={isApiError(error) ? error.code : error.message} onRetry={() => { setActionError(undefined); setRecoveryAttempted(false); void bootstrap.reload(); }} /> : null}
    {refreshBlocked ? <PageStatePanel page="activity" state="recovery" code="ACTIVITY_SAFE_VIEW_INCOMPLETE" detail="服务端保留了当前 Attempt，但无法用当前安全 API 重新取得相同活动内容。页面不会创建替代 Attempt。" onRetry={() => { setRecoveryAttempted(false); void bootstrap.reload(); }} /> : null}
    {!bootstrap.loading && !recovering && error === undefined && !refreshBlocked && opened === undefined && submittedProgress !== undefined ? <PageStatePanel page="activity" state="recovery" code="SUBMITTED_PROGRESS_RECOVERED" detail={`Bootstrap 已恢复该活动的 ${submittedProgress.status}/${submittedProgress.result ?? "unverified"} 进度；现行快照不包含提交后的完整安全复盘。`} /> : null}
    {!bootstrap.loading && !recovering && error === undefined && !refreshBlocked && opened === undefined && submittedProgress === undefined ? <PageStatePanel page="activity" state="empty" /> : null}
    {!bootstrap.loading && error === undefined && opened !== undefined ? <div className="activity-layout" data-page="activity"><aside className="activity-brief"><p className="section-kicker">ACTIVITY CONTRACT</p><dl className="metric-list"><div><dt>知识点</dt><dd>{opened.activity.primaryKnowledgePointId}</dd></div><div><dt>活动版本</dt><dd>{opened.activity.activityVersion}</dd></div><div><dt>Attempt</dt><dd>{opened.attemptId}</dd></div><div><dt>会话版本</dt><dd>{opened.sessionVersion}</dd></div></dl><p className="notice-line">打开阶段不会显示答案；正式提交后只显示安全复盘字段。</p></aside><div className="activity-workspace"><section className="activity-stage" style={{ minHeight: STABLE_LAYOUT.activityStageMinHeight }}>{result !== undefined ? <ResultView value={result} /> : opened.kind === "quiz" ? <><fieldset className="answer-list"><legend className="sr-only">题组答案</legend>{opened.activity.questions.map((question, questionIndex) => <div className="quiz-question" key={question.questionId}><h2>{questionIndex + 1}. {question.prompt}</h2>{question.kind === "judgment" ? [true, false].map((value) => <label className="answer-option" key={String(value)}><input type="radio" name={question.questionId} checked={answers[question.questionId] === value} onChange={() => setAnswers({ ...answers, [question.questionId]: value })} /><span>{value ? "正确" : "错误"}</span></label>) : question.options.map((option) => <label className="answer-option" key={option}><input type="radio" name={question.questionId} checked={answers[question.questionId] === option} onChange={() => setAnswers({ ...answers, [question.questionId]: option })} /><span>{option}</span></label>)}</div>)}</fieldset><div className="section-footer"><span>{completeAnswers.length}/{opened.activity.questions.length} 已回答</span><button type="button" className="button primary" disabled={busy || completeAnswers.length !== opened.activity.questions.length} onClick={() => void submit()}>提交完整题组</button></div></> : <><label htmlFor="code-draft">代码草稿</label><textarea id="code-draft" value={localDraft} onChange={(event) => setDraft(opened.attemptId, event.target.value)} spellCheck={false} /><p className="notice-line">{preparedText ?? "预览只运行公开检查，不写正式 Evidence。"}</p><div className="section-footer"><div className="button-row"><button type="button" className="button secondary" disabled={busy} onClick={() => void saveCodeDraft()}>保存草稿</button><button type="button" className="button secondary" disabled={busy} onClick={() => void preview()}>运行公开检查</button></div><button type="button" className="button primary" disabled={busy || localDraft === ""} onClick={() => void submit()}>提交正式评测</button></div></>} {result !== undefined && !isEvaluatorFailure(result) ? <div className="section-footer">{result.kind === "quiz" && result.result.retryAllowed ? <button type="button" className="button primary" disabled={busy} onClick={() => void advance(true)}>开始新 Attempt 重试</button> : <button type="button" className="button primary" disabled={busy} onClick={() => void advance(false)}>进入下一活动</button>}</div> : null}</section></div></div> : null}
  </PageFrame>;
}

function ResultView({ value }: { value: SubmitResult }) {
  if (isEvaluatorFailure(value)) return <div className="evaluator-stage" role="alert"><p className="state-code">{value.errorCode}</p><h2>评测器暂时不可用</h2><p>本次未评分，草稿和正式学习状态均不应推进。</p></div>;
  if (value.kind === "code") return <div className="result-stage"><div className="result-header"><div><p className="section-kicker">SERVER VERDICT</p><h2>{value.result.verdict}</h2></div><span className="score-block">{value.result.score} / 1</span></div><p className="feedback-copy">{value.result.safeFeedback}</p><dl className="metric-list horizontal"><div><dt>执行状态</dt><dd>{value.result.executionStatus}</dd></div><div><dt>错误类型</dt><dd>{value.result.errorCode}</dd></div><div><dt>评测版本</dt><dd>{value.result.evaluatorVersion}</dd></div></dl></div>;
  const score = quizScore(value.result);
  return <div className="result-stage"><div className="result-header"><div><p className="section-kicker">SERVER VERDICT</p><h2>{value.result.verdict}</h2></div><span className="score-block">{score === null ? "N/A" : score.toFixed(2)}</span></div><p className="feedback-copy">{value.result.safeFeedback}</p><dl className="metric-list horizontal"><div><dt>正确题数</dt><dd>{value.result.correctCount}/{value.result.totalCount}</dd></div><div><dt>通过阈值</dt><dd>{value.result.requiredCorrectCount}</dd></div><div><dt>Evidence</dt><dd>{value.evidenceId ?? "无"}</dd></div></dl>{value.result.answerReview === undefined ? null : <section className="answer-review"><h2>提交后安全复盘</h2>{value.result.answerReview.map((item) => <div key={item.questionId}><strong>{item.questionId} · {item.correct ? "正确" : "需复习"}</strong><p>正确答案：{String(item.correctAnswer)}</p><p>{item.explanation}</p><small>{item.sourceAnchorIds.join(", ")}</small></div>)}</section>}</div>;
}
