# W4-D4 E 阻塞问题单

## ENVIRONMENT_MISMATCH

- 预期：Node `v22.23.1`、Python `3.13.7`、Pandas `3.0.5`。
- 实际：Node `v24.18.0`；`python.exe` 与 `python3.exe` 均为 WindowsApps `0.0.0.0` 占位入口；Pandas 不可用。
- 复现：在 `pi-study-helper` 执行 `npm.cmd test -- --run --maxWorkers=1`。
- 结果：84 个测试文件中 81 通过、3 失败；719 项中 692 通过、26 失败、1 跳过。
- 失败文件：`python-process-evaluation-r2.test.ts`、`python-process-evaluation.test.ts`、`w3-b-d1-delivery.test.ts`。
- 归因：环境；E 未修改 Python 评测器、B 资产或环境锁。

## PORT_OCCUPIED

- 预期：Demo API 固定监听 `127.0.0.1:4310`，Vite 固定监听 `127.0.0.1:5173`。
- 实际：4310 被用户进程 `QQ.exe` PID `34036` 监听。
- 处理：未终止用户进程，未漂移端口。
- 影响：真实 Demo 浏览器截图为 `BLOCKED`；in-process 真实 HTTP 轨迹、Vite 安全直链与 DOM 测试继续独立执行。

## UPSTREAM_A_NEXT_STEP_REVIEW_TIMELINE_MISSING

- 预期：学习页从安全 `NextStepOutput` 展示审核时间线。
- 实际：A `NextStepOutput` 无 `reviewTimeline`。
- 影响：学习页明确显示 `UPSTREAM_CONTRACT_BLOCKED`，不伪造审核记录。

## UPSTREAM_A_BOOTSTRAP_EVIDENCE_VERSION_MISSING

- 预期：诊断完成后若首次建路失败，刷新可从 Bootstrap 取得重试所需版本。
- 实际：`SessionRecoverySafeView` 无 `evidenceVersion`。
- 影响：该失败恢复分支停止推进，不使用 Web 内存猜测版本。

## UPSTREAM_A_COMPLETED_SUMMARY_SNAPSHOT_MISSING

- 预期：完成会话刷新后恢复完整总结和 KnowledgeState。
- 实际：完成态 Bootstrap 只保留活动进度，不提供已持久化 `CompleteSessionOutput` 或完整 KnowledgeState 投影。
- 影响：总结页只展示可复算进度并明确 `COMPLETED_SUMMARY_NOT_IN_BOOTSTRAP`。

## QUIZ ATTEMPT 复核结果

最初合同静态检查认为 quiz 草稿题面无法恢复。E 随后通过真实 HTTP 证明：Bootstrap 的 `currentAttempt` 可驱动 `getNextStep -> openActivity`，返回相同 `attemptId` 和相同 `questionIds`，且不创建新 Attempt。该项已由 E 消费端安全恢复，不再单独阻塞；其证据在 `real-api.test.ts`。
