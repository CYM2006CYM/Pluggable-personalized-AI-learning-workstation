// @vitest-environment jsdom
import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { createMemoryRouter, RouterProvider } from "react-router-dom";
import { afterEach, describe, expect, it, vi } from "vitest";
import { appRoutes } from "../../src/web/app/routes.js";
import { PageStatePanel } from "../../src/web/components/PageStatePanel.js";
import { bootstrap, fail, nextStep, ok, openedQuiz, recovery } from "./fixtures/w4-api.js";

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
let root: Root | undefined;

afterEach(() => {
  act(() => root?.unmount()); root = undefined; vi.unstubAllGlobals(); document.body.innerHTML = "";
});

async function renderRoute(pathname: string, fetchImpl: ReturnType<typeof vi.fn>, state?: unknown) {
  vi.stubGlobal("fetch", fetchImpl);
  const host = document.createElement("div"); document.body.append(host); root = createRoot(host);
  const router = createMemoryRouter(appRoutes, { initialEntries: [state === undefined ? pathname : { pathname, state }] });
  await act(async () => { root!.render(<RouterProvider router={router} />); await new Promise((resolve) => setTimeout(resolve, 0)); });
  return { host, router };
}

describe("W4 real API pages", () => {
  it("renders the start page from Bootstrap with both entry modes and three questionnaire fields", async () => {
    const { host } = await renderRoute("/", vi.fn().mockResolvedValue(ok(bootstrap())));
    expect(host.textContent).toContain("Pandas Cleaning");
    expect(host.textContent).toContain("系统推荐"); expect(host.textContent).toContain("按章节学习");
    expect(host.querySelectorAll("select")).toHaveLength(5);
    expect(host.textContent).not.toContain("Mock DTO");
  });

  it("renders the recommended diagnostic from the safe envelope", async () => {
    const session = recovery({ stage: "diagnostic" });
    const { host } = await renderRoute("/diagnostic/session-w4", vi.fn().mockResolvedValue(ok(bootstrap(session))));
    expect(host.textContent).toContain("哪个表达式创建列表");
    expect(host.textContent).toContain("Draft v1");
  });

  it("renders all W4 path node fields", async () => {
    const session = recovery({ stage: "path" });
    const { host } = await renderRoute("/path/session-w4", vi.fn().mockResolvedValue(ok(bootstrap(session))));
    expect(host.textContent).toContain("S-R"); expect(host.textContent).toContain("worked_example");
    expect(host.textContent).toContain("必需"); expect(host.textContent).toContain("位置锁定");
  });

  it("renders the learning card and reports the missing upstream review timeline", async () => {
    const fetchMock = vi.fn().mockResolvedValueOnce(ok(bootstrap(recovery()))).mockResolvedValueOnce(ok(nextStep));
    const { host } = await renderRoute("/learn/session-w4/node-basic", fetchMock);
    expect(host.textContent).toContain("Python 列表"); expect(host.textContent).toContain("UPSTREAM_CONTRACT_BLOCKED");
  });

  it("renders a four-question quiz without opening-stage answers", async () => {
    const { host } = await renderRoute("/activity/session-w4/act-basic", vi.fn().mockResolvedValue(ok(bootstrap(recovery({ stage: "activity" })))), { opened: openedQuiz, nodeId: "node-basic" });
    expect(host.querySelectorAll(".quiz-question")).toHaveLength(4);
    expect(host.textContent).not.toContain("正确答案：");
    expect(host.textContent).toContain("0/4 已回答");
  });

  it("recovers the same quiz Attempt from the Bootstrap reference", async () => {
    const session = recovery({ stage: "activity" });
    session.currentAttempt = { kind: "quiz", activityId: "act-basic", attemptId: "attempt-1", status: "draft", retryNumber: 0 };
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(ok(bootstrap(session)))
      .mockResolvedValueOnce(ok(nextStep))
      .mockResolvedValueOnce(ok(openedQuiz));
    const { host } = await renderRoute("/activity/session-w4/act-basic", fetchMock);
    expect(host.textContent).toContain("Attempt");
    expect(host.textContent).toContain("attempt-1");
    expect(host.querySelectorAll(".quiz-question")).toHaveLength(4);
    expect(fetchMock).toHaveBeenCalledTimes(3);
  });

  it("calls completeSession and renders the server summary", async () => {
    const session = recovery({ stage: "activity" });
    const fetchMock = vi.fn().mockResolvedValueOnce(ok(bootstrap(session))).mockResolvedValueOnce(ok({ requestId: "complete", sessionId: "session-w4", sessionVersion: 3, profileRevision: 3, completedAt: "2026-08-16T00:00:00.000Z", summary: "Session completed with unresolved items: act-basic:partial.", nextRecommendation: "Review." }));
    const { host } = await renderRoute("/summary/session-w4", fetchMock);
    expect(host.textContent).toContain("act-basic:partial"); expect(host.textContent).toContain("Review.");
  });

  it("maps loading, empty, error, conflict and recovery to stable accessible panels", () => {
    const host = document.createElement("div"); document.body.append(host); root = createRoot(host);
    for (const state of ["loading", "empty", "error", "conflict", "recovery"] as const) {
      act(() => root!.render(<PageStatePanel page="activity" state={state} />));
      expect(host.querySelector(`[data-state="${state}"]`)).not.toBeNull();
    }
  });

  it("renders transport errors without leaking server messages", async () => {
    const { host } = await renderRoute("/", vi.fn().mockResolvedValue(fail(503, "initialization_not_ready")));
    expect(host.textContent).toContain("initialization_not_ready");
    expect(host.textContent).not.toContain("safe error");
  });
});
