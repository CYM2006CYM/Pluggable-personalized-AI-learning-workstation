import { useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import type { PathCandidateOutput } from "../../contracts/index.js";
import { api, isApiError, newRequestId } from "../api/client.js";
import { useBootstrap } from "../api/use-bootstrap.js";
import { PageFrame } from "../components/PageFrame.js";
import { PageStatePanel } from "../components/PageStatePanel.js";
import { STABLE_LAYOUT } from "../styles/layout-contract.js";

export function PathPage() {
  const { sessionId = "" } = useParams<{ sessionId: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const bootstrap = useBootstrap(sessionId);
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<Error>();
  const candidate = (location.state as { candidate?: PathCandidateOutput } | null)?.candidate;
  const session = bootstrap.data?.session;
  const path = candidate?.pathId === undefined ? session?.path : { pathId: candidate.pathId, pathVersion: candidate.pathVersion!, status: candidate.status, nodes: candidate.nodes };

  const confirm = async () => {
    if (session === undefined || path === undefined || path.status === "infeasible") return;
    setBusy(true); setActionError(undefined);
    try {
      const confirmed = await api.confirmPath({ requestId: newRequestId("web-confirm-path"), sessionId, sessionVersion: session.view.sessionVersion, profileRevision: session.view.profileRevision, pathId: path.pathId, pathVersion: path.pathVersion });
      const next = await api.getNextStep({ sessionId, sessionVersion: confirmed.sessionVersion, profileRevision: confirmed.profileRevision, pathVersion: confirmed.pathVersion });
      if (next.completed || next.node === undefined) navigate(`/summary/${sessionId}`);
      else navigate(`/learn/${sessionId}/${next.node.nodeId}`, { state: { next } });
    } catch (error) { setActionError(error instanceof Error ? error : new Error("path_confirm_failed")); }
    finally { setBusy(false); }
  };
  const error = actionError ?? bootstrap.error;
  return <PageFrame eyebrow="路径确认" title="查看并确认学习路径" summary="顺序、先修状态和安排原因来自确定性路径结果。" actions={<span className="header-badge">预算 {session?.view.availableMinutes ?? 0} 分钟</span>}>
    {bootstrap.loading ? <PageStatePanel page="path" state="loading" /> : null}
    {!bootstrap.loading && error ? <PageStatePanel page="path" state={isApiError(error) && error.status === 409 ? "conflict" : "error"} code={isApiError(error) ? error.code : error.message} onRetry={() => { setActionError(undefined); void bootstrap.reload(); }} /> : null}
    {!bootstrap.loading && error === undefined && (session === undefined || path === undefined) ? <PageStatePanel page="path" state="empty" detail="诊断已完成但 Bootstrap 没有路径时，E 不会猜测 evidenceVersion 重建路径。" /> : null}
    {!bootstrap.loading && error === undefined && session !== undefined && path !== undefined ? <div className="path-layout" data-page="path"><section className="work-section path-section"><div className="section-heading"><div><p className="section-kicker">PATH VERSION {path.pathVersion}</p><h2>确定性学习路径</h2></div><span className="status-tag success">{path.status}</span></div><ol className="path-list">{path.nodes.map((node, index) => <li className={`path-node ${node.status}`} key={node.nodeId} style={{ minHeight: STABLE_LAYOUT.pathNodeMinHeight }}><span className="path-sequence">{String(index + 1).padStart(2, "0")}</span><div className="path-node-main"><strong>{node.knowledgePointId}</strong><span>{node.reasonCodes.join(" · ") || "固定拓扑"}</span><small>{node.difficulty} · {node.scaffold} · {node.required ? "必需" : "可选"} · {node.positionLocked ? "位置锁定" : "可重算"}</small></div><div className="path-node-meta"><span>{node.estimatedMinutes}分钟</span><strong>{node.status}</strong></div></li>)}</ol><div className="section-footer"><span className="quiet-label">{candidate?.status === "infeasible" ? "路径不可行" : `${path.nodes.length} 个节点`}</span><button type="button" className="button primary" disabled={busy || candidate?.status === "infeasible"} onClick={() => void confirm()}>确认路径</button></div></section><aside className="work-section budget-panel"><p className="section-kicker">TIME CONTRACT</p><h2>时间与先修</h2><dl className="metric-list"><div><dt>当前预算</dt><dd>{session.view.availableMinutes}分钟</dd></div><div><dt>最低需要</dt><dd>{candidate?.minimumRequiredMinutes ?? "已满足"}</dd></div><div><dt>缺失先修</dt><dd>{candidate?.missingPrerequisiteIds.length ?? 0}项</dd></div><div><dt>会话版本</dt><dd>{session.view.sessionVersion}</dd></div></dl><p className="notice-line">重算原因只显示真实 `changeReasons` 响应；当前页面不伪造该字段。</p></aside></div> : null}
  </PageFrame>;
}
