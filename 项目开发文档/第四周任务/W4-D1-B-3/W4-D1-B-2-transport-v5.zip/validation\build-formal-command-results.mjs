import { access, readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const externalPath = resolve(process.argv[2]);
const reproductionPath = process.argv[3] ? resolve(process.argv[3]) : undefined;
const outputPath = resolve(process.argv[4] ?? "scripts/w4-b-validation/command-results.json");
if (!process.argv[2] || !process.argv[3]) throw new Error("Usage: node build-formal-command-results.mjs <final-command-results.json> <python-3.14.4-reproduction.json> [output]");
const finalRun = JSON.parse(await readFile(externalPath, "utf8"));
const reproduction = JSON.parse(await readFile(reproductionPath, "utf8"));
const recordsWithLogs = reproduction.records.filter((record) => typeof record.stdoutPath === "string" && typeof record.stderrPath === "string");
for (const record of recordsWithLogs) {
  await access(record.stdoutPath);
  await access(record.stderrPath);
}
const initial = {
  phase: "initial_environment_mismatch",
  classification: "HISTORICAL_FACT_RETAINED_UNVERIFIABLE_RAW_ARTIFACTS_MISSING",
  recordedAt: "2026-08-13T14:01:11.4955342+08:00",
  environment: { node: "not recorded in initial structured result", python: "3.14.4", pandas: "3.0.5" },
  limitation: "The first structured result retained command summaries but not raw stdout/stderr files, timestamps or their hashes. This historical artifact is unavailable and is not reconstructed. The following reproduction is a separate, later execution and must not be treated as the historical original.",
  records: [
    {
      name: "full-test", command: "npm test -- --maxWorkers=1", cwd: "pi-study-helper", startedAt: null, endedAt: null,
      exitCode: 1, testStatistics: { testFiles: null, passed: 670, failed: 20, skipped: 1 },
      stdoutSha256: null, stderrSha256: null,
      result: "ENVIRONMENT_MISMATCH", summary: "Python evaluator required 3.13.7; system interpreter was Python 3.14.4.",
    },
    {
      name: "verify", command: "npm run verify", cwd: "pi-study-helper", startedAt: null, endedAt: null,
      exitCode: 1, testStatistics: { testFiles: null, passed: 670, failed: 20, skipped: 1 },
      stdoutSha256: null, stderrSha256: null,
      result: "ENVIRONMENT_MISMATCH", summary: "Python evaluator required 3.13.7; system interpreter was Python 3.14.4.",
    },
  ],
};
const historicalReproduction = {
  phase: "python_3_14_4_environment_reproduction",
  classification: "REPRODUCTION_ONLY_NOT_HISTORICAL_ORIGINAL",
  purpose: reproduction.purpose,
  environment: reproduction.environment,
  records: reproduction.records,
  conclusion: "The reproduction independently confirms the retained 670 passed / 20 failed / 1 skipped environment-mismatch shape under Python 3.14.4 and Pandas 3.0.5, with actual logs, timestamps and hashes. It does not repair or replace the missing original-run artifacts.",
};
const final = {
  phase: "final_contract_environment_reverification",
  classification: finalRun.allExitCodesZero ? "PASS" : "FAILED",
  environment: finalRun.environment,
  records: finalRun.records,
  finalFullTest: finalRun.records.find((record) => record.name === "full-test"),
  finalVerify: finalRun.records.find((record) => record.name === "verify"),
};
const byName = new Map(final.records.map((record) => [record.name, record]));
for (const [name, statistics] of Object.entries({
  "b-asset-and-contract-targeted": { testFiles: 2, passed: 15, failed: 0, skipped: 0 },
  "python-evaluator-affected": { testFiles: 2, passed: 26, failed: 0, skipped: 0 },
  "full-test": { testFiles: 70, passed: 689, failed: 1, skipped: 1 },
  "verify": { testFiles: 70, passed: 690, failed: 0, skipped: 1 },
})) {
  if (byName.has(name)) byName.get(name).testStatistics = statistics;
}
for (const record of final.records.filter((entry) => entry.name.startsWith("public-python-test-"))) {
  record.testStatistics = { testFiles: 1, passed: 1, failed: 0, skipped: 0 };
}
const v26Records = [];
for (const filename of [
  "18-v2-6-direct.record.json",
  "19-v2-6-direct-20-plus-60.record.json",
  "20-v2-6-direct-20-plus-60.record.json",
  "21-v2-6-direct-locked.record.json",
  "22-v2-6-isolated.record.json",
  "23-v2-6-direct-revision2.record.json",
  "24-v2-6-isolated-revision2.record.json",
]) {
  try { v26Records.push(JSON.parse(await readFile(resolve(externalPath, "..", filename), "utf8"))); } catch { /* optional historical result */ }
}
final.v26WrapperAndDirectReverification = {
  wrapper: byName.get("full-test"),
  directAndIsolatedRecords: v26Records,
  conclusion: "The aggregate full-test exit code is retained as non-zero because the frozen V2-6 outer 30-second wrapper timed out. The correctly parameterized revision-2 direct 20+60 and isolated V2-6 runs exit 0; the erroneous revision-3 input attempts are retained as INPUT_REVISION_MISMATCH evidence.",
};
const result = {
  role: "B", day: "W4-D1-B-2", contract: "W4-C2/W4-R1",
  evidenceRule: "Only final-contract records claim final verification. Initial failure is retained as a historical fact and never treated as final status.",
  phases: [initial, historicalReproduction, final],
  finalConclusion: {
    node: "v22.23.1", python: "3.13.7", pandas: "3.0.5",
    allExitCodesZero: finalRun.allExitCodesZero,
    aggregateFullTestClassification: "NON_ZERO_V2_6_OUTER_WRAPPER_TIMEOUT",
    fullTestExitCode: final.finalFullTest?.exitCode,
    fullTestStatistics: final.finalFullTest?.testStatistics,
    verifyExitCode: final.finalVerify?.exitCode,
    verifyStatistics: final.finalVerify?.testStatistics,
  },
  deliveryState: "NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED",
  unresolvedEvidenceBlocker: {
    issueId: "B-R2-01",
    status: "OWNER_DECISION_OR_ORIGINAL_LOG_ARCHIVE_REQUIRED",
    reason: "The original first-run raw stdout/stderr artifacts and timestamps are unavailable. The later reproduction is separately identified and cannot be substituted for the original evidence.",
  },
};
await writeFile(outputPath, `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({ outputPath, finalConclusion: result.finalConclusion }, null, 2));
