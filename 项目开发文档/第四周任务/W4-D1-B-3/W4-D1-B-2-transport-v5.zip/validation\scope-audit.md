# W4-B-D1-B-2 scope audit

Allowed candidate paths only:

- `fixtures/profiles/pandas-cleaning-revision-3-draft/`
- `scripts/w4-b-validation/`
- `../../新版设计文档-重写版/第四周任务/handoff-w4-b-d1.md`

The exact proposed-submit list, raw SHA-256 and byte length are generated in the repository-external `W4-D1-B-2-proposed-submit-manifest-v5.json`. It covers every file below the two B roots above and the B handoff. It explicitly excludes all ZIPs, SHA-256 sidecars, raw stdout/stderr logs, the B external virtual environment, A compiled audit runtime, `node_modules`, `.demo-data`, repository-external audit directories and other-role files.

No `src/`, HTTP, Agent, Web, SDK, dependency, lockfile, revision 2, formal gold, Rubric, hidden-test, TaskBundle, reference-solution, or W3 environment-lock file is modified. Revision 3 preserves copied frozen code-evaluation assets; `quality/w4-b-revision-2-immutability.json` records the original revision 2 tree independently.

Candidate state: `NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`.

Evidence limitation: B-R2-01 remains owner-gated because the historical first-run raw stdout/stderr artifacts, timestamps and hashes are unavailable. The external `W4-D1-B-2-historical-reproduction-logs-v3/` records a later, separately labelled Python 3.14.4 reproduction; it is deliberately excluded from proposed Git and must not be represented as the original run.
