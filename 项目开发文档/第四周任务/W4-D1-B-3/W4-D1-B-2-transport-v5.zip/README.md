﻿W4-D1-B-2 v5 ordinary transport package.
Public-safe candidate subset; no private answer, rubric, hidden test, reference solution or private CSV body is included.
The owner-only audit package and its SHA-256 are bound by W4-D1-B-2-delivery-manifest-v5.json.
B-R2-01 remains owner-gated: the original initial-run raw logs cannot be reconstructed.
