# W4 B D1-B-2 revision 3 remediation candidate handoff

## Candidate identity

- Contract/schedule: `W4-C2 / W4-R1`
- B start HEAD / `origin/main`: `00037c1aa995a0ec2aec70b097fc680e193ed08a`
- A formal upstream: `4c52eb7c78fa80007aa9a8ab4e00768d71d3f3f5`
- Candidate directory: `pi-study-helper/fixtures/profiles/pandas-cleaning-revision-3-draft/`
- Candidate seal tree SHA-256: `e118fd65c4583821f686cba4faab5990a81d2149a8f73cf89af2c376ba15b352`
- State: `NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`

## Evidence and remediation audit inputs

- The sole formal structured result is `pi-study-helper/scripts/w4-b-validation/command-results.json`. It retains the initial Python 3.14.4 environment-mismatch fact, separately records a later Python 3.14.4 reproduction with complete logs/hashes, and appends the B-owned independent contract-environment reverification. Only the final contract-environment phase supplies final command conclusions.
- The initial aggregate run remains historical: `670 passed / 20 failed / 1 skipped`, with `npm run verify` exit `1`, attributed to Python 3.14.4 not meeting the environment lock. Its original raw logs, timestamps and hashes were not retained. The later reproduction independently matches the same aggregate shape with complete evidence, but is expressly not represented as the historical original. Owner-provided original artifacts or a written evidence exception remain required to close B-R2-01.
- Final B-owned environment evidence records an actual `node.exe --version` output of Node `v22.23.1` and the external interpreter `C:\Users\Lenovo\AppData\Local\Temp\w4-d1-b-python313\Scripts\python.exe`, Python `3.13.7`, Pandas `3.0.5`.
- The final `verify` exits `0` with `70` files, `690` passed and `1` skipped. The separately invoked aggregate `npm test -- --maxWorkers=1` exits `1` with `69` files passed, `1` V2-6 outer-wrapper timeout, `689` tests passed, `1` failed and `1` skipped; the frozen revision-2 V2-6 direct 20+60 and isolated recomputation both exit `0`. This wrapper outcome is not rewritten as PASS.
- The repository-external `W4-D1-B-2-delivery-manifest-v5.json` supplies the current ordinary transport ZIP, complete responsible-person audit ZIP, both sidecars, exact proposed-submit manifest, and raw command logs. The audit ZIP contains all 79 candidate file bodies, including server-only private answers and frozen private inputs, plus the revision 2 baseline and B validation scripts.
- Ordinary transport ZIP is a public-safe subset only. It never carries private answer bodies, hidden tests, Rubrics, reference solutions or private CSV content. It carries the public candidate, all cryptographic inventories and an audit-access record that binds it to the owner-only directory.
- `quality/w4-b-coverage-matrix.json` now records per core point: card, activity, fixed/supplemental groups, private answer groups, source anchors and raw SHA-256/byte length of the cards, public questions, private answers and source map assets. `quality/w4-b-asset-inventory.json` excludes itself and the seal so no self-referential hash is asserted.

## B delivery

- Revision 3 retains Schema 2 and sets `revision=3`, `revisionOf=2`, and `status=draft`.
- Six target knowledge points have `all_in_order`, positive content estimates, exactly one safe fixed card, one group-MCQ activity, a four-question fixed group, and one supplemental question.
- `basic-python` remains an auxiliary prerequisite. Cards are not activities; no card ID appears in `activityIds`. `goal.requiredActivityIds` contains only `act-practical`.
- Public question groups expose only question surfaces. Private answers, explanations and source mappings are in the server-only private answer-key asset. Supplemental questions only complete eligible dynamic candidates; they are not a complete retry group.
- Revision 2 immutability, source coverage, public/private isolation, final inventory and quality reports are in revision 3 `quality/`; the latter records completed formal A Schema validation while retaining `candidate`, `pending_owner_decision` and `activeEligible=false`.

## Downstream consumption

- A: recompute and validate `quality/revision-seal.json` before any draft activation. Do not alter B assets while validating.
- C: use only the candidate directory and repository-returned seal/tree identity during later activation; do not copy or recalculate Profile content.
- D: use fixed cards, question groups and source-safe summaries only; never ingest `assessments/private/quiz-answer-key.json` into Agent context.
- E: consume cards and opened quiz safe DTOs only. Correct answers, explanations and private source mappings are available only after formal submit through A/C safe projections.

## Known limits

The candidate does not claim activation, HTTP/API, Web, Agent, live-model, or W4 GO success.

- No assertion is made that the aggregate full test passes in this run: its V2-6 outer wrapper timed out at 30 seconds. The correct frozen revision-2 direct/isolated recomputations pass; the mismatch is recorded for the owner because B cannot modify the W2 frozen wrapper or A runtime compatibility code.
- No upload lock has been requested. D/C/E must not consume this candidate as a formal upstream until the owner independently reviews the complete audit directory, resolves B-R2-01's missing original-log evidence by archive or written exception, and explicitly grants an upload lock.
