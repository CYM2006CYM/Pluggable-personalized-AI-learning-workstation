# W4-D1-A remediation owner audit

This is an owner-review audit artifact, not a formal submission package.

- `candidate-files/`: complete 50-file candidate set, including tracked and untracked files.
- `tracked-changes.patch`: tracked files only; UTF-8 without BOM, LF; clean-baseline `git apply --check` result is recorded separately.
- `manifest.json`: SHA-256 and byte length for every other package payload file.
- `command-results.json` and `command-logs/`: current command records and exact stdout/stderr; historical failed records remain in the JSON.
- `remediation-test-mapping.md`, `public-exports.md`, `transaction-failure-matrix.json`, validation report and handoff: owner review indexes.

Known gate result: all A-targeted, Python evaluator, native type, docs and smoke gates pass. Full test and `verify` fail only because frozen W2 V2-6 omits the W4-mandatory diagnostic CAS field. Direct and isolated reproductions are included; W2 tests were not changed and CAS was not weakened.

State: `NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_GRANTED`.