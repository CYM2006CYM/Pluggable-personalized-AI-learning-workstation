# W4 A D1 Remediation Handoff

## Candidate identity

- Base HEAD / `origin/main`: `dc23504c3f353883d4f665e64a47cee9afb5723a`
- W4 start commit: `ac6e307e17cf84450845dfc5ffa467063dd3ae4c`
- Contract/schedule: `W4-C2 / W4-R1`
- State: `NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_GRANTED`

This is the one-time remediation candidate requested by the owner. A new owner-review audit ZIP is generated, but no formal submission package is generated or uploaded.

## Delivered boundary

- Canonical browser-safe contracts: `pi-study-helper/src/contracts/index.ts`, `domain.ts`, and `facade.ts`.
- W3 compatibility import: `pi-study-helper/src/application/learning-runtime-facade.ts`.
- 17-method composition: `ComposedLearningRuntimeFacade`.
- Strict read-only bootstrap: `FileAppBootstrapFacade`.
- Deterministic code/quiz bridges and path-suffix recomputation.
- A-owned deterministic validation for `AdaptiveContentPort` and post-commit isolation for `CapabilityTaskPort`.
- Strict revision 3 draft seal verification and conflict-blocking activation.

Only `src/web/mocks/safe-dtos.ts` and `tests/web/dto-contract.test.ts` are changed under the owner's explicit Web exception. No other Web, HTTP, dependency, lock, SDK or formal content boundary is touched.

## Remediation result

- A-W4-D1-01: diagnostic CAS and formal completion semantics closed.
- A-W4-D1-02: activity DTOs and Attempt views are compile-time discriminated unions with exhaustive dispatch.
- A-W4-D1-03: exact diagnostic envelope and shared nested allowlist projections; three Attempt states recover safely.
- A-W4-D1-04: goal targets identify core revision 3 points; auxiliary prerequisites are not forced into card/quiz closure.
- A-W4-D1-05: contracts are a pure type leaf; native root/test/Web type gates pass independently.
- A-W4-D1-06: real card IDs gate Attempt creation and acknowledgement/open replay atomically.
- A-W4-D1-07: background questionnaire has one strict save/recover/complete shape.
- A-W4-D1-08: approved environment and corrected per-command evidence; audit patch/manifest are self-contained.

The detailed mapping is `pi-study-helper/scripts/w4-a-validation/remediation-test-mapping.md`.

## Downstream handoff

- B: provide formal `pandas-cleaning-revision-3-draft`, private answer bindings and revision seal. A did not create or edit them.
- D: implement the public ports. Dynamic output remains candidate content until A validates it; task failure never rolls back a formal session commit.
- C: import contracts and Facade implementations without copying DTOs or exposing repository candidates.
- E: consume only contracts-safe Bootstrap/recovery/activity views; correct answers remain post-submit only.

## Verification

- Original audit fact retained: A suite `17 files / 131 tests PASS`; Python/Pandas and native type gates were previously reported blocked.
- Remediation A suite: `17 files / 140 tests PASS`.
- Approved runtime: Node `v22.23.1`, Python `3.13.7`, Pandas `3.0.5` from repository-external locations.
- Python evaluator/delivery: `3 files / 35 tests PASS`.
- Native `tsc --noEmit`, test config, Web config and `npm.cmd run typecheck` are recorded separately.
- Full suite and `verify` fail only at W2 V2-6. This is not its 30-second timeout allowance: direct and isolated runs prove the frozen caller omits mandatory `diagnosticDraftVersion`, so W4 correctly rejects it with `diagnostic_answer_invalid`. W2 code/tests are not modified and CAS is not weakened; owner adjudication is required.

Exact timestamps, exit codes, test counts and output hashes are in `pi-study-helper/scripts/w4-a-validation/command-results.json`. The validation report, export inventory and transaction matrix are in the same directory.

Owner review must first resolve the frozen W2 V2-6 caller versus the W4 mandatory-CAS contract. Until that adjudication and an explicit upload lock, this candidate remains blocked, uncommitted and unpushed.
