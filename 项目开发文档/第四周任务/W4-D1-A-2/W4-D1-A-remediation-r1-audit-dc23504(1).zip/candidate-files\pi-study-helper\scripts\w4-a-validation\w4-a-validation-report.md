# W4-A D1 Remediation Validation Report

## Identity and authority

- Contract/schedule: `W4-C2 / W4-R1`
- Actual base HEAD and `origin/main`: `dc23504c3f353883d4f665e64a47cee9afb5723a`
- W4 start commit: `ac6e307e17cf84450845dfc5ffa467063dd3ae4c`
- State: `NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_GRANTED`
- Deliverable: owner-review audit ZIP only; no formal submission package was generated or uploaded.

Changes stay inside the A-authorized contracts/application/domain/repositories/tests/validation/handoff scope, plus the owner's two explicit Web exceptions: `src/web/mocks/safe-dtos.ts` and `tests/web/dto-contract.test.ts`. HTTP/bootstrap servers, other Web files, B formal Profile/private assets, prompts/recordings/agents, W3 environment locks, TaskBundle, Rubric, hidden tests, reference solutions, gold, SDK, dependencies, `package.json` and `package-lock.json` remain unchanged.

## Remediation closure

1. Diagnostic draft and answer writes require client `diagnosticDraftVersion`; stale/missing CAS cannot write. Draft writes only advance the draft version. Fixed and `background_only` completion use a formal session transaction, advance `sessionVersion`, and enter `path`; background completion preserves Evidence, evidence version and existing KnowledgeState.
2. Activity open, submit, submission result and Attempt views are outer-`kind` discriminated unions. Composition dispatch is exhaustive; code and quiz fields cannot cross branches.
3. Bootstrap parses the diagnostic asset strictly and constructs Profile, session, draft, progress, Attempt and path outputs from explicit allowlists. Unknown question fields fail; extensions and internal snapshot fields cannot flow to the DTO.
4. Revision 3 core points are the deterministic union of `goals[].targetKnowledgePointIds`. Only that set requires full cards/question groups/`all_in_order`; prerequisite-only auxiliary points remain auxiliary. Revision 2 behavior is unchanged.
5. `src/contracts/domain.ts` is the sole shared domain type source and contracts have no Node/runtime reverse imports. The W3 application path is compatibility re-export only.
6. Pending cards require the real bound asset `cardId`. Missing or wrong IDs fail before Attempt creation; correct acknowledgement and open share a transaction and replay idempotently. No Evidence is created by acknowledgement.
7. `BackgroundQuestionnaire` is one strict three-field object through public input, persistence, restart recovery, Bootstrap and `background_only` completion.
8. Evidence collection binds the approved isolated Node/Python environment and records each command separately with cwd, UTC timestamps, real exit code, counts and stdout/stderr SHA-256. The tracked patch is generated separately as LF/no-BOM and describes tracked files only.

The exact finding-to-test mapping is `remediation-test-mapping.md`; exports are in `public-exports.md`; crash boundaries are in `transaction-failure-matrix.json`.

## Runtime composition and downstream boundary

All 17 `LearningRuntimeFacade` methods have an importable composition. Code and quiz submissions derive Evidence, KnowledgeState, activity progress and path suffix internally. `evaluator_error` leaves formal session state unchanged. Capability tasks are triggered only after a formal commit and cannot roll back it. Context questions use a fixed safe fallback.

B remains owner of formal revision 3 content, private answers and seal. D remains owner of live model/task adapters. C owns HTTP/process bootstrap. E consumes contracts only; the two approved Web edits restore that boundary and do not implement E behavior.

## Verification record

Canonical machine-readable results are in `command-results.json`. The file preserves the original candidate evidence and the first remediation collection, including its incorrect Windows PowerShell exit-code capture, then records the corrected rerun. Reports use the corrected native process exit codes.

- Original candidate A suite: `17 files / 131 tests PASS`.
- Remediated A suite before final evidence: `17 files / 140 tests PASS`.
- Approved environment: Node `v22.23.1`, Python `3.13.7`, Pandas `3.0.5`; exact executables are recorded.
- Python evaluator/delivery group: `3 files / 35 tests PASS` in the approved environment.
- Root, test and Web TypeScript commands are recorded independently, followed by the repository `typecheck` script.
- The full suite and `verify` fail only at W2 V2-6, but this rerun is not the previously allowed 30-second timeout case. Direct and isolated V2-6 runs show that its frozen runtime test omits the now-mandatory `diagnosticDraftVersion`; the remediated runtime correctly returns `diagnostic_answer_invalid`. Changing that W2 test or accepting a missing CAS is outside the ruling, so the gate remains an explicit owner-adjudication blocker rather than being relabeled PASS.
- `check:docs`, `smoke:extension`, `git diff --check` and `git status --short` are recorded independently.

The audit ZIP contains the corrected evidence, complete candidate file set, manifest, per-file SHA-256/byte counts, tracked-only patch, clean-baseline patch check and owner-review message. Its SHA-256 is supplied beside the ZIP and in the package metadata.

## Remaining owner decisions

- Formal revision 3 content/seal activation still requires B's assets and owner approval.
- Live D adapters, C HTTP integration and E product integration remain outside this candidate.
- The frozen W2 V2-6 caller must be reconciled by the owner with the W4 mandatory-CAS ruling; this candidate does not change W2 tests or weaken CAS.
- This audit artifact is not upload-lock authorization and must not be committed or pushed before owner review.
