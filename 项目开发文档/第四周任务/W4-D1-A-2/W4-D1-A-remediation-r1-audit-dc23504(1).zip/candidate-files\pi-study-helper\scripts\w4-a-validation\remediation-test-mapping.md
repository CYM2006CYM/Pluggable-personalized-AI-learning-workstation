# W4-D1-A Remediation Test Mapping

| Finding | Implementation closure | Primary verification |
| --- | --- | --- |
| A-W4-D1-01 | Required diagnostic CAS; draft-only versions; fixed/background formal completion and idempotency | `diagnostic-runtime.test.ts`, `file-learning-session-repository.test.ts` |
| A-W4-D1-02 | Outer-kind code/quiz open, submit, result and Attempt unions; exhaustive dispatch | `w4-contracts.test.ts`, `composed-learning-runtime-facade.test.ts` |
| A-W4-D1-03 | Exact diagnostic envelope and shared nested allowlists; required path fields; recoverable Attempt reference | `app-bootstrap-facade.test.ts`, `code-activity-facade-adapter.test.ts`, `file-learning-session-repository.test.ts` |
| A-W4-D1-04 | Goal-target union identifies revision 3 core set; auxiliary prerequisites remain optional | `profile-v2-schema.test.ts`, revision 2 Profile tests |
| A-W4-D1-05 | Pure contracts leaf; one domain type authority; browser-safe imports | three independent `tsc` commands, `w4-contracts.test.ts`, `tests/web/dto-contract.test.ts` |
| A-W4-D1-06 | Real asset card IDs, transactional acknowledgement/open, lifecycle conflict and replay | `code-activity-facade-adapter.test.ts`, `quiz-activity-runtime.test.ts`, `path-runtime.test.ts` |
| A-W4-D1-07 | One strict `BackgroundQuestionnaire` shape across save, restart, Bootstrap and completion | `diagnostic-runtime.test.ts`, `app-bootstrap-facade.test.ts` |
| A-W4-D1-08 | Approved isolated environment, native gates, exit-code-correct evidence, LF tracked patch and complete manifest | `command-results.json`, audit manifest and clean-baseline `git apply --check` record |

The A targeted suite contains 17 files and 140 tests after remediation. The original candidate result (17 files / 131 tests) and all earlier failed/environment-blocked command records remain in `command-results.json` under historical evidence.
