# W4-D4 E 独立验证正文

状态：`READY_FOR_OWNER_REVIEW_WITH_LIMITATIONS / NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`

本文件不签署 W4 GO。V4-1～V4-8 的技术门禁均已通过，但负责人要求的流程规范文件未找到，输入总状态为 `AUDIT_INPUT_INCOMPLETE`；同时 4310 固定端口被外部 QQ 进程占用，真实浏览器正常态未执行。

## 输入绑定

- `HEAD` 与最新 `origin/main` 均为 `a896c4b219cccb0da256fdf7e5d1cb96ba41f7b4`。
- A：`4c52eb7c78fa80007aa9a8ab4e00768d71d3f3f5`。
- B：`56398ab5f44283e9c10b6d66ec2f0732cc043790`。
- D：`dc1693e5bfcc0bed226ff0f20613fc4b2ec88681`。
- C：`a896c4b219cccb0da256fdf7e5d1cb96ba41f7b4`。
- B revision 3 seal：78 项；asset tree SHA-256 为 `d1438022a49f83df20fa865443c36f4c3442856c8b679aac989de9e61a3feb30`。
- D 录制响应：14 条；SHA-256 为 `4dc9fae61d7d179947fe24ed661b5a6826484f9c27e79a0b2fc39a55a186061c`。
- 未找到 `团队协作参考/审计后一次性整改提示词编写规范.md`。该缺失只影响流程输入完整性，不作为任何 V4 技术断言的依据。

## 整改结果

1. submitted 活动刷新后通过 Bootstrap 与 `getNextStep` 读取服务端游标，可进入下一活动，不重建旧 Attempt。
2. 代码公开检查严格先保存当前编辑文本，再使用返回的新 `draftVersion` 运行；保存失败不运行旧草稿。409 保留本地文本并自动重读 Bootstrap。
3. evaluator_error 保持同一 Attempt，可读取服务端草稿后重试；成功与重复失败分支均有 React 测试。
4. 路径页消费诊断流程传入的 `evidenceVersion` 调用 `replanPath`，展示 `changed`、`fallbackToPrevious` 和 `changeReasons`。刷新后缺少该字段时保留路径并禁用重算。
5. 总结页展示 fail、partial、insufficient、unverified；页面不计算 mastery，不伪造 KnowledgeState。
6. Vite 后端代理收窄到 bootstrap、sessions、activities 端点，避免与 Web `/api/*.ts` 模块路径冲突；浏览器白屏回归已由边界测试覆盖。

## V4 结果

| 门禁 | 状态 | 独立证据 |
|---|---|---|
| V4-1 | PASS | 非法题组、完整答案合同与程序判分通过受影响回归。 |
| V4-2 | PASS | 非法 Schema、超时、provider 错误和 fallback 降级通过。 |
| V4-3 | PASS | 审核顺序、高风险审核和 Agent 越权拒绝通过。 |
| V4-4 | PASS | 画像只使用正式 Evidence，失败保留旧快照。 |
| V4-5 | PASS | 推荐与章节两条真实 HTTP 轨迹从空临时数据走到提交后刷新与下一步。 |
| V4-6 | PASS | HTTP、DOM、bundle、日志、Agent 上下文及 Vite 直链扫描通过。 |
| V4-7 | PASS | 六类 14 条录制响应独立复算通过；在线模型为 `LIVE_NOT_RUN`。 |
| V4-8 | PASS | revision 3 六个核心点逐点执行卡片、题组、判分、重试、insufficient 与泄漏边界。 |

V4-8 不是由单点外推：`tests/web/v4-six-point.test.ts` 对六个知识点分别验证固定 4 题、打开阶段零答案、`ceil(total*0.75)`、`correctCount/totalCount`、pass/fail、新 Attempt、题目 ID 无交集、insufficient 无 Evidence 及 `answerReview` 白名单。

## 合同环境与命令

独立便携环境位于审计目录，不修改仓库依赖、系统 PATH 或注册表：

- Node `v22.23.1`，npm `10.9.8`。
- Python `3.13.7`，Pandas `3.0.5`，dateutil `2.9.0.post0`。
- `PYTHONNOUSERSITE=1`；Node 子进程解析到同一便携 Python。

最终 `command-results.json` 共 12 项，`nonzeroExitCount=0`：

- Web：11 文件，69 项通过。
- 两条真实 API：1 文件，3 项通过。
- 六点 V4-8：1 文件，7 项通过。
- A/B/C/D/E 受影响回归：13 文件，78 项通过。
- 全量：85 文件，738 项通过，1 项跳过。
- typecheck、check:docs、build:web、smoke:extension、verify、git diff --check 均为自然退出码 0。

首次在错误环境中的 26 项失败没有覆盖，作为 `ENVIRONMENT_MISMATCH_RETAINED` 保存在交付包 `evidence/history/environment-mismatch-20260816/`。

## 浏览器与安全

- 4310 在复验时由外部 `QQ.exe` PID 10840 监听。E 未结束该进程，也未漂移合同端口。
- 固定 5173 的桌面 1440x1000 与移动 390x844 错误恢复态通过 CDP 捕获：均为 `rootChildren=1` 且无横向溢出。
- 正常真实 API 浏览器轨迹标记 `NOT_RUN_FIXED_PORT_OCCUPIED`，不写成通过。
- 空白截图与 Edge profile 不进入候选 ZIP；有效截图不含 Key、私有答案或宿主绝对路径。
- 生产 bundle 不含私有资产路径、answer-key 文件名、hidden tests、Rubric 内容、系统提示词、Key 或宿主路径。bundle 中保留合同允许的提交后 `correctAnswer` 字段名。

## 归因修正

- `reviewTimeline` 是可选字段；当前响应未提供时写 `NOT_PROVIDED`，不是 A 违约。
- Bootstrap 未冻结 `evidenceVersion`；刷新后重算不可重放属于当前安全 DTO 范围，不要求 A 为 E 自定义场景改合同。
- Bootstrap 未冻结持久化 `CompleteSessionOutput` 或完整 `KnowledgeState`；完成态只展示可恢复活动事实，不归因为 A 违约。

## 结论

候选代码与 V4 技术证据可交负责人复核，但因 `AUDIT_INPUT_INCOMPLETE` 与浏览器正常态固定端口限制，不签整体 PASS，不申请上传锁，不提交，不推送。最终 W4 GO 仍由负责人在 D5 签署。
