# W4-D2 岗位 D 交接单

## 身份与上游

- 合同：W4-C2 / W4-R1
- 实际基线：`6b8d87541919ffba64bcc2845bfad47ffffcdf0a`
- A：`4c52eb7c78fa80007aa9a8ab4e00768d71d3f3f5`，HEAD 祖先检查退出 0
- B：`56398ab5f44283e9c10b6d66ec2f0732cc043790`，HEAD 祖先检查退出 0
- revision 3：78 entries，`e118fd65c4583821f686cba4faab5990a81d2149a8f73cf89af2c376ba15b352`

## D 候选输出

1. `AdaptiveContentService`：区分 quiz/card；低风险题直达、高风险题和全部卡片完整审核；15/60 秒降级；私有 checkpoint/cache/trace；恢复不重复发布。
2. `ProfileAdaptiveContentSourceProvider`：只读取 B 的公开 knowledge/activity/source 投影，不读取 B 私有答案、Rubric、hidden tests、reference solutions 或私有 CSV。
3. `CapabilityTaskService`：只响应两个冻结触发器；同会话任务串行；五维 complete/partial/unverified；任务失败保留旧快照。
4. `FileProfileUserRuntimeStore`：所有 D 运行态严格落在 Profile 族 `_user/w4-d/`，键名哈希化。
5. 13 条无密钥录制响应，覆盖正常、非法 Schema、超时、provider 错误、高风险审核、越权拒绝六类；默认 recorded，`LIVE_NOT_RUN`。
6. 定向、受控时钟、安全、画像、录制重放和 A/B fixed fallback 联调测试。

## 验证与已知限制

仓库外合同环境为 Node v22.23.1、Python v3.13.7、Pandas 3.0.5。类型检查、4 files/27 tests 的 D 定向、7 files/179 tests 的 A/D 回归、录制响应安全校验、文档、扩展 smoke 和 release check 均 PASS。

合同环境 `npm run verify` 的最终全量为 73/74 files、716 passed、1 failed、1 skipped。唯一失败是 D 未修改的 W2 V2-6 综合 runner 在固定 30 秒处超时；其内层固定 60 秒测试直接执行和热缓存复跑仍分别约 64.5/69.5 秒。D 未修改 W2 文件规避该既有性能门限。Python 环境导致的三个既有文件失败已在合同环境全部转为 PASS。

未进行在线模型测试，未证明在线时延、供应商可用性或真实模型质量。`RECORDED_PASS` 仅代表离线录制边界，状态为 `LIVE_NOT_RUN`。

## 锁与发布声明

`NOT_COMMITTED`、`NOT_PUSHED`、`uploadLock=NOT_REQUESTED`。无 Profile 激活、无 HTTP/Web 变更、无 C 开工、无 W4 GO。负责人独立审计并另行授予上传锁前，不得提交或推送。
