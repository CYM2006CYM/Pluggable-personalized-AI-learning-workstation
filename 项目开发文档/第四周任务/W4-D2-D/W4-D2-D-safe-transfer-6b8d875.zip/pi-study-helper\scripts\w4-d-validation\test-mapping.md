# W4-D2-D 必测反例映射

| # | 合同反例 | 证据位置 | 当前执行状态 |
|---:|---|---|---|
| 1 | 修改 `correctAnswer` 拒绝 | `adaptive-content-service.test.ts` authority table | PASS |
| 2 | Evidence/KnowledgeState/mastery/score/path/cursor 越权拒绝 | authority table、严格 exact-key 校验 | PASS |
| 3 | 私有资产请求拒绝 | authority table、review-stage 脱敏反例 | PASS |
| 4 | 低风险题仅 Generator | low-risk quiz test | PASS |
| 5 | 高风险严格审核顺序 | high-risk quiz test | PASS |
| 6 | 所有动态卡片完整审核 | card review test | PASS |
| 7 | checkpoint 恢复且不重复发布 | checkpoint resume test | PASS |
| 8 | card/quiz 不串缓存 | identical-key separation test | PASS |
| 9 | 15 秒返回 unavailable 绑定 fixed | controlled-clock test + fixed fallback integration | PASS |
| 10 | 60 秒内晚到只缓存 | controlled-clock late-cache test | PASS |
| 11 | 60 秒后丢弃 | controlled-clock discard test | PASS |
| 12 | 非法 Schema unavailable | invalid-output tests/recording | PASS |
| 13 | provider 错误 unavailable | provider-error tests/recording | PASS |
| 14 | 全模型不可用固定主链继续 | `w4-d-fixed-fallback-integration.test.ts` | PASS |
| 15 | 无证据维度 unverified | capability partial/empty tests | PASS |
| 16 | 画像失败保留旧快照 | capability failure test | PASS |
| 17 | 画像失败不回滚事务 | 冻结异步端口边界 + old-snapshot preservation | PASS |
| 18 | 录制响应无真实敏感数据 | fixture security test + `security-scan-result.json` | PASS |
| 19 | CIDPP 未进入请求主链 | scope/CIDPP static scan | 静态 PASS |
| 20 | D 不绕过 A 产生学习结果 | A-port integration + scope audit | PASS |

六类无密钥轨迹均由 `w4-d-recorded-responses.test.ts` 通过正式 `ModelExecutionPort` 边界重放。`RECORDED_PASS` 不是在线模型能力证明；在线状态固定为 `LIVE_NOT_RUN`。
