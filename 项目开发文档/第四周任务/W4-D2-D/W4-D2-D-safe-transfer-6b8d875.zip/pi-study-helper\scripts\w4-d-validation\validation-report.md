# W4-D2-D 验证报告

状态：`D_SCOPE_PASS / FULL_VERIFY_BLOCKED_BY_PREEXISTING_V2_6_TIMEOUT`

## 已确认基线

- 实际 `HEAD` 与 `origin/main`：`6b8d87541919ffba64bcc2845bfad47ffffcdf0a`，两者一致。
- A 正式提交：`4c52eb7c78fa80007aa9a8ab4e00768d71d3f3f5`，祖先检查退出 0。
- B 正式提交：`56398ab5f44283e9c10b6d66ec2f0732cc043790`，祖先检查退出 0。
- B 之后仅有负责人第四周审计文档索引提交 `6b8d875`；未出现额外源码、合同或 Profile 修改。
- revision 3 独立读取正式 seal：78 entries，`e118fd65c4583821f686cba4faab5990a81d2149a8f73cf89af2c376ba15b352`。

## 实现结论

- `AdaptiveContentService` 只实现 A 冻结的 `AdaptiveContentPort`，仅返回候选或 `unavailable`。
- quiz 与 card 使用独立 `artifactKind`、稳定运行键、checkpoint 和私有缓存。
- 低风险 quiz 仅执行 Generator；高风险 quiz 执行 Generator → Hunter → 条件 Defender → Judge；所有 card 进入完整审核链。
- Hunter/Judge 不接收动态题的 `correctAnswer` 或 `explanation`；任何额外 authority 字段、私有资产请求、绝对路径或凭据形态内容均拒绝。
- 15 秒返回 `unavailable`；15–60 秒合格晚到结果仅进入私有缓存；到达 60 秒的结果丢弃。
- `CapabilityTaskService` 只接受两个冻结触发器，异步生成五维 `complete/partial/unverified` 快照；任务状态与快照状态分离，失败保留旧快照。
- 所有 checkpoint、缓存、轨迹、画像快照和画像任务状态的文件实现均限定在 Profile 族 `_user/w4-d/`。
- 没有接入在线模型、真实 Key 或运行时 CIDPP。状态为 `LIVE_NOT_RUN`。

## 验证结果

- 官方 Node v22.23.1 便携包 SHA-256 与 Node 官方 `SHASUMS256.txt` 一致；合同环境 npm 为 10.9.8。
- 仓库外 Python v3.13.7 / Pandas 3.0.5 环境完成预检，且正式测试禁用用户 site-packages。
- `npm run typecheck`：PASS。
- D 定向：4 files、27 tests，全部 PASS。
- A/D 受影响回归：7 files、179 tests，全部 PASS。
- 六类录制响应：13 条，覆盖与敏感扫描 PASS；`LIVE_NOT_RUN`。
- `npm run check:docs`、`npm run smoke:extension`、`npm run check:release`：PASS。
- 首次全量在缺少合同 Python 时为 70/74 files、695/718 tests；环境归因后，三个 Python 相关失败文件全部 PASS。
- 合同环境 `npm run verify` 最终为 73/74 files、716 passed、1 failed、1 skipped。唯一失败是既有 `scripts/w2-verification/v2-comprehensive-verification.test.mjs` 的 V2-6 30 秒外层超时；其内层既有测试也在固定 60 秒处超时。直接执行与热缓存复跑分别耗时约 64.5 秒和 69.5 秒，均证明这是同步盘环境下的既有性能门限，不是 D 源码、A/B fallback 或 Python 环境失败。

首次依赖缺失、安装超时、D 定向竞态失败及全部后续修复结果均保留在唯一 `command-results.json`，没有用后续 PASS 覆盖首次事实。D 未修改 W2 验证器或扩大所有权范围以规避超时。

## 发布状态

`NOT_COMMITTED`、`NOT_PUSHED`、`uploadLock=NOT_REQUESTED`。未进行持久 Profile 激活，未修改 HTTP/Web，未签发 C 开工或 W4 GO。
