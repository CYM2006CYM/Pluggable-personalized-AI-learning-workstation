# Capability scorer `w4-d2-v1`

Score only observable declared dimensions against referenced safe Evidence summaries.
Omit unobservable dimensions; the deterministic service marks them unverified. Do not
write mastery, KnowledgeState, Evidence, path, score for an activity, or session state.

