import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import { randomUUID } from "node:crypto";
import type { AppBootstrapFacade } from "../contracts/index.js";
import type { LearningRuntimeFacade } from "../contracts/facade.js";
import type { DemoRuntime } from "./composition-root.js";

const MAX_BODY = 64 * 1024;
const PRIVATE_KEYS = new Set(["evidenceCandidate", "knowledgeStates", "pathCandidate", "activityProgress", "correctAnswer", "answerKey", "hiddenTests", "rubric", "referenceSolution"]);
const NOT_FOUND = new Set(["session_not_found", "activity_not_found", "attempt_not_found"]);
const CONFLICT = new Set(["profile_revision_conflict", "session_version_conflict", "idempotency_conflict", "activity_lifecycle_conflict", "activity_version_conflict", "draft_version_conflict", "path_version_conflict"]);
const UNPROCESSABLE = new Set(["diagnostic_incomplete", "diagnostic_answer_invalid", "diagnostic_answer_conflict", "evidence_invalid", "prerequisite_violation", "submission_contract_error"]);
const EVALUATOR = new Set(["environment_mismatch", "evaluator_error", "evaluator_start_failed", "evaluator_timeout", "dependency_missing", "test_asset_invalid", "result_protocol_invalid", "runner_crash"]);

type JsonObject = Record<string, unknown>;
type RuntimeMethod = (input: any) => Promise<unknown>;

function requestId(request: IncomingMessage): string {
  const header = request.headers["x-request-id"];
  return typeof header === "string" && /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/u.test(header) ? header : `http-${randomUUID()}`;
}

function send(response: ServerResponse, status: number, body: unknown): void {
  const bytes = Buffer.from(JSON.stringify(body), "utf8");
  response.writeHead(status, { "content-type": "application/json; charset=utf-8", "content-length": bytes.byteLength, "cache-control": "no-store" });
  response.end(bytes);
}

function safeError(error: unknown): { code: string; status: number } {
  const code = typeof error === "object" && error !== null && "errorCode" in error && typeof error.errorCode === "string" ? error.errorCode : "internal_error";
  if (NOT_FOUND.has(code)) return { code, status: 404 };
  if (CONFLICT.has(code)) return { code, status: 409 };
  if (UNPROCESSABLE.has(code)) return { code, status: 422 };
  if (code === "invalid_profile" || code === "storage_error") return { code, status: 500 };
  return { code, status: 500 };
}

async function body(request: IncomingMessage): Promise<JsonObject> {
  const contentType = String(request.headers["content-type"] ?? "").split(";", 1)[0].trim().toLowerCase();
  if (contentType !== "application/json") throw Object.assign(new Error("invalid content type"), { transportStatus: 400, transportCode: "invalid_content_type" });
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of request) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    size += buffer.byteLength;
    if (size > MAX_BODY) throw Object.assign(new Error("request too large"), { transportStatus: 400, transportCode: "request_too_large" });
    chunks.push(buffer);
  }
  let parsed: unknown;
  try { parsed = JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch { throw Object.assign(new Error("invalid json"), { transportStatus: 400, transportCode: "invalid_json" }); }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) throw Object.assign(new Error("request shape invalid"), { transportStatus: 400, transportCode: "invalid_request_shape" });
  const value = parsed as JsonObject;
  if ([...PRIVATE_KEYS].some((key) => key in value)) throw Object.assign(new Error("private request field"), { transportStatus: 400, transportCode: "invalid_request_shape" });
  return value;
}

function withRequestId(value: JsonObject, id: string): JsonObject {
  if (value.requestId !== undefined && (typeof value.requestId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/u.test(value.requestId))) {
    throw Object.assign(new Error("requestId invalid"), { transportStatus: 400, transportCode: "invalid_request_shape" });
  }
  return { ...value, requestId: value.requestId ?? id };
}

function route(pathname: string, method: string): { call: (runtime: DemoRuntime, value: JsonObject, id: string) => Promise<unknown> } | undefined {
  const call = (name: keyof LearningRuntimeFacade, extra: (value: JsonObject, id: string) => JsonObject = (value, id) => withRequestId(value, id)) => ({ call: (runtime: DemoRuntime, value: JsonObject, id: string) => (runtime.facade[name] as unknown as RuntimeMethod)(extra(value, id)) });
  if (method === "GET" && pathname === "/api/bootstrap") return { call: (runtime, value) => runtime.bootstrap.getBootstrap({ recoverSessionId: typeof value.recoverSessionId === "string" ? value.recoverSessionId : undefined }) };
  let match: RegExpMatchArray | null;
  if (method === "POST" && pathname === "/api/sessions") return call("startSession");
  if ((match = pathname.match(/^\/api\/sessions\/([^/]+)\/recover$/u)) && method === "POST") return call("recoverSession", (v, id) => withRequestId({ ...v, sessionId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/sessions\/([^/]+)\/complete$/u)) && method === "POST") return call("completeSession", (v, id) => withRequestId({ ...v, sessionId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/sessions\/([^/]+)\/diagnostic\/draft$/u)) && method === "POST") return call("saveDiagnosticDraft", (v, id) => withRequestId({ ...v, sessionId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/sessions\/([^/]+)\/diagnostic\/answers$/u)) && method === "POST") return call("submitDiagnosticAnswer", (v, id) => withRequestId({ ...v, sessionId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/sessions\/([^/]+)\/diagnostic\/complete$/u)) && method === "POST") return call("completeDiagnostic", (v, id) => withRequestId({ ...v, sessionId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/sessions\/([^/]+)\/path$/u)) && method === "POST") return call("buildPath", (v, id) => withRequestId({ ...v, sessionId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/sessions\/([^/]+)\/path\/confirm$/u)) && method === "POST") return call("confirmPath", (v, id) => withRequestId({ ...v, sessionId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/sessions\/([^/]+)\/next-step$/u)) && method === "GET") return call("getNextStep", (v, id) => ({ ...v, sessionId: match![1] }));
  if ((match = pathname.match(/^\/api\/sessions\/([^/]+)\/path\/replan$/u)) && method === "POST") return call("replanPath", (v, id) => withRequestId({ ...v, sessionId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/activities\/([^/]+)\/open$/u)) && method === "POST") return call("openActivity", (v, id) => withRequestId({ ...v, activityId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/activities\/([^/]+)\/draft$/u)) && method === "POST") return call("saveActivityDraft", (v, id) => withRequestId({ ...v, activityId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/activities\/([^/]+)\/run$/u)) && method === "POST") return call("prepareActivityRun", (v, id) => withRequestId({ ...v, activityId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/activities\/([^/]+)\/submit$/u)) && method === "POST") return call("submitActivity", (v, id) => withRequestId({ ...v, activityId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/activities\/([^/]+)\/attempts\/([^/]+)$/u)) && method === "GET") return call("getActivityAttempt", (v, id) => ({ ...v, activityId: match![1], attemptId: match![2] }));
  if ((match = pathname.match(/^\/api\/activities\/([^/]+)\/recover$/u)) && method === "POST") return call("recoverActivity", (v, id) => withRequestId({ ...v, activityId: match![1] }, id));
  if ((match = pathname.match(/^\/api\/sessions\/([^/]+)\/context-questions$/u)) && method === "POST") return call("askContextQuestion", (v, id) => withRequestId({ ...v, sessionId: match![1] }, id));
  return undefined;
}

export interface HttpServerHandle {
  server: Server;
  ready: Promise<DemoRuntime>;
  close(): Promise<void>;
}

export function startHttpServer(runtimePromise: Promise<DemoRuntime>, port = 4310): HttpServerHandle {
  let runtime: DemoRuntime | undefined;
  let initializationError = false;
  const runtimeReady = runtimePromise.then((value) => { runtime = value; return value; }, (error) => { initializationError = true; throw error; });
  const server = createServer(async (request, response) => {
    const id = requestId(request);
    const url = new URL(request.url ?? "/", "http://127.0.0.1");
    if (runtime === undefined) { send(response, 503, { requestId: id, error: { code: initializationError ? "initialization_failed" : "initialization_not_ready", message: "Service initialization is not ready." } }); return; }
    let input: JsonObject = {};
    try {
      if (request.method !== "GET") input = await body(request);
      if (request.method === "GET" && url.searchParams.has("recoverSessionId")) input.recoverSessionId = url.searchParams.get("recoverSessionId");
      const target = route(url.pathname, request.method ?? "GET");
      if (target === undefined) { send(response, 404, { requestId: id, error: { code: "not_found", message: "Resource not found." } }); return; }
      const data = await target.call(runtime, input, id);
      const status = typeof data === "object" && data !== null && "contentReadiness" in data && data.contentReadiness === "preparing" ? 202 : 200;
      send(response, status, { requestId: id, data });
    } catch (error) {
      const transport = error as { transportStatus?: number; transportCode?: string };
      if (transport.transportStatus !== undefined) { send(response, transport.transportStatus, { requestId: id, error: { code: transport.transportCode ?? "invalid_request", message: "Request format is invalid." } }); return; }
      const mapped = safeError(error);
      if (EVALUATOR.has(mapped.code)) {
        send(response, 200, { requestId: id, data: { status: "evaluator_error", errorCode: mapped.code, verdict: "not_graded" } });
        return;
      }
      send(response, mapped.status, { requestId: id, error: { code: mapped.code, message: "The request could not be completed." } });
    }
  });
  server.on("clientError", (_error, socket) => socket.destroy());
  const listenReady = new Promise<void>((resolveListen, rejectListen) => {
    server.once("error", rejectListen);
    server.listen({ host: "127.0.0.1", port }, () => resolveListen());
  });
  const ready = Promise.all([runtimeReady, listenReady]).then(([value]) => value);
  return { server, ready, close: async () => {
    await runtime?.close();
    if (!server.listening) return;
    await new Promise<void>((resolveClose) => server.close(() => resolveClose()));
  } };
}
