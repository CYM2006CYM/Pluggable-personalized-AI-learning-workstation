# 岗位 C W4-D3 交接清单

## 基线与上游绑定

- 合同：`W4-C2/W4-R1`
- `W4_START_COMMIT`：`ac6e307e17cf84450845dfc5ffa467063dd3ae4c`
- 实际 `HEAD`：`dc1693e5bfcc0bed226ff0f20613fc4b2ec88681`
- `origin/main`：`dc1693e5bfcc0bed226ff0f20613fc4b2ec88681`
- A 正式提交：`4c52eb7c78fa80007aa9a8ab4e00768d71d3f3f5`
- B 正式提交：`56398ab5f44283e9c10b6d66ec2f0732cc043790`
- D 正式提交：`dc1693e5bfcc0bed226ff0f20613fc4b2ec88681`
- B revision 3：78 entries；seal `e118fd65c4583821f686cba4faab5990a81d2149a8f73cf89af2c376ba15b352`
- D 录制响应 SHA-256：`4dc9fae61d7d179947fe24ed661b5a6826484f9c27e79a0b2fc39a55a186061c`

## 本次新增文件

- `pi-study-helper/src/demo/composition-root.ts`
- `pi-study-helper/src/demo/http-server.ts`
- `pi-study-helper/src/demo/launcher.ts`
- `pi-study-helper/tsconfig.demo.json`
- `pi-study-helper/tests/w4-c-d3-http.test.ts`
- `pi-study-helper/scripts/w4-c-validation/` 下的端点矩阵、结构化结果、安全报告、Manifest 和哈希清单
- `新版设计文档-重写版/第四周任务/handoff-w4-c-d3.md`
- `pi-study-helper/package.json` 仅新增 `build:demo`、`demo`、`demo:live` 命令

## 实际验证

- `npm.cmd run build:demo`：退出码 0
- C 定向测试首次结果：1 文件、9/10 通过、1 失败、退出码 1；失败原因为测试夹具调用旧激活辅助方法，未构造旧 revision active；未修改生产代码。
- C 定向测试最终结果：1 文件、10/10 通过、退出码 0
- `npm.cmd run typecheck`：退出码 0
- `npm.cmd run check:docs`：81 个 Markdown 文件，退出码 0
- `npm.cmd run build:web`：退出码 0
- `npm.cmd run verify`：78 文件、737 通过、1 跳过、0 失败，退出码 0
- `git diff --check`：退出码 0

## 边界与限制

- 默认 Demo 仅使用录制响应；真实在线模型状态为 `LIVE_NOT_RUN`。
- Profile fixture 保持 draft，运行时仅在 `.demo-data` 中通过 A 仓储激活或复用 revision 3。
- 未修改 A contracts/Facade、B revision 3 资产、D 动态实现、W3 环境锁、SDK、依赖或 `package-lock.json`。
- 未实现生产级 Python 沙箱、最终环境锁或 Profile 激活发布。

## Git 状态

- `NOT_COMMITTED`
- `NOT_PUSHED`
- `uploadLock=NOT_REQUESTED`
- 审计 ZIP 仅作为仓库外传输材料，不进入 Git。
