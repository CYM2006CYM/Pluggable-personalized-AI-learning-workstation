# C 岗位 W4-D3 端点与状态码矩阵

## 端点

| 方法 | 路径 | Facade 用例 |
| --- | --- | --- |
| GET | `/api/bootstrap` | `AppBootstrapFacade.getBootstrap` |
| POST | `/api/sessions` | `startSession` |
| POST | `/api/sessions/:id/recover` | `recoverSession` |
| POST | `/api/sessions/:id/complete` | `completeSession` |
| POST | `/api/sessions/:id/diagnostic/draft` | `saveDiagnosticDraft` |
| POST | `/api/sessions/:id/diagnostic/answers` | `submitDiagnosticAnswer` |
| POST | `/api/sessions/:id/diagnostic/complete` | `completeDiagnostic` |
| POST | `/api/sessions/:id/path` | `buildPath` |
| POST | `/api/sessions/:id/path/confirm` | `confirmPath` |
| GET | `/api/sessions/:id/next-step` | `getNextStep` |
| POST | `/api/sessions/:id/path/replan` | `replanPath` |
| POST | `/api/activities/:id/open` | `openActivity` |
| POST | `/api/activities/:id/draft` | `saveActivityDraft` |
| POST | `/api/activities/:id/run` | `prepareActivityRun` |
| POST | `/api/activities/:id/submit` | `submitActivity` |
| GET | `/api/activities/:id/attempts/:attemptId` | `getActivityAttempt` |
| POST | `/api/activities/:id/recover` | `recoverActivity` |
| POST | `/api/sessions/:id/context-questions` | `askContextQuestion` |

## 状态码

- `200`：同步业务结果，包括 fail、partial、insufficient、path infeasible 和已归因 evaluator 故障。
- `202`：异步接收（当前 D3 组合根的画像任务在 Facade 内异步入队）。
- `400`：JSON、Content-Type、请求大小、字段结构或私有字段错误。
- `404`：资源不存在或未知路由。
- `409`：版本、幂等或生命周期冲突。
- `422`：传输有效但业务语义无效。
- `500`：存储或未分类内部错误。
- `503`：组合根尚未初始化完成。

成功响应统一为 `{ requestId, data }`；错误响应只包含安全错误码、固定安全消息和 requestId。
