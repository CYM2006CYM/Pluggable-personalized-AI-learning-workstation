# W4-D1 B revision 3 完整候选交付包

状态：NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED。

候选目录共 79 个文件，seal tree SHA-256：`7861a42fc7a1aacf1e3bcb800f4262c671ccf58703da74a1f75475f796e530ec`。

本 ZIP 依据 W4-C2 公开/私有隔离规则，只携带公开候选文件与私有文件的路径、字节长度和 SHA-256；不携带私有答案正文、私有来源映射、Rubric、hidden tests、reference solutions 或私有数据。完整本地候选由 `evidence/revision-seal.json`、`candidate-full-file-sha256.json` 和 `candidate-private-manifest.json` 加密学绑定。

所有必交项与对应文件见 `delivery-manifest.json`。ZIP 的 SHA-256 在同级 sidecar 文件 `W4-D1-B-complete-delivery-v3-SHA256.txt` 中；该文件不能置入 ZIP 本身，以避免自引用哈希矛盾。
