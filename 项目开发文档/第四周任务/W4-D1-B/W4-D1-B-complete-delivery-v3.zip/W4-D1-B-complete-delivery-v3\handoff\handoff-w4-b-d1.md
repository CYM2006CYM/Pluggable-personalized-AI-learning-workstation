# W4 B D1 revision 3 candidate handoff

## Candidate identity

- Contract/schedule: `W4-C2 / W4-R1`
- B start HEAD / `origin/main`: `00037c1aa995a0ec2aec70b097fc680e193ed08a`
- A formal upstream: `4c52eb7c78fa80007aa9a8ab4e00768d71d3f3f5`
- Candidate directory: `pi-study-helper/fixtures/profiles/pandas-cleaning-revision-3-draft/`
- Candidate seal tree SHA-256: `7861a42fc7a1aacf1e3bcb800f4262c671ccf58703da74a1f75475f796e530ec`
- State: `NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`

## B delivery

- Revision 3 retains Schema 2 and sets `revision=3`, `revisionOf=2`, and `status=draft`.
- Six target knowledge points have `all_in_order`, positive content estimates, exactly one safe fixed card, one group-MCQ activity, a four-question fixed group, and one supplemental question.
- `basic-python` remains an auxiliary prerequisite. Cards are not activities; no card ID appears in `activityIds`. `goal.requiredActivityIds` contains only `act-practical`.
- Public question groups expose only question surfaces. Private answers, explanations and source mappings are in the server-only private answer-key asset. Supplemental questions only complete eligible dynamic candidates; they are not a complete retry group.
- Revision 2 immutability, source coverage, public/private isolation and file inventory reports are in revision 3 `quality/`.

## Downstream consumption

- A: recompute and validate `quality/revision-seal.json` before any draft activation. Do not alter B assets while validating.
- C: use only the candidate directory and repository-returned seal/tree identity during later activation; do not copy or recalculate Profile content.
- D: use fixed cards, question groups and source-safe summaries only; never ingest `assessments/private/quiz-answer-key.json` into Agent context.
- E: consume cards and opened quiz safe DTOs only. Correct answers, explanations and private source mappings are available only after formal submit through A/C safe projections.

## Known limits

The candidate does not claim activation, HTTP/API, Web, Agent, live-model, or W4 GO success. Python evaluator confirmation requires the locked Python 3.13.7 environment; this workstation currently has Python 3.14.4 and records that mismatch rather than changing the environment lock.
