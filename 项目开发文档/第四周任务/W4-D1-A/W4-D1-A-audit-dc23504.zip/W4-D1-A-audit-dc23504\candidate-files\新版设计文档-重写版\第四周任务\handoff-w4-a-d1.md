# W4 A D1 Handoff

## Candidate identity

- Actual base HEAD: `dc23504c3f353883d4f665e64a47cee9afb5723a`
- Inherited W4 contract start: `ac6e307e17cf84450845dfc5ffa467063dd3ae4c`
- Contract/schedule: `W4-C2 / W4-R1`
- State: `NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`

This is a worktree candidate. It has not been committed, pushed, packaged, or uploaded.

## Delivered interfaces

- Canonical public contracts: `pi-study-helper/src/contracts/index.ts` and `pi-study-helper/src/contracts/facade.ts`.
- W3 compatible import: `pi-study-helper/src/application/learning-runtime-facade.ts`.
- 17-method runtime composition: `ComposedLearningRuntimeFacade`.
- Read-only bootstrap: `FileAppBootstrapFacade` implementing `AppBootstrapFacade`.
- Deterministic code bridge: `CodeActivityFacadeAdapter` and `ProfileFamilyCodeActivityAssetResolver`.
- Deterministic quiz bridge: `QuizActivityRuntime`, `ProfileFamilyQuizActivityAssetResolver`, and `DeterministicQuizRuntime`.
- Required activity path recomputation: `ActivityPathSuffixReplanner` and `createActivityPathSuffixReplanner`; code/quiz adapters cannot omit this binding.
- D integration ports: `AdaptiveContentPort` and `CapabilityTaskPort`.
- Revision 3 activation: `ProfileFamilyRepository.activateRevision3Draft(subjectId)`.

The exact exported symbol list is in `pi-study-helper/scripts/w4-a-validation/public-exports.md`.

## Downstream handoff

### B

Build the formal `pandas-cleaning-revision-3-draft` against `ActivityPolicy`, `LearningCardSafeView`, `QuizQuestionGroupAsset`, `QuizAnswerKeyAsset`, and the legacy/W4 `McqActivityAsset` union. Keep public questions answer-free and bind the private key through each activity's `evaluatorRef`. Generate the formal `quality/revision-seal.json`; A did not generate or modify B assets.

### D

Implement `AdaptiveContentPort` and `CapabilityTaskPort`. A revalidates dynamic card/question shape, count, source authorization, duplication, excluded IDs, and answers before use. Dynamic candidates do not directly produce learner results. Capability tasks are triggered only after the formal transaction succeeds and must report `not_updated`, `stale`, or `failed` without rolling back the session.

### C

Import the contracts and `ComposedLearningRuntimeFacade`; do not duplicate DTOs. Bind the HTTP/bootstrap implementation to `LearningRuntimeFacade` and `AppBootstrapFacade`. Preserve request/session/profile/path/Attempt version conflicts and do not expose repository transaction candidates.

### E

Consume `AppBootstrapSafeView`, `SessionRecoverySafeView`, `NextStepOutput`, discriminated code/quiz activity DTOs, and `ActivityProgressEntry`. Correct answers and explanations are absent from open output and appear only in post-submit `answerReview`. No `src/web/` files were touched by A.

## Validation

- Targeted deterministic suite: PASS, 17 files / 131 tests (including activity path suffix coverage).
- Explicit test TypeScript compile with the already installed nested Node types: PASS.
- Full suite: 66/69 files passed; 647 passed / 25 failed / 1 skipped of 673 tests. All failures are existing Python evaluation suites blocked by environment mismatch and missing `pandas`.
- Native `typecheck` and `verify`: blocked at Node type resolution because the locked install has no root `@types/node`; no dependency or lock changes were made.
- Final `check:docs` and `git diff --check` results are recorded with all command hashes in `pi-study-helper/scripts/w4-a-validation/command-results.json`.

Detailed conclusions and limits are in `pi-study-helper/scripts/w4-a-validation/w4-a-validation-report.md`; fault behavior is in `pi-study-helper/scripts/w4-a-validation/transaction-failure-matrix.json`.

## Known limits

- Formal B revision 3 content/seal is still required before real activation can be certified.
- Live D model capability was not run; deterministic fixed/unavailable adapters were used.
- Python/Pandas W3 integration remains unproved on this host.
- HTTP/process and Web integration remain owned by C and E.

No upload lock should be requested until the owner reviews the candidate diff and the environment-blocked gates above.
