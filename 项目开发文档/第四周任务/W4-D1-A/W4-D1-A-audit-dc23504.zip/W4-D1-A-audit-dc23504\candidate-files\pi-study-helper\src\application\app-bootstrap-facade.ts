import type { AppBootstrapFacade, AppBootstrapSafeView } from "../contracts/index.js";
import type { LearningSessionCatalogPort, SessionBindingReader } from "../repositories/learning-session-repository.js";
import type { InternalPathSessionPort } from "../repositories/internal-path-session-port.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";

export interface FileAppBootstrapFacadeOptions {
  profiles: ProfileFamilyRepository;
  sessions: LearningSessionCatalogPort & SessionBindingReader & InternalPathSessionPort;
}

const PRIVATE_DIAGNOSTIC_KEYS = new Set(["correctAnswer", "explanation", "evaluatorRef", "privateAnswerRef", "hiddenTestRefs", "rubricRef", "referenceSolutionRef"]);

function safeDiagnosticEnvelope(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(safeDiagnosticEnvelope);
  if (typeof value !== "object" || value === null) return value;
  return Object.fromEntries(Object.entries(value)
    .filter(([key]) => !PRIVATE_DIAGNOSTIC_KEYS.has(key))
    .map(([key, child]) => [key, safeDiagnosticEnvelope(child)]));
}

/** Read-only bootstrap projection. Private Profile assets are never traversed. */
export class FileAppBootstrapFacade implements AppBootstrapFacade {
  constructor(private readonly options: FileAppBootstrapFacadeOptions) {}

  async getBootstrap(input: { recoverSessionId?: string }): Promise<AppBootstrapSafeView> {
    const manifests = await this.options.profiles.listActiveProfileV2Manifests();
    const goals: AppBootstrapSafeView["goals"] = [];
    const chapters: AppBootstrapSafeView["chapters"] = [];
    const diagnostic: AppBootstrapSafeView["diagnostic"] = [];
    for (const manifest of manifests) {
      const [goalsRaw, knowledgeRaw, diagnosticRaw] = await Promise.all([
        this.options.profiles.readActiveProfileV2File(manifest.subjectId, manifest.paths.goals),
        this.options.profiles.readActiveProfileV2File(manifest.subjectId, manifest.paths.knowledge),
        manifest.paths.diagnostic === undefined
          ? Promise.resolve(undefined)
          : this.options.profiles.readActiveProfileV2File(manifest.subjectId, manifest.paths.diagnostic),
      ]);
      const goalAsset = JSON.parse(goalsRaw) as { goals: Array<{ goalId: string; title: string }> };
      const knowledgeAsset = JSON.parse(knowledgeRaw) as { knowledgePoints: Array<{ chapterId: string }> };
      goals.push(...goalAsset.goals.map(({ goalId, title }) => ({ goalId, title })));
      for (const chapterId of [...new Set(knowledgeAsset.knowledgePoints.map((point) => point.chapterId))].sort((left, right) => left.localeCompare(right, "en"))) {
        if (!chapters.some((chapter) => chapter.chapterId === chapterId)) chapters.push({ chapterId, title: chapterId });
      }
      diagnostic.push({
        subjectId: manifest.subjectId,
        profileRevision: manifest.revision,
        required: manifest.capabilities.diagnostic,
        ...(diagnosticRaw === undefined ? {} : { envelope: safeDiagnosticEnvelope(JSON.parse(diagnosticRaw)) }),
      });
    }
    const snapshots = await this.options.sessions.listBoundSnapshots();
    const recoverableSessions = snapshots
      .filter((snapshot) => snapshot.view.status !== "completed")
      .map((snapshot) => structuredClone(snapshot.view));
    const recovered = input.recoverSessionId === undefined
      ? undefined
      : await this.options.sessions.getBoundSnapshot(input.recoverSessionId);
    const internalPath = recovered === undefined
      ? undefined
      : await this.options.sessions.getInternalPathSnapshot({ sessionId: recovered.sessionId, sessionVersion: recovered.sessionVersion, profileRevision: recovered.profileRevision });
    return {
      profiles: manifests.map((manifest) => ({ subjectId: manifest.subjectId, name: manifest.name, revision: manifest.revision, modalities: [...manifest.capabilities.modalities] })),
      goals,
      chapters,
      diagnostic,
      recoverableSessions,
      ...(recovered === undefined ? {} : {
        session: {
          sessionId: recovered.sessionId,
          sessionVersion: recovered.sessionVersion,
          profileRevision: recovered.profileRevision,
          view: recovered.view,
          diagnosticDraftVersion: recovered.diagnosticDraftVersion,
          ...(recovered.diagnosticDraft === undefined ? {} : { diagnosticDraft: structuredClone(recovered.diagnosticDraft) }),
          activityProgress: structuredClone(recovered.activityProgress),
          ...(recovered.currentAttempt === undefined ? {} : { currentAttempt: structuredClone(recovered.currentAttempt) }),
          ...(recovered.path === undefined ? {} : { path: {
            pathId: recovered.path.pathId,
            pathVersion: recovered.path.pathVersion,
            status: recovered.path.status,
            nodes: internalPath === undefined ? structuredClone(recovered.path.nodes) : internalPath.nodes.map((node) => ({
              nodeId: node.nodeId, knowledgePointId: node.knowledgePointId, activityIds: [...node.activityIds], status: node.status,
              estimatedMinutes: node.estimatedMinutes, reasonCodes: [...node.reasonCodes], difficulty: node.difficulty,
              scaffold: node.scaffold, required: node.required, positionLocked: node.positionLocked,
            })),
          } }),
        },
      }),
    };
  }
}
