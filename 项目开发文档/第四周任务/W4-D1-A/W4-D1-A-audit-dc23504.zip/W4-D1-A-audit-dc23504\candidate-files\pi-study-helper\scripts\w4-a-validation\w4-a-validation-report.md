# W4-A D1 Validation Report

## Identity and scope

- Actual HEAD: `dc23504c3f353883d4f665e64a47cee9afb5723a`
- W4 contract baseline: `ac6e307e17cf84450845dfc5ffa467063dd3ae4c`
- Contract version: `W4-C2`; schedule: `W4-R1`
- Role: A; day: D1; implementation state: candidate worktree
- State: `NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`

No changes were made to `src/web/`, HTTP/bootstrap services, model prompts or recorded responses, formal Profile assets, W3 environment locks, TaskBundle, Rubric, gold data, SDK dependencies, or `package-lock.json`. No upload ZIP was generated.

## Implementation result

1. Public DTOs now have one source under `src/contracts/`; the W3 application import path is a compatibility re-export.
2. Profile Schema accepts optional `activityPolicy` and positive `contentEstimatedMinutes`, preserves revision 2 defaults, and validates revision 3 cards, grouped questions, private answer closure, source bindings, and illegal mixed shapes.
3. `PathEngine` preserves W3 `select_one`, supports ordered complete `all_in_order`, accounts for content plus all selected activity time, keeps prerequisite closure, and retains the final practical.
4. Quiz runtime owns Attempt snapshots, complete answer validation, `ceil(n * 0.75)` scoring, one non-overlapping retry, safe post-submit review, Evidence generation, and request/Attempt idempotency.
5. Session storage owns `activityProgress`, `diagnosticDraftVersion`, current Attempt, derived Evidence/KnowledgeState/path/progress, and last-checkpoint publication. The fault matrix is in `transaction-failure-matrix.json`.
6. Diagnostic draft/background CAS does not increment `sessionVersion`; `background_only` produces no diagnostic Evidence and refresh recovery resumes at the path stage.
7. Code and quiz adapters atomically acknowledge a pending card and open the first unfinished activity. Formal submit derives facts internally; `evaluator_error` does not advance progress.
8. Bootstrap returns safe Profile, goal, chapter, diagnostic envelope, recoverable session, path, progress, draft, and current Attempt projections.
9. Revision 3 activation strictly reads `pandas-cleaning-revision-3-draft`, verifies the self-excluding POSIX-sorted seal, activates once, reuses the same seal, and blocks other revisions or seal drift.
10. Formal code and quiz submission require a bound `ActivityPathSuffixReplanner`; Evidence, KnowledgeState, progress, replacement path, and old-path archive publish through the same session candidate, including `insufficient` terminal quiz results that produce no Evidence.

## Facade completion

| Method | Provider | Status |
| --- | --- | --- |
| `startSession` | session facade delegation | PASS |
| `recoverSession` | path/session facade delegation | PASS |
| `completeSession` | `ComposedLearningRuntimeFacade` | PASS |
| `saveDiagnosticDraft` | diagnostic delegation | PASS |
| `submitDiagnosticAnswer` | diagnostic delegation | PASS |
| `completeDiagnostic` | diagnostic delegation plus post-commit task trigger | PASS |
| `buildPath` | path delegation | PASS |
| `confirmPath` | path delegation | PASS |
| `getNextStep` | path delegation | PASS |
| `replanPath` | path delegation | PASS |
| `openActivity` | code/quiz discriminated dispatch | PASS |
| `saveActivityDraft` | code adapter | PASS |
| `prepareActivityRun` | code adapter | PASS |
| `submitActivity` | code/quiz discriminated dispatch plus post-commit task trigger | PASS |
| `getActivityAttempt` | code/quiz discriminated dispatch | PASS |
| `recoverActivity` | code adapter | PASS |
| `askContextQuestion` | fixed safe fallback | PASS |

`completeSession` accepts any formal learner verdict on the final path practical, including fail, and summarizes fail/partial/insufficient plus unverified/support-needed knowledge. The context fallback exposes no private assets or host paths.

## A/D ports

- `AdaptiveContentPort`: declared in `src/contracts/index.ts`. `selectDeterministicCard()` and `selectDeterministicQuizContent()` enforce shape, count, source, duplicate, exclusion, and answer-key constraints. Selection is dynamic, then supplemental completion, then whole fixed group, then insufficient. `createDeterministicContentPort()` is the no-model unavailable adapter that deterministically falls through to fixed content.
- `CapabilityTaskPort`: declared in `src/contracts/index.ts`. It is invoked only after a formal diagnostic or activity commit resolves. Enqueue failure is isolated from the session transaction; the port's returned `taskStatus` records not-updated/stale/failed semantics. `createEmptyCapabilityTaskPort()` is the no-op deterministic implementation.

No live D model call was made. Port behavior is proven with deterministic adapters and spies only.

## Revision 3 activation and consumers

- Activation entry: `ProfileFamilyRepository.activateRevision3Draft(subjectId)`.
- B consumes `ActivityPolicy`, revision 3 Profile fields, card/question-group assets, private answer closure, and `RevisionSeal`; B must provide the formal revision 3 directory and seal.
- D implements `AdaptiveContentPort` and `CapabilityTaskPort`; A remains the authority for deterministic validation and facts.
- C imports `LearningRuntimeFacade`, `ComposedLearningRuntimeFacade`, `AppBootstrapFacade`, and safe error/DTO contracts when implementing HTTP/bootstrap outside this change.
- E imports `AppBootstrapSafeView`, `SessionRecoverySafeView`, path/activity discriminated unions, progress, and safe quiz review. No Web code was modified here.

The complete symbol inventory is in `public-exports.md`.

## Verification conclusion

- W4-A targeted suite: PASS, 17 files and 131 tests (including activity path suffix integration coverage).
- Explicit test TypeScript compile using the already installed nested SDK Node types: PASS.
- `check:docs`: PASS before final evidence generation; final result is recorded in `command-results.json`.
- `git diff --check`: PASS before final evidence generation; final result is recorded in `command-results.json`.
- Full test suite: environment-blocked, 66/69 files passed; 647 passed, 25 failed, 1 skipped out of 673 tests. All 25 failures are in the three existing Python evaluator/delivery files and report `dependency_missing`, `environment_mismatch`, or `ModuleNotFoundError: No module named 'pandas'`.
- Native `typecheck` and therefore `verify`: environment-blocked because the locked install contains `@types/node` only under the coding-agent dependency, while the repository TypeScript configuration resolves no root Node types. The formal scripts were not rewritten and dependencies were not changed.

## Unproved and deferred

- B's formal revision 3 content, private answers, and seal do not exist in this A candidate; validation uses a synthetic temporary fixture only.
- D's real adaptive/model adapters and live model behavior were not run.
- W3 Python/Pandas integration cannot be certified in the current host environment.
- C HTTP/process integration and E Web integration remain outside role A and were not modified.

Machine-readable command timestamps, exit codes, counts, and stdout/stderr SHA-256 values are in `command-results.json`.
