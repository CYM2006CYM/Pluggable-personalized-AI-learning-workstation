# W4-A Public Export Inventory

## Canonical contract entrypoint

`src/contracts/index.ts` is the single public W4 type source. It re-exports the complete facade surface from `src/contracts/facade.ts`. The former W3 import path, `src/application/learning-runtime-facade.ts`, is a compatibility-only re-export of `src/contracts/facade.ts`.

## W4 contract exports

| Area | Exported symbols |
| --- | --- |
| Profile policy and cards | `ActivityPolicy`, `Revision3KnowledgePointFields`, `LearningCardSafeView` |
| Quiz assets | `QuizQuestionSafeView`, `QuizQuestionPrivate`, `QuizQuestionGroupAsset`, `QuizAnswerKeyAsset`, `LegacySingleQuestionActivityAsset`, `W4QuestionGroupActivityAsset`, `McqActivityAsset` |
| Quiz runtime DTOs | `QuizActivitySafeView`, `QuizAnswerInput`, `QuizSubmitActivityInput`, `QuizActivityResult` |
| Diagnostic | `DiagnosticDraftVersion`, `DiagnosticCompletion`, `BackgroundQuestionnaire` |
| Progress and recovery | `ActivityProgressStatus`, `ActivityProgressEntry`, `NodeActivityProgress`, `SessionRecoverySafeView` |
| Application bootstrap | `AppBootstrapSafeView`, `AppBootstrapFacade` |
| A/D ports | `AdaptiveContentPort`, `CapabilityTaskPort`, `createDeterministicContentPort`, `createEmptyCapabilityTaskPort` |
| Revision seal | `RevisionSeal`, `RevisionSealEntry` |

## Facade exports

`src/contracts/facade.ts` exports `LearningRuntimeFacade` and all input/output DTOs for its 17 methods. W4 additions on that surface are:

- `SessionRecoverySafeView` with diagnostic draft, activity progress, current Attempt, and safe path recovery projections.
- `PathNodeSafeView.difficulty`, `.scaffold`, `.required`, and `.positionLocked`.
- `ReplanPathOutput.changeReasons`.
- Discriminated code/quiz open and submit DTOs through `ActivityDraftOutput` and `SubmitActivityInput`.
- Safe post-submit quiz review through `QuizActivityResult.answerReview`.

Public write inputs do not expose `evidenceCandidate`, `knowledgeStates`, `pathCandidate`, or `activityProgress`. Open-activity output does not expose private answers, explanations, Rubric data, hidden tests, reference solutions, host paths, or graph execution objects.

## Importable implementations

| Consumer need | Export and source |
| --- | --- |
| 17-method composition | `ComposedLearningRuntimeFacade` from `src/application/composed-learning-runtime-facade.ts` |
| Read-only bootstrap | `FileAppBootstrapFacade` from `src/application/app-bootstrap-facade.ts` |
| Code activity bridge | `CodeActivityFacadeAdapter`, `ProfileFamilyCodeActivityAssetResolver` from `src/application/code-activity-facade-adapter.ts` |
| Quiz activity bridge | `QuizActivityRuntime`, `ProfileFamilyQuizActivityAssetResolver` from `src/application/quiz-activity-runtime.ts` |
| Activity path suffix | `ActivityPathSuffixReplanner`, `createActivityPathSuffixReplanner` from `src/application/activity-path-suffix.ts`; both formal activity bridges require this dependency |
| Deterministic content gates | `selectDeterministicCard`, `selectDeterministicQuizContent` from `src/application/deterministic-content-policy.ts` |
| Quiz scoring core | `DeterministicQuizRuntime` from `src/domain/quiz-runtime.ts` |
| Revision 3 activation | `ProfileFamilyRepository.activateRevision3Draft()` from `src/repositories/profile-family-repository.ts` |

## Downstream ownership

- B consumes Profile fields, card/question-group containers, private key closure rules, and revision seal validation. B remains the owner of formal revision 3 content and seal.
- D implements `AdaptiveContentPort` and `CapabilityTaskPort`; A validates content after the adaptive port and does not treat model output as a result.
- C consumes `LearningRuntimeFacade`, `ComposedLearningRuntimeFacade`, and `AppBootstrapFacade`; C remains the owner of HTTP and process/bootstrap services.
- E consumes only contracts safe views and Facade outputs; E remains the owner of `src/web/`.
