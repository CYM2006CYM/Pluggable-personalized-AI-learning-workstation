import { describe, expect, it } from "vitest";
import { FileAppBootstrapFacade } from "../src/application/app-bootstrap-facade.js";
import type { ProfileFamilyRepository } from "../src/repositories/profile-family-repository.js";
import type { FileLearningSessionRepository } from "../src/repositories/file-learning-session-repository.js";

describe("FileAppBootstrapFacade", () => {
  it("returns deterministic safe profile/session recovery projections and removes private diagnostic fields", async () => {
    const manifest = { subjectId: "subject", name: "Subject", revision: 3, capabilities: { modalities: ["reading", "quiz"], diagnostic: true }, paths: { goals: "goals.json", knowledge: "knowledge.json", diagnostic: "diagnostic.json" } };
    const files: Record<string, string> = {
      "goals.json": JSON.stringify({ goals: [{ goalId: "goal", title: "Goal" }] }),
      "knowledge.json": JSON.stringify({ knowledgePoints: [{ chapterId: "chapter-b" }, { chapterId: "chapter-a" }] }),
      "diagnostic.json": JSON.stringify({ questions: [{ questionId: "q", prompt: "safe", correctAnswer: "private", nested: { explanation: "private", value: "safe" } }] }),
    };
    const profiles = {
      async listActiveProfileV2Manifests() { return [manifest]; },
      async readActiveProfileV2File(_subjectId: string, path: string) { return files[path]!; },
    } as unknown as ProfileFamilyRepository;
    const view = { sessionId: "session", sessionVersion: 4, profileRevision: 3, subjectId: "subject", mode: "recommended", goalId: "goal", availableMinutes: 20, status: "active", stage: "activity", diagnosticRequired: true, pathVersion: 1 };
    const recovered = {
      sessionId: "session", sessionVersion: 4, profileRevision: 3, view,
      diagnosticDraftVersion: 2, diagnosticDraft: { currentQuestionId: "q", processedQuestionIds: [] },
      activityProgress: [{ nodeId: "node", activities: [{ activityId: "quiz", status: "in_progress", attemptIds: ["attempt"], quizRetryCount: 0, updatedAt: "2026-08-12T00:00:00.000Z" }] }],
      currentAttempt: { activityId: "quiz", attemptId: "attempt", retryNumber: 0 },
      path: { pathId: "path", pathVersion: 1, status: "active", nodes: [{ nodeId: "node", knowledgePointId: "kp", activityIds: ["quiz"], status: "available", estimatedMinutes: 10, reasonCodes: [] }] },
    };
    const sessions = {
      async listBoundSnapshots() { return [recovered]; },
      async getBoundSnapshot() { return recovered; },
      async getInternalPathSnapshot() { return { ...recovered.path, nodes: [{ ...recovered.path.nodes[0], difficulty: "M-U", scaffold: "hint", required: true, positionLocked: true }] }; },
    } as unknown as FileLearningSessionRepository;
    const bootstrap = await new FileAppBootstrapFacade({ profiles, sessions }).getBootstrap({ recoverSessionId: "session" });
    expect(bootstrap).toMatchObject({
      profiles: [{ subjectId: "subject", revision: 3, modalities: ["reading", "quiz"] }],
      goals: [{ goalId: "goal", title: "Goal" }],
      chapters: [{ chapterId: "chapter-a" }, { chapterId: "chapter-b" }],
      recoverableSessions: [view],
      session: { diagnosticDraftVersion: 2, currentAttempt: { attemptId: "attempt" }, path: { nodes: [{ difficulty: "M-U", scaffold: "hint", required: true, positionLocked: true }] } },
    });
    expect(JSON.stringify(bootstrap.diagnostic)).not.toContain("correctAnswer");
    expect(JSON.stringify(bootstrap.diagnostic)).not.toContain("explanation");
    expect(JSON.stringify(bootstrap.diagnostic)).toContain("safe");
  });
});
