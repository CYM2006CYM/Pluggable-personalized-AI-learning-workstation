# W4-D1-A-5 upload candidate

This is the complete A candidate based on $baseline and W4-C2/W4-R1.

- Apply 	racked-changes.patch only after A receives the upload lock and confirms HEAD/origin/main still match the approved baseline.
- candidate-files/ contains the same 55 files for direct inspection.
- command-results.json and command-logs/ preserve real exit codes, including the first full-suite V2-6 wrapper timeout.
- The final smoke and verify passed; prior baseline/candidate smoke timeouts remain classified as FLAKY_BASELINE_REPRODUCIBLE and are not rewritten.
- No commit, push, upload lock, Profile activation or W4 GO is performed by this package.