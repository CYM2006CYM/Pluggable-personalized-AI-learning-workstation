# C W4-D3 R3 Validation Report

Contract: `W4-C2 / W4-R1`

Current binding: `HEAD = origin/main = c50e2c1aea19a7cf77aacbaa654f9f298b6c0dbe`.

## Result

`C_R3_01_PASS`, `C_R3_02_PASS`, and `C_R3_03_PASS` are demonstrated by the C HTTP suite and affected cross-role tests. C-R3-04 binding data is updated to the current A/B/D commits and revision 3 asset tree, but the candidate remains `BLOCKED_UPSTREAM_TEST_STALE` because the existing D-owned test still asserts an obsolete seal. C did not modify that test or any A/B/D file.

## Implemented

- Strict query construction for `next-step` and Attempt GET routes, including duplicate and extra-key rejection.
- Diagnostic evaluator references resolve relative to the diagnostic blueprint directory.
- HTTP tests use contract environment/PATH behavior and contain no developer Python path.
- Demo composition root activates or reuses revision 3 without copying or rewriting Profile assets.
- Real recommended and chapter HTTP traces cover questionnaire persistence, diagnostic completion, path confirmation, helper single-question activity, quiz opening/submission, refresh recovery, and safe public output.

## Verification

- C HTTP: 15/15.
- A/B/C/D affected tests: 36/36.
- `typecheck`, `check:docs`, `build:demo`, `build:web`, and `git diff --check`: exit 0.
- Full test and `verify`: 79 files, 746 passed, 1 failed, 1 skipped. The only failure is `tests/w4-d-fixed-fallback-integration.test.ts`, whose expected seal is obsolete while the current formal B seal is recorded in `upstream-binding.json`; this is retained as a blocker and not changed by C.
- `npm.cmd run demo`: fixed ports are enforced. The local environment intermittently has an external listener on 4310, so the smoke result is a truthful nonzero port-conflict result; no drift and no external process termination occurred.
- Live model: `LIVE_NOT_RUN`.

All command timestamps, exit codes, counts, and stdout/stderr hashes are in `command-results.json`. Raw logs stay outside the candidate.

## Scope

Profile remains `draft`. No A contracts/Facade, B revision 3 assets or private answers, D implementation/recordings, E web files, SDK, dependencies, lockfiles, gold, or W3 environment lock were modified.

Status: `NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`.
