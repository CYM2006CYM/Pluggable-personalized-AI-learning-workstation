# C W4-D3 R3 Upstream Blocker

Status: `BLOCKED_UPSTREAM_TEST_STALE`

Actual HEAD and origin/main: `c50e2c1aea19a7cf77aacbaa654f9f298b6c0dbe`.

Minimal input: run `npm.cmd test -- --maxWorkers=1` in the C candidate environment with Node `v22.23.1`, Python `3.13.7`, Pandas `3.0.5`, and `PYTHONNOUSERSITE=1`.

Complete entry point: `tests/w4-d-fixed-fallback-integration.test.ts`, test `independently recalculates A's revision seal entry count and B's formal tree hash`.

Expected: the test accepts the current formal revision 3 asset tree binding.

Actual: the test compares the recalculated 78-entry tree against an obsolete owner assertion, so the test process exits 1. The current formal B tree hash is recorded in `upstream-binding.json`.

Error: assertion failure; 79 test files, 746 passed, 1 failed, 1 skipped. Stdout SHA-256: `da5d1c8d182f598169f6bf71b2f14fdabbe26fc6cd3d4d9eb683a24fb3689e63`; stderr SHA-256: `c00ae00a4169d8a7cf69f80cc2f5a0e3dab92ebb313df599e8941ec7d3834fe6`.

Ownership: D/B upstream test binding. C did not modify A, B, D, or this test and cannot resolve it in the C layer without violating the ownership boundary.

Required owner action: update the D-owned assertion to the current formal B binding, then rerun the full gate. No C commit, push, or upload lock is requested.
