import type {
  BuildPathInput,
  ConfirmPathInput,
  ConfirmedPathOutput,
  FacadeResponseMeta,
  GetNextStepInput,
  NextStepOutput,
  PathCandidateOutput,
  PathNodeSafeView,
  ReadRequestMeta,
  RecoverSessionInput,
  RecoverSessionOutput,
  ReplanPathInput,
  ReplanPathOutput,
  SessionSafeView,
} from "./learning-runtime-facade.js";
import type { KnowledgeState } from "../domain/v2-types.js";
import {
  PathEngine,
  type LearningPath,
  type LearningPathNode,
  type PathActivityDefinition,
  type PathEngineProfile,
  type PathEngineInput,
  type PathEngineReplanInput,
  type PathReasonCode,
} from "../domain/path-engine.js";
import type {
  LearningSessionRepository,
  PathSafeSnapshot,
  SessionSnapshot,
} from "../repositories/learning-session-repository.js";
import { LearningSessionRepositoryError } from "../repositories/learning-session-repository.js";
import type { ProfileFamilyRepository } from "../repositories/profile-family-repository.js";

export interface PathProfileResolver {
  load(subjectId: string, profileRevision: number): Promise<PathEngineProfile>;
}

/** Adapts the v2 Profile repository projection to the pure PathEngine input. */
export class ProfileFamilyPathResolver implements PathProfileResolver {
  constructor(private readonly profiles: ProfileFamilyRepository) {}

  async load(subjectId: string, profileRevision: number): Promise<PathEngineProfile> {
    const manifest = await this.profiles.loadActiveProfileV2(subjectId);
    if (manifest.revision !== profileRevision) {
      throw new LearningSessionRepositoryError("profile_revision_conflict", "Profile revision does not match session");
    }
    const [goalsRaw, knowledgeRaw, activitiesRaw] = await Promise.all([
      this.profiles.readActiveProfileV2File(subjectId, manifest.paths.goals),
      this.profiles.readActiveProfileV2File(subjectId, manifest.paths.knowledge),
      manifest.paths.activities === undefined
        ? Promise.resolve('{"activities":[]}')
        : this.profiles.readActiveProfileV2File(subjectId, manifest.paths.activities),
    ]);
    const goals = JSON.parse(goalsRaw) as PathEngineProfile["goals"];
    const knowledge = JSON.parse(knowledgeRaw) as PathEngineProfile["knowledgePoints"];
    const activities = JSON.parse(activitiesRaw) as PathEngineProfile["activities"];
    return {
      subjectId: manifest.subjectId,
      profileRevision: manifest.revision,
      goals: Array.isArray(goals) ? goals : (goals as unknown as { goals: PathEngineProfile["goals"] }).goals,
      knowledgePoints: Array.isArray(knowledge)
        ? knowledge
        : (knowledge as unknown as { knowledgePoints: PathEngineProfile["knowledgePoints"] }).knowledgePoints,
      activities: Array.isArray(activities)
        ? activities
        : (activities as unknown as { activities: PathEngineProfile["activities"] }).activities,
    };
  }
}

export interface PathLearningFacadeOptions {
  sessions: LearningSessionRepository;
  profile: PathProfileResolver;
  now?: () => Date;
}

export interface PathRuntimeFacade {
  buildPath(input: BuildPathInput): Promise<PathCandidateOutput>;
  confirmPath(input: ConfirmPathInput): Promise<ConfirmedPathOutput>;
  getNextStep(input: GetNextStepInput): Promise<NextStepOutput>;
  replanPath(input: ReplanPathInput): Promise<ReplanPathOutput>;
  recoverSession(input: RecoverSessionInput): Promise<RecoverSessionOutput>;
}

type CandidateRecord = { path: LearningPath; profile: PathEngineProfile };

function asSafeNode(node: LearningPathNode): PathNodeSafeView {
  return {
    nodeId: node.nodeId,
    knowledgePointId: node.knowledgePointId,
    activityIds: [...node.activityIds],
    status: node.status,
    estimatedMinutes: node.estimatedMinutes,
    reasonCodes: [...node.reasonCodes],
  };
}

function asSafeSnapshot(path: LearningPath, status: PathSafeSnapshot["status"] = "candidate"): PathSafeSnapshot {
  return {
    pathId: path.pathId,
    pathVersion: path.pathVersion,
    status,
    goalId: path.goalId,
    mode: path.mode,
    nodes: path.nodes.map(asSafeNode),
  };
}

function meta(snapshot: SessionSnapshot): FacadeResponseMeta {
  return {
    sessionId: snapshot.sessionId,
    sessionVersion: snapshot.sessionVersion,
    profileRevision: snapshot.profileRevision,
  };
}

function sameRequestVersion(snapshot: SessionSnapshot, input: ReadRequestMeta): void {
  if (snapshot.profileRevision !== input.profileRevision) {
    throw new LearningSessionRepositoryError("profile_revision_conflict", "Profile revision does not match session");
  }
  if (snapshot.sessionVersion !== input.sessionVersion) {
    throw new LearningSessionRepositoryError("session_version_conflict", "Session version is stale");
  }
}

function activityView(activity: PathActivityDefinition | undefined, activityId: string) {
  if (!activity) return undefined;
  return {
    activityId: activity.activityId,
    activityVersion: activity.profileRevision ?? 1,
    kind: activity.kind ?? "explain" as const,
    title: activity.title ?? activity.activityId,
    prompt: activity.prompt ?? "",
    primaryKnowledgePointId: activity.primaryKnowledgePointId,
    supportingKnowledgePointIds: [...activity.supportingKnowledgePointIds],
    ...(activity.starterCode === undefined ? {} : { starterCode: activity.starterCode }),
  };
}

function internalPath(snapshot: PathSafeSnapshot, sessionId: string, profileRevision: number, evidenceVersion: number): LearningPath {
  return {
    pathId: snapshot.pathId,
    sessionId,
    profileRevision,
    evidenceVersion,
    pathVersion: snapshot.pathVersion,
    engineVersion: "path-engine-v1",
    status: snapshot.status === "candidate" ? "draft" : "confirmed",
    mode: snapshot.mode,
    goalId: snapshot.goalId,
    availableMinutes: snapshot.nodes.reduce((total, node) => total + node.estimatedMinutes, 0),
    estimatedMinutes: snapshot.nodes.filter((node) => node.status !== "skipped")
      .reduce((total, node) => total + node.estimatedMinutes, 0),
    nodes: snapshot.nodes.map((node) => ({
      ...node,
      positionLocked: node.status === "completed" || node.status === "in_progress",
      required: node.status !== "skipped",
      difficulty: "S-U" as const,
      scaffold: "hint" as const,
      reasonCodes: [...node.reasonCodes] as PathReasonCode[],
    })),
    positionLockedNodeIds: snapshot.nodes.filter((node) => node.status === "completed" || node.status === "in_progress")
      .map((node) => node.nodeId),
    changeReasons: [],
    createdAt: "1970-01-01T00:00:00.000Z",
  };
}

/**
 * D1 path application boundary. It deliberately exposes only the five path
 * and recovery use cases; diagnostic and activity use cases remain owned by
 * their later workdays.
 */
export class PathLearningRuntimeFacade implements PathRuntimeFacade {
  private readonly candidates = new Map<string, CandidateRecord>();
  private readonly now: () => Date;

  constructor(private readonly options: PathLearningFacadeOptions) {
    this.now = options.now ?? (() => new Date());
  }

  private async snapshot(input: ReadRequestMeta): Promise<SessionSnapshot> {
    const snapshot = await this.options.sessions.getSnapshot(input);
    sameRequestVersion(snapshot, input);
    return snapshot;
  }

  private async engineFor(snapshot: SessionSnapshot): Promise<{ engine: PathEngine; profile: PathEngineProfile }> {
    const profile = await this.options.profile.load(snapshot.view.subjectId, snapshot.profileRevision);
    return { engine: new PathEngine(profile), profile };
  }

  private buildInput(input: BuildPathInput, snapshot: SessionSnapshot, pathVersion?: number): PathEngineInput {
    return {
      sessionId: input.sessionId,
      profileRevision: input.profileRevision,
      evidenceVersion: input.evidenceVersion,
      goalId: input.goalId,
      mode: input.mode,
      availableMinutes: input.availableMinutes,
      selectedKnowledgePointIds: [...input.selectedKnowledgePointIds],
      lockedNodeIds: [...input.lockedNodeIds],
      knowledgeStates: snapshot.knowledgeStates,
      ...(pathVersion === undefined ? {} : { pathVersion }),
      createdAt: this.now().toISOString(),
    };
  }

  async buildPath(input: BuildPathInput): Promise<PathCandidateOutput> {
    const snapshot = await this.snapshot(input);
    const { engine, profile } = await this.engineFor(snapshot);
    const result = engine.build(this.buildInput(input, snapshot, (snapshot.path?.pathVersion ?? 0) + 1));
    if (result.status === "infeasible") {
      return {
        ...meta(snapshot),
        requestId: input.requestId,
        status: "infeasible",
        nodes: [],
        missingPrerequisiteIds: result.failure.missingPrerequisiteIds,
        minimumRequiredMinutes: result.failure.minimumRequiredMinutes,
        errorCode: "path_infeasible",
      };
    }
    this.candidates.set(result.path.pathId, { path: result.path, profile });
    return {
      ...meta(snapshot),
      requestId: input.requestId,
      status: "candidate",
      pathId: result.path.pathId,
      pathVersion: result.path.pathVersion,
      nodes: result.path.nodes.map(asSafeNode),
      missingPrerequisiteIds: result.path.nodes
        .filter((node) => node.reasonCodes.includes("prerequisite_gap"))
        .map((node) => node.knowledgePointId),
    };
  }

  async confirmPath(input: ConfirmPathInput): Promise<ConfirmedPathOutput> {
    const snapshot = await this.snapshot(input);
    const candidate = this.candidates.get(input.pathId);
    const path = candidate?.path ?? (snapshot.path?.pathId === input.pathId
      ? internalPath(snapshot.path, snapshot.sessionId, snapshot.profileRevision, snapshot.latestCommit.evidenceVersion)
      : undefined);
    if (!path || path.pathVersion !== input.pathVersion) {
      return { ...meta(snapshot), requestId: input.requestId, pathId: input.pathId, pathVersion: input.pathVersion, status: "active", errorCode: "path_version_conflict" };
    }
    const committed = await this.options.sessions.commit({
      requestId: input.requestId,
      sessionId: input.sessionId,
      sessionVersion: input.sessionVersion,
      profileRevision: input.profileRevision,
      candidate: {
        requestId: input.requestId,
        knowledgeStates: snapshot.knowledgeStates,
        pathCandidate: asSafeSnapshot(path, "active"),
        nextStage: "learning",
      },
    });
    this.candidates.delete(input.pathId);
    return {
      ...meta(committed),
      requestId: input.requestId,
      pathId: input.pathId,
      pathVersion: input.pathVersion,
      status: "active",
    };
  }

  async getNextStep(input: GetNextStepInput): Promise<NextStepOutput> {
    const snapshot = await this.snapshot(input);
    const path = snapshot.path;
    if (!path || path.pathVersion !== input.pathVersion) {
      return { ...meta(snapshot), pathVersion: input.pathVersion, completed: false, errorCode: "path_version_conflict" };
    }
    const node = path.nodes.find((item) => item.status === "in_progress") ?? path.nodes.find((item) => item.status === "available");
    if (!node) return { ...meta(snapshot), pathVersion: path.pathVersion, completed: true };
    const profile = await this.options.profile.load(snapshot.view.subjectId, snapshot.profileRevision);
    const activity = activityView(profile.activities.find((item) => item.activityId === node.activityIds[0]), node.activityIds[0]);
    return {
      ...meta(snapshot),
      pathVersion: path.pathVersion,
      completed: false,
      node,
      ...(activity === undefined ? {} : { activity }),
    };
  }

  async replanPath(input: ReplanPathInput): Promise<ReplanPathOutput> {
    const snapshot = await this.snapshot(input);
    if (!snapshot.path || snapshot.path.pathVersion !== input.pathVersion) {
      return { ...meta(snapshot), requestId: input.requestId, changed: false, pathId: snapshot.path?.pathId ?? "", pathVersion: input.pathVersion, nodes: [], fallbackToPrevious: true, errorCode: "path_version_conflict" };
    }
    const { engine, profile } = await this.engineFor(snapshot);
    const previous = internalPath(snapshot.path, snapshot.sessionId, snapshot.profileRevision, input.evidenceVersion);
    const result = engine.replan({
      sessionId: input.sessionId,
      profileRevision: input.profileRevision,
      evidenceVersion: input.evidenceVersion,
      goalId: snapshot.path.goalId,
      mode: snapshot.path.mode,
      availableMinutes: input.availableMinutes,
      selectedKnowledgePointIds: [...input.selectedKnowledgePointIds],
      lockedNodeIds: [...input.lockedNodeIds],
      knowledgeStates: snapshot.knowledgeStates,
      pathVersion: input.pathVersion + 1,
      createdAt: this.now().toISOString(),
      previousPath: previous,
      trigger: input.trigger,
    });
    if (result.status === "infeasible") {
      return { ...meta(snapshot), requestId: input.requestId, changed: false, pathId: previous.pathId, pathVersion: previous.pathVersion, nodes: snapshot.path.nodes, fallbackToPrevious: true, errorCode: "path_infeasible" };
    }
    this.candidates.set(result.path.pathId, { path: result.path, profile });
    return { ...meta(snapshot), requestId: input.requestId, changed: true, pathId: result.path.pathId, pathVersion: result.path.pathVersion, nodes: result.path.nodes.map(asSafeNode), fallbackToPrevious: false };
  }

  async recoverSession(input: RecoverSessionInput): Promise<RecoverSessionOutput> {
    const recovered = await this.options.sessions.recover(input);
    return {
      ...meta(recovered),
      requestId: input.requestId,
      view: recovered.view,
      recoveryAction: recovered.recoveryAction,
    };
  }
}
