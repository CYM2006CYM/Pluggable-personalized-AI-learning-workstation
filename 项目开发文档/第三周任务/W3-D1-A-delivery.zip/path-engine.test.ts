import { describe, expect, it } from "vitest";
import type { KnowledgeState } from "../src/domain/v2-types.js";
import { PathEngine, type PathEngineProfile } from "../src/domain/path-engine.js";

const profile: PathEngineProfile = {
  subjectId: "demo",
  profileRevision: 2,
  goals: [{
    goalId: "goal-main",
    title: "主目标",
    targetKnowledgePointIds: ["c"],
    requiredActivityIds: ["act-a", "act-b", "act-c"],
  }],
  knowledgePoints: [
    { id: "a", title: "基础", chapterId: "ch", sectionId: "s", prerequisiteIds: [], relatedKnowledgePointIds: [], sourceAnchorIds: ["src-a"], activityIds: ["act-a"], importance: 0.1 },
    { id: "b", title: "中间", chapterId: "ch", sectionId: "s", prerequisiteIds: ["a"], relatedKnowledgePointIds: [], sourceAnchorIds: ["src-b"], activityIds: ["act-b"], importance: 0.2 },
    { id: "c", title: "目标", chapterId: "ch", sectionId: "s", prerequisiteIds: ["b"], relatedKnowledgePointIds: [], sourceAnchorIds: ["src-c"], activityIds: ["act-c"], importance: 0.3 },
  ],
  activities: [
    { activityId: "act-a", primaryKnowledgePointId: "a", supportingKnowledgePointIds: [], goalIds: ["goal-main"], estimatedMinutes: 5, difficulty: "S-R", allowedScaffolds: ["hint", "worked_example"] },
    { activityId: "act-b", primaryKnowledgePointId: "b", supportingKnowledgePointIds: [], goalIds: ["goal-main"], estimatedMinutes: 10, difficulty: "S-U", allowedScaffolds: ["hint", "worked_example"] },
    { activityId: "act-c", primaryKnowledgePointId: "c", supportingKnowledgePointIds: [], goalIds: ["goal-main"], estimatedMinutes: 20, difficulty: "M-U", allowedScaffolds: ["none", "hint"] },
  ],
};

function state(id: string, partial: Partial<KnowledgeState> = {}): KnowledgeState {
  return {
    knowledgePointId: id,
    profileRevision: 2,
    evidenceVersion: 0,
    aggregationVersion: "knowledge-state-v1",
    mastery: null,
    confidence: 0,
    status: "unverified",
    validEvidenceCount: 0,
    evidenceFormCount: 0,
    evidenceIds: [],
    consideredEvidenceIds: [],
    asOf: "2026-01-01T00:00:00.000Z",
    skipEligible: false,
    lastUpdatedAt: "2026-01-01T00:00:00.000Z",
    ...partial,
  };
}

describe("PathEngine path-engine-v1", () => {
  it("builds a stable prerequisite-closed topological path", () => {
    const engine = new PathEngine(profile);
    const input = {
      sessionId: "session-1",
      profileRevision: 2,
      evidenceVersion: 0,
      goalId: "goal-main",
      mode: "recommended" as const,
      availableMinutes: 40,
      selectedKnowledgePointIds: [],
      lockedNodeIds: [],
      knowledgeStates: [state("a"), state("b"), state("c")],
    };
    const first = engine.build(input);
    const second = engine.build(input);
    expect(first).toEqual(second);
    expect(first.status).toBe("ok");
    if (first.status !== "ok") return;
    expect(first.path.nodes.map((node) => node.knowledgePointId)).toEqual(["a", "b", "c"]);
    expect(first.path.nodes[0]?.status).toBe("available");
    expect(first.path.nodes[1]?.status).toBe("locked");
  });

  it("compresses optional mastered prerequisites and reports budget infeasibility", () => {
    const engine = new PathEngine(profile);
    const mastered = state("a", { mastery: 1, confidence: 1, status: "mastered", skipEligible: true, evidenceFormCount: 1 });
    const result = engine.build({
      sessionId: "session-1",
      profileRevision: 2,
      evidenceVersion: 1,
      goalId: "goal-main",
      mode: "recommended",
      availableMinutes: 20,
      selectedKnowledgePointIds: [],
      lockedNodeIds: [],
      knowledgeStates: [mastered, state("b"), state("c")],
    });
    expect(result.status).toBe("infeasible");
    if (result.status === "infeasible") expect(result.failure.code).toBe("path_infeasible");
  });

  it("keeps completed and in-progress nodes at their original positions during replan", () => {
    const engine = new PathEngine(profile);
    const initial = engine.build({
      sessionId: "session-1", profileRevision: 2, evidenceVersion: 0, goalId: "goal-main", mode: "recommended",
      availableMinutes: 40, selectedKnowledgePointIds: [], lockedNodeIds: [], knowledgeStates: [state("a"), state("b"), state("c")],
    });
    expect(initial.status).toBe("ok");
    if (initial.status !== "ok") return;
    initial.path.nodes[0]!.status = "completed";
    const replanned = engine.replan({
      sessionId: "session-1", profileRevision: 2, evidenceVersion: 1, goalId: "goal-main", mode: "recommended",
      availableMinutes: 40, selectedKnowledgePointIds: [], lockedNodeIds: ["node-a"], knowledgeStates: [state("a", { status: "mastered", mastery: 1, confidence: 1, skipEligible: true }), state("b"), state("c")],
      previousPath: initial.path, trigger: "knowledge_state_changed",
    });
    expect(replanned.status).toBe("ok");
    if (replanned.status === "ok") expect(replanned.path.nodes[0]?.nodeId).toBe("node-a");
  });

  it("passes the 20-case development determinism matrix (10 repeated runs each)", () => {
    const engine = new PathEngine(profile);
    for (let caseIndex = 1; caseIndex <= 20; caseIndex += 1) {
      const states = [
        state("a", caseIndex % 3 === 0 ? { mastery: 1, confidence: 1, status: "mastered", skipEligible: true, evidenceFormCount: 1 } : {}),
        state("b", caseIndex % 5 === 0 ? { mastery: 0.4, confidence: 0.8, status: "support_needed" } : {}),
        state("c"),
      ];
      const input = {
        sessionId: `development-${caseIndex}`,
        profileRevision: 2,
        evidenceVersion: caseIndex % 4,
        goalId: "goal-main",
        mode: caseIndex % 2 === 0 ? "chapter" as const : "recommended" as const,
        availableMinutes: 40 + (caseIndex % 4) * 5,
        selectedKnowledgePointIds: caseIndex % 2 === 0 ? ["c"] : [],
        lockedNodeIds: caseIndex % 7 === 0 ? ["node-a"] : [],
        knowledgeStates: states,
      };
      const outputs = Array.from({ length: 10 }, () => engine.build(input));
      for (const output of outputs.slice(1)) expect(output).toEqual(outputs[0]);
      if (outputs[0].status === "ok") {
        const positions = new Map(outputs[0].path.nodes.map((node, index) => [node.knowledgePointId, index]));
        for (const node of outputs[0].path.nodes) {
          for (const prerequisite of profile.knowledgePoints.find((point) => point.id === node.knowledgePointId)!.prerequisiteIds) {
            expect(positions.get(prerequisite)!).toBeLessThan(positions.get(node.knowledgePointId)!);
          }
        }
      }
    }
  });
});
