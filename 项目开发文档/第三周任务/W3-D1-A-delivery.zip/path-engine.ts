import { createHash } from "node:crypto";
import type {
  ActivityReferenceDefinition,
  Difficulty,
  KnowledgePointDefinition,
  KnowledgeState,
  LearningGoalDefinition,
} from "./v2-types.js";

export type PathMode = "chapter" | "recommended";
export type PathStatus = "draft" | "confirmed" | "superseded";
export type PathNodeStatus = "locked" | "available" | "in_progress" | "completed" | "skipped";
export type ScaffoldLevel = "none" | "hint" | "worked_example";
export type PathReasonCode =
  | "prerequisite_gap"
  | "low_mastery"
  | "goal_required"
  | "review_due"
  | "user_selected"
  | "error_remediation"
  | "time_compressed"
  | "evidence_insufficient";

export interface PathActivityDefinition extends ActivityReferenceDefinition {
  title?: string;
  prompt?: string;
  difficulty?: Difficulty;
  estimatedMinutes?: number;
  allowedScaffolds?: ScaffoldLevel[];
  kind?: "mcq" | "code_completion" | "coding_practical" | "explain" | "debug";
  starterCode?: string;
  profileRevision?: number;
}

export interface PathEngineProfile {
  subjectId?: string;
  profileRevision: number;
  goals: LearningGoalDefinition[];
  knowledgePoints: KnowledgePointDefinition[];
  activities: PathActivityDefinition[];
}

export interface LearningPathNode {
  nodeId: string;
  knowledgePointId: string;
  activityIds: string[];
  status: PathNodeStatus;
  positionLocked: boolean;
  required: boolean;
  difficulty: Difficulty;
  scaffold: ScaffoldLevel;
  estimatedMinutes: number;
  reasonCodes: PathReasonCode[];
}

export interface LearningPath {
  pathId: string;
  sessionId: string;
  profileRevision: number;
  evidenceVersion: number;
  pathVersion: number;
  engineVersion: "path-engine-v1";
  status: PathStatus;
  mode: PathMode;
  goalId: string;
  availableMinutes: number;
  estimatedMinutes: number;
  nodes: LearningPathNode[];
  positionLockedNodeIds: string[];
  changeReasons: PathReasonCode[];
  createdAt: string;
}

export interface PathFailure {
  code: "path_infeasible";
  missingPrerequisiteIds: string[];
  minimumRequiredMinutes: number;
  suggestions: Array<"increase_time" | "change_goal" | "run_probe">;
}

export type PathBuildResult =
  | { status: "ok"; path: LearningPath }
  | { status: "infeasible"; failure: PathFailure };

export interface PathEngineInput {
  sessionId: string;
  profileRevision: number;
  evidenceVersion: number;
  goalId: string;
  mode: PathMode;
  availableMinutes: number;
  selectedKnowledgePointIds: string[];
  lockedNodeIds: string[];
  knowledgeStates: KnowledgeState[];
  pathVersion?: number;
  createdAt?: string;
}

export interface PathEngineReplanInput extends PathEngineInput {
  previousPath: LearningPath;
  trigger: "knowledge_state_changed" | "skip_eligibility_changed" | "error_remediation" | "user_constraint_changed";
}

export class PathEngineError extends Error {
  constructor(readonly errorCode: "invalid_profile" | "path_infeasible", message: string) {
    super(message);
    this.name = "PathEngineError";
  }
}

const DIFFICULTIES: readonly Difficulty[] = ["S-R", "S-U", "M-U", "M-A", "C-A"];
const SCAFFOLDS: readonly ScaffoldLevel[] = ["none", "hint", "worked_example"];
const EVIDENCE_FORMS_REQUIRING_CODE = new Set(["code_execution", "practical_rubric"]);

function stableJson(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  const record = value as Record<string, unknown>;
  return `{${Object.keys(record).sort().map((key) => `${JSON.stringify(key)}:${stableJson(record[key])}`).join(",")}}`;
}

function hash(value: unknown): string {
  return createHash("sha256").update(stableJson(value)).digest("hex").slice(0, 24);
}

function assertPositiveInteger(value: number, label: string): void {
  if (!Number.isInteger(value) || value < 1) throw new PathEngineError("path_infeasible", `${label} must be a positive integer`);
}

function compareIds(left: string, right: string): number {
  return left.localeCompare(right, "en");
}

function isMastered(state: KnowledgeState | undefined): boolean {
  return state?.status === "mastered" || (state?.skipEligible === true && state.mastery !== null && state.mastery >= 0.8);
}

function isLowMastery(state: KnowledgeState | undefined): boolean {
  return state?.mastery !== null && state?.mastery !== undefined && state.mastery < 0.6;
}

function canSkip(point: KnowledgePointDefinition, state: KnowledgeState | undefined): boolean {
  if (!state?.skipEligible || !isMastered(state)) return false;
  if (point.requiresCodeEvidence === true && state.evidenceFormCount < 1) return false;
  if (point.requiresCodeEvidence === true && state.consideredEvidenceIds.length > 0 && state.evidenceFormCount < 1) return false;
  return true;
}

function activityMinutes(activity: PathActivityDefinition): number {
  return Number.isInteger(activity.estimatedMinutes) && (activity.estimatedMinutes as number) > 0
    ? activity.estimatedMinutes as number
    : 10;
}

function activityDifficulty(activity: PathActivityDefinition): Difficulty {
  return activity.difficulty && DIFFICULTIES.includes(activity.difficulty) ? activity.difficulty : "S-U";
}

function chooseScaffold(activity: PathActivityDefinition, state: KnowledgeState | undefined): ScaffoldLevel {
  const allowed = activity.allowedScaffolds?.filter((item): item is ScaffoldLevel => SCAFFOLDS.includes(item)) ?? ["none"];
  if (allowed.length === 0) return "none";
  if (isMastered(state)) return allowed.includes("none") ? "none" : allowed[0];
  if (isLowMastery(state)) return allowed.includes("worked_example") ? "worked_example" : allowed.includes("hint") ? "hint" : allowed[0];
  return allowed.includes("hint") ? "hint" : allowed[0];
}

function addReasons(target: PathReasonCode[], ...reasons: PathReasonCode[]): void {
  for (const reason of reasons) if (!target.includes(reason)) target.push(reason);
}

export class PathEngine {
  constructor(readonly profile: PathEngineProfile) {
    if (!Number.isInteger(profile.profileRevision) || profile.profileRevision < 1) {
      throw new PathEngineError("invalid_profile", "profileRevision must be a positive integer");
    }
    const pointIds = new Set<string>();
    for (const point of profile.knowledgePoints) {
      if (pointIds.has(point.id)) throw new PathEngineError("invalid_profile", `Duplicate knowledge point: ${point.id}`);
      pointIds.add(point.id);
    }
    const activityIds = new Set<string>();
    for (const activity of profile.activities) {
      if (activityIds.has(activity.activityId)) throw new PathEngineError("invalid_profile", `Duplicate activity: ${activity.activityId}`);
      activityIds.add(activity.activityId);
    }
    const goalIds = new Set<string>();
    for (const goal of profile.goals) {
      if (goalIds.has(goal.goalId)) throw new PathEngineError("invalid_profile", `Duplicate goal: ${goal.goalId}`);
      goalIds.add(goal.goalId);
      for (const pointId of goal.targetKnowledgePointIds) {
        if (!pointIds.has(pointId)) throw new PathEngineError("invalid_profile", `Goal ${goal.goalId} references missing point: ${pointId}`);
      }
      for (const activityId of goal.requiredActivityIds) {
        if (!activityIds.has(activityId)) throw new PathEngineError("invalid_profile", `Goal ${goal.goalId} references missing activity: ${activityId}`);
      }
      if (goal.finalActivityId !== undefined && !activityIds.has(goal.finalActivityId)) {
        throw new PathEngineError("invalid_profile", `Goal ${goal.goalId} references missing final activity: ${goal.finalActivityId}`);
      }
    }
    for (const point of profile.knowledgePoints) {
      for (const prerequisite of point.prerequisiteIds) {
        if (!pointIds.has(prerequisite)) throw new PathEngineError("invalid_profile", `Point ${point.id} references missing prerequisite: ${prerequisite}`);
      }
      for (const activityId of point.activityIds) {
        if (!activityIds.has(activityId)) throw new PathEngineError("invalid_profile", `Point ${point.id} references missing activity: ${activityId}`);
      }
    }
    for (const activity of profile.activities) {
      if (!pointIds.has(activity.primaryKnowledgePointId)) {
        throw new PathEngineError("invalid_profile", `Activity ${activity.activityId} references missing primary point`);
      }
      if (activity.supportingKnowledgePointIds.includes(activity.primaryKnowledgePointId)) {
        throw new PathEngineError("invalid_profile", `Activity ${activity.activityId} repeats its primary point as supporting point`);
      }
      for (const pointId of [...activity.supportingKnowledgePointIds]) {
        if (!pointIds.has(pointId)) throw new PathEngineError("invalid_profile", `Activity ${activity.activityId} references missing supporting point: ${pointId}`);
      }
      for (const goalId of activity.goalIds) {
        if (!goalIds.has(goalId)) throw new PathEngineError("invalid_profile", `Activity ${activity.activityId} references missing goal: ${goalId}`);
      }
    }
    this.assertAcyclicProfilePrerequisites();
  }

  private assertAcyclicProfilePrerequisites(): void {
    const points = new Map(this.profile.knowledgePoints.map((point) => [point.id, point]));
    const visited = new Set<string>();
    const visiting = new Set<string>();
    const visit = (id: string): void => {
      if (visited.has(id)) return;
      if (visiting.has(id)) throw new PathEngineError("invalid_profile", `Prerequisite cycle at ${id}`);
      visiting.add(id);
      for (const prerequisite of points.get(id)?.prerequisiteIds ?? []) visit(prerequisite);
      visiting.delete(id);
      visited.add(id);
    };
    for (const point of this.profile.knowledgePoints) visit(point.id);
  }

  build(input: PathEngineInput): PathBuildResult {
    this.validateInput(input);
    const goal = this.profile.goals.find((item) => item.goalId === input.goalId);
    if (!goal) throw new PathEngineError("invalid_profile", `Unknown goal: ${input.goalId}`);
    const points = new Map(this.profile.knowledgePoints.map((point) => [point.id, point]));
    const activities = new Map(this.profile.activities.map((activity) => [activity.activityId, activity]));
    const targetIds = new Set(goal.targetKnowledgePointIds);
    const closure = this.prerequisiteClosure(targetIds, points);
    const states = new Map(input.knowledgeStates.map((state) => [state.knowledgePointId, state]));
    const missingPrerequisiteIds = [...closure].filter((id) => !targetIds.has(id) && !isMastered(states.get(id)));

    const orderedIds = this.stableTopologicalOrder([...closure], points, targetIds, states, input.mode);
    const nodes: LearningPathNode[] = [];
    for (const pointId of orderedIds) {
      const point = points.get(pointId)!;
      const state = states.get(pointId);
      const required = targetIds.has(pointId) || (!canSkip(point, state) && this.isRequiredForTarget(pointId, targetIds, points));
      const pointActivityIds = point.activityIds.filter((id) => activities.has(id));
      const selectedActivity = this.selectActivity(pointActivityIds, goal, activities);
      if (!selectedActivity) {
        throw new PathEngineError("invalid_profile", `Knowledge point ${pointId} has no usable activity`);
      }
      const reasons: PathReasonCode[] = [];
      if (required) addReasons(reasons, "goal_required");
      if (missingPrerequisiteIds.includes(pointId)) addReasons(reasons, "prerequisite_gap");
      if (isLowMastery(state)) addReasons(reasons, "low_mastery");
      if (!state || state.status === "unverified") addReasons(reasons, "evidence_insufficient");
      if (input.selectedKnowledgePointIds.includes(pointId)) addReasons(reasons, "user_selected");
      const skipped = !required && canSkip(point, state);
      if (skipped) addReasons(reasons, "review_due");
      const activity = selectedActivity;
      const status: PathNodeStatus = skipped
        ? "skipped"
        : this.initialStatus(point, closure, states, points);
      nodes.push({
        nodeId: `node-${pointId}`,
        knowledgePointId: pointId,
        activityIds: [activity.activityId],
        status,
        positionLocked: input.lockedNodeIds.includes(`node-${pointId}`) || input.lockedNodeIds.includes(pointId),
        required,
        difficulty: activityDifficulty(activity),
        scaffold: chooseScaffold(activity, state),
        estimatedMinutes: activityMinutes(activity),
        reasonCodes: reasons,
      });
    }

    const minimumRequiredMinutes = nodes.filter((node) => node.required && node.status !== "skipped")
      .reduce((total, node) => total + node.estimatedMinutes, 0);
    if (minimumRequiredMinutes > input.availableMinutes) {
      return this.failure(missingPrerequisiteIds, minimumRequiredMinutes, "increase_time");
    }
    let estimatedMinutes = nodes.filter((node) => node.status !== "skipped")
      .reduce((total, node) => total + node.estimatedMinutes, 0);
    if (estimatedMinutes > input.availableMinutes) {
      const optional = nodes.filter((node) => !node.required && node.status !== "skipped").reverse();
      for (const node of optional) {
        node.status = "skipped";
        addReasons(node.reasonCodes, "time_compressed");
        estimatedMinutes -= node.estimatedMinutes;
        if (estimatedMinutes <= input.availableMinutes) break;
      }
    }
    const pathVersion = input.pathVersion ?? 1;
    const canonicalInput = {
      sessionId: input.sessionId,
      profileRevision: input.profileRevision,
      evidenceVersion: input.evidenceVersion,
      goalId: input.goalId,
      mode: input.mode,
      availableMinutes: input.availableMinutes,
      selectedKnowledgePointIds: [...input.selectedKnowledgePointIds].sort(compareIds),
      lockedNodeIds: [...input.lockedNodeIds].sort(compareIds),
      knowledgeStates: [...input.knowledgeStates].map((state) => ({
        knowledgePointId: state.knowledgePointId,
        mastery: state.mastery,
        status: state.status,
        skipEligible: state.skipEligible,
        evidenceVersion: state.evidenceVersion,
        evidenceFormCount: state.evidenceFormCount,
      })).sort((a, b) => compareIds(a.knowledgePointId, b.knowledgePointId)),
    };
    const path: LearningPath = {
      pathId: `path-${hash(canonicalInput)}`,
      sessionId: input.sessionId,
      profileRevision: input.profileRevision,
      evidenceVersion: input.evidenceVersion,
      pathVersion,
      engineVersion: "path-engine-v1",
      status: "draft",
      mode: input.mode,
      goalId: input.goalId,
      availableMinutes: input.availableMinutes,
      estimatedMinutes,
      nodes,
      positionLockedNodeIds: nodes.filter((node) => node.positionLocked).map((node) => node.nodeId),
      changeReasons: [],
      createdAt: input.createdAt ?? "1970-01-01T00:00:00.000Z",
    };
    return { status: "ok", path };
  }

  replan(input: PathEngineReplanInput): PathBuildResult {
    const result = this.build({ ...input, pathVersion: input.previousPath.pathVersion + 1 });
    if (result.status === "infeasible") return result;
    const fixed = new Map<string, { index: number; node: LearningPathNode }>();
    input.previousPath.nodes.forEach((node, index) => {
      if (node.status === "completed" || node.status === "in_progress" || node.positionLocked || input.lockedNodeIds.includes(node.nodeId)) {
        fixed.set(node.nodeId, { index, node: structuredClone(node) });
      }
    });
    const mutable = result.path.nodes.filter((node) => !fixed.has(node.nodeId));
    const merged: Array<LearningPathNode | undefined> = [];
    for (const item of fixed.values()) merged[item.index] = item.node;
    let cursor = 0;
    for (let index = 0; index < Math.max(merged.length, result.path.nodes.length); index += 1) {
      if (merged[index] !== undefined) continue;
      const next = mutable[cursor++];
      if (next) merged[index] = next;
    }
    for (; cursor < mutable.length; cursor += 1) merged.push(mutable[cursor]);
    result.path.nodes = merged.filter((node): node is LearningPathNode => node !== undefined);
    result.path.estimatedMinutes = result.path.nodes.filter((node) => node.status !== "skipped")
      .reduce((total, node) => total + node.estimatedMinutes, 0);
    result.path.positionLockedNodeIds = result.path.nodes.filter((node) => node.positionLocked).map((node) => node.nodeId);
    result.path.changeReasons = [input.trigger === "error_remediation" ? "error_remediation" : "evidence_insufficient"];
    return result;
  }

  private validateInput(input: PathEngineInput): void {
    if (!input.sessionId || input.profileRevision !== this.profile.profileRevision) {
      throw new PathEngineError("invalid_profile", "Session or profile revision is invalid");
    }
    assertPositiveInteger(input.availableMinutes, "availableMinutes");
    if (!Number.isInteger(input.evidenceVersion) || input.evidenceVersion < 0) {
      throw new PathEngineError("path_infeasible", "evidenceVersion must be a non-negative integer");
    }
    const points = new Set(this.profile.knowledgePoints.map((point) => point.id));
    for (const id of [...input.selectedKnowledgePointIds, ...input.lockedNodeIds.map((item) => item.replace(/^node-/u, ""))]) {
      if (!points.has(id)) throw new PathEngineError("invalid_profile", `Unknown knowledge point constraint: ${id}`);
    }
  }

  private prerequisiteClosure(targetIds: Set<string>, points: Map<string, KnowledgePointDefinition>): Set<string> {
    const closure = new Set<string>();
    const visiting = new Set<string>();
    const visit = (id: string): void => {
      if (closure.has(id)) return;
      if (visiting.has(id)) throw new PathEngineError("invalid_profile", `Prerequisite cycle at ${id}`);
      const point = points.get(id);
      if (!point) throw new PathEngineError("invalid_profile", `Unknown knowledge point: ${id}`);
      visiting.add(id);
      for (const prerequisite of point.prerequisiteIds) visit(prerequisite);
      visiting.delete(id);
      closure.add(id);
    };
    for (const id of targetIds) visit(id);
    return closure;
  }

  private isRequiredForTarget(id: string, targets: Set<string>, points: Map<string, KnowledgePointDefinition>): boolean {
    for (const target of targets) {
      const seen = new Set<string>();
      const walk = (current: string): boolean => {
        if (current === id) return true;
        if (seen.has(current)) return false;
        seen.add(current);
        return (points.get(current)?.prerequisiteIds ?? []).some(walk);
      };
      if (walk(target)) return true;
    }
    return false;
  }

  private stableTopologicalOrder(
    ids: string[],
    points: Map<string, KnowledgePointDefinition>,
    targets: Set<string>,
    states: Map<string, KnowledgeState>,
    mode: PathMode,
  ): string[] {
    const declaration = new Map(this.profile.knowledgePoints.map((point, index) => [point.id, index]));
    const remaining = new Set(ids);
    const result: string[] = [];
    while (remaining.size > 0) {
      const ready = [...remaining].filter((id) => (points.get(id)?.prerequisiteIds ?? []).every((prerequisite) => !remaining.has(prerequisite)));
      if (ready.length === 0) throw new PathEngineError("invalid_profile", "Prerequisite graph contains a cycle");
      ready.sort((left, right) => {
        const lp = points.get(left)!;
        const rp = points.get(right)!;
        const targetCompare = Number(targets.has(right)) - Number(targets.has(left));
        if (targetCompare !== 0) return targetCompare;
        const gapCompare = Number(!isMastered(states.get(left))) - Number(!isMastered(states.get(right)));
        if (gapCompare !== 0) return gapCompare;
        const importanceCompare = rp.importance - lp.importance;
        if (importanceCompare !== 0) return importanceCompare;
        if (mode === "chapter") {
          const chapterCompare = lp.chapterId.localeCompare(rp.chapterId, "en");
          if (chapterCompare !== 0) return chapterCompare;
        }
        return (declaration.get(left) ?? Number.MAX_SAFE_INTEGER) - (declaration.get(right) ?? Number.MAX_SAFE_INTEGER)
          || compareIds(left, right);
      });
      for (const id of ready) {
        remaining.delete(id);
        result.push(id);
      }
    }
    return result;
  }

  private selectActivity(ids: string[], goal: LearningGoalDefinition, activities: Map<string, PathActivityDefinition>): PathActivityDefinition | undefined {
    const goalActivities = new Set(goal.requiredActivityIds);
    return ids.map((id) => activities.get(id)).filter((activity): activity is PathActivityDefinition => activity !== undefined)
      .sort((left, right) => {
        const requiredCompare = Number(goalActivities.has(left.activityId)) - Number(goalActivities.has(right.activityId));
        return requiredCompare || activityMinutes(left) - activityMinutes(right) || compareIds(left.activityId, right.activityId);
      })[0];
  }

  private initialStatus(
    point: KnowledgePointDefinition,
    closure: Set<string>,
    states: Map<string, KnowledgeState>,
    points: Map<string, KnowledgePointDefinition>,
  ): PathNodeStatus {
    if (isMastered(states.get(point.id))) return "available";
    const blocked = point.prerequisiteIds.some((id) => closure.has(id) && !isMastered(states.get(id)) && !canSkip(points.get(id)!, states.get(id)));
    return blocked ? "locked" : "available";
  }

  private failure(missingPrerequisiteIds: string[], minimumRequiredMinutes: number, preferred: "increase_time" | "change_goal"): PathBuildResult {
    return {
      status: "infeasible",
      failure: {
        code: "path_infeasible",
        missingPrerequisiteIds: [...new Set(missingPrerequisiteIds)].sort(compareIds),
        minimumRequiredMinutes,
        suggestions: [preferred, preferred === "increase_time" ? "change_goal" : "increase_time", "run_probe"],
      },
    };
  }
}
