# handoff-w3-a-d1：岗位 A 第三周 D1 交接清单

## 基线与范围

```text
岗位：A 领域与架构
合同：W3-C2 / W3-R2
W3_START_COMMIT：f190326a4a906b46e4001484ffa30a7839b82ed2
执行时HEAD：8d8a87bbd455e10ddcbbb02ab2384f39cb889fb4
分支：main（工作区无既有修改）
本日范围：path-engine-v1、路径 Facade/恢复接线、作者测试
明确未做：Profile 激活、Attempt/Evidence 正式提交、Python 执行器、React、SDK和其他岗位资产
```

## D1 交付内容

| 合同项 | 实现位置 | 状态 |
|---|---|---|
| 先修闭包与环保护 | `pi-study-helper/src/domain/path-engine.ts` | PASS |
| `skipEligible` 与 `requiresCodeEvidence` | `src/domain/path-engine.ts` | PASS |
| 验证/回补原因码、稳定拓扑排序 | `src/domain/path-engine.ts` | PASS |
| 难度与脚手架选择 | `src/domain/path-engine.ts` | PASS |
| 预算压缩与 `path_infeasible` | `src/domain/path-engine.ts` | PASS |
| build/confirm/getNextStep/replan/recover 接线 | `src/application/path-learning-facade.ts` | PASS |
| v2 Profile 只读加载适配 | `src/repositories/profile-family-repository.ts` | PASS |
| 20 开发案例、每例 10 次稳定性和路径合法性 | `tests/path-engine.test.ts` | PASS |

算法输出只由规范化 Profile、目标、证据版本、知识状态、模式、预算和用户合法约束决定；PathEngine 不读取模型、不使用随机数或当前时间参与排序。路径 ID 使用规范化输入哈希生成；服务层时间只用于快照展示字段。

## 验证记录

```text
node node_modules/vitest/vitest.mjs run tests/path-engine.test.ts --maxWorkers=1
PASS：1个测试文件，4项测试

node node_modules/typescript/bin/tsc --noEmit
未能完成全量类型检查：当前node_modules缺少@types/node及Pi依赖的可执行产物；新增A文件未出现除node:crypto类型缺失之外的类型错误。

node node_modules/vitest/vitest.mjs run --maxWorkers=1
路径相关测试通过；全量回归受现有环境阻塞：6个旧测试套件无法导入pi-coding-agent/dist/index.js，V2-6综合脚本超过20秒超时。

git diff --check
PASS
```

## 文件边界

```text
pi-study-helper/src/domain/path-engine.ts
pi-study-helper/src/application/path-learning-facade.ts
pi-study-helper/src/repositories/profile-family-repository.ts
pi-study-helper/tests/path-engine.test.ts
```

以上文件均属 A 岗位范围；未修改 B/C/D/E 的资料、评测、模型、前端、gold、依赖或SDK文件。Profile v2 仍保持 draft，D1 未执行激活事务。

## D2 交接注意事项

1. `PathLearningRuntimeFacade` 已调用现有 `LearningSessionRepository` 的 CAS `commit/recover`；D3 可在同一边界接入正式 ActivityResult、Attempt/Evidence 和 KnowledgeState 更新。
2. D1 候选路径暂存在 Facade 的候选缓存，确认后的路径由会话仓储原子持久化；若需要跨进程恢复未确认候选，应在 D3 另行增加候选快照仓储，不得写入 B/C 资产目录。
3. 当前仓库依赖安装不完整，正式上传前需在完整依赖环境重新执行 `npm.cmd run typecheck`、`npm.cmd test`、`npm.cmd run verify`。

