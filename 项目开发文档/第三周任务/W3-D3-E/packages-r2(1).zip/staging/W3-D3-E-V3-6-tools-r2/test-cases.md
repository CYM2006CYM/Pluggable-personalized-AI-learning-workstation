﻿# V3-6 测试用例合同

## 目标

环境、依赖、测试资产和协议故障均不得制造学习者负Evidence。

## 冻结输入

- `b-task-bundles-file`
- `c-formal-commit`
- `c-binding-fix-commit`
- `c-environment-lock`
- `c-environment-hash`
- `a-d3-formal-commit`

## 原始命令

- `npm.cmd test -- --maxWorkers=1 --run tests/activity-rubric.test.ts tests/evaluation-protocol.test.ts tests/python-process-evaluation.test.ts tests/python-process-evaluation-r2.test.ts tests/knowledge-state.test.ts`（期望退出码 0）

## 期望项数与指标

- `expectedTestItems` = `8`
- `taskCount` = `2`
- `failureCategories` = `dependency,environment,test_asset,protocol`
- `negativeEvidenceCount` = `0`

## 机械PASS条件

- 四类评测器故障在两个任务上均得到覆盖
- ActivityResult为not_graded或等价公共失败
- Evidence新增数为0
- KnowledgeState和路径不因评测器故障降级

任一命令退出码不符、指标缺失、输入哈希不匹配或机械条件不满足时只能记录 BLOCKED，失败所有者为：C（正式事务映射问题点名A）。D3不得执行这些命令或填写最终结论。
