﻿# W3-D3 E 完整输入清单说明

~~~text
contractVersion = W3-C4/W3-R2
deliveryStage = W3-D3
fullV3Status = NOT_RUN_D3
manifestCompleteness = STRUCTURE_COMPLETE_INPUTS_PENDING
~~~

清单已经为每项输入登记路径、Git提交、SHA-256/哈希模式、所有者、用途和状态。纯Git提交锚点没有文件SHA-256，明确使用 hashMode=git-object-id，不把SHA-1提交号冒充文件SHA-256。

当前待输入只有：

1. -d3-formal-commit；
2. d-d3-formal-commit；
3. owner-readonly-gold-candidate。

在三项全部由负责人确认并形成新的D4解析清单前，通用工具拒绝 Execute 模式。D3不得修改本清单中的已冻结值以适配后续实现；若任何已冻结输入变化，必须重新提交负责人裁决并形成新基线版本。
