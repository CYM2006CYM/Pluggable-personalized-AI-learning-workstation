﻿# W3-D3 岗位E验证工具基线

本目录只准备V3-1至V3-8，不执行D4验证。

## 使用约束

1. D3只运行 Invoke-W3D3Gate.ps1 -Mode Plan。
2. Execute模式必须同时满足：显式令牌 W3-D4、解析清单所有必需输入均为FROZEN、提供实际仓库根目录。
3. Execute只生成命令证据；最终门禁结论还必须按对应 	est-cases.md 和 evidence-template.json 完成机械指标核对。
4. D4不得编辑本基线；如输入或合同变化，停止执行并交负责人重新裁决。
