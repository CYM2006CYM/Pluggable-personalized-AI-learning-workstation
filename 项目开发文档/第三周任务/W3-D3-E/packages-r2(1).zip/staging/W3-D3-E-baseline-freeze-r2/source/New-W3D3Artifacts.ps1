﻿[CmdletBinding()]
param(
    [string]$SourceRoot = $PSScriptRoot
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Utf8 {
    param([string]$Path, [string]$Content)
    $parent = Split-Path -Parent $Path
    if ($parent) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    Set-Content -LiteralPath $Path -Value $Content -Encoding utf8
}

function Write-Json {
    param([string]$Path, [object]$Value)
    Write-Utf8 -Path $Path -Content ($Value | ConvertTo-Json -Depth 100)
}

function New-Input {
    param(
        [string]$Id,
        [string]$Status,
        [string]$PathKind,
        [string]$Path,
        [AllowNull()][string]$GitCommit,
        [AllowNull()][string]$Sha256,
        [string]$Owner,
        [string]$Purpose,
        [string]$HashMode = "raw-byte-sha256",
        [AllowNull()][object]$AdditionalHashes = $null
    )
    return [ordered]@{
        id = $Id
        status = $Status
        pathKind = $PathKind
        path = $Path
        gitCommit = $GitCommit
        sha256 = $Sha256
        hashMode = $HashMode
        additionalHashes = $AdditionalHashes
        owner = $Owner
        purpose = $Purpose
    }
}

$manifest = [ordered]@{
    schemaVersion = "w3-d3-input-manifest-v1"
    contractVersion = "W3-C4/W3-R2"
    deliveryStage = "W3-D3"
    fullV3Status = "NOT_RUN_D3"
    gitStatus = "NOT_COMMITTED / NOT_PUSHED"
    generatedAt = "2026-08-09T13:04:23+08:00"
    repositorySnapshot = [ordered]@{
        head = "a0730d667a9429e395e92f687dbf6b2e0e0db179"
        originMain = "a0730d667a9429e395e92f687dbf6b2e0e0db179"
        w3StartCommit = "f190326a4a906b46e4001484ffa30a7839b82ed2"
        completeness = "STRUCTURE_COMPLETE_INPUTS_PENDING"
    }
    pendingInputIds = @("a-d3-formal-commit", "d-d3-formal-commit", "owner-readonly-gold-candidate")
    inputs = @(
        (New-Input "w3-start-commit" "FROZEN" "git-object" "git:commit/f190326a4a906b46e4001484ffa30a7839b82ed2" "f190326a4a906b46e4001484ffa30a7839b82ed2" $null "负责人" "不可变第三周起点" "git-object-id"),
        (New-Input "b-formal-commit" "FROZEN" "git-object" "git:commit/277805b4dc612548f4dcdf4f91189abb4ef5c8e3" "277805b4dc612548f4dcdf4f91189abb4ef5c8e3" $null "B" "正式TaskBundle提交锚点" "git-object-id"),
        (New-Input "b-task-bundles-file" "FROZEN" "repo-relative" "pi-study-helper/fixtures/profiles/pandas-cleaning-v2-draft/assessments/private/task-bundles.json" "277805b4dc612548f4dcdf4f91189abb4ef5c8e3" "3ca1df592f78366a73bf07c1ea82a9dc8a5eb24ae92da20fbab1d8f7a9894426" "B" "两个正式任务的冻结资产容器"),
        (New-Input "b-asset-inspect" "FROZEN" "logical" "task-bundles.json#act-inspect-dataframe" "277805b4dc612548f4dcdf4f91189abb4ef5c8e3" "bcc38620bdacede9d690ee62efbedaf8f0aee8dabaa55e9b7ca5b2452d29905c" "B" "act-inspect-dataframe assetBundleHash" "canonical-task-bundle-sha256"),
        (New-Input "b-asset-practical" "FROZEN" "logical" "task-bundles.json#act-practical" "277805b4dc612548f4dcdf4f91189abb4ef5c8e3" "3273308c4c9829b263a550c2d69eb40e5098b4e0802399c2334053afb3d6815c" "B" "act-practical assetBundleHash" "canonical-task-bundle-sha256"),
        (New-Input "c-formal-commit" "FROZEN" "git-object" "git:commit/8f8e2c71dfd6128307fb7bcdcaf04c7c99a5c9cd" "8f8e2c71dfd6128307fb7bcdcaf04c7c99a5c9cd" $null "C" "正式评测适配器提交锚点" "git-object-id"),
        (New-Input "c-binding-fix-commit" "FROZEN" "git-object" "git:commit/8648620213463701319d089a5ab088e62e243af0" "8648620213463701319d089a5ab088e62e243af0" $null "C" "正式环境和Bundle绑定修复提交" "git-object-id"),
        (New-Input "c-environment-lock" "FROZEN" "repo-relative" "pi-study-helper/fixtures/profiles/pandas-cleaning-v2-draft/environments/environment-lock.json" "8648620213463701319d089a5ab088e62e243af0" "59917d1528d031f46a1e76359d99628e810f2dfa78a92d66e03386c860fbaf43" "C/负责人" "正式Node环境锁文件"),
        (New-Input "c-environment-hash" "FROZEN" "logical" "environment-lock.json#environmentHash" "8648620213463701319d089a5ab088e62e243af0" "9e73aebc1b5191b24ee91b27994cf48d596c757695738074de6d846ee2cf5b76" "C/负责人" "排除environmentHash自身复算的正式环境哈希" "canonical-json-sha256"),
        (New-Input "c-formal-binding-evidence" "FROZEN" "repo-relative" "pi-study-helper/scripts/w3-code-evaluation/environment-formal-binding-evidence.json" "8648620213463701319d089a5ab088e62e243af0" "69c1394920ddd21639607ca727e5ebe1bb292ef51724534a8cebbb73ab048514" "C" "C正式环境和TaskBundle绑定证据"),
        (New-Input "owner-profile-approval" "FROZEN" "repo-relative" "新版设计文档-重写版/第三周任务/W3-D3-负责人Profile-v2激活批准.md" "a0730d667a9429e395e92f687dbf6b2e0e0db179" "498ef406b554d75a09f2d8a2c7a97ac439091eb0dccf8688fe24f9a63fb986b4" "负责人" "D36 Profile v2激活批准"),
        (New-Input "development-20" "FROZEN" "repo-relative" "evaluation/personas/development-20.jsonl" "f190326a4a906b46e4001484ffa30a7839b82ed2" "1b238dfae09e5c6ea942329a3a0fd952ad9c190edd9666335ad735301cb27876" "负责人" "V3-1/V3-2开发案例输入" "raw-byte-sha256" ([ordered]@{ normalizedTextSha256 = "54c0f5f30bc0b9a104ac2e9e38e6ca3d6f33c5cbe3ade17c62be1c69be1b8473" })),
        (New-Input "a-d1-v3-1-evidence" "FROZEN" "repo-relative" "pi-study-helper/scripts/w3-path-validation/W3-D1-A-V3-1-evidence.json" "6773d99fc1f4c87dc816e44a48d9fac624a9b2b9" "f29d9fb982d2647b2b440496d02585a06fa5ae8e5b27f384f00493d2a27a820b" "A" "V3-1作者证据，仅作独立复算对照"),
        (New-Input "a-d1-v3-2-evidence" "FROZEN" "repo-relative" "pi-study-helper/scripts/w3-path-validation/W3-D1-A-V3-2-evidence.json" "6773d99fc1f4c87dc816e44a48d9fac624a9b2b9" "02f9f7754ad5e9197555803d90c668d63f5b8a05cc59b0db902a30f76543754a" "A" "V3-2作者证据，仅作独立复算对照"),
        (New-Input "a-d3-formal-commit" "PENDING" "git-object" "PENDING_A_D3_FORMAL_COMMIT" $null $null "A" "Profile激活、正式事务、KnowledgeState和路径后缀正式提交" "pending"),
        (New-Input "d-d3-formal-commit" "PENDING" "git-object" "PENDING_D_D3_FORMAL_COMMIT" $null $null "D" "D1封存Agent材料的D3正式提交" "pending"),
        (New-Input "e-d1-sealed-annotations" "FROZEN" "external-absolute" "D:/.A_C_code/PPALW/W3-D1/e-final-021-060.jsonl" $null "af450ede185be215e12e5d13688ebc7b34cb3af9816f50803e5612c2219da266" "E" "final-021至060第二盲标封存"),
        (New-Input "e-d1-seal-record" "FROZEN" "external-absolute" "D:/.A_C_code/PPALW/W3-D1/seal-record.json" $null "e96569d1a47395649300e016e5f582d66dfb9dac1b7294840340b5222f21a636" "E" "E-D1覆盖、行数和封存哈希记录"),
        (New-Input "final-60-frozen-input" "FROZEN" "repo-relative" "evaluation/personas/final-60.jsonl" "f190326a4a906b46e4001484ffa30a7839b82ed2" "4fcc7c3e2c605f912890ddec5af7d4fa875c861d1636dcaf425a63ddb17f4b9d" "负责人" "60例冻结输入；D3不运行正式系统输出" "raw-byte-sha256" ([ordered]@{ normalizedTextSha256 = "b77ba4902003ba20bc5b233c4797838eb26325d1b38fd02bc68ba02206cb1d1c" })),
        (New-Input "e-d2-r2-package" "FROZEN" "external-absolute" "D:/.A_C_code/PPALW/W3-D2/W3-D2-E-owner-review-package-r2.zip" $null "678bb456f824d90d7eed3c7a71a71666bdd44a9fbf302e690c95603d1a72525e" "E" "D46整改后的六页候选和81项作者测试"),
        (New-Input "e-d2-r2-hash-report" "FROZEN" "external-absolute" "D:/.A_C_code/PPALW/W3-D2/W3-D2-E-hashes-r2.sha256" $null "2b8f5ab5cea37b09f3e3b9d61663c09ca3307b9ec079f6333b04ac8653803aef" "E" "E-D2包外及包内逐文件哈希记录"),
        (New-Input "owner-readonly-gold-candidate" "PENDING" "owner-controlled-directory" "PENDING_OWNER_READONLY_GOLD_DIRECTORY" $null $null "负责人" "D4只读gold候选目录；预期包含gold-candidate.jsonl、adjudication-log.jsonl和freeze-record.json" "pending")
    )
}

$inputRoot = Join-Path $SourceRoot "input-manifest"
Write-Json (Join-Path $inputRoot "W3-D3-input-manifest.json") $manifest

$inputMarkdown = @"
# W3-D3 E 完整输入清单说明

~~~text
contractVersion = W3-C4/W3-R2
deliveryStage = W3-D3
fullV3Status = NOT_RUN_D3
manifestCompleteness = STRUCTURE_COMPLETE_INPUTS_PENDING
~~~

清单已经为每项输入登记路径、Git提交、SHA-256/哈希模式、所有者、用途和状态。纯Git提交锚点没有文件SHA-256，明确使用 `hashMode=git-object-id`，不把SHA-1提交号冒充文件SHA-256。

当前待输入只有：

1. `a-d3-formal-commit`；
2. `d-d3-formal-commit`；
3. `owner-readonly-gold-candidate`。

在三项全部由负责人确认并形成新的D4解析清单前，通用工具拒绝 Execute 模式。D3不得修改本清单中的已冻结值以适配后续实现；若任何已冻结输入变化，必须重新提交负责人裁决并形成新基线版本。
"@
Write-Utf8 (Join-Path $inputRoot "W3-D3-input-manifest.md") $inputMarkdown
Write-Utf8 (Join-Path $inputRoot "DELIVERY.md") "# 输入清单交付说明`n`n本目录是结构完整但包含3项待输入的D3清单。交付负责人审核字段、已知哈希和PENDING边界，不表示D4输入已齐备。`n"

$common = [ordered]@{
    schemaVersion = "w3-d3-gate-config-v1"
    contractVersion = "W3-C4/W3-R2"
    deliveryStage = "W3-D3"
    executionPolicy = "PLAN_ONLY_D3_EXPLICIT_W3_D4_TOKEN_REQUIRED"
    evidenceSha256Method = "SHA-256 over raw file bytes; lowercase hexadecimal"
}

$gates = @(
    [ordered]@{
        gate="V3-1"; title="180分钟投影路径确定性"; ownerOnFailure="A";
        purpose="20例按w3-v3-feasible-180-v1仅投影availableMinutes=180，每例10次。";
        required=@("w3-start-commit","development-20","owner-profile-approval","a-d1-v3-1-evidence","a-d3-formal-commit","b-task-bundles-file","c-environment-lock");
        commands=@([ordered]@{id="v3-1-path-20x10";executable="npm.cmd";arguments=@("test","--","--maxWorkers=1","--run","tests/path-engine-development-20.test.ts");workingDirectory="pi-study-helper";expectedExitCode=0});
        metrics=[ordered]@{expectedTestItems=200;caseCount=20;runsPerCase=10;candidateCount=20;identicalSnapshots=20;actualPathLegalRate=1;projectionRuleVersion="w3-v3-feasible-180-v1"};
        pass=@("20/20均产生candidate","每例10次输出哈希唯一数为1","实际路径合法率100%","输入投影只改变availableMinutes");
        outputs=@("v3-1-command-evidence.json","v3-1-path-evidence.json","v3-1-file-hashes.sha256")
    },
    [ordered]@{
        gate="V3-2"; title="原始预算与边界fixture"; ownerOnFailure="A";
        purpose="验证20例原始预算不可行结构、全部掌握和缺失先修fixture。";
        required=@("w3-start-commit","development-20","owner-profile-approval","a-d1-v3-2-evidence","a-d3-formal-commit","b-task-bundles-file","c-environment-lock");
        commands=@([ordered]@{id="v3-2-original-budget";executable="npm.cmd";arguments=@("test","--","--maxWorkers=1","--run","tests/path-engine-development-20.test.ts");workingDirectory="pi-study-helper";expectedExitCode=0});
        metrics=[ordered]@{expectedTestItems=220;originalCases=20;runsPerCase=10;boundaryFixtures=2;boundaryRunsPerFixture=10;illegalPathCount=0;projectionRuleVersion="w3-v3-original-budget-v1"};
        pass=@("20例原始预算结果结构均合法","全部掌握fixture确定且先修可跳过","缺失先修fixture不跨越先修闭包","非法路径为0");
        outputs=@("v3-2-command-evidence.json","v3-2-path-evidence.json","v3-2-file-hashes.sha256")
    },
    [ordered]@{
        gate="V3-3"; title="双任务错误矩阵与重复一致性"; ownerOnFailure="C（业务资产问题点名B）";
        purpose="两个正式任务覆盖正确、部分正确和六类学习者错误，每类连续3次。";
        required=@("b-formal-commit","b-task-bundles-file","b-asset-inspect","b-asset-practical","c-formal-commit","c-binding-fix-commit","c-environment-lock","c-environment-hash","a-d3-formal-commit");
        commands=@([ordered]@{id="v3-3-error-matrix";executable="npm.cmd";arguments=@("test","--","--maxWorkers=1","--run","tests/activity-rubric.test.ts","tests/python-process-evaluation.test.ts","tests/python-process-evaluation-r2.test.ts");workingDirectory="pi-study-helper";expectedExitCode=0});
        metrics=[ordered]@{expectedTestItems=48;taskCount=2;classificationCountPerTask=8;repeatCount=3;requiredClasses=@("correct","partially_correct","syntax_error","runtime_error","test_failed","timeout","output_limit","disallowed_import")};
        pass=@("两个任务均覆盖8类结果","每类连续3次逐字段一致","错误归因符合learner/evaluator边界","公共结果不暴露隐藏材料");
        outputs=@("v3-3-command-evidence.json","v3-3-matrix-evidence.json","v3-3-file-hashes.sha256")
    },
    [ordered]@{
        gate="V3-4"; title="C边界与正式事实所有权"; ownerOnFailure="C（若A事务公开缺口则点名A）";
        purpose="扫描C源码和公共输出，确认C止于ActivityResult且不写正式事实。";
        required=@("c-formal-commit","c-binding-fix-commit","c-environment-lock","a-d3-formal-commit");
        commands=@(
            [ordered]@{id="v3-4-port-tests";executable="npm.cmd";arguments=@("test","--","--maxWorkers=1","--run","tests/code-evaluation-port.test.ts","tests/evaluation-protocol.test.ts");workingDirectory="pi-study-helper";expectedExitCode=0},
            [ordered]@{id="v3-4-source-scan";executable="powershell.exe";arguments=@("-NoProfile","-ExecutionPolicy","Bypass","-File","{ToolRoot}/Test-CBoundary.ps1","-RepositoryRoot","{RepositoryRoot}","-OutputFile","{OutputRoot}/v3-4-source-scan.json");workingDirectory=".";expectedExitCode=0}
        );
        metrics=[ordered]@{expectedTestItems=4;forbiddenWriteMatches=0;publicReturnType="ActivityResult";formalFactsOwner="A"};
        pass=@("C源码不导入正式事实仓储能力","C无Attempt/Evidence/KnowledgeState/Path写入","公共返回只为ActivityResult","正式事实由A事务仓储公开");
        outputs=@("v3-4-command-evidence.json","v3-4-source-scan.json","v3-4-file-hashes.sha256")
    },
    [ordered]@{
        gate="V3-5"; title="幂等与事务无半写"; ownerOnFailure="A";
        purpose="验证requestId+attemptId幂等及每个正式提交阶段故障无半写。";
        required=@("a-d3-formal-commit","owner-profile-approval","b-task-bundles-file","c-formal-commit","c-binding-fix-commit");
        commands=@(
            [ordered]@{id="v3-5-typecheck";executable="npm.cmd";arguments=@("run","typecheck");workingDirectory="pi-study-helper";expectedExitCode=0},
            [ordered]@{id="v3-5-full-tests";executable="npm.cmd";arguments=@("test","--","--maxWorkers=1");workingDirectory="pi-study-helper";expectedExitCode=0}
        );
        metrics=[ordered]@{expectedTestItems=6;idempotencyCases=1;faultStages=@("attempt","evidence","knowledge_state","path_suffix","checkpoint_publish");halfWritesAllowed=0};
        pass=@("重复requestId+attemptId不重复计分","五个阶段逐一注入故障","每次失败后正式事实快照不出现半写","恢复后结果确定且不重复Evidence");
        outputs=@("v3-5-command-evidence.json","v3-5-transaction-evidence.json","v3-5-file-hashes.sha256")
    },
    [ordered]@{
        gate="V3-6"; title="评测器故障无负Evidence"; ownerOnFailure="C（正式事务映射问题点名A）";
        purpose="环境、依赖、测试资产和协议故障均不得制造学习者负Evidence。";
        required=@("b-task-bundles-file","c-formal-commit","c-binding-fix-commit","c-environment-lock","c-environment-hash","a-d3-formal-commit");
        commands=@([ordered]@{id="v3-6-evaluator-failures";executable="npm.cmd";arguments=@("test","--","--maxWorkers=1","--run","tests/activity-rubric.test.ts","tests/evaluation-protocol.test.ts","tests/python-process-evaluation.test.ts","tests/python-process-evaluation-r2.test.ts","tests/knowledge-state.test.ts");workingDirectory="pi-study-helper";expectedExitCode=0});
        metrics=[ordered]@{expectedTestItems=8;taskCount=2;failureCategories=@("dependency","environment","test_asset","protocol");negativeEvidenceCount=0};
        pass=@("四类评测器故障在两个任务上均得到覆盖","ActivityResult为not_graded或等价公共失败","Evidence新增数为0","KnowledgeState和路径不因评测器故障降级");
        outputs=@("v3-6-command-evidence.json","v3-6-failure-evidence.json","v3-6-file-hashes.sha256")
    },
    [ordered]@{
        gate="V3-7"; title="60例gold冻结顺序与双盲资格"; ownerOnFailure="负责人（原始盲标资格问题点名对应标注所有者）";
        purpose="只消费负责人只读候选及审计记录，验证60/60、D44终裁和先冻结后运行。";
        required=@("final-60-frozen-input","e-d1-sealed-annotations","e-d1-seal-record","owner-readonly-gold-candidate");
        commands=@([ordered]@{id="v3-7-gold-freeze";executable="powershell.exe";arguments=@("-NoProfile","-ExecutionPolicy","Bypass","-File","{ToolRoot}/Test-GoldFreeze.ps1","-GoldCandidate","{InputPath:owner-readonly-gold-candidate}/gold-candidate.jsonl","-AdjudicationLog","{InputPath:owner-readonly-gold-candidate}/adjudication-log.jsonl","-OwnerFreezeRecord","{InputPath:owner-readonly-gold-candidate}/freeze-record.json","-OutputFile","{OutputRoot}/v3-7-gold-freeze.json");workingDirectory=".";expectedExitCode=0});
        metrics=[ordered]@{expectedTestItems=104;goldCaseCount=60;adjudicationCount=40;qualificationChecks=4;negotiationStatus="SKIPPED_BY_D44";formalRunsBeforeFreeze=0};
        pass=@("gold覆盖final-001至060且无重复","40例终裁记录全部SKIPPED_BY_D44","双盲资格记录PASS","任何正式60例系统运行发生在冻结之后");
        outputs=@("v3-7-command-evidence.json","v3-7-gold-freeze.json","v3-7-file-hashes.sha256")
    },
    [ordered]@{
        gate="V3-8"; title="六页、DTO分层与恢复交互"; ownerOnFailure="E";
        purpose="复验六页、五状态、活动四阶段、D46恢复和DTO/fixture安全边界。";
        required=@("e-d2-r2-package","e-d2-r2-hash-report","a-d3-formal-commit","d-d3-formal-commit","owner-readonly-gold-candidate");
        commands=@(
            [ordered]@{id="v3-8-web-tests";executable="npm.cmd";arguments=@("run","test:web");workingDirectory="pi-study-helper";expectedExitCode=0},
            [ordered]@{id="v3-8-typecheck";executable="npm.cmd";arguments=@("run","typecheck");workingDirectory="pi-study-helper";expectedExitCode=0},
            [ordered]@{id="v3-8-web-boundary";executable="powershell.exe";arguments=@("-NoProfile","-ExecutionPolicy","Bypass","-File","{ToolRoot}/Test-WebBoundary.ps1","-WebRoot","{RepositoryRoot}/pi-study-helper/src/web","-SourceRoot","{RepositoryRoot}/pi-study-helper/src","-OutputFile","{OutputRoot}/v3-8-web-boundary.json");workingDirectory=".";expectedExitCode=0}
        );
        metrics=[ordered]@{expectedTestItems=81;routeCount=6;pageStateCases=30;activityModes=4;obsoleteLearnRouteMatches=0;draftTransitionChecks=3;leakMatches=0};
        pass=@("六页面均可达且旧学习路由无效","六页各五状态及主要操作可用","草稿跨冲突/错误/恢复逐字保留","Facade DTO与页面fixture分离且泄漏扫描为0","前端不做评分、mastery、路径、Rubric或PASS判定");
        outputs=@("v3-8-command-evidence.json","v3-8-web-boundary.json","v3-8-file-hashes.sha256")
    }
)

foreach ($gate in $gates) {
    $gateRoot = Join-Path $SourceRoot ("gates/{0}" -f $gate.gate)
    $config = [ordered]@{}
    foreach ($key in $common.Keys) { $config[$key] = $common[$key] }
    $config.gate = $gate.gate
    $config.title = $gate.title
    $config.purpose = $gate.purpose
    $config.ownerOnFailure = $gate.ownerOnFailure
    $config.requiredInputIds = $gate.required
    $config.commands = $gate.commands
    $config.expectedMetrics = $gate.metrics
    $config.mechanicalPassConditions = $gate.pass
    $config.outputContract = $gate.outputs
    Write-Json (Join-Path $gateRoot "gate-config.json") $config

    $template = [ordered]@{
        schemaVersion = "w3-d3-gate-evidence-template-v1"
        contractVersion = "W3-C4/W3-R2"
        deliveryStage = "W3-D3"
        gate = $gate.gate
        gateConfigSha256 = $null
        resolvedInputManifestSha256 = $null
        testedCommit = $null
        environment = $null
        originalCommands = $gate.commands
        expectedMetrics = $gate.metrics
        actualMetrics = $null
        rawOutputFiles = @()
        exitCodes = @()
        evidenceFiles = $gate.outputs
        evidenceSha256 = @()
        failureOwner = $gate.ownerOnFailure
        executionStatus = "NOT_RUN_D3"
        gateConclusion = "NOT_PRODUCED_D3"
        notes = "D4执行时复制本模板到证据目录填写；不得修改D3冻结原件。"
    }
    Write-Json (Join-Path $gateRoot "evidence-template.json") $template

    $commandText = ($gate.commands | ForEach-Object { "- ``$($_.executable) $($_.arguments -join ' ')``（期望退出码 $($_.expectedExitCode)）" }) -join "`n"
    $passText = ($gate.pass | ForEach-Object { "- $_" }) -join "`n"
    $inputText = ($gate.required | ForEach-Object { "- ``$_``" }) -join "`n"
    $metricText = ($gate.metrics.GetEnumerator() | ForEach-Object { "- ``$($_.Key)`` = ``$($_.Value -join ',')``" }) -join "`n"
    $caseMarkdown = @"
# $($gate.gate) 测试用例合同

## 目标

$($gate.purpose)

## 冻结输入

$inputText

## 原始命令

$commandText

## 期望项数与指标

$metricText

## 机械PASS条件

$passText

任一命令退出码不符、指标缺失、输入哈希不匹配或机械条件不满足时只能记录 `BLOCKED`，失败所有者为：$($gate.ownerOnFailure)。D3不得执行这些命令或填写最终结论。
"@
    Write-Utf8 (Join-Path $gateRoot "test-cases.md") $caseMarkdown

    $delivery = @"
# $($gate.gate) D3交付说明

本包冻结 $($gate.gate) 的工具、输入引用、命令、预期项数、机械PASS/BLOCKED条件和证据模板。

~~~text
contractVersion = W3-C4/W3-R2
deliveryStage = W3-D3
executionStatus = NOT_RUN_D3
gateConclusion = NOT_PRODUCED_D3
~~~

D4必须使用负责人确认的解析输入清单、显式 `W3-D4` 授权令牌和本包原始哈希执行。不得以作者报告中的PASS文字代替执行，不得修改本包来适配失败结果。
"@
    Write-Utf8 (Join-Path $gateRoot "DELIVERY.md") $delivery
}

$readme = @"
# W3-D3 岗位E验证工具基线

本目录只准备V3-1至V3-8，不执行D4验证。

## 使用约束

1. D3只运行 `Invoke-W3D3Gate.ps1 -Mode Plan`。
2. Execute模式必须同时满足：显式令牌 `W3-D4`、解析清单所有必需输入均为FROZEN、提供实际仓库根目录。
3. Execute只生成命令证据；最终门禁结论还必须按对应 `test-cases.md` 和 `evidence-template.json` 完成机械指标核对。
4. D4不得编辑本基线；如输入或合同变化，停止执行并交负责人重新裁决。
"@
Write-Utf8 (Join-Path $SourceRoot "README.md") $readme
Write-Output "ARTIFACTS_GENERATED gates=8 inputs=$($manifest.inputs.Count) pending=3"
