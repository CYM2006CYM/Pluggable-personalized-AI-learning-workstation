﻿# V3-4 测试用例合同

## 目标

扫描C源码和公共输出，确认C止于ActivityResult且不写正式事实。

## 冻结输入

- `c-formal-commit`
- `c-binding-fix-commit`
- `c-environment-lock`
- `a-d3-formal-commit`

## 原始命令

- `npm.cmd test -- --maxWorkers=1 --run tests/code-evaluation-port.test.ts tests/evaluation-protocol.test.ts`（期望退出码 0）
- `powershell.exe -NoProfile -ExecutionPolicy Bypass -File {ToolRoot}/Test-CBoundary.ps1 -RepositoryRoot {RepositoryRoot} -OutputFile {OutputRoot}/v3-4-source-scan.json`（期望退出码 0）

## 期望项数与指标

- `expectedTestItems` = `4`
- `forbiddenWriteMatches` = `0`
- `publicReturnType` = `ActivityResult`
- `formalFactsOwner` = `A`

## 机械PASS条件

- C源码不导入正式事实仓储能力
- C无Attempt/Evidence/KnowledgeState/Path写入
- 公共返回只为ActivityResult
- 正式事实由A事务仓储公开

任一命令退出码不符、指标缺失、输入哈希不匹配或机械条件不满足时只能记录 BLOCKED，失败所有者为：C（若A事务公开缺口则点名A）。D3不得执行这些命令或填写最终结论。
