﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$GoldCandidate,
    [Parameter(Mandatory = $true)]
    [string]$AdjudicationLog,
    [Parameter(Mandatory = $true)]
    [string]$OwnerFreezeRecord,
    [string]$OutputFile
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Read-JsonLines {
    param([string]$Path)
    $lineNumber = 0
    return @(Get-Content -LiteralPath $Path -Encoding UTF8 | ForEach-Object {
        $lineNumber++
        if ([string]::IsNullOrWhiteSpace($_)) { throw "Blank JSONL line at ${Path}:$lineNumber" }
        try { $_ | ConvertFrom-Json } catch { throw "Invalid JSONL at ${Path}:$lineNumber" }
    })
}

$gold = Read-JsonLines $GoldCandidate
$adjudication = Read-JsonLines $AdjudicationLog
$freeze = Get-Content -LiteralPath $OwnerFreezeRecord -Raw -Encoding UTF8 | ConvertFrom-Json
$expectedCaseIds = 1..60 | ForEach-Object { "final-{0:d3}" -f $_ }
$actualCaseIds = @($gold | ForEach-Object { [string]$_.caseId })
$errors = [System.Collections.Generic.List[string]]::new()

if ($gold.Count -ne 60) { $errors.Add("gold count must be 60") }
if (($expectedCaseIds -join "|") -ne ($actualCaseIds -join "|")) { $errors.Add("gold caseId coverage/order mismatch") }
if (($actualCaseIds | Sort-Object -Unique).Count -ne 60) { $errors.Add("gold caseId duplicate") }
if ($adjudication.Count -ne 40) { $errors.Add("adjudication count must be 40") }
if (@($adjudication | Where-Object { $_.negotiationStatus -ne "SKIPPED_BY_D44" }).Count -ne 0) { $errors.Add("D44 negotiation status mismatch") }
if ($freeze.contractVersion -ne "W3-C4/W3-R2") { $errors.Add("freeze contract mismatch") }
if ($freeze.doubleBlindQualification -ne "PASS") { $errors.Add("double blind qualification is not PASS") }
if ($freeze.ownerAdjudication -ne "COMPLETE") { $errors.Add("owner adjudication is not COMPLETE") }
if ($freeze.systemRunBeforeFreezeCount -ne 0) { $errors.Add("formal system run existed before freeze") }

$result = [ordered]@{
    schemaVersion = "w3-d3-gold-freeze-check-v1"
    gate = "V3-7"
    goldCount = $gold.Count
    adjudicationCount = $adjudication.Count
    negotiationStatus = "SKIPPED_BY_D44"
    goldSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $GoldCandidate).Hash.ToLowerInvariant()
    adjudicationSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $AdjudicationLog).Hash.ToLowerInvariant()
    freezeRecordSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $OwnerFreezeRecord).Hash.ToLowerInvariant()
    errors = @($errors)
    status = if ($errors.Count -eq 0) { "PASS" } else { "BLOCKED" }
}
if ($OutputFile) { $result | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $OutputFile -Encoding utf8 }
$result | ConvertTo-Json -Depth 20
if ($errors.Count -gt 0) { exit 1 }
