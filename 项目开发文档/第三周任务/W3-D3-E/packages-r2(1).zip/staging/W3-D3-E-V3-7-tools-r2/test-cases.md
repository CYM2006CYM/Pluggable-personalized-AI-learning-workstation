﻿# V3-7 测试用例合同

## 目标

只消费负责人只读候选及审计记录，验证60/60、D44终裁和先冻结后运行。

## 冻结输入

- `final-60-frozen-input`
- `e-d1-sealed-annotations`
- `e-d1-seal-record`
- `owner-readonly-gold-candidate`

## 原始命令

- `powershell.exe -NoProfile -ExecutionPolicy Bypass -File {ToolRoot}/Test-GoldFreeze.ps1 -GoldCandidate {InputPath:owner-readonly-gold-candidate}/gold-candidate.jsonl -AdjudicationLog {InputPath:owner-readonly-gold-candidate}/adjudication-log.jsonl -OwnerFreezeRecord {InputPath:owner-readonly-gold-candidate}/freeze-record.json -OutputFile {OutputRoot}/v3-7-gold-freeze.json`（期望退出码 0）

## 期望项数与指标

- `expectedTestItems` = `104`
- `goldCaseCount` = `60`
- `adjudicationCount` = `40`
- `qualificationChecks` = `4`
- `negotiationStatus` = `SKIPPED_BY_D44`
- `formalRunsBeforeFreeze` = `0`

## 机械PASS条件

- gold覆盖final-001至060且无重复
- 40例终裁记录全部SKIPPED_BY_D44
- 双盲资格记录PASS
- 任何正式60例系统运行发生在冻结之后

任一命令退出码不符、指标缺失、输入哈希不匹配或机械条件不满足时只能记录 BLOCKED，失败所有者为：负责人（原始盲标资格问题点名对应标注所有者）。D3不得执行这些命令或填写最终结论。
