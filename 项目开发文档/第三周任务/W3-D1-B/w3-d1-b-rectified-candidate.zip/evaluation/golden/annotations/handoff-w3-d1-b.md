# B 岗位 W3 D1 交接清单（整改候选 - 最终版）

- 范围：`final-021`—`final-060` 第一标注（40/40）及两个固定 `profile_fixed` TaskBundle。
- 周起点：`f190326a4a906b46e4001484ffa30a7839b82ed2`；冻结输入 SHA-256（UTF-8/LF 规范化）：`b77ba4902003ba20bc5b233c4797838eb26325d1b38fd02bc68ba02206cb1d1c`。
- B 原始标注 SHA-256（UTF-8/LF 规范化）：`eaefe9cfbbf8f6144e8299abfc0d82b66cb9ffe8dd1d783e841c5bdfac2690bf`；原封存时间：`2026-08-06T01:36:01.3556942Z`；整改时间：`2026-08-06T12:22:14.105987Z`。
- 两个 Bundle：`bundle-act-inspect-dataframe-v2, bundle-act-practical-v2`；资产树 SHA-256（29 项）：`b19d341e535e5ce9b6f03f57827c97f137304e1348cbf27b7e55423b1ac3607c`。
- C 消费入口：`fixtures/profiles/pandas-cleaning-v2-draft/assessments/private/task-bundles.json` 的 `bundles`。
- Profile 仍是可审计的 draft 来源；未激活，环境限制未由 B 填写。

## 整改完成项

1. **原 seal 保留 + supersedes 候选封存**：原 seal `b-final-021-060.seal.json` 作为审计原件保留；候选 `b-final-021-060.seal.candidate.json` 标记 `supersedes`，标注内容哈希不变。
2. **冻结输入哈希算法修复**：定义并登记 `hashMode: utf8-lf-normalized`（SHA-256 over UTF-8 bytes with CRLF→LF）；脚本和作者测试均按规范化计算，不对原始工作区字节直接哈希。
3. **复算脚本改为默认只读验证**：`prepare-w3-b-d1-delivery.py --verify` 在内存中重算所有哈希并逐项比对，任何差异失败退出；禁止写入标注/seal/handoff/候选资产。构建功能以 `--build-candidate --temp-dir` 显式区分，仅在独立临时目录运行。
4. **TaskBundle 资产闭合修复**：`dataframe-comparisons.json`、`knowledge-points.json`、`learning-goals.json`、`source-map.json`、`profile.json` 全部纳入资产树（29 项）。
5. **Rubric 到测试映射修复**：`test-practical-hidden-02` 从 `engineering/static_check` 改为 `invariants/blocking=true`；新增 `test-practical-hidden-structure/missing/duplicates/types` 四个维度专用测试；`engineering` 维度改为 `manual_review`（无自动化测试，C 手动审查代码质量）；`rubric-practical.json` 与 `task-bundles.json` 中 rubric 定义已统一。
6. **可独立审计候选包**：保持仓库相对路径，包含两个 Bundle、测试索引、脚本、作者测试、seal、handoff 和逐文件清单。

## 验证证据

- 只读验证脚本（`python quality/prepare-w3-b-d1-delivery.py --verify`）：退出码 0，VERIFICATION PASSED。
- 作者测试（`npx vitest run tests/w3-b-d1-delivery.test.ts`）：12/12 通过，退出码 0。
- 类型检查（`npx tsc --noEmit`）：通过，退出码 0。

## 上传资格

- 当前状态：`BLOCKED` → 整改完成，等待负责人审计。
- 上传条件：E 独立封存 → 负责人双封存资格检查 PASS → A 第一把上传锁释放 → 获负责人第二把锁授权。
- 本材料不构成上传授权。
