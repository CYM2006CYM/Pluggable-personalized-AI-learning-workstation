# B W3-D1 整改候选包验证证据

## 环境

- 操作系统：Windows 10 (AMD64)
- Python：3.10.11 (tags/v3.10.11:7d4cc5a, Apr  5 2023, 00:38:17) [MSC v.1929 64 bit (AMD64)]
- Node.js/Vitest：v4.1.10
- TypeScript：npx tsc --noEmit
- 验证时间：2026-08-06T12:37:09.935571Z
- 工作目录：c:\Users\Lenovo\Pluggable-personalized-AI-learning-workstation

## 命令 1：只读验证脚本

**命令**：
```
python quality/prepare-w3-b-d1-delivery.py --verify
```

**退出码**：0

**输出**：
```
VERIFICATION PASSED
  Input hash:       b77ba4902003ba20bc5b233c4797838eb26325d1b38fd02bc68ba02206cb1d1c
  Annotation hash:  eaefe9cfbbf8f6144e8299abfc0d82b66cb9ffe8dd1d783e841c5bdfac2690bf
  Asset tree hash:  b19d341e535e5ce9b6f03f57827c97f137304e1348cbf27b7e55423b1ac3607c
  Asset entries:    29
  Bundles:          bundle-act-inspect-dataframe-v2, bundle-act-practical-v2
```

**验证项**：
1. 40 条标注 schema 和内容完整性（只读，内存校验）
2. 两个 TaskBundle assetBundleHash 一致性
3. 所有引用闭合：comparisonRef、datasetRefs、testRefs、rubricRef
4. 冻结输入哈希（UTF-8/LF 规范化）：与 seal 一致
5. 标注哈希（UTF-8/LF 规范化）：与 seal 一致，且与原 seal 相同（未改动）
6. 资产树总哈希（29 项）：与 seal 一致
7. 每个资产文件哈希：逐项比对，全部一致

## 命令 2：作者测试

**命令**：
```
npx vitest run tests/w3-b-d1-delivery.test.ts
```

**退出码**：0

**输出**：
```
 RUN  v4.1.10 C:/Users/Lenovo/Pluggable-personalized-AI-learning-workstation/pi-study-helper

 ✓ tests/w3-b-d1-delivery.test.ts (12 tests) 64ms

 Test Files  1 passed (1)
      Tests  12 passed (12)
   Start at  20:36:24
   Duration  1.16s (transform 43ms, setup 0ms, import 147ms, tests 64ms, environment 0ms)
```

**12 项测试覆盖**：
1. 两个 profile_fixed TaskBundle 闭合
2. 40 条 B 标注 SHA-256 不变
3. 规范化输入哈希（UTF-8/LF）
4. 每个资产文件哈希与 seal 一致
5. 资产树总哈希
6. 所有引用闭合（comparisonRef、datasetRef、testRef）
7. 每个 tests 评分 Rubric 维度有测试映射
8. test-practical-hidden-02 映射为 invariants（非 engineering）
9. act-practical 有 structure/missing/duplicates/types 维度测试
10. 候选 seal 有 supersedes 和正确 schema
11. 资产树包含 dataframe-comparisons.json 和 profile.json
12. 新增维度测试文件在资产树中

## 命令 3：类型检查

**命令**：
```
npx tsc --noEmit
```

**退出码**：0

**输出**：（无错误输出，通过）

## 结论

全部三项验证通过，候选包可交付负责人独立审计。
