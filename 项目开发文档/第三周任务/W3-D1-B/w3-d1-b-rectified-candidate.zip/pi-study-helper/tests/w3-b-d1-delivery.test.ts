import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { resolve, relative } from "node:path";
import { describe, expect, it } from "vitest";

const repoRoot = resolve(import.meta.dirname, "..", "..");
const profileRoot = resolve(import.meta.dirname, "..", "fixtures/profiles/pandas-cleaning-v2-draft");
const annotationsRoot = resolve(repoRoot, "evaluation/golden/annotations");

const sha256 = (value: string | Buffer) => createHash("sha256").update(value).digest("hex");

const NORMALIZED_EXTS = [".json", ".py", ".jsonl", ".md"];

async function normalizedHash(path: string): Promise<{ hash: string; byteLength: number; mode: string }> {
  const raw = await readFile(path);
  const ext = path.slice(path.lastIndexOf("."));
  const isNormalized = NORMALIZED_EXTS.includes(ext);
  const payload = isNormalized
    ? Buffer.from(raw.toString("binary").replace(/\r\n/g, "\n").replace(/\r/g, "\n"), "binary")
    : raw;
  return {
    hash: sha256(payload),
    byteLength: payload.length,
    mode: isNormalized ? "normalized-text" : "raw-binary",
  };
}

function assetTreeHash(entries: { path: string; hashMode: string; sha256: string; byteLength: number }[]): string {
  const stream = entries
    .map((e) => `${e.path}\0${e.hashMode}\0${e.sha256}\0${e.byteLength}\n`)
    .join("");
  return sha256(Buffer.from(stream, "utf-8"));
}

function relPath(absPath: string): string {
  return relative(repoRoot, absPath).replace(/\\/g, "/");
}

async function readJson(path: string): Promise<any> {
  return JSON.parse(await readFile(path, "utf-8"));
}

describe("B W3 D1 rectified sealed delivery", () => {
  // ── 1. Two profile-fixed TaskBundles ──────────────────────────
  it("closes only the two profile-fixed TaskBundles required for W3", async () => {
    const manifest = await readJson(resolve(profileRoot, "assessments/private/task-bundles.json"));
    expect(manifest.status).toBe("w3-sealed-pending-owner-qualification");
    expect(manifest.bundles.map((b: any) => b.activity.activityId)).toEqual([
      "act-inspect-dataframe", "act-practical",
    ]);
    for (const bundle of manifest.bundles) {
      expect(bundle.source).toBe("profile_fixed");
      expect(bundle.activity.allowedSources).toEqual(["profile_fixed"]);
      expect(bundle.contract).toBeDefined();
      expect(bundle.publicTests.length).toBeGreaterThan(0);
      expect(bundle.hiddenTests.length).toBeGreaterThan(0);
      expect(bundle.activity.referenceSolutionRef).toMatch(/^solution-/u);
      expect(bundle.activity.knownWrongSolutionRefs.length).toBeGreaterThan(0);
      expect(bundle.rubric.dimensions.length).toBeGreaterThan(0);
      expect(bundle.environmentRef).toBe("env-python-pandas-candidate");
      expect(bundle.assetBundleHash).toMatch(/^[a-f0-9]{64}$/u);
    }
  });

  // ── 2. 40 valid B annotations with unchanged hash ────────────
  it("seals exactly 40 valid B annotations with unchanged SHA-256", async () => {
    const annotationPath = resolve(annotationsRoot, "b-final-021-060.jsonl");
    const seal = await readJson(resolve(annotationsRoot, "b-final-021-060.seal.candidate.json"));
    const rows = (await readFile(annotationPath, "utf8")).trim().split(/\r?\n/u).map((l) => JSON.parse(l));
    expect(rows).toHaveLength(40);
    expect(rows.map((r: any) => r.caseId)).toEqual(
      Array.from({ length: 40 }, (_, i) => `final-${String(i + 21).padStart(3, "0")}`)
    );
    for (const row of rows) {
      expect(Object.keys(row).sort()).toEqual([
        "annotatorRole", "caseId", "forbiddenActions", "nodeConstraints",
        "notes", "requiredRemediationKnowledgePointIds",
      ]);
      expect(row.annotatorRole).toBe("B");
      expect(row.nodeConstraints.length).toBe(7);
      expect(row.nodeConstraints.every((n: any) => n.required !== n.skippable)).toBe(true);
    }
    // Verify annotation hash matches seal and is unchanged from original
    const annHash = await normalizedHash(annotationPath);
    expect(seal.annotation.sha256).toBe(annHash.hash);
    expect(seal.annotation.sha256).toBe("eaefe9cfbbf8f6144e8299abfc0d82b66cb9ffe8dd1d783e841c5bdfac2690bf");
    expect(seal.annotation.hashMode).toBe("utf8-lf-normalized");
  });

  // ── 3. Normalized input hash ─────────────────────────────────
  it("verifies normalized input hash (UTF-8/LF)", async () => {
    const inputPath = resolve(repoRoot, "evaluation/personas/final-60.jsonl");
    const seal = await readJson(resolve(annotationsRoot, "b-final-021-060.seal.candidate.json"));
    const inputHash = await normalizedHash(inputPath);
    expect(seal.input.sha256).toBe(inputHash.hash);
    expect(seal.input.hashMode).toBe("utf8-lf-normalized");
    expect(seal.input.sha256).toBe("b77ba4902003ba20bc5b233c4797838eb26325d1b38fd02bc68ba02206cb1d1c");
  });

  // ── 4. Each asset file hash matches seal ─────────────────────
  it("verifies every asset file hash in the seal", async () => {
    const seal = await readJson(resolve(annotationsRoot, "b-final-021-060.seal.candidate.json"));
    const entries: { path: string; sha256: string; hashMode: string; byteLength: number }[] =
      seal.taskBundleAssetTree.entries;
    expect(entries.length).toBeGreaterThanOrEqual(29);
    for (const entry of entries) {
      const absPath = resolve(repoRoot, entry.path);
      const computed = await normalizedHash(absPath);
      expect(computed.hash, `hash mismatch for ${entry.path}`).toBe(entry.sha256);
      expect(computed.mode, `mode mismatch for ${entry.path}`).toBe(entry.hashMode);
      expect(computed.byteLength, `byteLength mismatch for ${entry.path}`).toBe(entry.byteLength);
    }
  });

  // ── 5. Asset tree total hash ─────────────────────────────────
  it("verifies asset tree total hash", async () => {
    const seal = await readJson(resolve(annotationsRoot, "b-final-021-060.seal.candidate.json"));
    const entries = seal.taskBundleAssetTree.entries
      .map((e: any) => ({
        path: e.path,
        hashMode: e.hashMode,
        sha256: e.sha256,
        byteLength: e.byteLength,
      }))
      .sort((a: any, b: any) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
    const computed = assetTreeHash(entries);
    expect(computed).toBe(seal.taskBundleAssetTree.sha256);
    expect(seal.taskBundleAssetTree.entryCount).toBe(entries.length);
  });

  // ── 6. Reference closure: comparisonRef, datasetRefs, testRefs ─
  it("verifies all reference closure in bundles", async () => {
    const manifest = await readJson(resolve(profileRoot, "assessments/private/task-bundles.json"));
    const comparisons = await readJson(resolve(profileRoot, "environments/dataframe-comparisons.json"));
    const comparisonIds = new Set(comparisons.comparisons.map((c: any) => c.comparisonId));
    const fixtures = await readJson(resolve(profileRoot, "datasets/fixtures.json"));
    const fixtureIds = new Set(fixtures.fixtures.map((f: any) => f.fixtureId));
    for (const bundle of manifest.bundles) {
      const cref = bundle.contract.output.comparisonRef;
      expect(comparisonIds.has(cref), `comparisonRef ${cref} not found`).toBe(true);
      for (const fref of bundle.activity.datasetRefs) {
        expect(fixtureIds.has(fref), `datasetRef ${fref} not found`).toBe(true);
      }
      const allTestIds = new Set([
        ...bundle.publicTests.map((t: any) => t.testId),
        ...bundle.hiddenTests.map((t: any) => t.testId),
      ]);
      for (const tref of [...bundle.activity.publicTestRefs, ...bundle.activity.hiddenTestRefs]) {
        expect(allTestIds.has(tref), `testRef ${tref} not found in bundle`).toBe(true);
      }
    }
  });

  // ── 7. Rubric dimension-to-test mapping ──────────────────────
  it("verifies every tests-scored Rubric dimension has a test mapping", async () => {
    const manifest = await readJson(resolve(profileRoot, "assessments/private/task-bundles.json"));
    for (const bundle of manifest.bundles) {
      const dimMap: Record<string, string[]> = bundle.rubric.dimensionTestMap || {};
      const allTestIds = new Set([
        ...bundle.publicTests.map((t: any) => t.testId),
        ...bundle.hiddenTests.map((t: any) => t.testId),
      ]);
      for (const dim of bundle.rubric.dimensions) {
        if (dim.scoringMethod === "tests") {
          const mapped = dimMap[dim.dimensionId];
          expect(mapped, `dimension ${dim.dimensionId} has scoringMethod=tests but no mapping`).toBeDefined();
          expect(mapped.length, `dimension ${dim.dimensionId} has no tests mapped`).toBeGreaterThan(0);
          for (const tid of mapped) {
            expect(allTestIds.has(tid), `mapped test ${tid} not in bundle tests`).toBe(true);
          }
        }
      }
    }
  });

  // ── 8. act-practical hidden-02 is invariants+blocking, not engineering ─
  it("verifies test-practical-hidden-02 is mapped to invariants (not engineering)", async () => {
    const manifest = await readJson(resolve(profileRoot, "assessments/private/task-bundles.json"));
    const practical = manifest.bundles.find((b: any) => b.bundleId === "bundle-act-practical-v2");
    const hidden02 = practical.hiddenTests.find((t: any) => t.testId === "test-practical-hidden-02");
    expect(hidden02.dimensionId).toBe("invariants");
    expect(hidden02.blocking).toBe(true);
    // engineering dimension should be manual_review, not static_check
    const engDim = practical.rubric.dimensions.find((d: any) => d.dimensionId === "engineering");
    expect(engDim.scoringMethod).toBe("manual_review");
  });

  // ── 9. act-practical has dimension-specific tests for all dimensions ─
  it("verifies act-practical has tests for structure, missing, duplicates, types", async () => {
    const manifest = await readJson(resolve(profileRoot, "assessments/private/task-bundles.json"));
    const practical = manifest.bundles.find((b: any) => b.bundleId === "bundle-act-practical-v2");
    const dimMap: Record<string, string[]> = practical.rubric.dimensionTestMap;
    for (const dim of ["structure", "missing", "duplicates", "types"]) {
      expect(dimMap[dim], `dimension ${dim} missing from dimensionTestMap`).toBeDefined();
      expect(dimMap[dim].length, `dimension ${dim} has no tests`).toBeGreaterThan(0);
    }
  });

  // ── 10. Seal consistency: supersedes, schemaVersion, hashAlgorithm ─
  it("verifies candidate seal has supersedes and correct schema", async () => {
    const seal = await readJson(resolve(annotationsRoot, "b-final-021-060.seal.candidate.json"));
    expect(seal.schemaVersion).toBe(2);
    expect(seal.owner).toBe("B");
    expect(seal.w3StartCommit).toBe("f190326a4a906b46e4001484ffa30a7839b82ed2");
    expect(seal.qualificationStatus).toBe("PENDING_OWNER_DUAL_SEAL_CHECK");
    expect(seal.supersedes).toBeDefined();
    expect(seal.supersedes.annotationHashUnchanged).toBe(true);
    expect(seal.supersedes.originalSealedAt).toBe("2026-08-06T01:36:01.3556942Z");
    expect(seal.hashAlgorithmRegistry).toBeDefined();
    expect(seal.hashAlgorithmRegistry["normalized-text"]).toBeDefined();
    expect(seal.hashAlgorithmRegistry["raw-binary"]).toBeDefined();
  });

  // ── 11. Asset tree includes dataframe-comparisons.json and profile ─
  it("verifies asset tree includes dataframe-comparisons.json and profile.json", async () => {
    const seal = await readJson(resolve(annotationsRoot, "b-final-021-060.seal.candidate.json"));
    const paths = new Set(seal.taskBundleAssetTree.entries.map((e: any) => e.path));
    expect(paths.has("pi-study-helper/fixtures/profiles/pandas-cleaning-v2-draft/environments/dataframe-comparisons.json")).toBe(true);
    expect(paths.has("pi-study-helper/fixtures/profiles/pandas-cleaning-v2-draft/knowledge/knowledge-points.json")).toBe(true);
    expect(paths.has("pi-study-helper/fixtures/profiles/pandas-cleaning-v2-draft/goals/learning-goals.json")).toBe(true);
    expect(paths.has("pi-study-helper/fixtures/profiles/pandas-cleaning-v2-draft/sources/source-map.json")).toBe(true);
    expect(paths.has("pi-study-helper/fixtures/profiles/pandas-cleaning-v2-draft/profile.json")).toBe(true);
  });

  // ── 12. New dimension-specific test files are in asset tree ──
  it("verifies new dimension-specific tests are in asset tree", async () => {
    const seal = await readJson(resolve(annotationsRoot, "b-final-021-060.seal.candidate.json"));
    const paths = new Set(seal.taskBundleAssetTree.entries.map((e: any) => e.path));
    const base = "pi-study-helper/fixtures/profiles/pandas-cleaning-v2-draft/assessments/private/tests";
    expect(paths.has(`${base}/test-practical-hidden-structure.py`)).toBe(true);
    expect(paths.has(`${base}/test-practical-hidden-missing.py`)).toBe(true);
    expect(paths.has(`${base}/test-practical-hidden-duplicates.py`)).toBe(true);
    expect(paths.has(`${base}/test-practical-hidden-types.py`)).toBe(true);
  });
});
