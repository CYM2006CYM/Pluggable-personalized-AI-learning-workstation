"""B W3 D1 delivery: read-only verification and candidate seal generation.

DEFAULT MODE (--verify): Reads all sealed assets in memory, recomputes every
hash, and compares against the candidate seal.  Any mismatch causes a non-zero
exit.  This mode NEVER writes to b-final-021-060.jsonl, the seal, the handoff,
or any candidate asset.

BUILD-CANDIDATE MODE (--build-candidate --temp-dir <path>): Pre-sealing
construction utility.  Copies the candidate package into an independent temp
directory and writes the generated seal there.  Must not be run against the
shared workspace.

This script consumes only the frozen persona input plus B's already sealed
first-20 annotations as precedent.  No E annotation, mechanical-difference
list, or formal-case system path/output is read.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path


W3_START_COMMIT = "f190326a4a906b46e4001484ffa30a7839b82ed2"
FIXED_ACTIVITY_IDS = ("act-inspect-dataframe", "act-practical")
ALLOWED_FORBIDDEN_ACTIONS = {
    "skip_unverified_prerequisite",
    "omit_required_node",
    "violate_prerequisite_order",
    "exceed_time_budget",
}
NORMALIZED_EXTS = {".json", ".py", ".jsonl", ".md"}


# ── Hash utilities ──────────────────────────────────────────────

def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def write_json(path: Path, value: object) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def normalize_payload(raw: bytes, ext: str) -> tuple[bytes, str]:
    """Return (payload, hashMode) for the given raw bytes and file extension."""
    if ext in NORMALIZED_EXTS:
        return raw.replace(b"\r\n", b"\n").replace(b"\r", b"\n"), "normalized-text"
    return raw, "raw-binary"


def normalized_entry(repo_root: Path, path: Path) -> dict:
    relative = path.resolve().relative_to(repo_root.resolve()).as_posix()
    raw = path.read_bytes()
    payload, mode = normalize_payload(raw, path.suffix)
    return {
        "path": relative,
        "hashMode": mode,
        "byteLength": len(payload),
        "sha256": sha256_bytes(payload),
    }


def asset_tree_hash(entries: list[dict]) -> str:
    stream = b"".join(
        e["path"].encode("utf-8") + b"\0" + e["hashMode"].encode("ascii") + b"\0"
        + e["sha256"].encode("ascii") + b"\0" + str(e["byteLength"]).encode("ascii") + b"\n"
        for e in entries
    )
    return sha256_bytes(stream)


def compute_hash_normalized(path: Path) -> tuple[str, int]:
    """Compute UTF-8/LF-normalized SHA-256 for a file."""
    raw = path.read_bytes()
    payload, _ = normalize_payload(raw, path.suffix)
    return sha256_bytes(payload), len(payload)


# ── Annotation validation ──────────────────────────────────────

def annotation_key(case: dict) -> str:
    return canonical_json({
        "availableMinutes": case["availableMinutes"],
        "diagnosticAnswers": case["diagnosticAnswers"],
    })


def validate_annotation(rows: list[dict], final_cases: list[dict]) -> None:
    expected_ids = [case["caseId"] for case in final_cases]
    if [row.get("caseId") for row in rows] != expected_ids:
        raise ValueError("annotation case IDs are not exactly final-021 through final-060")
    expected_keys = {
        "caseId", "annotatorRole", "nodeConstraints",
        "requiredRemediationKnowledgePointIds", "forbiddenActions", "notes",
    }
    for row in rows:
        if set(row) != expected_keys or row["annotatorRole"] != "B":
            raise ValueError(f"annotation schema is invalid for {row.get('caseId')}")
        if not isinstance(row["notes"], str) or not row["notes"]:
            raise ValueError(f"annotation notes are missing for {row['caseId']}")
        if not set(row["forbiddenActions"]).issubset(ALLOWED_FORBIDDEN_ACTIONS):
            raise ValueError(f"annotation forbiddenActions are invalid for {row['caseId']}")
        node_ids = []
        for node in row["nodeConstraints"]:
            if set(node) != {"knowledgePointId", "required", "allowedDifficulties",
                             "allowedScaffoldLevels", "skippable"}:
                raise ValueError(f"node schema is invalid for {row['caseId']}")
            if not isinstance(node["required"], bool) or not isinstance(node["skippable"], bool):
                raise ValueError(f"node flags are invalid for {row['caseId']}")
            if node["required"] == node["skippable"]:
                raise ValueError(f"required/skippable relation is invalid for {row['caseId']}")
            node_ids.append(node["knowledgePointId"])
        if row["requiredRemediationKnowledgePointIds"] and not set(
            row["requiredRemediationKnowledgePointIds"]
        ).issubset(node_ids):
            raise ValueError(f"remediation references are invalid for {row['caseId']}")


# ── Bundle validation (read-only) ──────────────────────────────

def validate_bundles(profile_root: Path) -> list[dict]:
    """Read and validate bundles without writing anything."""
    manifest_path = profile_root / "assessments/private/task-bundles.json"
    manifest = read_json(manifest_path)
    by_activity = {b["activity"]["activityId"]: b for b in manifest["bundles"]}
    if set(FIXED_ACTIVITY_IDS) - set(by_activity):
        raise ValueError("the required W3 fixed TaskBundles are missing")
    bundles = [by_activity[aid] for aid in FIXED_ACTIVITY_IDS]
    fixtures = read_json(profile_root / "datasets/fixtures.json")["fixtures"]
    for bundle in bundles:
        without_hash = {k: v for k, v in bundle.items() if k != "assetBundleHash"}
        resolved = [item for item in fixtures if item["fixtureId"] in bundle["activity"]["datasetRefs"]]
        expected = sha256_bytes(canonical_json({**without_hash, "resolvedFixtures": resolved}).encode("utf-8"))
        if bundle["assetBundleHash"] != expected:
            raise ValueError(f"assetBundleHash is stale for {bundle['bundleId']}")
    return bundles


# ── Asset tree construction (read-only) ────────────────────────

def collect_asset_paths(profile_root: Path, bundles: list[dict]) -> list[Path]:
    paths = {
        profile_root / "activities/learning-activities.json",
        profile_root / "assessments/private/task-bundles.json",
        profile_root / "assessments/public/test-cases.json",
        profile_root / "assessments/private/test-cases.json",
        profile_root / "datasets/fixtures.json",
        profile_root / "environments/environment-lock.json",
        profile_root / "environments/dataframe-comparisons.json",
        profile_root / "knowledge/knowledge-points.json",
        profile_root / "goals/learning-goals.json",
        profile_root / "sources/source-map.json",
        profile_root / "profile.json",
    }
    fixtures = {item["fixtureId"]: item for item in read_json(profile_root / "datasets/fixtures.json")["fixtures"]}
    for bundle in bundles:
        activity = bundle["activity"]
        paths.add(profile_root / "rubrics" / f"{activity['rubricRef']}.json")
        paths.add(profile_root / "reference-solutions" / f"{activity['referenceSolutionRef']}.py")
        for wrong in activity["knownWrongSolutionRefs"]:
            paths.add(profile_root / "assessments/private/known-wrong" / f"{wrong}.py")
        for test in bundle["publicTests"] + bundle["hiddenTests"]:
            paths.add(profile_root / test["fileRef"])
        for fixture_id in activity["datasetRefs"]:
            paths.add(profile_root / fixtures[fixture_id]["fileRef"])
    return sorted(paths, key=lambda p: str(p))


# ── Reference closure validation ───────────────────────────────

def validate_reference_closure(profile_root: Path, bundles: list[dict]) -> None:
    """Verify all references in bundles resolve to actual assets."""
    comparisons = read_json(profile_root / "environments/dataframe-comparisons.json")
    comparison_ids = {c["comparisonId"] for c in comparisons["comparisons"]}
    fixtures_data = read_json(profile_root / "datasets/fixtures.json")
    fixture_ids = {f["fixtureId"] for f in fixtures_data["fixtures"]}
    rubric_ids = set()
    for b in bundles:
        rubric_path = profile_root / "rubrics" / f"{b['activity']['rubricRef']}.json"
        rubric = read_json(rubric_path)
        rubric_ids.add(rubric["rubricId"])
    for bundle in bundles:
        activity = bundle["activity"]
        contract = bundle["contract"]
        cref = contract["output"].get("comparisonRef")
        if cref and cref not in comparison_ids:
            raise ValueError(f"comparisonRef '{cref}' not found in dataframe-comparisons.json for {bundle['bundleId']}")
        for fref in activity["datasetRefs"]:
            if fref not in fixture_ids:
                raise ValueError(f"datasetRef '{fref}' not found in fixtures.json for {bundle['bundleId']}")
        for tref in activity["publicTestRefs"] + activity["hiddenTestRefs"]:
            found = any(t["testId"] == tref for t in bundle["publicTests"] + bundle["hiddenTests"])
            if not found:
                raise ValueError(f"testRef '{tref}' not found in bundle tests for {bundle['bundleId']}")
        if activity["rubricRef"] not in rubric_ids:
            raise ValueError(f"rubricRef '{activity['rubricRef']}' not found for {bundle['bundleId']}")
        dim_map = bundle["rubric"].get("dimensionTestMap", {})
        for dim in bundle["rubric"]["dimensions"]:
            if dim["scoringMethod"] == "tests":
                if dim["dimensionId"] not in dim_map:
                    raise ValueError(f"dimension '{dim['dimensionId']}' has scoringMethod=tests but no test mapping in {bundle['bundleId']}")


# ── Verify mode (default, read-only) ───────────────────────────

def run_verify(repo_root: Path, profile_root: Path) -> int:
    seal_path = repo_root / "evaluation/golden/annotations/b-final-021-060.seal.candidate.json"
    if not seal_path.exists():
        print(f"ERROR: candidate seal not found at {seal_path}", file=sys.stderr)
        return 1
    seal = read_json(seal_path)
    errors = []

    # 1. Validate annotation (read-only)
    personas_path = repo_root / "evaluation/personas/final-60.jsonl"
    seed_path = repo_root / "evaluation/golden/annotations/b-first-20.jsonl"
    annotations_path = repo_root / "evaluation/golden/annotations/b-final-021-060.jsonl"
    cases = [json.loads(line) for line in personas_path.read_text(encoding="utf-8").splitlines() if line]
    target_cases = cases[20:]
    seeds = [json.loads(line) for line in seed_path.read_text(encoding="utf-8").splitlines() if line]
    if len(cases) != 60 or len(seeds) != 20 or len(target_cases) != 40:
        errors.append("frozen final input or B-owned precedent is incomplete")
    else:
        rows = [json.loads(line) for line in annotations_path.read_text(encoding="utf-8").splitlines() if line]
        try:
            validate_annotation(rows, target_cases)
        except ValueError as e:
            errors.append(str(e))

    # 2. Validate bundles (read-only)
    try:
        bundles = validate_bundles(profile_root)
    except ValueError as e:
        errors.append(str(e))
        bundles = []

    # 3. Validate reference closure
    if bundles:
        try:
            validate_reference_closure(profile_root, bundles)
        except ValueError as e:
            errors.append(str(e))

    # 4. Verify input hash (normalized)
    input_hash, input_len = compute_hash_normalized(personas_path)
    if input_hash != seal["input"]["sha256"]:
        errors.append(f"input hash mismatch: computed={input_hash} seal={seal['input']['sha256']}")

    # 5. Verify annotation hash (normalized)
    ann_hash, ann_len = compute_hash_normalized(annotations_path)
    if ann_hash != seal["annotation"]["sha256"]:
        errors.append(f"annotation hash mismatch: computed={ann_hash} seal={seal['annotation']['sha256']}")

    # 6. Verify asset tree
    if bundles:
        asset_paths = collect_asset_paths(profile_root, bundles)
        entries = [normalized_entry(repo_root, p) for p in asset_paths]
        entries.sort(key=lambda e: e["path"].encode("utf-8"))
        computed_tree = asset_tree_hash(entries)
        if computed_tree != seal["taskBundleAssetTree"]["sha256"]:
            errors.append(f"asset tree hash mismatch: computed={computed_tree} seal={seal['taskBundleAssetTree']['sha256']}")
        if len(entries) != seal["taskBundleAssetTree"].get("entryCount", 0):
            errors.append(f"asset entry count mismatch: computed={len(entries)} seal={seal['taskBundleAssetTree'].get('entryCount')}")

    # 7. Verify each asset entry hash
    if bundles:
        seal_entries = {e["path"]: e for e in seal["taskBundleAssetTree"]["entries"]}
        for p in asset_paths:
            rel = p.resolve().relative_to(repo_root.resolve()).as_posix()
            entry = normalized_entry(repo_root, p)
            seal_entry = seal_entries.get(rel)
            if seal_entry is None:
                errors.append(f"asset not in seal: {rel}")
            elif entry["sha256"] != seal_entry["sha256"]:
                errors.append(f"asset hash mismatch for {rel}: computed={entry['sha256']} seal={seal_entry['sha256']}")

    # Report
    if errors:
        print("VERIFICATION FAILED:", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        return 1
    print("VERIFICATION PASSED")
    print(f"  Input hash:       {input_hash}")
    print(f"  Annotation hash:  {ann_hash}")
    print(f"  Asset tree hash:  {seal['taskBundleAssetTree']['sha256']}")
    print(f"  Asset entries:    {seal['taskBundleAssetTree'].get('entryCount', len(seal['taskBundleAssetTree']['entries']))}")
    print(f"  Bundles:          {', '.join(b['bundleId'] for b in bundles)}")
    return 0


# ── Build-candidate mode (writes only to temp dir) ─────────────

def run_build_candidate(repo_root: Path, profile_root: Path, temp_dir: Path) -> int:
    if temp_dir.exists():
        if any(temp_dir.iterdir()):
            print(f"ERROR: temp dir is not empty: {temp_dir}", file=sys.stderr)
            return 1
    else:
        temp_dir.mkdir(parents=True)

    # Copy candidate package files maintaining repo-relative paths
    bundles = validate_bundles(profile_root)
    asset_paths = collect_asset_paths(profile_root, bundles)
    for src in asset_paths:
        rel = src.resolve().relative_to(repo_root.resolve())
        dst = temp_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    # Copy annotation and input
    for src in [
        repo_root / "evaluation/personas/final-60.jsonl",
        repo_root / "evaluation/golden/annotations/b-final-021-060.jsonl",
        repo_root / "evaluation/golden/annotations/b-first-20.jsonl",
        repo_root / "evaluation/golden/annotations/b-final-021-060.seal.json",
    ]:
        if src.exists():
            rel = src.resolve().relative_to(repo_root.resolve())
            dst = temp_dir / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)

    # Copy this script
    script_src = profile_root / "quality/prepare-w3-b-d1-delivery.py"
    script_rel = script_src.resolve().relative_to(repo_root.resolve())
    shutil.copy2(script_src, temp_dir / script_rel)

    # Compute hashes and generate candidate seal in temp dir
    entries = [normalized_entry(repo_root, p) for p in asset_paths]
    entries.sort(key=lambda e: e["path"].encode("utf-8"))
    tree_hash = asset_tree_hash(entries)
    input_hash, input_len = compute_hash_normalized(repo_root / "evaluation/personas/final-60.jsonl")
    ann_hash, ann_len = compute_hash_normalized(repo_root / "evaluation/golden/annotations/b-final-021-060.jsonl")

    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
    seal = {
        "schemaVersion": 2,
        "owner": "B",
        "scope": {"firstCaseId": "final-021", "lastCaseId": "final-060", "caseCount": 40},
        "w3StartCommit": W3_START_COMMIT,
        "input": {"path": "evaluation/personas/final-60.jsonl", "sha256": input_hash,
                  "hashMode": "utf8-lf-normalized", "byteLength": input_len},
        "annotation": {"path": "evaluation/golden/annotations/b-final-021-060.jsonl",
                       "sha256": ann_hash, "hashMode": "utf8-lf-normalized", "byteLength": ann_len},
        "sealedAt": now,
        "qualificationStatus": "PENDING_OWNER_DUAL_SEAL_CHECK",
        "taskBundleAssetTree": {"algorithm": "sha256", "entries": entries,
                                "sha256": tree_hash, "entryCount": len(entries)},
    }
    seal_dst = temp_dir / "evaluation/golden/annotations/b-final-021-060.seal.candidate.json"
    seal_dst.parent.mkdir(parents=True, exist_ok=True)
    write_json(seal_dst, seal)
    print(f"BUILD-CANDIDATE complete: {temp_dir}")
    print(f"  Seal written to: {seal_dst}")
    return 0


# ── Main ───────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="B W3 D1 delivery: verify (default) or build-candidate"
    )
    parser.add_argument("--verify", action="store_true", default=True,
                        help="Read-only verification (default)")
    parser.add_argument("--build-candidate", action="store_true",
                        help="Pre-sealing candidate build (requires --temp-dir)")
    parser.add_argument("--temp-dir", type=Path, default=None,
                        help="Independent temp directory for build-candidate mode")
    args = parser.parse_args()

    repo_root = Path(__file__).resolve().parents[5]
    profile_root = Path(__file__).resolve().parents[1]

    if args.build_candidate:
        if not args.temp_dir:
            print("ERROR: --build-candidate requires --temp-dir", file=sys.stderr)
            sys.exit(1)
        sys.exit(run_build_candidate(repo_root, profile_root, args.temp_dir))
    else:
        sys.exit(run_verify(repo_root, profile_root))


if __name__ == "__main__":
    main()
