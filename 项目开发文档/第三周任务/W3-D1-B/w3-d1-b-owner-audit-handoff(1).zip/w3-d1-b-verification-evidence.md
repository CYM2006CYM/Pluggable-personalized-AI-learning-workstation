# B W3-D1 整改候选验证证据

工作目录：`C:\Users\Lenovo\Pluggable-personalized-AI-learning-workstation`

## 1. 只读复验

命令：`python quality/prepare-w3-b-d1-delivery.py --verify`

```text
VERIFICATION PASSED
  Input hash:       b77ba4902003ba20bc5b233c4797838eb26325d1b38fd02bc68ba02206cb1d1c
  Annotation hash:  eaefe9cfbbf8f6144e8299abfc0d82b66cb9ffe8dd1d783e841c5bdfac2690bf
  Asset tree hash:  743e642d212d055fd309352e6c9b0fae0f525106906ad8e88e378c496c9d4b42
  Asset entries:    29
  Bundles:          bundle-act-inspect-dataframe-v2, bundle-act-practical-v2
```

## 2. 作者测试

命令：`npm.cmd test -- --run tests/w3-b-d1-delivery.test.ts`

```text
Test Files  1 passed (1)
Tests       13 passed (13)
```

覆盖：禁止 `manual_review`；activity/rubric 深相等；权重、阻断、反馈码和 `dimensionTestMap` 不漂移；输入/标注/资产树/引用闭合；manifest 覆盖除自身外全部文件；原 seal 归档与候选唯一入口。

## 3. 类型检查

命令：`npx.cmd tsc --noEmit`

结果：退出码 0，无错误输出。

## 4. 交付包旁路哈希

- ZIP：`w3-d1-b-rectified-candidate.zip`
- ZIP SHA-256 使用以下旁路命令计算，不把自身结果写回 ZIP 内容，避免循环依赖：`Get-FileHash -Algorithm SHA256 w3-d1-b-rectified-candidate.zip`
- manifest：实际包文件 40，登记文件 39，`selfExcluded=true`。
- 验证证据自身列于 manifest，哈希与长度由复验脚本检查。

以上仅供负责人审计；当前仍 `BLOCKED`，不申请上传锁。
