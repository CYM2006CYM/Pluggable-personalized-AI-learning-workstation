# B 岗位 W3-D1 负责人交接单

## 一、B 已交接内容

1. **40 条原始标注**：`final-021`—`final-060`，40/40；SHA-256 保持不变：
   `eaefe9cfbbf8f6144e8299abfc0d82b66cb9ffe8dd1d783e841c5bdfac2690bf`。
2. **两个固定 TaskBundle**：
   - `bundle-act-inspect-dataframe-v2`
   - `bundle-act-practical-v2`
3. **确定性 Rubric 修复**：`act-practical.engineering` 已恢复为 `static_check`，绑定固定 AST 规则、测试引用和安全反馈码；不再使用 `manual_review`。
4. **唯一事实同步**：Bundle 内嵌 activity 与 Profile activity 深相等；Bundle 内嵌 rubric 与 `rubricRef` 文件深相等；测试映射、权重、阻断规则和反馈码已锁定一致。
5. **资产树**：29 项，SHA-256：
   `743e642d212d055fd309352e6c9b0fae0f525106906ad8e88e378c496c9d4b42`。
6. **候选交付包**：[w3-d1-b-rectified-candidate.zip](../../../w3-d1-b-rectified-candidate.zip)。
7. **候选封存材料**：
   - 唯一拟上传候选：[b-final-021-060.seal.candidate.json](b-final-021-060.seal.candidate.json)
   - 原 seal 已移入只读历史归档：[original/audit-only/b-final-021-060.seal.json](original/audit-only/b-final-021-060.seal.json)
   - [候选 manifest](w3-d1-b-candidate-manifest.json)：ZIP 实际 40 文件、登记 39 文件、`selfExcluded=true`
   - [验证证据](w3-d1-b-verification-evidence.md)

## 二、负责人现在必须做什么

请按以下顺序完成并记录 PASS/FAIL：

1. 在 `pi-study-helper/fixtures/profiles/pandas-cleaning-v2-draft` 执行：

   ```text
   python quality/prepare-w3-b-d1-delivery.py --verify
   npm.cmd test -- --run tests/w3-b-d1-delivery.test.ts
   npx tsc --noEmit
   ```

2. 核对候选 seal 的标注 SHA-256、冻结输入 SHA-256、29 项资产树哈希和 `intendedUploadSealPath`。
3. 核对 manifest：ZIP 为 40 文件、登记 39 文件、自身不入哈希、验证证据路径/哈希/长度正确，且拟上传清单与归档/冻结输入分类无混淆。
4. 核对最终拟上传路径只存在候选 seal；历史 seal 只能按 `original/audit-only` 只读材料处理。
5. 完成负责人双封存资格检查，并等待 E 独立封存结果。
6. 只有在 E 独立封存 PASS、负责人双封存资格 PASS、A 释放第一把锁且负责人明确授权后，才能上传候选 ZIP。

## 三、明确禁止

- 不得重写、重排、覆盖 40 条原始标注。
- 不得修改标注 SHA-256：`eaefe9cf...`。
- 不得查看 E 原始标注或机械差异清单。
- 不得把历史 seal 当作当前交付入口。
- 不得在授权条件满足前上传、申请或释放上传锁。

当前交接状态：`BLOCKED — WAITING FOR OWNER AUDIT AND QUALIFICATION GATES`。
