# B 岗位 W3-D1 整改候选封存与校验报告

状态：`BLOCKED`（仅交负责人审计，不构成上传授权）。

## 不变输入

- 范围：`final-021`—`final-060`，40/40 原始标注；未查看 E 原始标注或机械差异清单。
- 标注 SHA-256（UTF-8/LF）：`eaefe9cfbbf8f6144e8299abfc0d82b66cb9ffe8dd1d783e841c5bdfac2690bf`。
- 冻结输入 SHA-256：`b77ba4902003ba20bc5b233c4797838eb26325d1b38fd02bc68ba02206cb1d1c`。

## 本次整改

1. `engineering` Rubric 恢复为 `static_check`；固定 AST 规则、`staticCheckRef` 和安全反馈码，禁止 `manual_review`。
2. Bundle activity 与 `activities/learning-activities.json` 深相等；Bundle rubric 与 `rubricRef` 文件深相等；`dimensionTestMap`、权重、阻断规则和反馈码统一。
3. 原 seal 字节移入 `original/audit-only/` 只读归档；唯一拟上传 seal 为 `b-final-021-060.seal.candidate.json`。
4. 资产树闭合为 29 项，树 SHA-256：`743e642d212d055fd309352e6c9b0fae0f525106906ad8e88e378c496c9d4b42`。
5. manifest 声明 ZIP 实际 40 文件、登记 39 文件、`selfExcluded=true`，并登记验证证据哈希/长度与精确 `intendedGitPaths`。

## 复验命令

```text
python quality/prepare-w3-b-d1-delivery.py --verify
npm.cmd test -- --run tests/w3-b-d1-delivery.test.ts
npx tsc --noEmit
```

## 交付入口

- 候选 ZIP：`w3-d1-b-rectified-candidate.zip`
- 唯一拟上传 seal：`evaluation/golden/annotations/b-final-021-060.seal.candidate.json`
- 历史只读 seal：`evaluation/golden/annotations/original/audit-only/b-final-021-060.seal.json`
- manifest：`evaluation/golden/annotations/w3-d1-b-candidate-manifest.json`
- 验证证据：`evaluation/golden/annotations/w3-d1-b-verification-evidence.md`

上传仍须等待 E 独立封存、负责人双封存资格检查 PASS、A 释放第一把锁及负责人明确授权；本材料不申请上传锁。
