import { createHash } from "node:crypto";
import { readFileSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join, relative, resolve } from "node:path";

const [packageRootArg, outputArg] = process.argv.slice(2);
if (!packageRootArg || !outputArg) {
  throw new Error("usage: node Audit-WebCandidate.mjs <package-root> <output-json>");
}

const packageRoot = resolve(packageRootArg);
const outputPath = resolve(outputArg);
const requireFromPackage = createRequire(join(packageRoot, "package.json"));
const ts = requireFromPackage("typescript");
const sourceRoot = join(packageRoot, "src");
const webRoot = join(sourceRoot, "web");
const mocksPath = join(webRoot, "mocks", "safe-dtos.ts");

function filesUnder(root, predicate) {
  return readdirSync(root).flatMap((name) => {
    const path = join(root, name);
    return statSync(path).isDirectory() ? filesUnder(path, predicate) : predicate(path) ? [path] : [];
  });
}

const webFiles = filesUnder(webRoot, (path) => /\.(?:ts|tsx)$/.test(path));
const nonWebSourceFiles = filesUnder(sourceRoot, (path) => /\.(?:ts|tsx|js|mjs)$/.test(path)).filter(
  (path) => !path.startsWith(`${webRoot}\\`) && !path.startsWith(`${webRoot}/`),
);
const mockSource = readFileSync(mocksPath, "utf8");
const sourceFile = ts.createSourceFile(mocksPath, mockSource, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
const declarations = new Map();

for (const statement of sourceFile.statements) {
  if (!ts.isVariableStatement(statement)) continue;
  for (const declaration of statement.declarationList.declarations) {
    if (ts.isIdentifier(declaration.name) && declaration.initializer) {
      declarations.set(declaration.name.text, declaration.initializer);
    }
  }
}

function unwrap(node) {
  while (
    ts.isAsExpression(node) ||
    ts.isSatisfiesExpression(node) ||
    ts.isParenthesizedExpression(node) ||
    ts.isTypeAssertionExpression(node)
  ) {
    node = node.expression;
  }
  return node;
}

function reachableSources(groupName) {
  const root = declarations.get(groupName);
  if (!root) throw new Error(`missing declaration: ${groupName}`);
  const visited = new Set();
  const names = new Set([groupName]);
  const segments = [];

  function visit(node) {
    const current = unwrap(node);
    if (ts.isIdentifier(current) && declarations.has(current.text)) {
      if (visited.has(current.text)) return;
      visited.add(current.text);
      names.add(current.text);
      visit(declarations.get(current.text));
      return;
    }

    segments.push(current.getText(sourceFile));
    ts.forEachChild(current, visit);
  }

  visit(root);
  return { names: [...names].sort(), text: segments.join("\n") };
}

const forbiddenPatterns = [
  ["correctAnswer", /\bcorrectAnswer\b/i],
  ["hiddenTest", /\bhiddenTests?\b/i],
  ["referenceSolution", /\breferenceSolutions?\b/i],
  ["privateCsv", /\bprivateCsv\b/i],
  ["fullRubric", /(?:完整\s*Rubric|\bfullRubric\b)/i],
  ["systemPrompt", /\bsystemPrompt\b/i],
  ["apiKey", /\bapiKey\b/i],
  ["hostAbsolutePath", /(?:[A-Za-z]:[\\/]|\/(?:Users|home|root|var|tmp)\/)/],
  ["fullProfile", /(?:完整\s*Profile|\bfullProfile\b)/i],
  ["privateRawSubmission", /(?:学习者私人原始提交|\bprivateRawSubmission\b|\blearnerPrivateRawSubmission\b)/i],
];

function scanGroup(groupName) {
  const reachable = reachableSources(groupName);
  const findings = forbiddenPatterns.flatMap(([id, pattern]) =>
    pattern.test(reachable.text) ? [{ id, pattern: pattern.source }] : [],
  );
  return {
    group: groupName,
    reachableDeclarations: reachable.names,
    sourceSha256: createHash("sha256").update(reachable.text, "utf8").digest("hex"),
    forbiddenPatternCount: forbiddenPatterns.length,
    findingCount: findings.length,
    findings,
    status: findings.length === 0 ? "PASS" : "BLOCKED",
  };
}

const facadeScan = scanGroup("FACADE_DTO_MOCKS");
const fixtureScan = scanGroup("PAGE_DISPLAY_FIXTURES");
const combinedWebSource = webFiles.map((path) => readFileSync(path, "utf8")).join("\n");
const capabilityPatterns = [
  ["realHttp", /\bfetch\s*\(|\bXMLHttpRequest\b|\baxios\s*\.|https?:\/\//i],
  ["pyodide", /\bpyodide\b/i],
  ["clientScoreRecalculation", /score\s*\*\s*100|100\s*\*\s*[^\n]*score/i],
  ["clientPassVerdict", /verdict\s*===?\s*["']pass["']|score\s*(?:>=|>)\s*[\d.]+/i],
  ["clientMasteryMutation", /(?:set|update|calculate|compute|derive)\w*Mastery|mastery\s*(?:=|\+=|-=)/i],
  ["clientPathDecision", /(?:calculate|compute|derive|select|replan)\w*Path|path\s*(?:=|\+=)/i],
  ["realRepositoryWrite", /unitOfWork|writeTransaction|rollbackTransaction|repository\.(?:save|write|update|delete)/i],
];
const capabilityFindings = capabilityPatterns.flatMap(([id, pattern]) =>
  pattern.test(combinedWebSource) ? [{ id, pattern: pattern.source }] : [],
);

const nonWebFixtureImports = nonWebSourceFiles.flatMap((path) => {
  const source = readFileSync(path, "utf8");
  return /PAGE_DISPLAY_FIXTURES|ProfileDisplayFixture|DiagnosticQuestionDisplayFixture|LearningCardDisplayFixture/.test(source)
    ? [relative(packageRoot, path).replaceAll("\\", "/")]
    : [];
});

const result = {
  schemaVersion: "w3-d4-e-web-candidate-audit-v1",
  checkedAt: new Date().toISOString(),
  packageRoot,
  sourceFile: relative(packageRoot, mocksPath).replaceAll("\\", "/"),
  facadeDtoMocks: facadeScan,
  pageDisplayFixtures: fixtureScan,
  fixtureLayerBoundary: {
    webRoot: "src/web",
    scannedNonWebSourceFiles: nonWebSourceFiles.length,
    nonWebFixtureImportCount: nonWebFixtureImports.length,
    nonWebFixtureImports,
    status: nonWebFixtureImports.length === 0 ? "PASS" : "BLOCKED",
  },
  forbiddenCapabilities: {
    scannedWebFiles: webFiles.length,
    findingCount: capabilityFindings.length,
    findings: capabilityFindings,
    status: capabilityFindings.length === 0 ? "PASS" : "BLOCKED",
  },
};

result.status = [
  result.facadeDtoMocks.status,
  result.pageDisplayFixtures.status,
  result.fixtureLayerBoundary.status,
  result.forbiddenCapabilities.status,
].every((status) => status === "PASS")
  ? "PASS"
  : "BLOCKED";

writeFileSync(outputPath, `${JSON.stringify(result, null, 2)}\n`, "utf8");
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
if (result.status !== "PASS") process.exitCode = 1;

