param(
    [string]$W3D4Root = 'D:/.A_C_code/PPALW/W3-D4'
)

$ErrorActionPreference = 'Stop'

$payloadParent = Join-Path $W3D4Root 'final-review-payload'
$payloadRoot = Join-Path $payloadParent 'W3-D4-E-final-owner-review'
$zipPath = Join-Path $W3D4Root 'W3-D4-E-final-owner-review.zip'
$zipSidecar = "$zipPath.sha256"
$zipVerification = Join-Path $W3D4Root 'W3-D4-E-final-owner-review.zip-verification.json'
$deliveryReport = Join-Path $W3D4Root 'W3-D4-E-final-delivery-report.md'
$deliveryHashes = Join-Path $W3D4Root 'W3-D4-E-final-delivery-files.sha256'
$remediation = Join-Path $W3D4Root 'final-r2-remediation'
$worktree = Join-Path $W3D4Root 'final-r2-worktree'
$runtimePackage = Join-Path $W3D4Root 'runtime-compat-af738627/review-package/W3-D4-E-runtime-compat-owner-review'
$originalPackage = Join-Path $W3D4Root 'review-package/W3-D4-E-owner-review-BLOCKED'
$d1Root = 'D:/.A_C_code/PPALW/W3-D1'
$d2Root = 'D:/.A_C_code/PPALW/W3-D2'

foreach ($target in @($payloadParent, $zipPath, $zipSidecar, $zipVerification, $deliveryHashes)) {
    if (Test-Path -LiteralPath $target) {
        throw "Refusing to overwrite existing final artifact: $target"
    }
}

function Copy-DirectoryContent {
    param([string]$Source, [string]$Destination)
    New-Item -ItemType Directory -Path $Destination | Out-Null
    Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $Destination -Recurse
    }
}

function Copy-FileTo {
    param([string]$Source, [string]$Destination)
    $parent = Split-Path -Parent $Destination
    if (-not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Path $parent | Out-Null
    }
    Copy-Item -LiteralPath $Source -Destination $Destination
}

New-Item -ItemType Directory -Path $payloadRoot | Out-Null

# Final summaries and tools created by E during this remediation.
Copy-DirectoryContent -Source (Join-Path $remediation 'summary') -Destination (Join-Path $payloadRoot 'summary')
Copy-DirectoryContent -Source (Join-Path $remediation 'tools') -Destination (Join-Path $payloadRoot 'tools')

# D1 owner materials.
New-Item -ItemType Directory -Path (Join-Path $payloadRoot 'd1') | Out-Null
foreach ($name in @('e-final-021-060.jsonl','seal-record.json','input-binding.json','pre-seal-validation.json','independence-declaration.md')) {
    Copy-FileTo -Source (Join-Path $d1Root $name) -Destination (Join-Path $payloadRoot "d1/$name")
}

# Correct D2-R2 frozen package and its published hash/report files.
New-Item -ItemType Directory -Path (Join-Path $payloadRoot 'd2') | Out-Null
foreach ($name in @('W3-D2-E-owner-review-package-r2.zip','W3-D2-E-hashes-r2.sha256','W3-D2-E-delivery-report-r2.md','W3-D2-E-review-record-r2.md')) {
    Copy-FileTo -Source (Join-Path $d2Root $name) -Destination (Join-Path $payloadRoot "d2/$name")
}

# D4 authorization and resolved manifest. These are copied from the original D4 audit package.
Copy-DirectoryContent -Source (Join-Path $originalPackage 'preflight') -Destination (Join-Path $payloadRoot 'preflight')
Copy-FileTo -Source (Join-Path $originalPackage 'resolved-config/W3-D4-resolved-input-manifest.json') -Destination (Join-Path $payloadRoot 'preflight/W3-D4-resolved-input-manifest.json')

# Environment and input recheck from D47 runtime-compatible execution.
Copy-DirectoryContent -Source (Join-Path $runtimePackage 'current-evidence/environment') -Destination (Join-Path $payloadRoot 'environment/raw')
Copy-FileTo -Source (Join-Path $runtimePackage 'summary/environment-summary.json') -Destination (Join-Path $payloadRoot 'environment/environment-summary.json')
Copy-DirectoryContent -Source (Join-Path $runtimePackage 'current-evidence/input-recheck') -Destination (Join-Path $payloadRoot 'input-recheck')

# Preserve only still-valid V3-1, V3-2, V3-4 and V3-7 evidence. Old V3-8 is intentionally excluded.
foreach ($gate in @('V3-1','V3-2','V3-4','V3-7')) {
    Copy-DirectoryContent -Source (Join-Path $runtimePackage "preserved-evidence/v3-execution/$gate") -Destination (Join-Path $payloadRoot "preserved-evidence/v3-execution/$gate")
}
Copy-DirectoryContent -Source (Join-Path $runtimePackage 'preserved-evidence/fixed-trace-demo') -Destination (Join-Path $payloadRoot 'preserved-evidence/fixed-trace-demo')
Copy-FileTo -Source (Join-Path $runtimePackage 'preserved-evidence/original-payload-hashes.sha256') -Destination (Join-Path $payloadRoot 'preserved-evidence/original-payload-hashes.sha256')

# Preserve D47 runtime rechecks for V3-3, V3-4, V3-5, V3-6 and platform compatibility.
Copy-DirectoryContent -Source (Join-Path $runtimePackage 'current-evidence/affected') -Destination (Join-Path $payloadRoot 'runtime-recheck')

# Replace invalid old V3-8 with the bound D2-R2 evidence and rerun outputs.
Copy-DirectoryContent -Source (Join-Path $remediation 'evidence/candidate-binding') -Destination (Join-Path $payloadRoot 'v3-8/candidate-binding')
Copy-DirectoryContent -Source (Join-Path $remediation 'evidence/web-audit') -Destination (Join-Path $payloadRoot 'v3-8/web-audit')
Copy-DirectoryContent -Source (Join-Path $remediation 'evidence/commands') -Destination (Join-Path $payloadRoot 'v3-8/commands')

$statusLines = @(git -C $worktree status --short --untracked-files=all)
$baseline = [ordered]@{
    schemaVersion = 'w3-d4-e-final-repository-baseline-v1'
    capturedAt = (Get-Date).ToString('o')
    worktree = $worktree
    head = (git -C $worktree rev-parse HEAD).Trim()
    originMain = (git -C $worktree rev-parse origin/main).Trim()
    baselineAncestor = $null
    statusShort = $statusLines
    expectedEFileCount = 27
    notCommitted = $true
    notPushed = $true
    uploadLock = 'NOT_REQUESTED'
}
git -C $worktree merge-base --is-ancestor af7386276d8a6e56e5263942b29b53e6d861250c HEAD
$baseline.baselineAncestor = $LASTEXITCODE -eq 0
$baseline | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $payloadRoot 'summary/repository-baseline.json') -Encoding UTF8

$commandRecords = Get-ChildItem -LiteralPath (Join-Path $payloadRoot 'v3-8/commands') -Recurse -Filter '*.evidence.json' |
    Sort-Object FullName |
    ForEach-Object { Get-Content -LiteralPath $_.FullName -Raw | ConvertFrom-Json }
$commandSummary = [ordered]@{
    schemaVersion = 'w3-d4-e-final-affected-command-summary-v1'
    commandCount = @($commandRecords).Count
    nonzeroExitCount = @($commandRecords | Where-Object exitCode -ne 0).Count
    commands = @($commandRecords | ForEach-Object {
        [ordered]@{
            id = $_.id
            command = $_.command
            workingDirectory = $_.workingDirectory
            startedAt = $_.startedAt
            completedAt = $_.completedAt
            exitCode = $_.exitCode
            observedCounts = $_.observedCounts
            stdoutSha256 = $_.stdoutSha256
            stderrSha256 = $_.stderrSha256
        }
    })
}
$commandSummary | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $payloadRoot 'summary/affected-command-summary.json') -Encoding UTF8

# Hash every payload file except the manifest and its recheck, then mechanically verify the directory.
$manifestPath = Join-Path $payloadRoot 'payload-files.sha256'
$recheckPath = Join-Path $payloadRoot 'payload-directory-recheck.json'
$payloadFiles = Get-ChildItem -LiteralPath $payloadRoot -Recurse -File |
    Where-Object { $_.FullName -notin @($manifestPath, $recheckPath) } |
    Sort-Object FullName
$manifestLines = foreach ($file in $payloadFiles) {
    $relativePath = $file.FullName.Substring($payloadRoot.Length + 1).Replace('\', '/')
    $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    "$hash  $relativePath"
}
[System.IO.File]::WriteAllLines($manifestPath, $manifestLines, [System.Text.UTF8Encoding]::new($false))

$mismatches = @()
foreach ($line in Get-Content -LiteralPath $manifestPath -Encoding UTF8) {
    if ($line -notmatch '^([0-9a-f]{64})\s\s(.+)$') { throw "Invalid payload manifest line: $line" }
    $actualPath = Join-Path $payloadRoot $Matches[2]
    $actualHash = (Get-FileHash -LiteralPath $actualPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualHash -ne $Matches[1]) {
        $mismatches += $Matches[2]
    }
}
$directoryRecheck = [ordered]@{
    schemaVersion = 'w3-d4-e-final-payload-directory-recheck-v1'
    checkedAt = (Get-Date).ToString('o')
    manifest = 'payload-files.sha256'
    entriesChecked = $manifestLines.Count
    mismatchCount = $mismatches.Count
    mismatches = $mismatches
    status = if ($mismatches.Count -eq 0) { 'PASS' } else { 'BLOCKED' }
}
$directoryRecheck | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $recheckPath -Encoding UTF8
if ($directoryRecheck.status -ne 'PASS') { throw 'Payload directory recheck failed.' }

Compress-Archive -LiteralPath $payloadRoot -DestinationPath $zipPath -CompressionLevel Optimal
$zipHash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
[System.IO.File]::WriteAllText($zipSidecar, "$zipHash  W3-D4-E-final-owner-review.zip`n", [System.Text.UTF8Encoding]::new($false))

# Recompute listed payload hashes from final ZIP entry streams.
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
try {
    $entryMap = @{}
    foreach ($entry in $zip.Entries) {
        if ([string]::IsNullOrEmpty($entry.Name)) { continue }
        $normalized = $entry.FullName.Replace('\', '/')
        $prefix = 'W3-D4-E-final-owner-review/'
        if ($normalized.StartsWith($prefix)) { $normalized = $normalized.Substring($prefix.Length) }
        $stream = $entry.Open()
        try {
            $sha = [System.Security.Cryptography.SHA256]::Create()
            try { $entryHash = ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
            finally { $sha.Dispose() }
        } finally { $stream.Dispose() }
        $entryMap[$normalized] = $entryHash
    }
} finally { $zip.Dispose() }

$zipMismatches = @()
$zipMissing = @()
foreach ($line in $manifestLines) {
    $null = $line -match '^([0-9a-f]{64})\s\s(.+)$'
    $expectedHash = $Matches[1]
    $relativePath = $Matches[2]
    if (-not $entryMap.ContainsKey($relativePath)) { $zipMissing += $relativePath; continue }
    if ($entryMap[$relativePath] -ne $expectedHash) { $zipMismatches += $relativePath }
}
$zipRecheck = [ordered]@{
    schemaVersion = 'w3-d4-e-final-zip-entry-recheck-v1'
    checkedAt = (Get-Date).ToString('o')
    zip = 'W3-D4-E-final-owner-review.zip'
    zipSha256 = $zipHash
    manifestEntries = $manifestLines.Count
    zipFileEntries = $entryMap.Count
    matchedManifestEntries = $manifestLines.Count - $zipMissing.Count - $zipMismatches.Count
    missingCount = $zipMissing.Count
    mismatchCount = $zipMismatches.Count
    missing = $zipMissing
    mismatches = $zipMismatches
    payloadDirectoryRecheckPresent = $entryMap.ContainsKey('payload-directory-recheck.json')
    status = if ($zipMissing.Count -eq 0 -and $zipMismatches.Count -eq 0) { 'PASS' } else { 'BLOCKED' }
}
$zipRecheck | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $zipVerification -Encoding UTF8
if ($zipRecheck.status -ne 'PASS') { throw 'Final ZIP entry recheck failed.' }

$deliveryFiles = @($zipPath, $zipSidecar, $zipVerification, $deliveryReport)
$deliveryLines = foreach ($file in $deliveryFiles) {
    $hash = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()
    "$hash  $([System.IO.Path]::GetFileName($file))"
}
[System.IO.File]::WriteAllLines($deliveryHashes, $deliveryLines, [System.Text.UTF8Encoding]::new($false))

[ordered]@{
    status = 'PASS'
    payloadFiles = $manifestLines.Count
    zipFileEntries = $entryMap.Count
    zipSha256 = $zipHash
    zipPath = $zipPath
    deliveryHashes = $deliveryHashes
} | ConvertTo-Json -Depth 4

