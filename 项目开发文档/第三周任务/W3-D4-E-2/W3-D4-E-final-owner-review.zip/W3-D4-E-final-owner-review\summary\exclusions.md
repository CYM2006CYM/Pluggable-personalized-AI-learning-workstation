# 最终审核包与Git拟提交排除项

最终审核包不包含：旧审核ZIP、旧5文件61项V3-8证据、`node_modules`、`dist-web`、截图、隔离运行时、下载文件、浏览器profile、OWNER-ONLY材料、B原始标注、机械差异清单、正式gold、SDK源码副本或整个仓库副本。

Git拟提交清单额外排除：本审核ZIP及sidecar、全部stdout/stderr原始日志、运行环境和审核包机械复算文件。日志只用于负责人审计，不是业务仓库拟提交资产。

当前Web候选大部分是未跟踪文件；普通`git diff --check`和只扫描tracked文件的release门禁不能单独覆盖它们。上传锁后必须按白名单暂存并补跑`git diff --cached --check`、`check:release`和`verify`，负责人确认暂存区清单前不得commit或push。

