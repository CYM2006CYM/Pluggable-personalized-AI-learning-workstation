param(
    [Parameter(Mandatory = $true)]
    [string]$WorktreeRoot,

    [Parameter(Mandatory = $true)]
    [string]$FrozenHashList,

    [Parameter(Mandatory = $true)]
    [string]$OutputJson
)

$ErrorActionPreference = "Stop"

$expected = foreach ($line in Get-Content -LiteralPath $FrozenHashList -Encoding UTF8) {
    if ($line -notmatch '^([0-9a-fA-F]{64})\s+(.+)$') {
        continue
    }

    [pscustomobject]@{
        targetRepositoryPath = $Matches[2].Replace('\', '/')
        expectedSha256 = $Matches[1].ToLowerInvariant()
    }
}

$files = foreach ($entry in $expected) {
    $absolutePath = Join-Path $WorktreeRoot $entry.targetRepositoryPath
    $exists = Test-Path -LiteralPath $absolutePath -PathType Leaf
    $actual = if ($exists) {
        (Get-FileHash -LiteralPath $absolutePath -Algorithm SHA256).Hash.ToLowerInvariant()
    } else {
        $null
    }

    [pscustomobject]@{
        targetRepositoryPath = $entry.targetRepositoryPath
        expectedSha256 = $entry.expectedSha256
        actualSha256 = $actual
        exists = $exists
        matched = $exists -and $actual -eq $entry.expectedSha256
    }
}

$candidatePaths = @($expected.targetRepositoryPath)
$actualEPaths = @(
    git -C $WorktreeRoot status --short --untracked-files=all |
        ForEach-Object { $_.Substring(3).Trim().Replace('\', '/') } |
        Where-Object {
            $_ -eq 'pi-study-helper/.gitignore' -or
            $_ -eq 'pi-study-helper/index.html' -or
            $_ -eq 'pi-study-helper/package.json' -or
            $_ -eq 'pi-study-helper/package-lock.json' -or
            $_ -eq 'pi-study-helper/tsconfig.web.json' -or
            $_ -eq 'pi-study-helper/vite.config.ts' -or
            $_ -like 'pi-study-helper/src/web/*' -or
            $_ -like 'pi-study-helper/tests/web/*'
        }
)

$extraEFiles = @($actualEPaths | Where-Object { $_ -notin $candidatePaths } | Sort-Object -Unique)
$missingFromStatus = @($candidatePaths | Where-Object { $_ -notin $actualEPaths })
$missing = @($files | Where-Object { -not $_.exists }).Count
$mismatch = @($files | Where-Object { $_.exists -and -not $_.matched }).Count
$matched = @($files | Where-Object matched).Count
$boundaryPath = Join-Path $WorktreeRoot 'pi-study-helper/tests/web/boundary-contract.test.mjs'

$result = [ordered]@{
    schemaVersion = 'w3-d4-e-d2-r2-worktree-binding-v1'
    checkedAt = (Get-Date).ToString('o')
    baselineCommit = (git -C $WorktreeRoot rev-parse HEAD).Trim()
    worktree = (Resolve-Path -LiteralPath $WorktreeRoot).Path
    frozenHashList = (Resolve-Path -LiteralPath $FrozenHashList).Path
    frozenHashListSha256 = (Get-FileHash -LiteralPath $FrozenHashList -Algorithm SHA256).Hash.ToLowerInvariant()
    candidateFiles = @($expected).Count
    matched = $matched
    missing = $missing
    unexpectedMismatch = $mismatch
    extraEFiles = $extraEFiles.Count
    extraEFilePaths = $extraEFiles
    missingFromGitStatus = $missingFromStatus
    boundaryContractPresent = (Test-Path -LiteralPath $boundaryPath -PathType Leaf)
    files = $files
    status = if (
        @($expected).Count -eq 27 -and
        $matched -eq 27 -and
        $missing -eq 0 -and
        $mismatch -eq 0 -and
        $extraEFiles.Count -eq 0 -and
        $missingFromStatus.Count -eq 0 -and
        (Test-Path -LiteralPath $boundaryPath -PathType Leaf)
    ) { 'PASS' } else { 'BLOCKED' }
}

$parent = Split-Path -Parent $OutputJson
if (-not (Test-Path -LiteralPath $parent)) {
    New-Item -ItemType Directory -Path $parent | Out-Null
}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $OutputJson -Encoding UTF8
$result | ConvertTo-Json -Depth 8

if ($result.status -ne 'PASS') {
    exit 1
}

