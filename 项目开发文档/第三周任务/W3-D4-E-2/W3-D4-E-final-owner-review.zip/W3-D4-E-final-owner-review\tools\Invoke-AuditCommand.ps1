param(
    [Parameter(Mandatory = $true)][string]$Id,
    [Parameter(Mandatory = $true)][string]$Executable,
    [Parameter(Mandatory = $false)][string[]]$CommandArguments = @(),
    [Parameter(Mandatory = $false)][string]$ArgumentsBase64,
    [Parameter(Mandatory = $true)][string]$WorkingDirectory,
    [Parameter(Mandatory = $true)][string]$OutputDirectory
)

$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null

if (-not [string]::IsNullOrWhiteSpace($ArgumentsBase64)) {
    $argumentsJson = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($ArgumentsBase64))
    $decodedArguments = $argumentsJson | ConvertFrom-Json
    $CommandArguments = [string[]]$decodedArguments
}

$stdoutPath = Join-Path $OutputDirectory "$Id.stdout.log"
$stderrPath = Join-Path $OutputDirectory "$Id.stderr.log"
$evidencePath = Join-Path $OutputDirectory "$Id.evidence.json"
$commandText = $Executable + " " + (($CommandArguments | ForEach-Object {
    if ($_ -match '\s') { '"' + $_.Replace('"', '\"') + '"' } else { $_ }
}) -join " ")

$startedAt = [DateTimeOffset]::Now
Push-Location $WorkingDirectory
try {
    $previousErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    & $Executable @CommandArguments 1> $stdoutPath 2> $stderrPath
    $exitCode = $LASTEXITCODE
    $ErrorActionPreference = $previousErrorActionPreference
} finally {
    Pop-Location
}
$completedAt = [DateTimeOffset]::Now

$stdoutHash = (Get-FileHash -LiteralPath $stdoutPath -Algorithm SHA256).Hash.ToLowerInvariant()
$stderrHash = (Get-FileHash -LiteralPath $stderrPath -Algorithm SHA256).Hash.ToLowerInvariant()
$stdout = Get-Content -LiteralPath $stdoutPath -Raw

$testFilesPassed = $null
$testFilesFailed = $null
$testsPassed = $null
$testsFailed = $null
$testsSkipped = $null
if ($stdout -match 'Test Files\s+(\d+) passed') { $testFilesPassed = [int]$Matches[1] }
if ($stdout -match 'Test Files\s+(?:\d+ passed[^\r\n]*\|\s*)?(\d+) failed') { $testFilesFailed = [int]$Matches[1] }
if ($stdout -match 'Tests\s+(\d+) passed') { $testsPassed = [int]$Matches[1] }
if ($stdout -match 'Tests\s+(?:\d+ passed[^\r\n]*\|\s*)?(\d+) failed') { $testsFailed = [int]$Matches[1] }
if ($stdout -match 'Tests\s+[^\r\n]*?(\d+) skipped') { $testsSkipped = [int]$Matches[1] }

$evidence = [ordered]@{
    schemaVersion = "w3-d47-runtime-compat-command-evidence-v1"
    id = $Id
    command = $commandText
    executable = $Executable
    arguments = $CommandArguments
    workingDirectory = $WorkingDirectory
    startedAt = $startedAt.ToString("o")
    completedAt = $completedAt.ToString("o")
    durationMs = [math]::Round(($completedAt - $startedAt).TotalMilliseconds)
    exitCode = $exitCode
    stdoutFile = [System.IO.Path]::GetFileName($stdoutPath)
    stdoutSha256 = $stdoutHash
    stderrFile = [System.IO.Path]::GetFileName($stderrPath)
    stderrSha256 = $stderrHash
    observedCounts = [ordered]@{
        testFilesPassed = $testFilesPassed
        testFilesFailed = $testFilesFailed
        testsPassed = $testsPassed
        testsFailed = $testsFailed
        testsSkipped = $testsSkipped
    }
}
$evidence | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $evidencePath -Encoding utf8

Write-Output ($evidence | ConvertTo-Json -Depth 8)
exit $exitCode
