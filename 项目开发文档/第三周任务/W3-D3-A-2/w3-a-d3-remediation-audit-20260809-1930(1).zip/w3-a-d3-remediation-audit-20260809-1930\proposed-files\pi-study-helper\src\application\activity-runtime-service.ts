import type { ActivityResult } from "../domain/v2-types.js";
import type {
  CodeEvaluationPort,
  EvaluationActivityProjection,
  EvaluationEnvironmentProjection,
  PreparedEvaluation,
} from "../infrastructure/code-evaluation-port.js";
import type {
  ActivityRepository,
  PrepareActivityRunInput,
  PreparedActivityRun,
  RecordActivityResultInput,
} from "../repositories/activity-repository.js";
import { EvaluationPreparationError, EvaluationRunError } from "../infrastructure/code-evaluation-port.js";

export interface ActivityRunPreparationInput extends PrepareActivityRunInput {
  activity: EvaluationActivityProjection;
  taskVersion: string;
  environment: EvaluationEnvironmentProjection;
  assetBundleHash: string;
}

export interface PreparedFormalActivityRun extends PreparedActivityRun {
  prepared: PreparedEvaluation;
}

export interface ActivitySubmissionInput extends RecordActivityResultInput {
  prepared: PreparedEvaluation;
}

/** Application boundary between C's public evaluator port and A's repository. */
export class ActivityRuntimeService {
  constructor(private readonly repository: ActivityRepository, private readonly evaluator: CodeEvaluationPort) {}

  async prepareActivityRun(input: ActivityRunPreparationInput): Promise<PreparedFormalActivityRun> {
    const prepared = await this.evaluator.prepare({
      activity: input.activity,
      profileRevision: input.profileRevision,
      taskVersion: input.taskVersion,
      mode: input.mode,
      environment: input.environment,
      assetBundleHash: input.assetBundleHash,
    });
    const run = await this.repository.prepareRun(input);
    return { ...run, prepared };
  }

  async submitActivity(input: ActivitySubmissionInput, signal: AbortSignal): Promise<Awaited<ReturnType<ActivityRepository["recordResult"]>>> {
    let result: ActivityResult;
    try {
      result = await this.evaluator.run({
        requestId: input.requestId,
        attemptId: input.attemptId,
        prepared: input.prepared,
        code: input.code,
      }, signal);
    } catch (error) {
      if (error instanceof EvaluationRunError) {
        result = {
          executionStatus: "failed",
          verdict: "not_graded",
          errorKind: "evaluator",
          errorCode: error.errorCode,
          safeFeedback: "The evaluator rejected this idempotency binding; no learning fact was created.",
          evaluatorVersion: "unknown",
          environmentHash: input.prepared.environmentHash,
          assetBundleHash: input.prepared.assetBundleHash,
        };
      } else throw error;
    }
    return this.repository.recordResult({ ...input, result });
  }

  /** Converts preparation failures into non-graded failure records. */
  async recordPreparationFailure(input: RecordActivityResultInput, error: unknown): Promise<Awaited<ReturnType<ActivityRepository["recordResult"]>>> {
    if (!(error instanceof EvaluationPreparationError)) throw error;
    const result: ActivityResult = {
      executionStatus: "failed",
      verdict: "not_graded",
      errorKind: "evaluator",
      errorCode: error.errorCode,
      safeFeedback: "The formal evaluator could not be prepared; the draft remains available.",
      evaluatorVersion: "unknown",
      environmentHash: input.result.environmentHash,
      assetBundleHash: input.assignment.assetBundleHash,
    };
    return this.repository.recordResult({ ...input, result });
  }
}
