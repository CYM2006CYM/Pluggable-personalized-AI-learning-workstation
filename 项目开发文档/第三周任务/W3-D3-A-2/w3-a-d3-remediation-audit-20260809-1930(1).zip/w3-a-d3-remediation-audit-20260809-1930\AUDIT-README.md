# W3-D3 A Remediation Audit Candidate

Execution record: `W3-D36-PROFILE-ACTIVATION-1`  
Contract: `W3-C5/W3-R2`  
HEAD/origin/main: `bd1b599524ef2e3362d14a422d97debbf240f70f`

## Remediated blockers

1. Cross-repository recovery previously discarded the Activity Attempt although the session repository retained a durable recoverable transaction candidate. The UnitOfWork now retains the Attempt while that candidate exists; successful recovery publishes the session candidate then marks the exact Attempt committed once.
2. Session commit previously checked Evidence ID uniqueness only inside the incoming batch. It now rejects an ID already present in the committed snapshot before writing or advancing versions.

## Deterministic verification

- A explicit selection: 15 files, 132 passed, 0 failed, exit `0`.
- Cross-repository recovery and Evidence de-duplication: 2 files, 36 passed, 0 failed, exit `0`.
- `npm.cmd run typecheck`: exit `0`.
- `npm.cmd run check:docs`: exit `0`, 49 Markdown files checked.
- `git diff --check`: exit `0`; CRLF conversion warning only, no diff error.

Injected recovery points: `evidence_written`, `knowledge_state_written`, `path_written`, `checkpoint_written`. Each retains the old public checkpoint on initial failure; recovery leaves exactly one Attempt (with `committedAt`), Evidence, KnowledgeState, path and checkpoint. Duplicate recovery and same-request retry do not create a second fact.

## Scope and remaining risk

Python evaluator integration, real Key, online model and fixed-trace Demo were not run by design under D47 A deterministic-layer scope. The remaining risk is crash behavior after an operating-system-level failure outside the tested atomic file-replace boundaries; no production database or queue was introduced.

`NOT_COMMITTED`  
`NOT_PUSHED`  
Upload lock not requested.
