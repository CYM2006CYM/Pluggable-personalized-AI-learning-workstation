import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve } from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { ActivityRuntimeService } from "../src/application/activity-runtime-service.js";
import { FixtureCodeEvaluationAdapter } from "../src/infrastructure/code-evaluation-port.js";
import { FileActivityRepository } from "../src/repositories/file-activity-repository.js";

const roots: string[] = [];
afterEach(async () => { await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true }))); });

describe("D3 ActivityRuntimeService", () => {
  it("uses C's public port and persists only its public ActivityResult", async () => {
    const root = await mkdtemp(resolve(tmpdir(), "w3-d3-runtime-")); roots.push(root);
    const repository = new FileActivityRepository({ dataRoot: root });
    const hash = `sha256:${"a".repeat(64)}`;
    const assignment = { assignmentId: "assignment-1", activityId: "act-inspect-dataframe", activityVersion: 2, profileRevision: 2, primaryKnowledgePointId: "kp-dataframe", kind: "code_completion" as const, source: "fixed" as const, assetBundleHash: hash, environmentId: "env-python-pandas-candidate" };
    await repository.openActivity({ subjectId: "pandas", sessionId: "session-1", requestId: "open-1", assignment, attemptId: "attempt-1" });
    await repository.saveDraft({ subjectId: "pandas", sessionId: "session-1", requestId: "draft-1", activityId: assignment.activityId, attemptId: "attempt-1", activityVersion: 2, profileRevision: 2, draftVersion: 1, code: "print(1)" });
    const evaluator = new FixtureCodeEvaluationAdapter({ resultsByActivityId: {
      "act-inspect-dataframe": { executionStatus: "completed", verdict: "pass", score: 1, safeFeedback: "ok", evaluatorVersion: "C-formal", environmentHash: `sha256:${"b".repeat(64)}`, assetBundleHash: hash },
    } });
    const service = new ActivityRuntimeService(repository, evaluator);
    const prepared = await service.prepareActivityRun({ subjectId: "pandas", sessionId: "session-1", requestId: "run-1", activityId: assignment.activityId, attemptId: "attempt-1", activityVersion: 2, profileRevision: 2, draftVersion: 2, mode: "submit", activity: { activityId: assignment.activityId, kind: assignment.kind, profileRevision: 2, templateVersion: "v2", environmentRef: assignment.environmentId }, taskVersion: "v2", environment: { environmentId: assignment.environmentId, status: "measured", environmentHash: `sha256:${"b".repeat(64)}`, prototypeEvidenceRef: "d40" }, assetBundleHash: hash });
    const submitted = await service.submitActivity({ subjectId: "pandas", sessionId: "session-1", sessionVersion: 1, requestId: "submit-1", attemptId: "attempt-1", activityId: assignment.activityId, activityVersion: 2, profileRevision: 2, assignment, draftVersion: 2, code: "print(1)", prepared: prepared.prepared, result: { executionStatus: "not_started", verdict: "not_graded", safeFeedback: "unused", evaluatorVersion: "unused", environmentHash: `sha256:${"b".repeat(64)}`, assetBundleHash: hash } }, new AbortController().signal);
    expect(submitted).toMatchObject({ attempt: { attemptId: "attempt-1" }, result: { verdict: "pass" } });
  });
});
