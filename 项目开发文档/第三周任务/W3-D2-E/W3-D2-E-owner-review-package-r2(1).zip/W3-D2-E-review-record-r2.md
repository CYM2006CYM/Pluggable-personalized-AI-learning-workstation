# W3-D2 岗位 E 独立整改复测与审核记录 R2

```text
contractVersion = W3-C4/W3-R2
deliveryStage = W3-D2
E_W3_D2 = PASS
fullV3Status = NOT_RUN_D2
gitStatus = NOT_COMMITTED / NOT_PUSHED
```

## 1. 执行前审计

| 检查 | 实际结果 |
| --- | --- |
| `git fetch origin main` | exit 0 |
| `HEAD` | `a0730d667a9429e395e92f687dbf6b2e0e0db179` |
| `origin/main` | `a0730d667a9429e395e92f687dbf6b2e0e0db179` |
| `6773d99...` 为 HEAD 祖先 | exit 0 |
| 原工作区保护 | 旧候选未 pull、未覆盖；在独立干净 worktree 应用 E 文件 |
| 迁移完整性 | 27/27 文件 SHA-256 一致 |
| 候选权限范围 | 仅 `pi-study-helper` 下 27 个 E 前端/测试/依赖文件 |

执行前已重新阅读 20 号 D42/D43/D46、21 号前端安全 DTO、34 号总调度、35 号第 9 节、40 号 E 任务书和 `W3-D2-负责人前端最小裁决.md`。现行合同按 `W3-C4/W3-R2` 执行。

## 2. 最终命令原始结论

| 顺序 | 命令 | Exit | 原始统计 |
| ---: | --- | ---: | --- |
| 1 | `npm.cmd ci` | 0 | added 268 packages |
| 2 | `npm.cmd run typecheck` | 0 | `tsc --noEmit`、test 与 web 配置通过 |
| 3 | `npm.cmd run test:web` | 0 | Test Files 6 passed；Tests 81 passed |
| 4 | `npm.cmd run build:web` | 0 | Vite 7.1.7；45 modules transformed |
| 5 | `npm.cmd run check:docs` | 0 | 49 个 Markdown 链接有效 |
| 6 | `npm.cmd run check:release` | 0 | 282 tracked files，无 private data/secrets |
| 7 | `git diff --check` | 0 | 无输出 |

本轮未运行 `npm run verify`，因为 D2 合同不要求以其他岗位或机器环境门禁替代本岗位结论；未运行 V3-1 至 V3-8、gold 验证或 Go/No-Go。

## 3. 功能与反例审计

| 范围 | 结果 |
| --- | --- |
| 六页直接路由 | `/`、diagnostic、path、带 nodeId 的 learn、activity、summary 全部匹配 |
| 学习路由反例 | `/learn/session-demo-001` 只匹配通配页，不识别为学习页 |
| 路由参数 | Learn DOM 同时绑定 `sessionId` 与 `nodeId` |
| 六页五状态 | ready/empty/error/conflict/recovery 内容和主要操作均验证 |
| 活动四阶段 | draft/running/submitted/safe_feedback 均验证 |
| 提交分数 | mock 严格 `0.78`，DOM 为 `0.78 / 1`，无 `78 / 100` |
| 草稿保持 | 唯一草稿经过 conflict/error/recovery、开始页恢复和路由返回后逐字相同 |
| 交互方法 | textarea input 与按钮 click 均为真实 DOM 事件 |
| DTO 分层 | `FACADE_DTO_MOCKS` 与 `PAGE_DISPLAY_FIXTURES` 独立导出且不混用 |
| Web 层边界 | 页面 fixture 非 Web 层导入数 0 |

## 4. 冻结依赖和禁止能力

- `npm ls --depth=0`：React 18.3.1、React DOM 18.3.1、React Router DOM 6.30.1、Zustand 5.0.14、Vite 7.1.7、React plugin 5.0.4、jsdom 26.1.0、TypeScript 5.9.3、Vitest 4.1.10，退出码 0。
- SDK：`pi-loop-graph-sdk@0.2.0`，resolved commit 为 `401d3e9bfa49e630196caefbabd732a3209b17a0`。
- `package.json.allowScripts` 和 lock 根节点 `allowScripts` 均不存在，未执行 `npm audit fix`。
- package 直接依赖集合由测试精确断言，无白名单外新增依赖。
- Web 源码禁止词/能力扫描：所有敏感类别、真实 HTTP/`fetch`、Pyodide、审核页、客户端分数/PASS 计算、repository/transaction 操作均为 0。
- 构建 AST 扫描：`EXECUTABLE_FETCH_CALLS=0`，退出码 0。

## 5. 视觉复验记录

| 证据 | 视口/状态 | 结论 |
| --- | --- | --- |
| `desktop-start-r2.png` | 1440x900 / 开始 | PASS |
| `desktop-diagnostic-r2.png` | 1440x900 / 诊断 | PASS |
| `desktop-path-r2.png` | 1440x900 / 路径 | PASS |
| `desktop-learn-r2.png` | 1440x900 / 学习 | PASS |
| `desktop-activity-r2.png` | 1440x900 / 活动 | PASS |
| `desktop-summary-r2.png` | 1440x900 / 总结 | PASS |
| `mobile-start-r2.png` | 390x844 / 开始 | PASS |
| `mobile-path-r2.png` | 390x844 / 路径 | PASS |
| `mobile-activity-r2.png` | 390x844 / 活动 | PASS |
| `desktop-submitted-score-r2.png` | submitted / `0.78 / 1` | PASS |
| `desktop-recovery-entered-r2.png` | 检查点进入 recovery | PASS |
| `desktop-recovery-completed-r2.png` | 完整检查点恢复后 ready | PASS |

浏览器机械测量：390px 下六条路由的 `document.documentElement.scrollWidth` 与 `innerWidth` 均为 390；页面级横向溢出 0；主要交互控件越界 0；五个状态按钮均为 `45x34`。人工检查未发现文字、按钮、导航、状态控件重叠或最长文本溢出。

截图所用整改构建与最终工作树实际构建的三个产物哈希 3/3 一致：

```text
index.html                E906C06030DCE51348052DDB751A4192B2C082EB47F535AA88BAB25F3135C2F2
assets/index-CwgAyRfJ.css 56F6438B8F8217CE8DDA3B9F371F34E1791260F805F152AB4BB8167B03CF0E36
assets/index-BvgwsVxh.js  D7816C42A4CCB76F9CD9B2EC40E4FA41942DC9F0D028FE2586763098A863C319
```

## 6. 历史失败信息

- 旧 61 项套件本身通过，但不足以覆盖 D46。
- 增加 D46 反例后的首次结果为 6 个文件、77 项、19 项失败；失败集中于分数尺度、nodeId 路由、恢复闭环、受控草稿和 DTO/fixture 分层。
- 完成 E 文件整改并补足交互/边界用例后，最终为 6 个文件、81/81 项通过。
- 旧工作树曾因自行启动的 Vite 服务占用 `esbuild.exe` 导致一次 `npm ci` EPERM；停止该服务后恢复。本最终工作树首次 `npm ci` 即通过。

上述内容仅用于审计整改过程，不改变当前 `E_W3_D2=PASS` 结论。

## 7. 包内容审计规则

新 R2 ZIP 只包含 27 个 E 候选文件、12 张 R2 截图、本报告、交付报告和 SHA-256 清单。包内 `W3-D2-E-payload-hashes-r2.sha256` 对除清单自身外的 41 个 payload 逐文件登记；包外 `W3-D2-E-hashes-r2.sha256` 登记 ZIP 外层哈希和 ZIP 内全部 42 个条目。打包后重新解压到独立目录并机械复算，要求全部一致。

明确不包含：旧 ZIP、`node_modules`、`dist-web`、日志、浏览器 profile、仓库副本、D1 标注、B/E 原始封存、机械差异、正式 gold、A/B/C/D 文件、SDK 源码或合同文档。
