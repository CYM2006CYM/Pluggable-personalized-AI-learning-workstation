# W3-D1 岗位 E 负责人审核交接单

## 审核入口

主审核文件：`e-final-021-060.jsonl`

配套证据：

1. `independence-declaration.md`：独立性与封存声明；
2. `input-binding.json`：冻结输入、执行基线和规则资产绑定；
3. `pre-seal-validation.json`：封存前覆盖与 Schema 校验；
4. `seal-record.json`：输出哈希及封存状态；
5. `build-e-annotations.mjs`：可复算生成过程。

## 已完成检查

- 覆盖：`40/40`；
- caseId：`final-021` 至 `final-060`，稳定顺序，无缺失、重复或越界；
- annotatorRole：40 行全部为 `E`；
- JSONL：40 行均可独立解析为合法 JSON；
- 顶层 Schema：字段集合与 E 标注合同一致；
- 节点约束：知识点引用、难度、脚手架枚举和 required/skippable 标志均合法；
- 逐例一致性：回补知识点与 `nodeConstraints` 完全对应，并由冻结诊断输入重新推导通过；
- 禁止行为：40 例均为合同规定的四项禁止行为；
- 输入绑定：冻结输入 SHA-256 与登记值一致；
- 输出封存：实际 SHA-256 与封存记录一致；
- 独立性：未读取 B 标注、正式系统输出、机械差异清单或 gold 候选。

独立终检结果：`PASS`。终检统计为 40 行、40 个唯一 caseId、200 条节点约束、0 个错误。

## 负责人复核值

- 执行 HEAD：`2db7127bcd22035951474ddd3f86de4e8cfa77be`
- 冻结输入 SHA-256：`4fcc7c3e2c605f912890ddec5af7d4fa875c861d1636dcaf425a63ddb17f4b9d`
- E 标注 SHA-256：`af450ede185be215e12e5d13688ebc7b34cb3af9816f50803e5612c2219da266`
- 当前状态：`SEALED / NOT_COMMITTED / NOT_PUSHED`

负责人应先核对上述三项绑定值，再按合同执行独立性、Schema、覆盖和封存资格审计。当前材料位于 Git 仓库外，不包含待提交改动。
