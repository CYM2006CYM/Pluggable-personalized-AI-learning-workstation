import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const args = new Map();
for (let index = 2; index < process.argv.length; index += 2) {
  args.set(process.argv[index], process.argv[index + 1]);
}

const repoRoot = resolve(args.get("--repo") ?? "");
const headCommit = args.get("--head");
if (!repoRoot || !headCommit) {
  throw new Error("Usage: node build-e-annotations.mjs --repo <path> --head <commit>");
}

const profileRoot = resolve(
  repoRoot,
  "pi-study-helper/fixtures/profiles/pandas-cleaning-v2-draft",
);
const final60Path = resolve(repoRoot, "evaluation/personas/final-60.jsonl");
const questionPath = resolve(profileRoot, "assessments/diagnostic/questions.json");
const answerKeyPath = resolve(
  profileRoot,
  "assessments/diagnostic/private/answer-key.json",
);
const knowledgePath = resolve(profileRoot, "knowledge/knowledge-points.json");
const activitiesPath = resolve(profileRoot, "activities/learning-activities.json");

const OUTPUT_PATH = resolve("e-final-021-060.jsonl");
const BINDING_PATH = resolve("input-binding.json");
const VALIDATION_PATH = resolve("pre-seal-validation.json");
const SEAL_PATH = resolve("seal-record.json");

const FORBIDDEN_ACTIONS = [
  "skip_unverified_prerequisite",
  "omit_required_node",
  "violate_prerequisite_order",
  "exceed_time_budget",
];
const EXPECTED_FIELDS = [
  "caseId",
  "annotatorRole",
  "nodeConstraints",
  "requiredRemediationKnowledgePointIds",
  "forbiddenActions",
  "notes",
];
const PERSONA_LABELS = {
  self_learner: "自学者",
  practice_oriented: "实践导向学习者",
};

function sha256(buffer) {
  return createHash("sha256").update(buffer).digest("hex");
}

function parseJsonLines(text, source) {
  return text.split(/\r?\n/u).filter((line) => line.length > 0).map((line, index) => {
    try {
      return JSON.parse(line);
    } catch (error) {
      throw new Error(`${source}:${index + 1} is not valid JSON: ${error.message}`);
    }
  });
}

function equalJson(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}

function expectedCaseId(index) {
  return `final-${String(index).padStart(3, "0")}`;
}

const final60Bytes = await readFile(final60Path);
const final60Text = final60Bytes.toString("utf8");
const allCases = parseJsonLines(final60Text, "final-60.jsonl");
const questionsAsset = JSON.parse(await readFile(questionPath, "utf8"));
const answerKeyAsset = JSON.parse(await readFile(answerKeyPath, "utf8"));
const knowledgeAsset = JSON.parse(await readFile(knowledgePath, "utf8"));
const activitiesAsset = JSON.parse(await readFile(activitiesPath, "utf8"));

if (allCases.length !== 60) throw new Error("Frozen final-60 input must contain 60 cases");
const cases = allCases.slice(20, 60);
const questionById = new Map(questionsAsset.questions.map((item) => [item.questionId, item]));
const answerById = new Map(answerKeyAsset.answers.map((item) => [item.questionId, item.correctAnswer]));
const knowledgeById = new Map(knowledgeAsset.knowledgePoints.map((item) => [item.id, item]));
const activityByKnowledgePoint = new Map(
  activitiesAsset.activities.map((item) => [item.primaryKnowledgePointId, item]),
);
const knowledgeOrder = knowledgeAsset.knowledgePoints.map((item) => item.id);

const annotations = cases.map((item, caseIndex) => {
  const expectedId = expectedCaseId(caseIndex + 21);
  if (item.caseId !== expectedId) {
    throw new Error(`Expected ${expectedId}, received ${item.caseId}`);
  }
  if (!(item.personaType in PERSONA_LABELS)) {
    throw new Error(`${item.caseId} has an unexpected personaType`);
  }
  if (!Array.isArray(item.diagnosticAnswers) || item.diagnosticAnswers.length !== questionsAsset.questions.length) {
    throw new Error(`${item.caseId} must cover every diagnostic question exactly once`);
  }

  const seenQuestions = new Set();
  const remediationSet = new Set();
  let wrongCount = 0;
  let skippedCount = 0;

  for (const answer of item.diagnosticAnswers) {
    if (seenQuestions.has(answer.questionId)) {
      throw new Error(`${item.caseId} repeats ${answer.questionId}`);
    }
    seenQuestions.add(answer.questionId);
    const question = questionById.get(answer.questionId);
    if (!question || !answerById.has(answer.questionId)) {
      throw new Error(`${item.caseId} references an unknown diagnostic question`);
    }
    if (answer.action === "skip") {
      skippedCount += 1;
      remediationSet.add(question.knowledgePointId);
      continue;
    }
    if (answer.action !== "answer" || !equalJson(answer.answer, answerById.get(answer.questionId))) {
      wrongCount += 1;
      remediationSet.add(question.knowledgePointId);
    }
  }

  const remediationIds = knowledgeOrder.filter((id) => remediationSet.has(id));
  const nodeConstraints = remediationIds.map((knowledgePointId) => {
    const activity = activityByKnowledgePoint.get(knowledgePointId);
    if (!knowledgeById.has(knowledgePointId) || !activity) {
      throw new Error(`No frozen activity constraint exists for ${knowledgePointId}`);
    }
    return {
      knowledgePointId,
      required: true,
      allowedDifficulties: [activity.difficulty],
      allowedScaffoldLevels: [...activity.allowedScaffolds],
      skippable: false,
    };
  });

  const personaLabel = PERSONA_LABELS[item.personaType];
  const titles = remediationIds.map((id) => knowledgeById.get(id).title).join("、");
  const notes = remediationIds.length === 0
    ? `独立标注：${personaLabel}本例八项诊断均正确，冻结输入未显示需要立即补救的知识点。`
    : `独立标注：${personaLabel}本例有${wrongCount}项错误、${skippedCount}项跳过；按冻结先修顺序补救${titles}，并遵守${item.availableMinutes}分钟预算。`;

  return {
    caseId: item.caseId,
    annotatorRole: "E",
    nodeConstraints,
    requiredRemediationKnowledgePointIds: remediationIds,
    forbiddenActions: [...FORBIDDEN_ACTIONS],
    notes,
  };
});

const validationErrors = [];
const actualIds = annotations.map((item) => item.caseId);
const expectedIds = Array.from({ length: 40 }, (_, index) => expectedCaseId(index + 21));
if (!equalJson(actualIds, expectedIds)) validationErrors.push("caseId coverage or order mismatch");
if (new Set(actualIds).size !== 40) validationErrors.push("duplicate caseId");

for (const item of annotations) {
  if (!equalJson(Object.keys(item), EXPECTED_FIELDS)) validationErrors.push(`${item.caseId}: field set mismatch`);
  if (item.annotatorRole !== "E") validationErrors.push(`${item.caseId}: annotatorRole mismatch`);
  if (!equalJson(item.requiredRemediationKnowledgePointIds, item.nodeConstraints.map((node) => node.knowledgePointId))) {
    validationErrors.push(`${item.caseId}: remediation/node mismatch`);
  }
  if (!equalJson(item.forbiddenActions, FORBIDDEN_ACTIONS)) validationErrors.push(`${item.caseId}: forbiddenActions mismatch`);
  if (typeof item.notes !== "string" || item.notes.length === 0) validationErrors.push(`${item.caseId}: notes missing`);
  for (const node of item.nodeConstraints) {
    const activity = activityByKnowledgePoint.get(node.knowledgePointId);
    if (!activity
      || node.required !== true
      || node.skippable !== false
      || !equalJson(node.allowedDifficulties, [activity.difficulty])
      || !equalJson(node.allowedScaffoldLevels, activity.allowedScaffolds)) {
      validationErrors.push(`${item.caseId}: invalid constraint for ${node.knowledgePointId}`);
    }
  }
}

if (validationErrors.length > 0) {
  throw new Error(`Annotation validation failed:\n${validationErrors.join("\n")}`);
}

const outputText = `${annotations.map((item) => JSON.stringify(item)).join("\n")}\n`;
const outputBytes = Buffer.from(outputText, "utf8");
const outputSha256 = sha256(outputBytes);
const normalizedFinal60Sha256 = sha256(Buffer.from(final60Text.replace(/\r\n?/gu, "\n"), "utf8"));
const generatedAt = new Date().toISOString();

const inputBinding = {
  schemaVersion: "e-w3-d1-input-binding-v1",
  contract: "W3-C3/W3-R2",
  w3StartCommit: "f190326a4a906b46e4001484ffa30a7839b82ed2",
  executionHead: headCommit,
  profileRevision: 2,
  input: {
    path: "evaluation/personas/final-60.jsonl",
    caseRange: { first: "final-021", last: "final-060", count: 40 },
    rawByteSha256: sha256(final60Bytes),
    normalizedTextSha256: normalizedFinal60Sha256,
    byteLength: final60Bytes.byteLength,
  },
  ruleAssets: [
    "assessments/diagnostic/questions.json",
    "assessments/diagnostic/private/answer-key.json",
    "knowledge/knowledge-points.json",
    "activities/learning-activities.json",
  ],
  generatedAt,
};

const validation = {
  schemaVersion: "e-w3-d1-pre-seal-validation-v1",
  status: "PASS",
  executionHead: headCommit,
  checks: {
    jsonlSyntax: "PASS",
    lineCount: 40,
    stableCaseOrder: "final-021..final-060",
    uniqueCaseIds: 40,
    annotatorRoleE: 40,
    exactFieldSet: "PASS",
    nodeConstraintSchema: "PASS",
    frozenEnumUsage: "PASS",
    inputBinding: "PASS",
  },
  counts: {
    selfLearner: annotations.filter((item) => Number(item.caseId.slice(-3)) <= 40).length,
    practiceOriented: annotations.filter((item) => Number(item.caseId.slice(-3)) >= 41).length,
    noImmediateRemediation: annotations.filter((item) => item.nodeConstraints.length === 0).length,
    remediationRequired: annotations.filter((item) => item.nodeConstraints.length > 0).length,
  },
  inputSha256: sha256(final60Bytes),
  outputSha256,
  validatedAt: generatedAt,
};

const sealRecord = {
  schemaVersion: "e-w3-d1-seal-v1",
  status: "SEALED",
  file: "e-final-021-060.jsonl",
  sha256: outputSha256,
  byteLength: outputBytes.byteLength,
  lineCount: 40,
  firstCaseId: "final-021",
  lastCaseId: "final-060",
  sealedAt: generatedAt,
  commitStatus: "NOT_COMMITTED",
  pushStatus: "NOT_PUSHED",
};

await writeFile(OUTPUT_PATH, outputBytes, { flag: "wx" });
await writeFile(BINDING_PATH, `${JSON.stringify(inputBinding, null, 2)}\n`, { flag: "wx" });
await writeFile(VALIDATION_PATH, `${JSON.stringify(validation, null, 2)}\n`, { flag: "wx" });
await writeFile(SEAL_PATH, `${JSON.stringify(sealRecord, null, 2)}\n`, { flag: "wx" });

process.stdout.write(`${JSON.stringify({ output: OUTPUT_PATH, sha256: outputSha256, status: "SEALED" })}\n`);
