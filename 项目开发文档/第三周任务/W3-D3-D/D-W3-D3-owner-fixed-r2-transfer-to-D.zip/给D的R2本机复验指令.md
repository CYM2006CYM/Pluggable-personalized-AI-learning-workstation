# D岗位W3-D3 R2本机复验指令

负责人已在R1基础上完成唯一剩余整改：同步`validate-w3-materials.mjs`的Windows盘符、UNC、`/home`、`/tmp`、Bearer和凭据赋值扫描，并加入6个固定canary。除验证脚本和`candidate-manifest.sha256`外，其余7个正式文件保持R1原字节。

候选包：`D-W3-D3-rectified-candidate-r2.zip`

SHA-256：`8b61d7330433cc4dad9e2fa819a0c4bd1282d4dc6dbcfff8d64e88928b65306c`

请不要修改候选内容。先在你的正式仓库执行：

```powershell
git fetch origin main
git pull --ff-only origin main
git rev-parse HEAD
git rev-parse origin/main
git status --short
```

确认起点后，将候选包中的`pi-study-helper/`按原路径覆盖到仓库，再从`pi-study-helper`运行：

```powershell
node fixtures/model-responses/w3/validate-w3-materials.mjs
npx vitest run fixtures/model-responses/w3/offline-dynamic-question.test.ts --maxWorkers=1 --fileParallelism=false
npm.cmd run typecheck
git diff --check
```

预期：材料验证`PASS`且`sensitivePatternCanaries=6`，D定向测试`23/23`，typecheck和`git diff --check`退出码均为0。

拟提交只允许以下9项：

```text
pi-study-helper/fixtures/model-prompts/w3/dynamic-objective-question.md
pi-study-helper/fixtures/model-prompts/w3/model-configuration.json
pi-study-helper/fixtures/model-responses/w3/candidate-manifest.sha256
pi-study-helper/fixtures/model-responses/w3/d1-handoff.md
pi-study-helper/fixtures/model-responses/w3/offline-dynamic-question.test.ts
pi-study-helper/fixtures/model-responses/w3/recorded-responses.json
pi-study-helper/fixtures/model-responses/w3/unauthorized-requests.json
pi-study-helper/fixtures/model-responses/w3/validate-w3-materials.mjs
pi-study-helper/src/application/offline-dynamic-question-orchestrator.ts
```

内外层ZIP、sidecar、本指令、日志、临时目录和其他岗位文件均不得进入拟提交清单。回交实际HEAD、origin/main、`git status --short`、四条复验命令与退出码、最终拟提交清单，并明确`NOT_COMMITTED / NOT_PUSHED / 未申请上传锁`。不得commit或push，等待负责人授予D-D3上传锁。
