# W3-D1 B 岗位整改与负责人审计候选

状态：`BLOCKED`（仅负责人审计候选；未提交、未推送、未申请上传锁）。

基线 HEAD：`2db7127bcd22035951474ddd3f86de4e8cfa77be`，已确认与 `origin/main` 一致；祖先关系检查通过。D1 不激活 Profile。

## 反馈逐条核对

1. **确定性 Rubric：完成。** `act-practical.engineering` 使用独立 `static_check` 文件 `assessments/private/tests/test-practical-engineering-static.py`，规则覆盖 AST 解析、Import/ImportFrom、别名、危险模块（os/subprocess/socket/requests/urllib/pathlib/shutil）和 eval/exec/open；解析及违规均固定为 `AssertionError("static_check_failed")`。未修改六维权重、通过线、阻断规则或反馈码，未使用 `manual_review`。
2. **唯一事实与映射：完成。** 全局保持 5 个 Bundle；W3 目标恰为 `act-inspect-dataframe`、`act-practical`。两目标 Bundle activity 与 Profile 深相等，内嵌 rubric 与 `rubricRef` 深相等。`test-practical-hidden-02` 仅承担 variant-02 运行时不变量（含输入不变），engineering 仅映射 `test-practical-engineering-static`；公开/私有登记无重复、无悬空引用。
3. **新旧封存冲突：完成。** 原 seal 字节保留于 `original/audit-only`；候选 seal 是唯一拟上传入口，状态仍为 `PENDING_OWNER_DUAL_SEAL_CHECK`。报告、handoff、复算命令和交付清单均指向候选 seal、29 项资产树及候选树哈希 `ecb218c3a4f91503cbb966c3f51b71d635d3bf0648a78aa7d6f3a4c673fc9622`。
4. **Manifest/ZIP：完成。** manifest 使用 `packageEntries`、`fileEntries`、`proposedCommitPaths`、`frozenInputsReadOnly`、`auditOnly`、`auditEvidence`；`selfExcluded=true`。构建器实际读取 ZIP 中央目录，逐项核对路径、长度和 SHA-256；冻结输入和历史 seal 不在 proposedCommitPaths。
5. **作者验证：完成。** 验证全局 5 Bundle、W3 目标集合、activity/rubric 闭合、参考实现通过、starter 拒绝、known-wrong 逐项被拒绝，以及静态正反例（含别名与文件/进程/网络调用）。候选证据脚本退出码为 0，摘要为 baselinePassed、allBaselineRepeatsStable、allStartersRejected、allKnownWrongRejectedPerFixture 均 true。
6. **复验与门禁：技术整改完成，授权门禁未完成。** 已保留冻结哈希：标注 `eaefe9cfbbf8f6144e8299abfc0d82b66cb9ffe8dd1d783e841c5bdfac2690bf`；输入 `b77ba4902003ba20bc5b233c4797838eb26325d1b38fd02bc68ba02206cb1d1c`。仍等待 E 独立封存、负责人双封存资格检查 PASS、A 释放 D1 第一把锁及负责人明确授权。

## 已执行命令

`python quality/prepare-w3-b-d1-delivery.py --verify`：0；`npm.cmd test -- --run tests/pandas-cleaning-v2-assets.test.ts`：0（10/10）；`npm.cmd test -- --run tests/evaluation-protocol.test.ts`：0（8/8）；`npm.cmd test -- --run tests/w3-b-d1-delivery.test.ts`：0（7/7）；`npm.cmd test -- --run`：0（40 文件、424 通过、1 跳过）；`npx.cmd tsc --noEmit`：0；`npm.cmd run check:docs`：0（45 个 Markdown）；`git diff --check`：0。

候选 ZIP 已由 manifest 中央目录实核：42 个实际包文件、41 个已登记非自身文件、`selfExcluded=true`。ZIP 与负责人审计包的旁路 SHA-256 仅写入其仓库外旁路校验文件；任何环境类失败会原样记录，不改写为 PASS。
