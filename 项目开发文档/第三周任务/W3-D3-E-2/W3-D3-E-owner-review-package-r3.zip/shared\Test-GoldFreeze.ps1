﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$W2Reference,
    [Parameter(Mandatory = $true)]
    [string]$DifficultyGoldCandidate,
    [Parameter(Mandatory = $true)]
    [string]$PathConstraintsCandidate,
    [Parameter(Mandatory = $true)]
    [string]$AdjudicationLog,
    [Parameter(Mandatory = $true)]
    [string]$OwnerFreezeRecord,
    [string]$OutputFile
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Read-JsonLines {
    param([string]$Path)
    $lineNumber = 0
    return @(Get-Content -LiteralPath $Path -Encoding UTF8 | ForEach-Object {
        $lineNumber++
        if ([string]::IsNullOrWhiteSpace($_)) { throw "Blank JSONL line at ${Path}:$lineNumber" }
        try { $_ | ConvertFrom-Json } catch { throw "Invalid JSONL at ${Path}:$lineNumber" }
    })
}

$difficultyGold = Read-JsonLines $DifficultyGoldCandidate
$pathConstraints = Read-JsonLines $PathConstraintsCandidate
$adjudication = Read-JsonLines $AdjudicationLog
$w2Rows = Read-JsonLines $W2Reference
$freeze = Get-Content -LiteralPath $OwnerFreezeRecord -Raw -Encoding UTF8 | ConvertFrom-Json
$expectedCaseIds = 1..60 | ForEach-Object { "final-{0:d3}" -f $_ }
$errors = [System.Collections.Generic.List[string]]::new()
function Get-CaseId([object]$Row) {
    if ($null -eq $Row -or @($Row.PSObject.Properties | ForEach-Object { $_.Name }) -notcontains "caseId") { return "" }
    return [string]$Row.caseId
}
function Get-Sha256([string]$Path) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($sha.ComputeHash([System.IO.File]::ReadAllBytes($Path))) -replace '-', '').ToLowerInvariant()
    } finally {
        $sha.Dispose()
    }
}

function Assert-Candidate {
    param([object[]]$Rows, [string]$Name)
    $actual = @($Rows | ForEach-Object { Get-CaseId $_ })
    if (@($Rows).Count -ne 60) { $errors.Add("$Name count must be 60") }
    if (($expectedCaseIds -join "|") -ne ($actual -join "|")) { $errors.Add("$Name caseId coverage/order mismatch") }
    if (@($actual | Sort-Object -Unique).Count -ne 60) { $errors.Add("$Name caseId duplicate") }
}
Assert-Candidate $difficultyGold "difficulty gold candidate"
Assert-Candidate $pathConstraints "path constraints candidate"
Assert-Candidate $adjudication "adjudication log"
if (@($w2Rows).Count -lt 20) { $errors.Add("W2 reference must contain at least 20 cases") }
foreach ($candidate in @(@{Name="difficulty";Rows=$difficultyGold}, @{Name="path";Rows=$pathConstraints}, @{Name="adjudication";Rows=$adjudication})) {
    for ($i = 0; $i -lt 20; $i++) {
        if ((Get-CaseId $candidate["Rows"][$i]) -ne (Get-CaseId $w2Rows[$i])) { $errors.Add(("{0} first20 differs from W2 caseId" -f $candidate["Name"])) }
    }
}
if (@($adjudication | Select-Object -First 20 | Where-Object {
    $p = @($_.PSObject.Properties | ForEach-Object { $_.Name })
    $status = if ($p -contains "historicalStatus") { $_.historicalStatus } elseif ($p -contains "w2Status") { $_.w2Status } elseif ($p -contains "status") { $_.status } elseif ($p -contains "negotiationStatus") { $_.negotiationStatus } else { "" }
    [string]::IsNullOrWhiteSpace([string]$status)
}).Count -gt 0) { $errors.Add("adjudication first20 must preserve W2 historical status") }
if (@($adjudication | Select-Object -Skip 20 | Where-Object { [string]$_.negotiationStatus -ne "SKIPPED_BY_D44" }).Count -ne 0) { $errors.Add("D44 negotiation status mismatch for final-021..060") }
if ($freeze.contractVersion -ne "W3-C5/W3-R2") { $errors.Add("freeze contract mismatch") }
if ($freeze.doubleBlindQualification -ne "PASS") { $errors.Add("double blind qualification is not PASS") }
if ($freeze.ownerAdjudication -ne "COMPLETE") { $errors.Add("owner adjudication is not COMPLETE") }
if ($freeze.systemRunBeforeFreezeCount -ne 0) { $errors.Add("formal system run existed before freeze") }

$candidateHashes = [ordered]@{
    difficultyGold = Get-Sha256 $DifficultyGoldCandidate
    pathConstraints = Get-Sha256 $PathConstraintsCandidate
    adjudicationLog = Get-Sha256 $AdjudicationLog
}
if ((@($freeze.PSObject.Properties | ForEach-Object { $_.Name }) -notcontains "candidateSha256") -or $null -eq $freeze.candidateSha256) { $errors.Add("freeze record candidateSha256 is required") }
else {
    foreach ($key in $candidateHashes.Keys) {
        if ((@($freeze.candidateSha256.PSObject.Properties | ForEach-Object { $_.Name }) -notcontains $key) -or [string]$freeze.candidateSha256.$key -ne [string]$candidateHashes[$key]) { $errors.Add("freeze hash mismatch: $key") }
    }
}

$result = [ordered]@{
    schemaVersion = "w3-d3-gold-freeze-check-r3-v1"
    gate = "V3-7"
    candidateCounts = [ordered]@{ difficultyGold = @($difficultyGold).Count; pathConstraints = @($pathConstraints).Count }
    adjudicationCount = @($adjudication).Count
    negotiationStatus = "SKIPPED_BY_D44"
    candidateSha256 = $candidateHashes
    w2ReferenceSha256 = Get-Sha256 $W2Reference
    freezeRecordSha256 = Get-Sha256 $OwnerFreezeRecord
    errors = @($errors)
    status = if ($errors.Count -eq 0) { "PASS" } else { "BLOCKED" }
}
if ($OutputFile) { $result | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $OutputFile -Encoding utf8 }
$result | ConvertTo-Json -Depth 20
if ($errors.Count -gt 0) { exit 1 }
