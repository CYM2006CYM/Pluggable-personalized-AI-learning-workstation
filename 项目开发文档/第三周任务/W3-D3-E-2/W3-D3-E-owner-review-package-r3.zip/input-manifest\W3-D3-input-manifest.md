# W3-D3 R3 输入清单

contractVersion = W3-C5/W3-R2  
deliveryStage = W3-D3  
W3_START_COMMIT = f190326a4a906b46e4001484ffa30a7839b82ed2  
HEAD = bd1b599524ef2e3362d14a422d97debbf240f70f  
origin/main = bd1b599524ef2e3362d14a422d97debbf240f70f  
D47 = W3-D47-TEST-LAYERS-1  
D47提交 = bd1b599524ef2e3362d14a422d97debbf240f70f  
D47文件SHA-256 = ab7f390325d772c11e663c83c394e794f6bc764b76eaf769488e1b6281363445

## 已冻结输入

R2原有19项冻结输入保持原路径、提交和SHA-256；R3仅同步合同和基线快照，不覆盖R2清单。

## R3保持PENDING的输入

- `a-d3-formal-commit`
- `a-d3-deterministic-test-files`（固定事务故障测试文件清单，D3不得猜测文件名）
- `d-d3-formal-commit`
- `owner-difficulty-gold-candidate`
- `owner-path-constraints-candidate`
- `owner-adjudication-log-candidate`
- `owner-freeze-record-candidate`

负责人四项候选不绑定 `gold-candidate.jsonl` 等预设文件名。负责人交付后，D4解析清单写入实际路径和SHA-256；不得回写本D3冻结清单。

## 使用边界

V3-1、V3-2、V3-8属于确定性层且不启动Python；V3-3属于评测器集成层，必须在批准环境执行；固定轨迹Demo使用D正式冻结材料和假LLM/mock，不使用真实Key。在线模型登记 `LIVE_NOT_RUN`，只有实际触发fallback才登记 `MOCK_FALLBACK_USED`。
