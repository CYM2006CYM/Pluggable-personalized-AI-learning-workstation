# W3-D3 岗位E R3 验证工具基线

本目录是R2保留原件之上的最小R3整改，合同为 `W3-C5/W3-R2`，绑定负责人裁决 `W3-D47-TEST-LAYERS-1`（提交 `bd1b599524ef2e3362d14a422d97debbf240f70f`）。

## 三层计划

- 确定性层：V3-1、V3-2、V3-4、V3-5、V3-8；不启动Python。
- 评测器集成层：V3-3、V3-6；D4必须使用批准的Node/Python/Pandas环境，A正式事务测试文件清单在D3保持PENDING。
- 固定轨迹Demo层：使用D冻结录制响应和假LLM/mock，不使用真实Key；在线模型统一登记 `LIVE_NOT_RUN`。

允许的执行归因：`CODE_DEFECT`、`ENVIRONMENT_MISMATCH`、`AUDIT_INPUT_INCOMPLETE`、`LIVE_NOT_RUN`、`MOCK_FALLBACK_USED`。

## 使用约束

1. D3只运行 `Invoke-W3D3Gate.ps1 -Mode Plan`、解析、结构、反例和哈希自测。
2. Execute模式必须显式传 `W3-D4`，并且解析清单所有必需输入均为 `FROZEN`，同时提供实际仓库根目录。
3. V3-7不固定负责人候选文件名；D4解析清单绑定difficulty、path constraints、adjudication log和freeze record的实际路径与SHA-256。
4. A-D3未上传时，V3-4/V3-6只登记 `PENDING_A_D3_DETERMINISTIC_TEST_FILES`，不得采信作者PASS或猜测文件名。
5. R3不执行D4、不运行正式60例系统、不生成gold、不修改仓库、依赖、环境锁、SDK或合同。
