# D47 三层测试计划与结果模板

contractVersion = W3-C5/W3-R2  
decisionId = W3-D47-TEST-LAYERS-1  
decisionCommit = bd1b599524ef2e3362d14a422d97debbf240f70f  
fullV3Status = NOT_RUN_D3  
V3_1_TO_V3_8 = NOT_EXECUTED

| 测试层 | 门禁/入口 | 环境 | D3状态 | D4结果字段 |
| --- | --- | --- | --- | --- |
| 确定性层 | V3-1、V3-2、V3-4、V3-5、V3-8 | 不启动Python；不依赖评测器精确环境 | PLAN_ONLY | PASS/BLOCKED、失败归因 |
| 评测器集成层 | V3-3、V3-6 | Node 22.23.1、Python 3.13.7、Pandas 3.0.5 | PLAN_ONLY；A事务测试清单PENDING | PASS/BLOCKED、环境哈希、四类故障矩阵 |
| 固定轨迹Demo层 | D冻结录制响应、假LLM/mock | 不使用真实Key、网络或在线供应商 | LIVE_NOT_RUN | MOCK_FALLBACK_USED（仅实际触发） |

## 归因枚举

`CODE_DEFECT`、`ENVIRONMENT_MISMATCH`、`AUDIT_INPUT_INCOMPLETE`、`LIVE_NOT_RUN`、`MOCK_FALLBACK_USED`。

## D4结果模板

每层登记 `rawCommand`、明确测试文件清单、输入路径和SHA-256、实际退出码、项数、原始输出位置、证据SHA-256、失败所有者和归因。未执行不得写PASS；在线模型固定写 `LIVE_NOT_RUN`。某层输入不完整时只标记该层 `AUDIT_INPUT_INCOMPLETE`，不得污染其他确定性层。
