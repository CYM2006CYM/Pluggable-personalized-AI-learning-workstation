# V3-7 测试用例合同

## 目标

只消费负责人只读候选及审计记录，验证三份候选 60/60、D44终裁、W2前20历史稳定性和先冻结后运行。

## 冻结输入

- `final-60-frozen-input`（W2前20例参考）
- `owner-difficulty-gold-candidate`
- `owner-path-constraints-candidate`
- `owner-adjudication-log-candidate`
- `owner-freeze-record-candidate`

## 原始命令

- `powershell.exe -NoProfile -ExecutionPolicy Bypass -File {ToolRoot}/Test-GoldFreeze.ps1 -W2Reference {InputPath:final-60-frozen-input} -DifficultyGoldCandidate {InputPath:owner-difficulty-gold-candidate} -PathConstraintsCandidate {InputPath:owner-path-constraints-candidate} -AdjudicationLog {InputPath:owner-adjudication-log-candidate} -OwnerFreezeRecord {InputPath:owner-freeze-record-candidate} -OutputFile {OutputRoot}/v3-7-gold-freeze.json`（期望退出码 0）

## 期望项数与指标

- `expectedTestItems` = `104`
- 三份候选和 adjudication-log 均为 `60` 条，caseId 顺序为 `final-001` 至 `final-060`
- `adjudicationCount` = `60`；前20例保留W2历史状态，后40例 `SKIPPED_BY_D44`
- `qualificationChecks` = `6`
- `negotiationStatus` = `SKIPPED_BY_D44`
- `formalRunsBeforeFreeze` = `0`

## 机械PASS条件

- difficulty/path constraints/adjudication 三份候选覆盖final-001至060且无重复
- freeze记录三份SHA-256与实际文件一致
- 前20例与W2参考caseId稳定一致，adjudication保留历史状态
- 后40例终裁记录全部SKIPPED_BY_D44
- 双盲资格、负责人终裁和冻结状态完整
- 任何正式60例系统运行发生在冻结之后

任一命令退出码不符、指标缺失、输入哈希不匹配或机械条件不满足时只能记录 BLOCKED，失败所有者为：负责人（原始盲标资格问题点名对应标注所有者）。D3不得执行这些命令或填写最终结论。
