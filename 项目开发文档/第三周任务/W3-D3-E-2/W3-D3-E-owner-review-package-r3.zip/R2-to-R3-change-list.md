# R2 到 R3 逐文件变更清单

R2 原件位于 `../source`、`../packages-r2`，其哈希和交付报告保持不变。R3 位于 `r3-source`，不覆盖R2。

| R3文件/范围 | 变更 |
| --- | --- |
| 全部 `gate-config.json`、`evidence-template.json`、DELIVERY/test-cases | 合同由 `W3-C4/W3-R2` 同步为 `W3-C5/W3-R2`，增加 `testLayer`、D47绑定和归因枚举 |
| `input-manifest/W3-D3-input-manifest.*` | HEAD/origin更新为 `bd1b599...`，增加D47文件绑定；负责人四项候选和A事务测试清单保持PENDING |
| `shared/Invoke-W3D3Gate.ps1` | 校验W3-C5，Plan证据记录测试层、D47和归因枚举 |
| `shared/Test-CBoundary.ps1` | 默认扫描四个C正式文件，增加ActivityResult/正式事实所有权字段和checkpoint/Store禁止模式 |
| `shared/Test-GoldFreeze.ps1` | 四候选路径参数化；三份60条稳定顺序、W2前20、后40 D44状态、三份哈希及冻结状态校验 |
| `gates/V3-4/*` | 绑定A事务测试清单PENDING，覆盖四文件边界 |
| `gates/V3-6/*` | 绑定 `PENDING_A_D3_DETERMINISTIC_TEST_FILES`，扩展两个任务×四类故障状态断言 |
| `gates/V3-7/*` | 移除单一gold文件名假设，改为负责人四项PENDING候选输入 |
| `D47-test-plan.md` | 增加确定性、评测器集成、固定轨迹Demo三层计划和结果模板 |
| `decisions/W3-D47-TEST-LAYERS-1.md` | R3包内副本，记录决策内容、提交和SHA-256绑定 |

未修改：R2文件、React页面、A/B/C/D代码、合同原件、gold、SDK、依赖和环境锁。
