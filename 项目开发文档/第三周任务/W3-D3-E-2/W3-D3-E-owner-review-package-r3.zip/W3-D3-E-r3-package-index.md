﻿# W3-D3 E R3 包内索引

contractVersion = W3-C5/W3-R2
deliveryStage = W3-D3
payloadFileCount = 52
payloadHashMethod = SHA-256 over raw bytes, lowercase hexadecimal
payloadHashFile = W3-D3-E-r3-payload-hashes.sha256（不包含自身，避免自引用）

排除：R2旧ZIP、node_modules、dist-web、日志、浏览器profile、整个仓库副本、D1标注、B/E原始封存材料、机械差异清单、正式gold、A/B/C/D代码和SDK源码副本。
