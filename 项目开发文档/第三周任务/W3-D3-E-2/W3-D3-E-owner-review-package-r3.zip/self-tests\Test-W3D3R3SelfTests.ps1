[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [string]$SourceRoot,
    [Parameter(Mandatory = $true)] [string]$OutputFile
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$root = (Resolve-Path -LiteralPath $SourceRoot).Path
$work = Join-Path $root ("self-test-work-" + [DateTime]::UtcNow.ToString("yyyyMMddHHmmssfff"))
New-Item -ItemType Directory -Path $work -Force | Out-Null

function Write-JsonLines([string]$Path, [object[]]$Rows) {
    $Rows | ForEach-Object { $_ | ConvertTo-Json -Compress -Depth 20 } | Set-Content -LiteralPath $Path -Encoding utf8
}
function New-Cases { param([int]$Count = 60)
    1..$Count | ForEach-Object { [ordered]@{ caseId = "final-{0:d3}" -f $_; value = "fixture-$_" } }
}
function Run-Gold([string]$Difficulty, [string]$Path, [string]$Adjudication, [string]$Freeze, [string]$W2) {
    $oldPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root "shared/Test-GoldFreeze.ps1") -W2Reference $W2 -DifficultyGoldCandidate $Difficulty -PathConstraintsCandidate $Path -AdjudicationLog $Adjudication -OwnerFreezeRecord $Freeze 1>$null 2>$null
        return $LASTEXITCODE
    } catch {
        return 1
    } finally {
        $ErrorActionPreference = $oldPreference
    }
}
function Clone-Rows([object[]]$Rows) { return @($Rows | ForEach-Object { $_ | ConvertTo-Json -Depth 20 | ConvertFrom-Json }) }
function Run-PlanOrExecute([string[]]$Arguments) {
    $oldPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root "shared/Invoke-W3D3Gate.ps1") @Arguments 1>$null 2>$null
        return $LASTEXITCODE
    } catch {
        return 1
    } finally {
        $ErrorActionPreference = $oldPreference
    }
}

$w2 = Join-Path $work "w2.jsonl"
$difficulty = Join-Path $work "difficulty.jsonl"
$path = Join-Path $work "path.jsonl"
$adjudication = Join-Path $work "adjudication.jsonl"
$freeze = Join-Path $work "freeze.json"
$w2Rows = New-Cases
$difficultyRows = New-Cases
$pathRows = New-Cases
$adjudicationRows = New-Cases | ForEach-Object { $_ | Add-Member -NotePropertyName historicalStatus -NotePropertyValue "W2_KEEP" -PassThru } | ForEach-Object { if ([int]$_.caseId.Substring(6) -ge 21) { $_.negotiationStatus = "SKIPPED_BY_D44" }; $_ }
Write-JsonLines $w2 $w2Rows
Write-JsonLines $difficulty $difficultyRows
Write-JsonLines $path $pathRows
Write-JsonLines $adjudication $adjudicationRows
$freezeObject = [ordered]@{
    contractVersion = "W3-C5/W3-R2"
    doubleBlindQualification = "PASS"
    ownerAdjudication = "COMPLETE"
    systemRunBeforeFreezeCount = 0
    candidateSha256 = [ordered]@{
        difficultyGold = (Get-FileHash -Algorithm SHA256 $difficulty).Hash.ToLowerInvariant()
        pathConstraints = (Get-FileHash -Algorithm SHA256 $path).Hash.ToLowerInvariant()
        adjudicationLog = (Get-FileHash -Algorithm SHA256 $adjudication).Hash.ToLowerInvariant()
    }
}
$freezeObject | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $freeze -Encoding utf8

$checks = [ordered]@{}
$checks.duplicateCaseIdRejected = & { $rows = Clone-Rows $difficultyRows; $rows[1].caseId = $rows[0].caseId; $p = Join-Path $work "duplicate.jsonl"; Write-JsonLines $p $rows; (Run-Gold $p $path $adjudication $freeze $w2) -ne 0 }
$checks.missingCandidateRejected = (Run-Gold (Join-Path $work "missing.jsonl") $path $adjudication $freeze $w2) -ne 0
$checks.first20MutationRejected = & { $rows = Clone-Rows $difficultyRows; $rows[0].caseId = "final-999"; $p = Join-Path $work "first20-mutated.jsonl"; Write-JsonLines $p $rows; (Run-Gold $p $path $adjudication $freeze $w2) -ne 0 }
$checks.nonD44TailRejected = & { $rows = Clone-Rows $adjudicationRows; $rows[59].negotiationStatus = "PENDING"; $p = Join-Path $work "tail-mutated.jsonl"; Write-JsonLines $p $rows; (Run-Gold $difficulty $path $p $freeze $w2) -ne 0 }
$checks.freezeHashMismatchRejected = & { $bad = Join-Path $work "bad-freeze.json"; $f = $freezeObject | ConvertTo-Json -Depth 20; $f = $f.Replace($freezeObject.candidateSha256.pathConstraints, "deadbeef"); Set-Content -LiteralPath $bad -Value $f -Encoding utf8; (Run-Gold $difficulty $path $adjudication $bad $w2) -ne 0 }

$v37 = Join-Path $root "gates/V3-7/gate-config.json"
$manifest = Join-Path $root "input-manifest/W3-D3-input-manifest.json"
$checks.executeWithoutTokenRejected = (Run-PlanOrExecute @("-GateConfig", $v37, "-InputManifest", $manifest, "-Mode", "Execute")) -ne 0
$checks.executePendingRejected = (Run-PlanOrExecute @("-GateConfig", $v37, "-InputManifest", $manifest, "-Mode", "Execute", "-D4AuthorizationToken", "W3-D4", "-RepositoryRoot", (Split-Path $root -Parent))) -ne 0
$out = Join-Path $work "v38-plan"
$checks.deterministicLayerIsolation = (Run-PlanOrExecute @("-GateConfig", (Join-Path $root "gates/V3-8/gate-config.json"), "-InputManifest", $manifest, "-Mode", "Plan", "-OutputRoot", $out)) -eq 0

$result = [ordered]@{
    schemaVersion = "w3-d3-r3-self-test-v1"
    contractVersion = "W3-C5/W3-R2"
    executionStatus = "NOT_RUN_D3"
    gateConclusion = "NOT_PRODUCED_D3"
    checks = $checks
    allPassed = @($checks.GetEnumerator() | Where-Object { -not $_.Value }).Count -eq 0
    workDirectory = "external temporary fixture directory (excluded from package)"
    note = "Only rejection logic and Plan isolation; D4 and formal V3 were not executed."
}
$result | ConvertTo-Json -Depth 50 | Set-Content -LiteralPath $OutputFile -Encoding utf8
$result | ConvertTo-Json -Depth 50
if (-not $result.allPassed) { exit 1 }
