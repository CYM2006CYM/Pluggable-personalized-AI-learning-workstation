# C岗位W3-D2正式实现候选报告

## 结论

基于`c8b4aacffccdad92338abedfd7acb3b59b716e60`完成C岗位D2候选。负责人裁决、D1封存证据、B正式提交和两个`assetBundleHash`均已绑定；正式环境锁、自检、V3-3、V3-4和V3-6作者证据通过。当前仅为待负责人审计的draft Profile候选，不代表Profile active，也未获得上传授权。

## 环境锁

正式锁使用`W3-D40-ENV-1`批准值：Node `v22.23.1`、Python `3.13.7`、Pandas `3.0.5`、平台`win32-10.0.26100-x64`和评测器`node-python-evaluator-w3-c1`。依赖仅允许`pandas==3.0.5`，限制为`4000/8192/8192/8000/65536`。不声明网络隔离或可靠内存限制，`memoryBytes`省略，`pyodideVersion=null`。

正式锁排除`environmentHash`自身后按UTF-8规范化JSON重算：

```text
sha256:9e73aebc1b5191b24ee91b27994cf48d596c757695738074de6d846ee2cf5b76
```

## 评测实现

Node适配器在读取TaskBundle、CSV、测试或其他B资产前读取并验证正式环境锁，并用显式Python可执行文件复核Python/Pandas版本。随后严格执行`prepare -> user_code -> public_tests -> hidden_tests -> summarize`。三个执行阶段使用独立Python进程、固定工作目录、`shell=false`和最小环境；成功、失败、超时和取消均进入临时目录清理。

Rubric汇总保留B定义的权重、测试级与维度级阻断规则和通过线。正确、部分正确、语法错误、运行错误、测试失败、超时、超输出和禁用导入均为学习者结果；依赖、环境、测试资产、协议、harness和父进程故障均为评测器结果且不计分。

## 公共边界

公共输出止于21号`ActivityResult`，不包含五阶段细节、完整Rubric、阻断断言、原始stdout/stderr、隐藏测试、参考实现、私有CSV或宿主路径。C实现没有正式Attempt、Evidence、KnowledgeState、PathRepository或Session写入能力。

## 验证结果

最终作者测试`20/20`、C定向测试`36/36`、受影响回归`26/26`、全量测试`47文件/480通过/1跳过`；typecheck、check:docs、Extension冒烟、release、verify、自检和`git diff --check`均退出0。

首次作者测试曾因C规范化函数语法错误在加载期失败；修正后一次运行因预检启动窗口及临时21项计数失败，最终把测试级阻断覆盖合并回既有20项，并将环境预检与4000ms学习者执行限额分离。完整记录保留在`execution-log.txt`，未删除失败历史。

## 限制与声明

该环境只适用于本地受信任测试者，不是生产级恶意代码沙箱；`networkIsolation=false`、`reliableMemoryLimit=false`。D1三份原始文件和ZIP未改变；B资产、gold、SDK、package和其他岗位文件未改变。当前未暂存、未commit、未push。
