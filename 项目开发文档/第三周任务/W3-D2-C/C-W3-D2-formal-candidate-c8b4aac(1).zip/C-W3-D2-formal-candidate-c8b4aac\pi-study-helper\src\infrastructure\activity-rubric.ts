import type { ActivityResult, LearningRuntimeErrorCode } from "../domain/v2-types.js";

export interface RubricDimensionDefinition {
  dimensionId: string;
  weight: number;
  blocking: boolean;
  safeFeedbackCodes: readonly string[];
}

export interface ActivityRubricDefinition {
  passThreshold: number;
  dimensions: readonly RubricDimensionDefinition[];
}

export interface InternalTestResult {
  testId: string;
  dimensionId: string;
  blocking: boolean;
  passed: boolean;
}

export interface RubricSummaryInput {
  rubric: ActivityRubricDefinition;
  tests: readonly InternalTestResult[];
  evaluatorVersion: string;
  environmentHash: string;
  assetBundleHash: string;
}

export interface LearnerFailureInput {
  errorCode: Extract<
    LearningRuntimeErrorCode,
    | "syntax_error"
    | "runtime_error"
    | "test_failed"
    | "timeout"
    | "output_limit"
    | "disallowed_import"
    | "submission_contract_error"
  >;
  evaluatorVersion: string;
  environmentHash: string;
  assetBundleHash: string;
  safeFeedback: string;
}

export interface EvaluatorFailureInput {
  errorCode: Extract<
    LearningRuntimeErrorCode,
    | "environment_mismatch"
    | "evaluator_error"
    | "evaluator_start_failed"
    | "evaluator_timeout"
    | "dependency_missing"
    | "test_asset_invalid"
    | "result_protocol_invalid"
    | "runner_crash"
  >;
  evaluatorVersion: string;
  environmentHash: string;
  assetBundleHash: string;
  safeFeedback: string;
}

function roundScore(value: number): number {
  return Number(value.toFixed(12));
}

export function summarizeRubric(input: RubricSummaryInput): ActivityResult {
  const dimensionResults: Record<string, number> = {};
  let score = 0;
  let blockingPassed = true;

  for (const dimension of input.rubric.dimensions) {
    const tests = input.tests.filter((test) => test.dimensionId === dimension.dimensionId);
    const dimensionScore = tests.length === 0
      ? 0
      : tests.filter((test) => test.passed).length / tests.length;
    dimensionResults[dimension.dimensionId] = roundScore(dimensionScore);
    score += dimensionScore * dimension.weight;
    if (dimension.blocking && dimensionScore < 1) blockingPassed = false;
  }

  if (input.tests.some((test) => test.blocking && !test.passed)) blockingPassed = false;

  const normalizedScore = roundScore(score);
  const passed = normalizedScore >= input.rubric.passThreshold && blockingPassed;
  const verdict = passed ? "pass" : normalizedScore > 0 ? "partial" : "fail";
  return {
    executionStatus: "completed",
    verdict,
    ...(passed ? {} : { errorKind: "learner" as const, errorCode: "test_failed" as const }),
    score: normalizedScore,
    dimensionResults,
    safeFeedback: passed
      ? "All deterministic checks passed."
      : "One or more deterministic checks did not pass.",
    evaluatorVersion: input.evaluatorVersion,
    environmentHash: input.environmentHash,
    assetBundleHash: input.assetBundleHash,
  };
}

export function learnerFailure(input: LearnerFailureInput): ActivityResult {
  return {
    executionStatus: "completed",
    verdict: "fail",
    errorKind: "learner",
    errorCode: input.errorCode,
    score: 0,
    safeFeedback: input.safeFeedback,
    evaluatorVersion: input.evaluatorVersion,
    environmentHash: input.environmentHash,
    assetBundleHash: input.assetBundleHash,
  };
}

export function evaluatorFailure(input: EvaluatorFailureInput): ActivityResult {
  return {
    executionStatus: "failed",
    verdict: "not_graded",
    errorKind: "evaluator",
    errorCode: input.errorCode,
    safeFeedback: input.safeFeedback,
    evaluatorVersion: input.evaluatorVersion,
    environmentHash: input.environmentHash,
    assetBundleHash: input.assetBundleHash,
  };
}
