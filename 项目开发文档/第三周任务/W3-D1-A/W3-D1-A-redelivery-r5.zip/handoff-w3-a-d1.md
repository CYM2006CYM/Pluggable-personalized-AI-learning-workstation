# W3-D1 A R5 审计候选交接单

状态：等待负责人复审；未 commit、未 push、未申请上传锁。

R5 候选包：`W3-D1-A-redelivery-r5.zip`；ZIP SHA-256 以最终打包命令输出为准，并在交付回执中登记。
包内为 13 个扁平文件：A 路径源码/仓储 4 个、路径与 V3 测试 4 个、V3-1/V3-2 证据 2 个、SHA 清单、问题单和本交接单。

## 工作区证据

```text
HEAD=2db7127bcd22035951474ddd3f86de4e8cfa77be
origin/main=2db7127bcd22035951474ddd3f86de4e8cfa77be
W3_START_COMMIT=f190326a4a906b46e4001484ffa30a7839b82ed2
W3_START_COMMIT 是 HEAD 祖先：git merge-base --is-ancestor 退出码 0
```

交付时以实际执行的 `git status --short` 为准。ZIP、旧 ZIP、临时目录和本地审计材料不进入拟暂存清单。

本次交付前实际 `git status --short`：

```text
 M pi-study-helper/src/repositories/file-learning-session-repository.ts
 M pi-study-helper/src/repositories/profile-family-repository.ts
?? W3-D1-A-V3-1-evidence.json
?? W3-D1-A-V3-2-evidence.json
?? W3-D1-A-delivery.zip
?? W3-D1-A-development-20-evidence.json
?? W3-D1-A-file-sha256.txt
?? W3-D1-A-redelivery-r2.zip
?? W3-D1-A-redelivery-r3.zip
?? W3-D1-A-redelivery-r4.zip
?? W3-D1-A-redelivery-r5.zip
?? W3-D1-A-redelivery.zip
?? pi-study-helper/src/application/path-learning-facade.ts
?? pi-study-helper/src/domain/path-engine.ts
?? pi-study-helper/tests/path-engine-development-20.test.ts
?? pi-study-helper/tests/path-engine.test.ts
?? pi-study-helper/tests/path-runtime.test.ts
?? pi-study-helper/tests/profile-v2-revision-resolution.test.ts
?? 新版设计文档-重写版/第三周任务/W3-D1-A-PATH-INFEASIBLE-ISSUE.md
?? 新版设计文档-重写版/第三周任务/handoff-w3-a-d1.md
```

## 本轮实际修改

- `path-engine.ts`：`skipEligible` 唯一权威、严格先修状态、真实 Profile 可选活动预算压缩、稳定 changeReasons、保留必做/最终活动。
- `path-learning-facade.ts` 与 `file-learning-session-repository.ts`：通过 A 内部路径读取端口消费完整持久化快照；对外仍只返回 21 号安全 DTO，未新增公共 Facade/枚举/类型。
- 路径测试：skipEligible 反例、真实可选活动高低预算、changeReasons、候选/确认/重规划/恢复与 revision 隔离。
- `path-engine-development-20.test.ts`：真实读取 development-20，V3-1/V3-2 各 20×10，并补全候选合法性校验及全部掌握/缺失先修 fixture 审计字段。
- `W3-D1-A-V3-1-evidence.json`、`W3-D1-A-V3-2-evidence.json`：重新生成且复跑输出哈希一致。
- `W3-D1-A-PATH-INFEASIBLE-ISSUE.md`：改为“D45 已裁决”，明确双口径和冻结资产边界。

## 验证命令与结果

```text
npm.cmd test -- --run tests/path-engine.test.ts tests/path-engine-development-20.test.ts tests/path-runtime.test.ts tests/profile-v2-revision-resolution.test.ts tests/file-learning-session-repository.test.ts --maxWorkers=1
退出码 0；5 个文件；40 项通过

npm.cmd test -- --run --maxWorkers=1
首次冷缓存运行退出码 1；43 个文件；442 项通过、1 项跳过、1 项失败。
失败原文：scripts/w2-verification/v2-comprehensive-verification.test.mjs 的 V2-6，Test timed out in 20000ms。
随后同命令复跑退出码 0；43 个文件；443 项通过、1 项跳过；最终全量结果 PASS。未修改该非 A 测试。

npm.cmd run typecheck
退出码 0
npx.cmd tsc --noEmit
退出码 0
npm.cmd run check:docs
退出码 0；已检查 45 个项目 Markdown 文件，本地链接全部有效
git diff --check
退出码 0（仅 Git CRLF 提示）
```

V3-1：`projectionRuleVersion=w3-v3-feasible-180-v1`，20/20 candidate，20×10 逐字段稳定，候选合法率 100%。

V3-2：原始预算 20×10 稳定结构化 `path_infeasible`，非法路径 0；两个 A fixture 均为 candidate，全部掌握先修 skipped，缺失先修为 a available、b/target locked 且含 `prerequisite_gap`。

V3 证据复跑：`tests/path-engine-development-20.test.ts` 第二次运行退出码 0；V3-1 SHA-256 与 V3-2 SHA-256 均与重生成前一致。

## 精确拟暂存清单

```text
pi-study-helper/src/application/path-learning-facade.ts
pi-study-helper/src/domain/path-engine.ts
pi-study-helper/src/repositories/file-learning-session-repository.ts
pi-study-helper/src/repositories/profile-family-repository.ts
pi-study-helper/tests/path-engine-development-20.test.ts
pi-study-helper/tests/path-engine.test.ts
pi-study-helper/tests/path-runtime.test.ts
pi-study-helper/tests/profile-v2-revision-resolution.test.ts
W3-D1-A-V3-1-evidence.json
W3-D1-A-V3-2-evidence.json
新版设计文档-重写版/第三周任务/W3-D1-A-PATH-INFEASIBLE-ISSUE.md
新版设计文档-重写版/第三周任务/handoff-w3-a-d1.md
W3-D1-A-file-sha256.txt
```

明确声明：D1 未激活 Profile v2；未修改 development-20、生成脚本、B/C/D/E 资产、正式 60 例、gold、SDK、SDK 哈希、依赖、allowScripts 或 21 号公共类型；未提前实现 D3 Attempt/Evidence 正式事务。
