# W3-D1 A R6 审计候选交接单

状态：等待负责人复审；未 commit、未 push、未申请上传锁。R5 中“对外仍只返回 21 号安全 DTO”的声明曾与实现不符，本轮已修正为显式安全裁剪。

## 工作区与基线

```text
HEAD=2db7127bcd22035951474ddd3f86de4e8cfa77be
origin/main=2db7127bcd22035951474ddd3f86de4e8cfa77be
W3_START_COMMIT=f190326a4a906b46e4001484ffa30a7839b82ed2
W3_START_COMMIT 是 HEAD 祖先：git merge-base --is-ancestor 退出码 0
```

本次最终交付前实际 `git status --short` 以命令输出为准；旧 ZIP、旧 development-20 evidence 和本地审计材料全部排除，不进入拟提交清单。

## 本轮修改

- `internal-path-session-port.ts`：A 内部完整路径读写端口及安全投影函数；不改变 21 号公共合同。
- `file-learning-session-repository.ts`：合法公共 `PathSafeSnapshot` 不再静默丢失；非法候选明确 `evidence_invalid`；getSnapshot/commit/recover 显式裁剪公共 DTO；内部完整路径继续持久化并支持重启读取。
- `path-learning-facade.ts`：PathRuntime 类型显式要求公共仓储和 A 内部端口；不再导入具体 File 仓储、不再运行时探测隐藏方法。
- `path-engine.ts`：固定节点合并、分钟重算后执行最终预算/节点/活动/拓扑/状态/必做活动校验；超预算返回结构化 `path_infeasible`。
- 对应 PathEngine、PathRuntime、FileLearningSessionRepository 测试和 A-R5-01—04 映射文件。

## V3 保持不变

V3-1/V3-2 复跑前后文件哈希完全一致：

```text
V3-1 = f29d9fb982d2647b2b440496d02585a06fa5ae8e5b27f384f00493d2a27a820b
V3-2 = 02f9f7754ad5e9197555803d90c668d63f5b8a05cc59b0db902a30f76543754a
```

仍保持 development-20 `normalized-text` SHA-256：`54c0f5f30bc0b9a104ac2e9e38e6ca3d6f33c5cbe3ade17c62be1c69be1b8473`；未运行 final-60。

## 已执行命令

```text
npm.cmd test -- --run tests/path-engine.test.ts tests/path-runtime.test.ts tests/file-learning-session-repository.test.ts tests/profile-v2-revision-resolution.test.ts tests/path-engine-development-20.test.ts --maxWorkers=1
退出码 0；5 个文件；45 项通过

npm.cmd run typecheck
退出码 0；TypeScript 源码与测试配置均通过
npx.cmd tsc --noEmit
退出码 0
npm.cmd run check:docs
退出码 0；已检查 45 个项目 Markdown 文件
git diff --check
退出码 0（仅 profile-family-repository.ts CRLF 提示）
```

npm.cmd test -- --run --maxWorkers=1
退出码 0；43 个文件；448 项通过、1 项跳过；未出现失败或超时。

V3 定向复跑：退出码 0；1 个文件；1 项通过；V3-1/V3-2 SHA-256 与复跑前一致。

本次交付前实际 `git status --short`：

```text
 M pi-study-helper/src/repositories/file-learning-session-repository.ts
 M pi-study-helper/src/repositories/profile-family-repository.ts
 M pi-study-helper/tests/file-learning-session-repository.test.ts
?? W3-D1-A-V3-1-evidence.json
?? W3-D1-A-V3-2-evidence.json
?? W3-D1-A-delivery.zip
?? W3-D1-A-development-20-evidence.json
?? W3-D1-A-file-sha256.txt
?? W3-D1-A-redelivery-r2.zip
?? W3-D1-A-redelivery-r3.zip
?? W3-D1-A-redelivery-r4.zip
?? W3-D1-A-redelivery-r5.zip
?? W3-D1-A-redelivery-r6.zip
?? W3-D1-A-redelivery.zip
?? pi-study-helper/src/application/path-learning-facade.ts
?? pi-study-helper/src/domain/path-engine.ts
?? pi-study-helper/src/repositories/internal-path-session-port.ts
?? pi-study-helper/tests/path-engine-development-20.test.ts
?? pi-study-helper/tests/path-engine.test.ts
?? pi-study-helper/tests/path-runtime.test.ts
?? pi-study-helper/tests/profile-v2-revision-resolution.test.ts
?? 新版设计文档-重写版/第三周任务/W3-D1-A-PATH-INFEASIBLE-ISSUE.md
?? 新版设计文档-重写版/第三周任务/W3-D1-A-R6-verification.md
?? 新版设计文档-重写版/第三周任务/handoff-w3-a-d1.md
```

## R6 拟提交清单

```text
pi-study-helper/src/application/path-learning-facade.ts
pi-study-helper/src/domain/path-engine.ts
pi-study-helper/src/repositories/file-learning-session-repository.ts
pi-study-helper/src/repositories/internal-path-session-port.ts
pi-study-helper/src/repositories/profile-family-repository.ts
pi-study-helper/tests/path-engine-development-20.test.ts
pi-study-helper/tests/path-engine.test.ts
pi-study-helper/tests/path-runtime.test.ts
pi-study-helper/tests/file-learning-session-repository.test.ts
pi-study-helper/tests/profile-v2-revision-resolution.test.ts
W3-D1-A-V3-1-evidence.json
W3-D1-A-V3-2-evidence.json
W3-D1-A-file-sha256.txt
新版设计文档-重写版/第三周任务/W3-D1-A-R6-verification.md
新版设计文档-重写版/第三周任务/W3-D1-A-PATH-INFEASIBLE-ISSUE.md
新版设计文档-重写版/第三周任务/handoff-w3-a-d1.md
```

明确排除：`W3-D1-A-redelivery-r5.zip`及所有旧 ZIP、`W3-D1-A-development-20-evidence.json`、缓存、整库副本、hidden/private/reference/Rubric 安全材料、其他岗位文件；不修改 development-20、生成脚本、B/C/D/E 资产、正式 60 例、SDK、依赖、allowScripts、21 号公共类型或 Profile active 状态。

R6 映射表见 `W3-D1-A-R6-verification.md`。D1 未激活 Profile v2，未实现 D3 Attempt/Evidence 正式事务。
