# W3-D1-A：development-20 必做活动预算不可行问题单

状态：`待负责人裁决`。本问题单不修改 Profile、案例、预算、目标、Rubric、必做活动或 Profile active 状态。

## 复现输入

```text
输入文件：evaluation/personas/development-20.jsonl
输入案例：dev-001 至 dev-020，共20例
Profile：pandas-cleaning revision 2（保持 draft）
目标：goal-clean-orders
PathEngine：path-engine-v1
重复运行：每例10次，共200次
```

## 实际结果

所有20例的10次运行均逐字段一致，且均为 `path_infeasible`：

```text
candidate：0/20
path_infeasible：20/20
每例最小必做时间：165分钟
development-20预算范围：30、60、90、120、150分钟
```

`goal-clean-orders` 的必做活动及当前 Profile 声明时间合计为：

```text
act-read-csv             10
act-inspect-dataframe   15
act-missing             20
act-duplicates          25
act-types               30
act-practical           60
合计                    160
```

另外，`basic-python` 是 `read-csv` 的不可跳过先修，当前路径约束将其补救活动 `act-basic-python-remediation` 的 5 分钟计入最短合法路径，因此引擎报告 `minimumRequiredMinutes=165`。这是算法保留必做活动、最终活动和不可跳过先修后的可复现结果，不是通过删除节点或改变资料得到的结果。

## 负责人需要裁决的问题

请负责人确认以下合同处理方式之一：

1. 保持当前必做活动和时间，接受 development-20 全部 `path_infeasible`，将其作为预算约束负向案例；或
2. 由负责人批准修订 Profile/目标/活动预算后，再重新生成候选测试输入；或
3. 负责人批准明确的路径预算规则（例如必做活动的预算核算方式），由 A 按书面规则修改算法和测试。

A 不自行选择以上方案，不修改 B 的 Profile 或 evaluation 输入来制造 candidate 结果。

## 证据

逐案、逐次运行的完整记录见候选交付包中的 `W3-D1-A-development-20-evidence.json`。该记录只引用 `development-20.jsonl`，没有读取 `final-60.jsonl`，也没有生成正式案例路径输出。

