# W3-D1 A 候选整改交接单（D45 / W3-C3 / W3-R2）

状态：A 候选整改完成，等待负责人审计；未 commit、未 push、未申请上传锁。

## 工作区事实

```text
HEAD=2db7127bcd22035951474ddd3f86de4e8cfa77be
origin/main=2db7127bcd22035951474ddd3f86de4e8cfa77be
W3_START_COMMIT=f190326a4a906b46e4001484ffa30a7839b82ed2
W3_START_COMMIT 是 HEAD 祖先：true（git merge-base --is-ancestor 退出码 0）
Profile pandas-cleaning revision 2：draft（D1 未激活）
```

本次实际工作区状态以交付时执行的 `git status --short` 为准。旧候选 ZIP 保留，不纳入拟暂存清单。

## 精确拟暂存清单

```text
pi-study-helper/src/application/path-learning-facade.ts
pi-study-helper/src/domain/path-engine.ts
pi-study-helper/src/repositories/file-learning-session-repository.ts
pi-study-helper/src/repositories/profile-family-repository.ts
pi-study-helper/tests/path-engine-development-20.test.ts
pi-study-helper/tests/path-engine.test.ts
pi-study-helper/tests/path-runtime.test.ts
pi-study-helper/tests/profile-v2-revision-resolution.test.ts
W3-D1-A-V3-1-evidence.json
W3-D1-A-V3-2-evidence.json
新版设计文档-重写版/第三周任务/W3-D1-A-PATH-INFEASIBLE-ISSUE.md
新版设计文档-重写版/第三周任务/handoff-w3-a-d1.md
W3-D1-A-file-sha256.txt
```

`learning-session-repository.ts` 的公共类型未改变；旧 ZIP、旧 development-20 evidence 和本次新 ZIP 不在拟暂存清单中。

## 整改结果

- `skipEligible` 是先修压缩唯一条件；mastered 但不可跳过的先修保留并锁定后置节点。
- selectedKnowledgePointIds 参与闭包约束，闭包外合法知识点选择返回确定性 `path_infeasible`。
- 同层排序严格为目标、暴露缺口、importance、Profile 声明顺序、knowledgePointId；chapterId 不参与排序。
- chapter 模式只校验 chapterId，不裁剪 goal 或先修闭包。
- 必做活动和 finalActivity 保留；非必做活动按真实 Profile 活动、KnowledgeState 难度区间、最近距离和声明顺序选择；scaffold 满足状态建议与活动允许集合。
- 初始路径为 candidate→confirm→active；重规划成功一次事务发布新 active 并归档旧 superseded；失败和恢复保留旧 active。
- 正式 resolver 只读绑定 revision 的 active/archived；draft 被正式会话拒绝。
- 未新增第二套 Facade、公共枚举或公共状态类型。

## V3 证据

- 源文件：`evaluation/personas/development-20.jsonl`
- `hashMode=normalized-text`
- 固定 source SHA-256：`54c0f5f30bc0b9a104ac2e9e38e6ca3d6f33c5cbe3ade17c62be1c69be1b8473`
- V3-1：`projectionRuleVersion=w3-v3-feasible-180-v1`，20 例×10，candidate 20/20，实际路径合法率 100%。
- V3-2：原始预算 20 例×10，结构化 `path_infeasible` 20/20，非法路径 0；另含全部掌握和缺失先修 A 自有 fixture。
- 每例证据包含原始背景、诊断答案、goal、mode、KnowledgeState、原始/投影预算、投影输入哈希和 10 次输出哈希。
- 未读取 `final-60.jsonl`，未生成正式案例路径输出。

## 实际验证命令和结果

```text
npm.cmd test -- --run tests/path-engine.test.ts tests/path-engine-development-20.test.ts tests/path-runtime.test.ts tests/profile-v2-revision-resolution.test.ts tests/file-learning-session-repository.test.ts --maxWorkers=1
退出码 0；5 个文件，37 项通过

npm.cmd test -- --run --maxWorkers=1
退出码 1；43 个文件，439 项通过，1 项跳过，1 项失败
失败：scripts/w2-verification/v2-comprehensive-verification.test.mjs 的 V2-6，20,010ms 超时

npm.cmd run typecheck
退出码 0

npx.cmd tsc --noEmit
退出码 0

npm.cmd run check:docs
退出码 0；45 个 Markdown 文件链接有效

git diff --check
退出码 0
```

全量测试未声明 PASS；V2-6 超时原样登记，未修改其脚本。

## 交付边界声明

- D1 未激活 Profile v2。
- 未修改 B/C/D/E 资产、development-20.jsonl、build-w2-cases.mjs、正式 60 例、gold、SDK、SDK 哈希、依赖、allowScripts 或 21 号公共类型。
- 未实现 D3 的 Attempt/Evidence 正式事务。
- 本包仅供负责人审计候选；负责人 PASS 并明确授权前不得上传。
