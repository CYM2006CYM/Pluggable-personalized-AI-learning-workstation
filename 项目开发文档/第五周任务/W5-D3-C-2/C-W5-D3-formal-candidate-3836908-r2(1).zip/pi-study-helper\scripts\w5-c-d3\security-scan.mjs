import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const packageRoot = resolve(import.meta.dirname, "../..");
const repositoryRoot = resolve(packageRoot, "..");
const proposed = (await readFile(resolve(import.meta.dirname, "proposed-files.txt"), "utf8"))
  .split(/\r?\n/u).filter(Boolean)
  .filter((path) => !path.endsWith("/security-scan.json") && !path.endsWith("/manifest.json"));
const findings = [];
const patterns = [
  { id: "host_absolute_path", pattern: /[A-Za-z]:[\\/](?:Users|Temp|AppData)[\\/]/gu },
  { id: "credential_assignment", pattern: /(?:OPENAI_API_KEY|apiKey|token|secret)\s*[:=]\s*["'][^"']{8,}["']/giu },
  { id: "private_asset_path", pattern: /(?:fixtures[\\/]profiles[^\n"]*(?:hidden-tests|reference-solutions|private\.csv))/giu },
];
for (const path of proposed) {
  const text = await readFile(resolve(repositoryRoot, path), "utf8");
  for (const rule of patterns) if (rule.pattern.test(text)) findings.push({ path, rule: rule.id });
}
const result = { schemaVersion: 1, generatedAt: new Date().toISOString(), scannedFiles: proposed.length, findingCount: findings.length, findings, status: findings.length === 0 ? "PASS" : "BLOCKED" };
await writeFile(resolve(import.meta.dirname, "security-scan.json"), `${JSON.stringify(result, null, 2)}\n`, "utf8");
if (findings.length > 0) process.exitCode = 1;
