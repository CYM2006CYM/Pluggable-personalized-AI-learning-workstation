# W5-D3-C R3 负责人代整改交付报告

分类：`AUDIT_ONLY / NOT_FOR_GIT`

合同：`W5-C1/W5-R1`

基线：`383690831a8b3de42dad58795e71f218678f6fbc`

裁决：`W5-D64-PYODIDE-1 / PYODIDE_DISABLED_WITH_NODE_FALLBACK`

状态：`NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_GRANTED`

## 整改范围

- 删除最终候选对缺失R1测试文件的现行依赖；历史失败继续保留。
- 普通测试默认不写正式证据；仅采集器通过显式输出路径生成JSON。
- 命令结果只从精确拟提交集合和负责人合同环境生成。
- 安全扫描覆盖正式文件、handoff、审计日志和本报告。
- 最终组包固定执行安全扫描、Manifest重建、验证、组包和解包复验。

## 实测结果

以下结果由R3精确拟提交集合在负责人合同环境真实运行：

```text
TARGETED_TEST = 6_FILES_37_PASSED
FULL_TEST = 98_FILES_824_PASSED_1_SKIPPED
TYPECHECK = PASS
BUILD_DEMO = PASS
BUILD_WEB = PASS
DOCS = PASS
SMOKE_EXTENSION = PASS
RELEASE_CHECK = PASS
SECURITY_SCAN = PASS_55_FILES_0_FINDINGS
MANIFEST_VERIFY = PASS_25_FILES_PLUS_1_SELF_EXCLUDED
RESTAGED_VERIFY = PASS
```

环境：Node`v22.23.1`、npm`10.9.8`、Python`3.13.7`、Pandas`3.0.5`、`PYTHONNOUSERSITE=1`。10组真实HTTP公开包各完成Node三连测；Pyodide均登记`NOT_RUN / PYODIDE_CANDIDATE_UNAVAILABLE`；PID级子进程终止、故障矩阵和环境字段映射均通过。

最终组包工具按固定顺序执行安全扫描、Manifest重建、Manifest验证、组包和解包后再次验证；本报告更新后必须重新运行同一顺序，最终ZIP以最后一次复验结果和旁路SHA-256为准。

## 边界

Pyodide继续逐组登记`NOT_RUN / PYODIDE_CANDIDATE_UNAVAILABLE`。C不修改Profile环境锁、revision seal、revision 2、SDK、依赖、gold、Rubric、hidden tests、reference solution或其他岗位文件。
