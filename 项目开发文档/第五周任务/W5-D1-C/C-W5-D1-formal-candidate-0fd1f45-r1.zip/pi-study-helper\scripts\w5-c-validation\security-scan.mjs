import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const packageRoot = resolve(import.meta.dirname, "../..");
const files = [
  "src/demo/http-server.ts",
  "src/demo/composition-root.ts",
  "tests/w5-c-d1-public-run.test.ts",
  "tests/w4-c-d3-http.test.ts",
];
const forbidden = [
  /answer-key\.json/iu,
  /reference-solutions/iu,
  /(?:^|[^A-Za-z])private(?:[\\/])/iu,
  /(?:^|[^A-Za-z])hidden(?:[\\/])/iu,
  /(?:^|[^A-Za-z])(?:sk|rk)-[A-Za-z0-9_-]{20,}/u,
  /[A-Z]:[\\/]/u,
];
const findings = [];
for (const relative of files) {
  const content = await readFile(resolve(packageRoot, relative), "utf8");
  for (const pattern of forbidden) if (pattern.test(content)) findings.push({ file: relative, pattern: pattern.source });
}
const result = { schemaVersion: 1, scope: files, forbiddenPatterns: forbidden.map((pattern) => pattern.source), findings, status: findings.length === 0 ? "PASS" : "BLOCKED" };
await writeFile(resolve(import.meta.dirname, "security-scan.json"), `${JSON.stringify(result, null, 2)}\n`, "utf8");
if (findings.length !== 0) process.exitCode = 1;
