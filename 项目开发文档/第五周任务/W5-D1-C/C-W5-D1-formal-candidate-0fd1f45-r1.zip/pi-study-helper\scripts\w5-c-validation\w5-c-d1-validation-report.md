# C 岗位 W5-D1 验证报告

## 结论

`CANDIDATE_READY_FOR_REVIEW / NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`

本候选只验证并补充公开执行包 HTTP 边界。`POST /api/activities/:id/run` 通过既有 `prepareActivityRun` 校验会话、Attempt、活动版本、Profile revision、环境和公开资产后签发 `PublicExecutionBundle`；不执行权威判分，不写入正式 Evidence、mastery 或路径事实。E 的 `BrowserCodeRunner`/Worker 不属于 C D1 实现范围。

## 实际基线

- `W5_START_COMMIT`: `4e316822d343d90bdf295f37b7aaaa0131890501`
- `HEAD`: `0fd1f45386682a3859d8d9f6b37904b47ae98c33`
- `origin/main`: `0fd1f45386682a3859d8d9f6b37904b47ae98c33`
- A 公开执行合同已在当前正式上游；C 未修改 A 资产、B 环境锁/seal、D 材料或 E Web/Worker。

## 命令结果

完整结构化结果位于 `command-results.json`。最近一次实际结果：

| 命令 | 结果 |
|---|---|
| C 定向 HTTP + A 公开包/资产/Facade 回归 | 5 files / 44 tests passed, exit 0 |
| `npm.cmd run typecheck` | exit 0 |
| `npm.cmd run build:demo` | exit 0 |
| `npm.cmd run check:docs` | exit 0 |
| `npm.cmd run build:web` | exit 0 |
| `npm.cmd run smoke:extension` | exit 0 |
| `npm.cmd run check:release` | exit 0 |
| `npm.cmd run verify` | 88 files / 767 tests passed / 0 failed, exit 0 |
| `git diff --check` | exit 0 |

首次证据编排曾因 Windows Node 22 直接 `spawn npm.cmd` 返回 `EINVAL`；该失败保留在 `command-results.json.historicalFailures`，随后改为通过 `ComSpec` 调用且仍使用 `shell=false`，最终结果为上述实际值。

## 环境原型

`environment-prototype.json` 实测 Node `v22.23.1`、Python `3.13.7`、Pandas `3.0.5`、`PYTHONNOUSERSITE=1`（`site.ENABLE_USER_SITE=false`），最小 Pandas 清理任务 2 行结果通过。公开数据 1669 bytes，公开测试共 3486 bytes。当前副本未提供 Pyodide 模块，状态登记为 `PYODIDE_CANDIDATE_UNAVAILABLE`；未安装依赖、未修改环境锁，负责人 D3 裁决仍待定。

## 安全与故障边界

- `security-scan.json`：C-owned HTTP/组合根/测试范围零命中答案键、私有/隐藏资产路径、Key 和宿主绝对路径。
- 400 传输错误在 Facade 前拒绝；404/409/422/500/503 映射沿用既有合同。
- evaluator 业务故障保持 200 `not_graded`，不产生正式学习事实。
- 初始化未完成返回 503，端口占用失败且不漂移；这些边界由既有 HTTP 测试覆盖。

## D3 前置限制

Pyodide Worker 生命周期、取消/超时、输出裁剪、双后端 10 组对照和 `PYODIDE_ENABLED`/`PYODIDE_DISABLED_WITH_NODE_FALLBACK` 结论不在 D1 声称 PASS，必须等待 E 候选和负责人裁决后开展。
