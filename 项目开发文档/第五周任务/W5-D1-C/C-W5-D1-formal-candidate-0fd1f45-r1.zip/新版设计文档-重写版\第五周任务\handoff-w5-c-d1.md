# 岗位 C 第五周 D1 交接

## 状态

- 合同：`W5-C1 / W5-R1`
- `W5_START_COMMIT`：`4e316822d343d90bdf295f37b7aaaa0131890501`
- 当前候选基线：`0fd1f45386682a3859d8d9f6b37904b47ae98c33`
- `origin/main`：`0fd1f45386682a3859d8d9f6b37904b47ae98c33`
- 状态：`CANDIDATE_READY_FOR_REVIEW / NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`

## D1 完成内容

C 在既有 HTTP/组合根上复验并补充了 `POST /api/activities/:id/run` 的公开运行边界测试。该端点只接受当前会话、Attempt、活动版本、Profile revision、草稿版本和 `mode=preview`，由现有 `LearningRuntimeFacade.prepareActivityRun` 完成服务端 prepare、资产校验和公开投影，然后返回严格十字段 `PublicExecutionBundle`。

公开包只包含 `runId`、会话/活动/revision/environment 绑定、starter 摘要、公开数据文件、公开测试源码、过期时间和 bundle 摘要。C 不重建 bundle、不读取或下发 hidden tests、答案键、Rubric、参考实现、私有 CSV、Key 或宿主路径；预览不创建 Attempt、Evidence、mastery 或路径事实。Node/Python `submit` 仍是唯一权威评测路径。

E 拥有 `BrowserCodeRunner` 和 Worker。D1 不在服务端复制 Worker，不声称 Pyodide 或双后端通过；D3 需等待 E 候选及负责人 `PYODIDE_ENABLED`/`PYODIDE_DISABLED_WITH_NODE_FALLBACK` 裁决。

## 证据

- 新增 `tests/w5-c-d1-public-run.test.ts`：验证公开包原样返回、活动 ID 路由绑定、十字段白名单、私有/伪造 bundle 字段在 Facade 前被拒绝。
- 既有 `tests/w4-c-d3-http.test.ts`：验证 400/404/409/422/500/503、请求体上限、端口占用、初始化恢复和无 Python Bootstrap。
- 既有 A 测试：验证 bundle canonical hash、资产路径/内容 hash、环境绑定和过期包拒绝。
- `scripts/w5-c-validation/command-results.json` 记录命令全文、工作目录标识、UTC 起止时间、退出码、测试数量和 stdout/stderr SHA-256。
- `security-scan.json` 记录 C-owned HTTP/组合根/测试范围的敏感字段和宿主路径扫描。

## 上游与权限边界

当前正式上游为 `0fd1f45386682a3859d8d9f6b37904b47ae98c33`，包含 A 的公开执行合同与安全投影。C 不修改 A/B/D 文件、Profile 环境锁、revision seal、SDK、依赖、锁文件、E Web/Worker 或正式评测资产。

## 未证明能力

- E `BrowserCodeRunner`/Pyodide Worker、取消/超时/输出裁剪和双后端对照未在 C D1 声称通过。
- D3 的环境实测和 10 组对照必须在 E 候选与负责人裁决后进行。

## 拟提交范围

见 `pi-study-helper/scripts/w5-c-validation/proposed-files.txt`。ZIP、sidecar、`node_modules`、`.demo-data`、缓存和完整原始日志均不进入 Git。
