import { afterEach, describe, expect, it } from "vitest";
import { startHttpServer, type HttpServerHandle } from "../src/demo/http-server.js";
import type { DemoRuntime } from "../src/demo/composition-root.js";
import type { PreparedActivityOutput } from "../src/contracts/facade.js";

const handles: HttpServerHandle[] = [];

function prepared(): PreparedActivityOutput {
  return {
    requestId: "run-request",
    sessionId: "session-1",
    sessionVersion: 4,
    profileRevision: 3,
    mode: "preview",
    runId: "run-1",
    activityId: "activity-1",
    environmentId: "public-python",
    starterCodeHash: `sha256:${"a".repeat(64)}`,
    publicDatasetFiles: [{ name: "orders.csv", content: "id\n1\n", hash: `sha256:${"b".repeat(64)}` }],
    publicTestSources: ["def test_public(): pass"],
    expiresAt: "2026-08-18T00:05:00.000Z",
    bundleHash: `sha256:${"c".repeat(64)}`,
  };
}

async function listen(facade: DemoRuntime["facade"]): Promise<{ handle: HttpServerHandle; url: string; received: Array<Record<string, unknown>> }> {
  const received: Array<Record<string, unknown>> = [];
  const wrapped = new Proxy(facade, {
    get(target, property, receiver) {
      if (property !== "prepareActivityRun") return Reflect.get(target, property, receiver);
      return async (input: Record<string, unknown>) => {
        received.push(structuredClone(input));
        return prepared();
      };
    },
  });
  const runtime = { facade: wrapped, bootstrap: {}, close: async () => undefined } as unknown as DemoRuntime;
  const handle = startHttpServer(Promise.resolve(runtime), 0);
  handles.push(handle);
  await handle.ready;
  const address = handle.server.address();
  if (typeof address !== "object" || address === null) throw new Error("server did not bind");
  return { handle, url: `http://127.0.0.1:${address.port}`, received };
}

afterEach(async () => { await Promise.all(handles.splice(0).map((handle) => handle.close())); });

describe("W5 C D1 public execution boundary", () => {
  it("signs and returns the complete public bundle without rebuilding or adding private fields", async () => {
    const { url, received } = await listen({} as DemoRuntime["facade"]);
    const response = await fetch(`${url}/api/activities/activity-1/run`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-request-id": "http-run-1" },
      body: JSON.stringify({
        sessionId: "session-1",
        sessionVersion: 4,
        profileRevision: 3,
        attemptId: "attempt-1",
        draftVersion: 2,
        activityVersion: 3,
        mode: "preview",
      }),
    });
    expect(response.status).toBe(200);
    const body = await response.json() as { requestId: string; data: PreparedActivityOutput };
    expect(body.requestId).toBe("http-run-1");
    expect(body.data).toEqual(prepared());
    expect(Object.keys(body.data).sort()).toEqual([
      "activityId", "bundleHash", "environmentId", "expiresAt", "mode", "profileRevision",
      "publicDatasetFiles", "publicTestSources", "requestId", "runId", "sessionId", "sessionVersion", "starterCodeHash",
    ].sort());
    expect(JSON.stringify(body)).not.toMatch(/hidden|private|rubric|reference|answerKey|correctAnswer|[A-Za-z]:[\\/]/iu);
    expect(received).toEqual([{
      requestId: "http-run-1",
      sessionId: "session-1",
      sessionVersion: 4,
      profileRevision: 3,
      activityId: "activity-1",
      attemptId: "attempt-1",
      draftVersion: 2,
      activityVersion: 3,
      mode: "preview",
    }]);
  });

  it("rejects caller-supplied bundle and private evaluation fields before the Facade", async () => {
    const { url, received } = await listen({} as DemoRuntime["facade"]);
    const response = await fetch(`${url}/api/activities/activity-1/run`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        sessionId: "session-1",
        sessionVersion: 4,
        profileRevision: 3,
        attemptId: "attempt-1",
        draftVersion: 2,
        activityVersion: 3,
        mode: "preview",
        bundleHash: "sha256:forged",
        hiddenTests: ["secret"],
      }),
    });
    expect(response.status).toBe(400);
    expect(await response.json()).toMatchObject({ error: { code: "invalid_request_shape" } });
    expect(received).toHaveLength(0);
  });
});
