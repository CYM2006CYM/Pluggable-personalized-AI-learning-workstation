import { createHash } from "node:crypto";
import { readFile, readdir, stat, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const packageRoot = resolve(fileURLToPath(new URL("../..", import.meta.url)));
const evidenceRoot = resolve(packageRoot, "scripts/w5-e-validation/evidence/d2");
const networkUrl = process.env.D2_NETWORK_URL;
const forbidden = [
  { id: "hidden-tests", pattern: /hiddenTests?|answerKey/giu },
  { id: "reference-solution", pattern: /referenceSolution|reference-solutions/giu },
  { id: "rubric", pattern: /rubricRef|rubrics\//giu },
  { id: "credential", pattern: /(?:sk|rk)-[A-Za-z0-9_-]{20,}|apiKey|systemPrompt/gu },
  { id: "private-data", pattern: /privateCsv|private raw submission|learnerSubmission/giu },
  { id: "host-path", pattern: /[A-Z]:[\\/](?:Users|home|\.A_C_code)|\/home\//gu },
];

function sha256(value) { return createHash("sha256").update(value).digest("hex"); }
async function text(path) { return readFile(resolve(packageRoot, path), "utf8"); }
function findings(value) {
  return forbidden.flatMap(({ id, pattern }) => [...value.matchAll(pattern)].map((match) => ({ id, match: match[0] })));
}

const commandResults = await text("scripts/w5-e-validation/d2-command-results.json");
const surfaces = [
  { id: "production-bundle", paths: (await readdir(resolve(packageRoot, "dist-web/assets"))).map((name) => `dist-web/assets/${name}`) },
  { id: "worker-source-and-message-boundary", paths: ["src/web/preview/browser-code-runner.ts", "src/web/preview/create-browser-code-runner.ts", "src/web/preview/pyodide-preview.worker.ts"] },
  { id: "session-storage-schema", paths: ["src/web/state/activity-draft-storage.ts"] },
  { id: "public-bundle-fixture", paths: ["tests/web/fixtures/w4-api.ts"] },
  { id: "dom-projections", paths: (await readdir(evidenceRoot)).filter((name) => name.endsWith(".png.json")).map((name) => `scripts/w5-e-validation/evidence/d2/${name}`) },
];
if (networkUrl !== undefined) {
  const response = await fetch(networkUrl);
  if (!response.ok) throw new Error(`network_capture_failed:${response.status}`);
  surfaces.push({ id: "network-bootstrap-response", values: [await response.text()] });
}

const scans = [];
for (const surface of surfaces) {
  const entries = [];
  for (const path of surface.paths ?? []) {
    const value = await text(path);
    entries.push({ path, bytes: Buffer.byteLength(value), sha256: sha256(value), findings: findings(value) });
  }
  for (const path of surface.absolutePaths ?? []) {
    const value = await readFile(path, "utf8");
    entries.push({ path: "<TEMP_NETWORK_CAPTURE>", bytes: Buffer.byteLength(value), sha256: sha256(value), findings: findings(value) });
  }
  for (const value of surface.values ?? []) {
    entries.push({ path: "<IN_MEMORY_NETWORK_CAPTURE>", bytes: Buffer.byteLength(value), sha256: sha256(value), findings: findings(value) });
  }
  scans.push({ surface: surface.id, entries, status: entries.every((entry) => entry.findings.length === 0) ? "PASS" : "FAIL" });
}
scans.push({
  surface: "validation-logs",
  entries: [{ path: "scripts/w5-e-validation/d2-command-results.json", bytes: Buffer.byteLength(commandResults), sha256: sha256(commandResults), findings: findings(commandResults) }],
  status: findings(commandResults).length === 0 ? "PASS" : "FAIL",
});
const security = {
  schemaVersion: 1,
  candidate: "W5-D2-E",
  scans,
  runtimeAssertions: {
    previewResultPostedToServer: false,
    workerNetworkAccess: false,
    previewOutputPersisted: false,
    webImportsRepositoryOrPrivateAssets: false,
  },
  status: scans.every((scan) => scan.status === "PASS") ? "PASS" : "FAIL",
};
await writeFile(resolve(packageRoot, "scripts/w5-e-validation/d2-security-scan.json"), `${JSON.stringify(security, null, 2)}\n`, "utf8");

const screenshotNames = (await readdir(evidenceRoot)).filter((name) => name.endsWith(".png")).sort();
const screenshots = [];
for (const name of screenshotNames) {
  const pngPath = resolve(evidenceRoot, name);
  const projection = JSON.parse(await readFile(`${pngPath}.json`, "utf8"));
  const bytes = await readFile(pngPath);
  screenshots.push({
    path: `scripts/w5-e-validation/evidence/d2/${name}`,
    width: projection.width,
    height: projection.height,
    bytes: (await stat(pngPath)).size,
    sha256: sha256(bytes),
    rootChildren: projection.projection.rootChildren,
    horizontalOverflow: projection.projection.scrollWidth > projection.projection.clientWidth,
    controlsWithoutName: projection.projection.controlsWithoutName,
    settledScreenshot: name.startsWith("study-recovery") ? "PNG shows deep-link recovery state after the early JSON projection" : "PNG and JSON show the start state",
  });
}
const screenshotIndex = {
  schemaVersion: 1,
  candidate: "W5-D2-E",
  browser: "Microsoft Edge headless via CDP",
  ports: { api: 4311, vite: 5174, note: "4310 was occupied by an external process and was not touched" },
  screenshots,
  status: screenshots.length === 4 && screenshots.every((item) => item.rootChildren > 0 && !item.horizontalOverflow && item.controlsWithoutName === 0) ? "PASS" : "FAIL",
};
await writeFile(resolve(packageRoot, "scripts/w5-e-validation/d2-screenshot-index.json"), `${JSON.stringify(screenshotIndex, null, 2)}\n`, "utf8");
process.stdout.write(`${JSON.stringify({ security: security.status, screenshots: screenshotIndex.status, screenshotCount: screenshots.length }, null, 2)}\n`);
process.exitCode = security.status === "PASS" && screenshotIndex.status === "PASS" ? 0 : 1;
