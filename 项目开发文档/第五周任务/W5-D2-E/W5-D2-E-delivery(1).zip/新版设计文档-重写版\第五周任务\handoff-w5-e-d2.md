# 岗位 E W5-D2 交接单

状态：`READY_FOR_OWNER_REVIEW / NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`。

正式基线为 `HEAD == origin/main == 127a71cce4a8423327fb5ce75d31294252b92a0b`，消费 A-D1、C-D1 和 A-D2 正式主干事实。A-D2 交接正文仍含候选阶段状态，但本次只以 Git 提交事实绑定，不修改 A 的材料。

## 完成范围

- Web 开始页支持实际选择安全 Profile，并显示对应 revision 和 modalities；背景问卷、推荐入口和章节入口保持可用。
- 诊断完成后只把安全 `KnowledgeState` 投影和 `capabilityProfileRevision` 交给路径页；`mastery=null` 显示 `unverified`，刷新缺少投影时不推断掌握度。
- `/study` 只接受单份 `sessionId/nodeId/activityId` 三元组，以 Bootstrap 和 `getNextStep` 校验会话、revision、路径、节点、活动和当前 Attempt；失败时从开始页恢复，绝不调用 `startSession`。
- 代码预览固定执行“保存草稿 → 请求正式公开包 → 独立 Worker 本地运行”。完整 `PreparedActivityOutput` 原样交给正式 `BrowserCodeRunner` 合同；预览结果只显示，不回传、不正式提交、不持久化。
- Worker 每次运行创建独立实例，按 `runId` 拒绝迟到消息，支持取消、墙钟超时、UTF-8 输出字节上限、错误销毁和下一次重建。初始化、投递和运行时失败均映射为安全预览状态。
- 草稿记录只含 `sessionId/activityId/attemptId/profileRevision/draftVersion/userText`，仅在 Bootstrap 确认同一 Attempt 和版本后恢复；正式提交成功后清理。

## 降级与边界

`PYODIDE_CANDIDATE_UNAVAILABLE`：C-D1 已证明仓库没有获批的本地 Pyodide 资产。本候选不使用 CDN、不访问网络、不新增依赖，也不声称 Pyodide 已启用。页面明确显示不可用状态，既有 Node/Python 正式提交按钮独立可用。

`LIVE_MODEL=LIVE_NOT_RUN`。本候选不声明 D4 Web/TUI 正反向跨端闭环、服务重启闭环、负责人 D3 双后端裁决、三个正式案例或 W5 PASS。Monaco 保持关闭。

## 验证和材料

结构化命令结果与 stdout/stderr SHA-256、首次失败历史、测试映射、上游绑定、限制、泄漏扫描、截图索引、精确拟提交清单和逐文件 SHA-256 位于 `pi-study-helper/scripts/w5-e-validation/`。候选没有修改合同、Facade、HTTP 服务端、Profile、gold、SDK、依赖或锁文件，也没有移动或改写现有 W4 证据。

未取得负责人明确确认和上传锁，不执行 `git commit` 或 `git push`。
