import { createHash } from "node:crypto";
import { readFile, stat, writeFile } from "node:fs/promises";
import { resolve, relative } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const packageRoot = resolve(fileURLToPath(new URL("../..", import.meta.url)));
const repositoryRoot = resolve(packageRoot, "..");
const proposedPath = resolve(packageRoot, "scripts/w5-e-validation/d2-proposed-files.txt");
const manifestPath = resolve(packageRoot, "scripts/w5-e-validation/d2-sha256-manifest.json");
const handoff = "新版设计文档-重写版/第五周任务/handoff-w5-e-d2.md";

function gitLines(args) {
  const result = spawnSync("git", args, { cwd: repositoryRoot, encoding: "utf8" });
  if (result.status !== 0) throw new Error(result.stderr || "git_inventory_failed");
  return result.stdout.split(/\r?\n/u).filter(Boolean).map((path) => path.replaceAll("\\", "/"));
}

const candidates = new Set([
  ...gitLines(["diff", "--name-only"]),
  ...gitLines(["ls-files", "--others", "--exclude-standard"]),
  "pi-study-helper/scripts/w5-e-validation/d2-proposed-files.txt",
  "pi-study-helper/scripts/w5-e-validation/d2-sha256-manifest.json",
  handoff,
]);
const allowed = [...candidates].filter((path) => path.startsWith("pi-study-helper/src/web/")
  || path.startsWith("pi-study-helper/tests/web/")
  || path.startsWith("pi-study-helper/scripts/w5-e-validation/")
  || path === handoff).sort();
await writeFile(proposedPath, `${allowed.join("\n")}\n`, "utf8");

const files = [];
for (const path of allowed) {
  if (path.endsWith("d2-sha256-manifest.json")) continue;
  const absolute = resolve(repositoryRoot, path);
  const bytes = await readFile(absolute);
  files.push({ path, bytes: (await stat(absolute)).size, sha256: createHash("sha256").update(bytes).digest("hex") });
}
const manifest = {
  schemaVersion: 1,
  candidate: "W5-D2-E",
  baseHead: "127a71cce4a8423327fb5ce75d31294252b92a0b",
  selfExcluded: [relative(repositoryRoot, manifestPath).replaceAll("\\", "/")],
  files,
};
await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
process.stdout.write(`${JSON.stringify({ proposedFiles: allowed.length, manifestFiles: files.length }, null, 2)}\n`);
