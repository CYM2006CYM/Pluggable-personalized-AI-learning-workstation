import { createHash } from "node:crypto";
import { mkdtemp, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const packageRoot = resolve(fileURLToPath(new URL("../..", import.meta.url)));
const repositoryRoot = resolve(packageRoot, "..");
const outputPath = resolve(packageRoot, "scripts/w5-e-validation/d2-command-results.json");
const rawLogRoot = await mkdtemp(resolve(tmpdir(), "w5-e-d2-validation-"));
const ansi = /\u001b\[[0-9;]*m/gu;
const forbidden = /hiddenTest|referenceSolution|rubricRef|apiKey|systemPrompt|privateCsv|(?:sk|rk)-[A-Za-z0-9_-]{20,}/giu;
let previous;
try { previous = JSON.parse(await readFile(outputPath, "utf8")); } catch { previous = undefined; }

const commands = [
  ["typecheck", "npm.cmd run typecheck", packageRoot],
  ["test-web", "npm.cmd run test:web -- --maxWorkers=1", packageRoot],
  ["affected-regression", "npm.cmd test -- --run tests/w5-c-d1-public-run.test.ts tests/shared-session.test.ts tests/shared-web-extension-entry.test.ts --maxWorkers=1", packageRoot],
  ["full-test", "npm.cmd test -- --maxWorkers=1", packageRoot],
  ["check-docs", "npm.cmd run check:docs", packageRoot],
  ["build-web", "npm.cmd run build:web", packageRoot],
  ["build-demo", "npm.cmd run build:demo", packageRoot],
  ["smoke-extension", "npm.cmd run smoke:extension", packageRoot],
  ["check-release", "npm.cmd run check:release", packageRoot],
  ["verify", "npm.cmd run verify", packageRoot],
  ["git-diff-check", "git diff --check", repositoryRoot],
];

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

function normalize(value) {
  return String(value ?? "")
    .replace(ansi, "")
    .split(repositoryRoot).join("<REPOSITORY_ROOT>")
    .split(repositoryRoot.replaceAll("\\", "/")).join("<REPOSITORY_ROOT>")
    .replaceAll("\\", "/");
}

const results = [];
for (const [id, command, cwd] of commands) {
  const startedAtUtc = new Date().toISOString();
  const execution = spawnSync(command, { cwd, shell: true, encoding: "utf8", timeout: 900_000, maxBuffer: 64 * 1024 * 1024 });
  const endedAtUtc = new Date().toISOString();
  const stdout = normalize(execution.stdout);
  const stderr = normalize(execution.stderr);
  await writeFile(resolve(rawLogRoot, `${id}.stdout.log`), stdout, "utf8");
  await writeFile(resolve(rawLogRoot, `${id}.stderr.log`), stderr, "utf8");
  const matches = [...`${stdout}\n${stderr}`.matchAll(forbidden)].map((match) => match[0]);
  results.push({
    id,
    command,
    cwd: cwd === packageRoot ? "pi-study-helper" : ".",
    startedAtUtc,
    endedAtUtc,
    exitCode: execution.status ?? 1,
    status: execution.status === 0 ? "PASS" : execution.error?.code === "ETIMEDOUT" ? "TIMEOUT" : "FAIL",
    stdout: { bytes: Buffer.byteLength(stdout), sha256: sha256(stdout) },
    stderr: { bytes: Buffer.byteLength(stderr), sha256: sha256(stderr) },
    logSafetyFindings: [...new Set(matches)],
  });
}

const history = [
  {
    event: "first D2 typecheck",
    result: "DedicatedWorkerGlobalScope was absent from the configured Web lib",
    status: "FIXED_LOCAL_WORKER_TYPE",
    resolution: "The Worker uses a narrow local message/postMessage scope; final typecheck passes."
  },
  {
    event: "first D2 Web regression",
    result: "2 expected assertion failures after Profile selection and real Worker preview replaced D1 display-only behavior",
    status: "FIXED_EXPECTATION_UPGRADE",
    resolution: "Assertions now verify six selects and the exact public bundle delivered to the Worker; final Web suite passes."
  },
  {
    event: "first new deep-link test typecheck",
    result: "quiz Attempt fixture omitted retryNumber",
    status: "FIXED_TYPED_TEST_FIXTURE",
    resolution: "The fixture now conforms to CurrentAttemptSafeReference; final typecheck passes."
  }
];

const document = {
  schemaVersion: 1,
  candidate: "W5-D2-E",
  baseHead: "127a71cce4a8423327fb5ce75d31294252b92a0b",
  state: "NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED",
  generatedAtUtc: new Date().toISOString(),
  environment: {
    nodeVersion: process.version,
    pythonExecutable: process.env.PI_PYTHON_EXECUTABLE === undefined ? "UNSET" : "<CONTRACT_PYTHON_3_13_7_PANDAS_3_0_5>",
    pythonNoUserSite: process.env.PYTHONNOUSERSITE ?? "UNSET",
  },
  rawLogs: "AUDIT_ONLY_OUTSIDE_GIT",
  outputNormalization: "ANSI removed; repository path replaced by <REPOSITORY_ROOT>; separators normalized before byte count and SHA-256.",
  commands: results,
  history,
  priorRuns: previous === undefined ? [] : [
    ...(Array.isArray(previous.priorRuns) ? previous.priorRuns : []),
    {
      generatedAtUtc: previous.generatedAtUtc,
      overallStatus: previous.overallStatus,
      environment: previous.environment ?? { pythonExecutable: "UNSET" },
      commands: previous.commands,
    },
  ],
  overallStatus: results.every((result) => result.exitCode === 0 && result.logSafetyFindings.length === 0) ? "PASS" : "FAIL",
};
await writeFile(outputPath, `${JSON.stringify(document, null, 2)}\n`, "utf8");
process.stdout.write(`${JSON.stringify({ outputPath, rawLogs: "AUDIT_ONLY_OUTSIDE_GIT", overallStatus: document.overallStatus, commands: results.length }, null, 2)}\n`);
process.exitCode = document.overallStatus === "PASS" ? 0 : 1;
