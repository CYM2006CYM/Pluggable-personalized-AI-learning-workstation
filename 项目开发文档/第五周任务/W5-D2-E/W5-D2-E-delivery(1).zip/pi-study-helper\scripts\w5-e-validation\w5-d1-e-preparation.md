# W5 D1 E 岗位准备记录

状态：`PREPARATION_ONLY`

本记录只登记 E 在 D1 的页面、Worker 接口和测试骨架准备，不构成 W5 功能通过、上游交接或 V5 门禁结论。

## 范围

- 页面和 API 仍沿用 W4 的安全 DTO 与单一 `LearningRuntimeFacade` 适配。
- 新增 `WorkerBrowserCodeRunner` 生命周期适配骨架，覆盖每次运行创建独立 Worker、取消、超时、UTF-8 字节输出上限、Worker 销毁和迟到 `runId` 消息丢弃。
- 浏览器端只接受公开运行包的结构化字段；服务端创建、校验和签发公开包仍属于 A/C D2 正式交接内容。
- 没有实现 Pyodide 加载器、真实 Worker 脚本或公开执行端点。

## 新增文件

| 文件 | 用途 |
|---|---|
| `src/web/preview/browser-code-runner.ts` | E-owned 公开运行包结构视图、Worker 协议和生命周期适配骨架 |
| `tests/web/browser-code-runner.test.ts` | 协议、隔离、取消、超时、输出裁剪、迟到消息和错误状态测试 |

## D1 边界

- A/C 正式 `PublicExecutionBundle`、HTTP `/run` 和环境测量尚未交接；本骨架不把 W4 `PreparedActivityOutput` 宣称为 W5 正式合同。
- 公开预览结果不会写入 Attempt、Evidence、KnowledgeState 或 Path。
- `preview_unavailable`、`preview_cancelled`、`preview_timeout`、`preview_output_limit` 和 `preview_protocol_error` 均保持为预览错误，不映射为学习者负面证据。
- 未修改 `src/contracts/`、`src/application/`、`src/demo/`、Profile、gold、SDK、依赖和既有 W4 证据。

## 待 D2 输入

1. A D1 正式公开 DTO、安全投影和负向用例。
2. C D1 正式公开执行端点、候选环境和故障边界。
3. 负责人 D3 的 `PYODIDE_ENABLED` 或 `PYODIDE_DISABLED_WITH_NODE_FALLBACK` 裁决。

在上述输入到位前，E 不签署页面集成 PASS、Pyodide 可用性或 V5 结论。
