# 岗位 C W5-D1 R2 验证报告

## 结论

`CANDIDATE_READY_FOR_REVIEW / NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_GRANTED`

本轮补齐真实零副作用 HTTP 集成证据，并重构正式 Git 文件、Manifest 和审核 ZIP 的集合边界。`POST /api/activities/:id/run` 只执行 prepare、公开资产摘要校验和 `PublicExecutionBundle` 签发；不运行 evaluator、不产生正式学习事实。`POST /api/activities/:id/submit` 才是 Node/Python 权威 evaluator 入口。

## 基线与边界

- `W5_START_COMMIT`: `4e316822d343d90bdf295f37b7aaaa0131890501`
- `HEAD` / `origin/main`: `0fd1f45386682a3859d8d9f6b37904b47ae98c33`
- A 正式上游：`0fd1f45386682a3859d8d9f6b37904b47ae98c33`
- C 未修改 A contracts/Facade、B Profile/environment-lock/seal、D 评测材料、E Worker/BrowserCodeRunner、SDK、依赖、锁文件、gold 或正式事实规则。

## R2-01 真实集成

`tests/w5-c-d1-public-run.test.ts` 当前 4 个测试，其中真实用例连接 `startHttpServer`、真实 `CodeActivityFacadeAdapter`、`FileLearningSessionRepository`、`FileActivityRepository`、A 的 `projectPublicExecutionBundle`/`validatePublicExecutionBundle`，以及仅含公开 CSV/公开测试的测试资产 resolver。轨迹建立真实 session、候选路径和确认路径，打开代码 Activity 生成 Attempt，再通过 HTTP `/run` 获取公开包。测试逐字段确认 13 个公共响应字段、数据和 bundle hash，并比较调用前后 session snapshot：sessionVersion、Attempt、Evidence、KnowledgeState、mastery、path、activityProgress、evidenceVersion 均不变。环境不匹配和资产校验失败均无 public bundle；夹带 bundleHash/hiddenTests 仍在 Facade 前 400。

## R2-02 状态矩阵

`endpoint-status-matrix.json` 已明确区分 `/run` 与 `/submit`：`/run` 不运行 evaluator，环境或资产失败只返回安全 `not_graded` 投影；`/submit` 才执行权威 evaluator，evaluator 故障保持 HTTP 200、`not_graded`，不推进活动或写入负 Evidence。

## 命令结果

完整命令、工作目录、UTC 起止时间、自然/编排退出码、数量及 stdout/stderr 字节数和 SHA-256 见 `command-results.json`。C 定向为 5 files / 46 passed / 0 failed / 0 skipped；A/C 回归为 3 files / 17 passed / 0 failed / 0 skipped；Python evaluator 为 3 files / 31 passed / 0 failed / 0 skipped；全量测试和 `verify` 均为 88 files / 769 passed / 0 failed / 1 skipped。历史 `spawn npm.cmd -> EINVAL` 保留，归因于验证脚本编排；后续通过 `ComSpec` 且 `shell=false` 修复。初次 Manifest 复验因读取整改前旧 Manifest 返回 1，重新生成后最终复验返回 0；两次事实均保留。本轮第一次重新执行验证编排被外层工具的 5 秒超时中断（编排退出码 124、无自然退出码），清理遗留子进程后使用充足超时重跑，最终自然退出码为 0；该中断不归因为源码失败且未被删除。

## 环境与限制

合同环境要求 Node `v22.23.1`、npm `10.9.8`、Python `3.13.7`、Pandas `3.0.5`、`PYTHONNOUSERSITE=1`；`environment-prototype.json` 保存实际探针。Pyodide 状态仍为 `PYODIDE_CANDIDATE_UNAVAILABLE`，不安装依赖、不修改环境锁。C 未实现 E 的 Worker/BrowserCodeRunner；D3 双后端裁决和 10 组对照尚未开始。W5-D1-C 通过不等于 Pyodide 启用或 W5 GO。

## 文件集合

- `proposed-files.txt` 只列正式 Git 文件。
- `manifest.json` 是唯一 `selfExcluded` 文件，并覆盖其余正式拟提交文件。
- `hash-inventory.txt`、`manifest-verification.json` 仅在审核 ZIP 中标记 `AUDIT_ONLY / NOT_FOR_GIT`，不进入正式拟提交集合。
- ZIP、sidecar、完整原始日志、`.demo-data`、`.demo-build`、`node_modules`、虚拟环境和私有资产不进入 Git。
