# 岗位 C 第五周 D1 R2 交接

## 状态

- 合同：`W5-C1 / W5-R1`
- `W5_START_COMMIT`：`4e316822d343d90bdf295f37b7aaaa0131890501`
- `HEAD` / `origin/main` / A 正式上游：`0fd1f45386682a3859d8d9f6b37904b47ae98c33`
- 状态：`NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_GRANTED`

## R2 完成

`tests/w5-c-d1-public-run.test.ts` 新增真实 HTTP -> `CodeActivityFacadeAdapter` -> `FileLearningSessionRepository`/`FileActivityRepository` 轨迹，使用仅公开数据和公开测试的测试资产，并通过 A 的公开 bundle projector/validator 校验 13 字段 DTO、数据 hash、bundle hash 和无私有泄漏。`/run` 前后 sessionVersion、Attempt、Evidence、KnowledgeState、mastery、path、activityProgress、evidenceVersion 完全不变。环境不匹配、资产校验失败不签发 public bundle；请求夹带 bundleHash/hiddenTests 等派生或私有字段仍在 Facade 前返回 400。

`endpoint-status-matrix.json` 已区分：`/run` 只 prepare/校验/签发公开包且不运行 evaluator；`/submit` 才运行权威 Node/Python evaluator，评测器故障保持 HTTP 200、`not_graded` 且不产生负 Evidence。

## 上游与权限边界

C 未修改 A contracts/Facade、B Profile/environment-lock/seal、D 评测材料、E Worker/BrowserCodeRunner、SDK、依赖、锁文件、gold 或正式 Evidence/mastery/path 规则。C 未实现 E 的 Worker/BrowserCodeRunner。Pyodide 当前登记 `PYODIDE_CANDIDATE_UNAVAILABLE`；D3 双后端裁决和 10 组对照尚未开始。W5-D1-C 通过不等于 Pyodide 启用或 W5 GO。

## 证据与文件范围

完整命令证据见 `pi-study-helper/scripts/w5-c-validation/command-results.json`。C 定向为 5 files / 46 passed / 0 failed / 0 skipped；A/C 回归为 3 files / 17 passed / 0 failed / 0 skipped；Python evaluator 为 3 files / 31 passed / 0 failed / 0 skipped；全量测试和 `verify` 均为 88 files / 769 passed / 0 failed / 1 skipped。历史 `spawn npm.cmd -> EINVAL` 失败（验证脚本编排问题）以及后续 `ComSpec` + `shell=false` 修复结果均保留。本轮首次重跑又被外层工具 5 秒超时中断（编排退出码 124、无自然退出码），清理遗留子进程后用充足超时重跑并自然退出 0；该事实亦保留。`proposed-files.txt` 只列正式 Git 文件；`manifest.json` 是唯一 `selfExcluded`；`hash-inventory.txt` 与 `manifest-verification.json` 仅为 `AUDIT_ONLY / NOT_FOR_GIT` 审核材料。ZIP、sidecar、完整日志、缓存、`.demo-data`、`.demo-build`、`node_modules`、虚拟环境和私有资产不进入 Git。
