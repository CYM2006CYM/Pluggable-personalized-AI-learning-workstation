import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { resolve } from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { ActivityRuntimeService } from "../src/application/activity-runtime-service.js";
import { CodeActivityFacadeAdapter, type CodeActivityAssets } from "../src/application/code-activity-facade-adapter.js";
import { hashPublicExecutionBundle, sha256Text, validatePublicExecutionBundle } from "../src/application/public-execution-bundle.js";
import type { PreparedActivityOutput } from "../src/contracts/facade.js";
import { FixtureCodeEvaluationAdapter } from "../src/infrastructure/code-evaluation-port.js";
import { FileActivityRepository } from "../src/repositories/file-activity-repository.js";
import { FileLearningSessionRepository } from "../src/repositories/file-learning-session-repository.js";
import { startHttpServer, type HttpServerHandle } from "../src/demo/http-server.js";
import type { DemoRuntime } from "../src/demo/composition-root.js";

const roots: string[] = [];
const handles: HttpServerHandle[] = [];
const now = () => new Date("2026-08-18T00:00:00.000Z");
const environmentHash = `sha256:${"b".repeat(64)}`;
const assetBundleHash = `sha256:${"a".repeat(64)}`;
const publicData = "id\n1\n";
const publicDataHash = sha256Text(publicData);

const assets: CodeActivityAssets = {
  activity: {
    activityId: "code",
    activityVersion: 3,
    kind: "code_completion",
    title: "Public code activity",
    prompt: "Complete the public exercise",
    primaryKnowledgePointId: "kp",
    supportingKnowledgePointIds: [],
    starterCode: "print(1)\n",
    templateVersion: "3.0.0",
    environmentRef: "public-python",
  },
  knowledgePoint: { id: "kp", requiresCodeEvidence: true },
  assignment: {
    activityId: "code", activityVersion: 3, profileRevision: 3, primaryKnowledgePointId: "kp",
    kind: "code_completion", source: "fixed", assetBundleHash, environmentId: "public-python",
  },
  evaluationActivity: { activityId: "code", kind: "code_completion", profileRevision: 3, templateVersion: "3.0.0", environmentRef: "public-python" },
  taskVersion: "3.0.0",
  environment: { environmentId: "public-python", status: "measured", environmentHash, prototypeEvidenceRef: "W3-D40-ENV-1" },
  assetBundleHash,
  publicDatasetFiles: [{ name: "public.csv", content: publicData, hash: publicDataHash }],
  publicTestSources: ["def test_public():\n    assert True\n"],
};

async function createServer(options: { resolvedAssets?: CodeActivityAssets; resolverError?: Error }): Promise<{
  handle: HttpServerHandle;
  url: string;
  sessions: FileLearningSessionRepository;
  sessionId: string;
  sessionVersion: number;
  attemptId: string;
}> {
  const root = await mkdtemp(resolve(tmpdir(), "w5-c-public-run-"));
  roots.push(root);
  const sessions = new FileLearningSessionRepository({ dataRoot: root, now });
  const activities = new FileActivityRepository({ dataRoot: root, now });
  const session = await sessions.create({ requestId: "create", subjectId: "pandas-cleaning", mode: "recommended", goalId: "goal", availableMinutes: 20, profileRevision: 3, diagnosticRequired: false });
  await sessions.commit({ requestId: "build", sessionId: session.sessionId, sessionVersion: 1, profileRevision: 3, candidate: {
    requestId: "build",
    knowledgeStates: [],
    pathCandidate: { pathId: "path-1", pathVersion: 1, status: "candidate", goalId: "goal", mode: "recommended", nodes: [{ nodeId: "node-1", knowledgePointId: "kp", activityIds: ["code"], status: "available", estimatedMinutes: 10, reasonCodes: [], difficulty: "S-U", scaffold: "none", required: true, positionLocked: false }] },
  } });
  const active = await sessions.commit({ requestId: "confirm", sessionId: session.sessionId, sessionVersion: 2, profileRevision: 3, candidate: {
    requestId: "confirm",
    knowledgeStates: [],
    pathCandidate: { pathId: "path-1", pathVersion: 1, status: "active", goalId: "goal", mode: "recommended", nodes: [{ nodeId: "node-1", knowledgePointId: "kp", activityIds: ["code"], status: "available", estimatedMinutes: 10, reasonCodes: [], difficulty: "S-U", scaffold: "none", required: true, positionLocked: false }] },
    activityProgress: [{ nodeId: "node-1", card: { cardId: "card-kp", status: "pending" }, activities: [{ activityId: "code", status: "pending", attemptIds: [], quizRetryCount: 0, updatedAt: now().toISOString() }] }],
    boundLearningCards: [{ nodeId: "node-1", source: "fixed", card: { cardId: "card-kp", knowledgePointId: "kp", title: "KP", objective: "Learn KP", explanation: ["Public explanation"], example: "Example", commonMistake: "Mistake", sourceAnchorIds: [], estimatedMinutes: 1 } }],
  } });
  const evaluator = new FixtureCodeEvaluationAdapter({ resultsByActivityId: { code: { executionStatus: "completed", verdict: "pass", score: 1, safeFeedback: "ok", evaluatorVersion: "fixture", environmentHash, assetBundleHash } }, now });
  let assetLoads = 0;
  const adapter = new CodeActivityFacadeAdapter({
    sessions,
    activities,
    runtime: new ActivityRuntimeService(activities, evaluator),
    assets: { async load() { assetLoads += 1; if (options.resolverError && assetLoads > 1) throw options.resolverError; return structuredClone(options.resolvedAssets ?? assets); } },
    pathSuffix: { async replan() { return { changeReasons: [] }; } },
    now,
  });
  const opened = await adapter.openActivity({ requestId: "open", sessionId: session.sessionId, sessionVersion: active.sessionVersion, profileRevision: 3, activityId: "code", activityVersion: 3, pathVersion: 1, acknowledgedCardId: "card-kp" });
  const runtime = { facade: adapter as unknown as DemoRuntime["facade"], bootstrap: {} as DemoRuntime["bootstrap"], close: async () => undefined } as DemoRuntime;
  const handle = startHttpServer(Promise.resolve(runtime), 0);
  handles.push(handle);
  await handle.ready;
  const address = handle.server.address();
  if (typeof address !== "object" || address === null) throw new Error("server did not bind");
  return { handle, url: `http://127.0.0.1:${address.port}`, sessions, sessionId: session.sessionId, sessionVersion: opened.sessionVersion, attemptId: opened.attemptId };
}

afterEach(async () => {
  await Promise.all(handles.splice(0).map((handle) => handle.close()));
  await Promise.all(roots.splice(0).map((root) => rm(root, { recursive: true, force: true })));
});

describe("W5 C D1 public execution boundary", () => {
  it("runs the real HTTP -> CodeActivityFacadeAdapter -> repositories prepare path without facts", async () => {
    const { url, sessions, sessionId, sessionVersion, attemptId } = await createServer({});
    const before = await sessions.getSnapshot({ sessionId, sessionVersion, profileRevision: 3 });
    const response = await fetch(`${url}/api/activities/code/run`, {
      method: "POST", headers: { "content-type": "application/json", "x-request-id": "http-run-1" },
      body: JSON.stringify({ sessionId, sessionVersion, profileRevision: 3, attemptId, draftVersion: 2, activityVersion: 3, mode: "preview" }),
    });
    expect(response.status).toBe(200);
    const body = await response.json() as { requestId: string; data: PreparedActivityOutput };
    expect(body.requestId).toBe("http-run-1");
    expect(Object.keys(body.data).sort()).toEqual(["activityId", "bundleHash", "environmentId", "expiresAt", "mode", "profileRevision", "publicDatasetFiles", "publicTestSources", "requestId", "runId", "sessionId", "sessionVersion", "starterCodeHash"].sort());
    expect(body.data.publicDatasetFiles[0]).toEqual({ name: "public.csv", content: publicData, hash: publicDataHash });
    expect(body.data.bundleHash).toBe(hashPublicExecutionBundle(body.data));
    validatePublicExecutionBundle({
      runId: body.data.runId,
      sessionId: body.data.sessionId,
      activityId: body.data.activityId,
      profileRevision: body.data.profileRevision,
      environmentId: body.data.environmentId,
      starterCodeHash: body.data.starterCodeHash,
      publicDatasetFiles: body.data.publicDatasetFiles,
      publicTestSources: body.data.publicTestSources,
      expiresAt: body.data.expiresAt,
      bundleHash: body.data.bundleHash,
    }, { sessionId, activityId: "code", profileRevision: 3, environmentId: "public-python" }, now());
    const after = await sessions.getSnapshot({ sessionId, sessionVersion: body.data.sessionVersion, profileRevision: 3 });
    expect(after).toEqual(before);
    expect(JSON.stringify(body)).not.toMatch(/hidden|private|rubric|reference|answer|api[_ -]?key|correct|[A-Za-z]:[\\/]/iu);
  });

  it("rejects caller-supplied bundle and private evaluation fields before the Facade", async () => {
    const { url } = await createServer({});
    const response = await fetch(`${url}/api/activities/code/run`, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ sessionId: "session", sessionVersion: 4, profileRevision: 3, attemptId: "attempt", draftVersion: 2, activityVersion: 3, mode: "preview", bundleHash: "sha256:forged", hiddenTests: ["secret"] }),
    });
    expect(response.status).toBe(400);
    expect(await response.json()).toMatchObject({ error: { code: "invalid_request_shape" } });
  });

  it("does not issue a public bundle for an environment mismatch", async () => {
    const wrong = structuredClone(assets); wrong.environment = { ...wrong.environment, environmentId: "wrong-environment" };
    const { url, sessionId, sessionVersion, attemptId } = await createServer({ resolvedAssets: wrong });
    const response = await fetch(`${url}/api/activities/code/run`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ sessionId, sessionVersion, profileRevision: 3, attemptId, draftVersion: 2, activityVersion: 3, mode: "preview" }) });
    expect(response.status).toBe(200);
    const payload = await response.json() as Record<string, unknown>;
    expect(payload).toMatchObject({ data: { verdict: "not_graded" } });
    expect((payload.data as Record<string, unknown>)?.publicDatasetFiles).toBeUndefined();
    expect(JSON.stringify(payload)).not.toMatch(/wrong-environment|private|hidden|rubric|reference|[A-Za-z]:[\\/]/iu);
  });

  it("does not issue a public bundle when the asset resolver reports invalid assets", async () => {
    const { url, sessionId, sessionVersion, attemptId } = await createServer({ resolverError: Object.assign(new Error("asset details"), { errorCode: "test_asset_invalid" }) });
    const response = await fetch(`${url}/api/activities/code/run`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ sessionId, sessionVersion, profileRevision: 3, attemptId, draftVersion: 2, activityVersion: 3, mode: "preview" }) });
    expect(response.status).toBe(200);
    const payload = await response.json() as Record<string, unknown>;
    expect(payload).toMatchObject({ data: { errorCode: "test_asset_invalid", verdict: "not_graded" } });
    expect((payload.data as Record<string, unknown>)?.publicDatasetFiles).toBeUndefined();
    expect(JSON.stringify(payload)).not.toMatch(/asset details|private|hidden|rubric|reference|[A-Za-z]:[\\/]/iu);
  });
});
