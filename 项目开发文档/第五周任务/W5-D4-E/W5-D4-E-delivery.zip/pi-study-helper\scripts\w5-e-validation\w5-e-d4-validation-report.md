# W5-D4 E 验证报告

状态：`READY_FOR_OWNER_REVIEW / NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_GRANTED`

正式基线为 `aaf588202b3ae92ed72c63994b912d78977516bb`，合同为 `W5-C1/W5-R1`，Profile revision 3 seal 为 `ccff2e2afdabaad262baeaa498b527438fcadeec1ddf5e198289f8404071e85d`。

## 结论

- `PYODIDE_DECISION=PYODIDE_DISABLED_WITH_NODE_FALLBACK`
- `PYODIDE_ENABLED=false`
- `LIVE_MODEL=LIVE_NOT_RUN`
- `PATH_LEGALITY=3/3`
- `PAIR_DIFFERENCES=32/12/21`
- `CROSS_END=PASS`
- `SAME_ATTEMPT=PASS`
- `SAME_EVIDENCE=PASS`
- `PENDING_AFTER_COMMIT_ONLY=PASS`
- `SECURITY_SCAN=PASS`
- `DESKTOP_MOBILE=PASS`

活动页不再导入或实例化浏览器 Runner，不显示预览按钮，也不发起 `/run`。底层 BrowserCodeRunner、Worker 和公开运行合同继续保留。正式提交按钮通过页面测试、运行期测试和 Edge/CDP 页面投影确认可用。

三案例页面直接读取 A-D4 正式结构化结果，不读取 B 的预期差异矩阵，不在前端执行 PathEngine 或 mastery 计算。E 的独立验证器从 A 输出重新计算哈希与差异，并按 revision 3 的公共知识点拓扑和活动归属验证路径。

## 命令结果

- Web：16 files，104 passed，0 failed，0 skipped。
- 受影响回归：8 files，33 passed，0 failed，0 skipped。
- 全量：104 files，841 passed，0 failed，1 skipped。
- `npm.cmd run verify`：104 files，841 passed，0 failed，1 skipped。
- 所有非测试门禁退出码为 0。

逐命令 UTC、退出码、测试项数及 stdout/stderr SHA-256 见 `d4-command-results.json`。原始日志仅保存在系统临时目录，不进入 Git 或 ZIP。

## 安全与页面证据

Edge/CDP 捕获 6 张 PNG 和对应结构化投影。扫描范围为 DOM、网络、Worker 资源、local/session storage、Cache Storage、IndexedDB、控制台日志及 `dist-web` 构建产物。所有范围零敏感命中，且页面网络没有 `/run` 请求或外部请求，生产构建没有 Worker chunk。

PNG 为 `AUDIT_ONLY`。正式 Git 仅保留截图索引、投影、哈希和必要结构化证据。

