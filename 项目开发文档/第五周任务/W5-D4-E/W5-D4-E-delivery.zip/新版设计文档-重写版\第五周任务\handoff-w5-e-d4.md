# 岗位 E W5-D4 交接单

状态：`READY_FOR_OWNER_REVIEW / NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_GRANTED`

## 正式绑定

- 合同：`W5-C1/W5-R1`
- 基线：`aaf588202b3ae92ed72c63994b912d78977516bb`
- A-D2：`127a71cce4a8423327fb5ce75d31294252b92a0b`
- E-D2：`590985af616861e503ee30f2bf56c6392b0055f7`
- C-D3：`6acc56fa03986797be54156af639a905c2e74a64`
- B-D3：`a0d5a37116a6c67f009ca19e313501d9eed96f78`
- A-D4 可移植 Manifest 修复：`aaf588202b3ae92ed72c63994b912d78977516bb`
- revision 3 seal：`ccff2e2afdabaad262baeaa498b527438fcadeec1ddf5e198289f8404071e85d`

## E-D4 结果

1. 页面已落实 `PYODIDE_DISABLED_WITH_NODE_FALLBACK`：活动页没有可点击预览按钮、不调用 `/run`、没有预览路由或双后端启用文案；`BrowserCodeRunner`、Worker 与公共 `/run` 合同保留，Node/Python“提交正式评测”保持可用。
2. 新增 `/showcases` 只读页面，直接以 Vite `?raw` 消费 A-D4 的 `showcase-path-results.json` 和 `showcase-differences.json`。页面源码不保存手工路径节点或差异矩阵。
3. E 独立复算三条路径均通过公共 Profile 拓扑、活动归属、脚手架、下一步与路径/输出哈希校验，合法率 `3/3 = 100%`；三对实际差异为 `32 / 12 / 21`，均不少于三项。
4. A 的两条正式跨端轨迹重新运行并由 E 结构化复验：Web/TUI 共享同一 session，同一 Attempt 和 Evidence ID/版本可在刷新或服务重启后读取，pending 只在正式结果 `committed=true` 后清理。
5. 模型失败固定 fallback、评测器失败恢复、版本冲突、重复提交和服务重启由受影响回归覆盖。
6. Edge/CDP 实际生成 6 份页面证据：三案例桌面、案例移动端、活动关闭态桌面和移动端。DOM、网络、Worker 资源、浏览器存储、控制台日志及生产 bundle 泄漏扫描均为 PASS。

## 测试摘要

- 合同环境：Node `v22.23.1`、npm `10.9.8`、Python `3.13.7`、Pandas `3.0.5`、`PYTHONNOUSERSITE=1`
- Web：`16 files / 104 passed / 0 failed / 0 skipped`
- 受影响回归：`8 files / 33 passed / 0 failed / 0 skipped`
- 全量：`104 files / 841 passed / 0 failed / 1 skipped`
- `typecheck`、A-D4 Manifest、CRLF 可移植性、docs、Web/Demo build、extension smoke、release、`verify` 和 `git diff --check` 均通过。

## 证据位置

结构化命令结果、独立验证、浏览器捕获、安全扫描、截图索引、页面文案、测试映射、限制与上游绑定位于 `pi-study-helper/scripts/w5-e-validation/`。PNG 仅作为 `AUDIT_ONLY` 进入候选 ZIP，不进入正式 Git 拟提交清单；结构化投影进入正式清单。

首次浏览器脚本解析失败、CDP 表达式失败、构建目录定位失败和 Vite `/@fs` 宿主路径扫描失败均保留在 `d4-command-results.json` 的开发失败历史中，最终复验已闭合。

## 未证明能力

- `PYODIDE_ENABLED=false`
- `LIVE_MODEL=LIVE_NOT_RUN`
- 不声明双后端 PASS 或 `measured_dual_backend`
- 本交接是 E-D4 候选，不构成 W5 最终 PASS、commit、push 或上传锁授权。

