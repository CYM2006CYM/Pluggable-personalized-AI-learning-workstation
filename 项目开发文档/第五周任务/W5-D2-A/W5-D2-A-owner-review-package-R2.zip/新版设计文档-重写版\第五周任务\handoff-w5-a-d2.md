# 岗位 A W5-D2 交接单

状态：候选已完成，`NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`。

基线：`baseHead=677f54c609ef3bfbe78ff6d37f6b432e9c68ff4d`，该提交包含 W5-D0 与 W5-D1 正式上游。D2 本地候选尚未生成正式 commit，不得作为 C/E 的正式上游。

## 实现入口

- `pi-study-helper/src/tui/shared-session.ts`
- `TuiSharedSessionBridge` 仅依赖既有 `LearningRuntimeFacade.getNextStep`，用于服务端 Bootstrap、pending 保存/恢复和成功后的清理。
- `PendingActivityState` 只允许 `sessionId`、版本字段、`nodeId`、`activityId`、`attemptId`、`draftVersion` 和 `savedAt`。
- `buildStudyDeepLink`/`parseStudyDeepLink` 只允许 localhost 的 `/study` 路径及 `sessionId`、`nodeId`、`activityId` 参数。

## 安全与恢复语义

pending JSON 使用字段白名单和版本校验；未知字段、宿主路径、答案或无效版本会被拒绝并清理。深链拒绝非 localhost、未知查询参数、认证信息、fragment、绝对路径和换行注入。恢复始终重新调用 Facade，服务端版本是权威事实；旧绑定不会创建新会话。预览、取消和 pending 恢复本身不写入 Evidence、Attempt、KnowledgeState、mastery 或路径进度。

## 验证

`tests/shared-session.test.ts`：4 项 D2 定向测试通过；`npm.cmd run typecheck` 通过。全量 Vitest 共 89 文件，`748 passed / 25 failed / 1 skipped`，失败均为原始机器缺少 Python/Pandas 或既有 W3 Python 环境依赖，未由本次 TUI 改动引入；负责人合同环境复验仍以 D1 独立证据为准，不能覆盖本地历史结果。

## E 消费方式

E 可导入 `shared-session.ts` 的安全链接函数和 `PendingActivityState`，页面接入时调用同一 Facade Bootstrap；不得把 pending JSON 扩展为答案、Rubric、参考实现、隐藏测试或宿主路径。页面/Worker 行为和路由文件不在本候选范围内。

## 已知限制

本 D2 候选不实现浏览器 Worker、页面路由或真实跨端网络传输；仅提供 A 侧可导入的安全状态模型、深链边界和 Facade 共享会话适配器，等待 E 的页面接入及负责人后续 D4 复验。
