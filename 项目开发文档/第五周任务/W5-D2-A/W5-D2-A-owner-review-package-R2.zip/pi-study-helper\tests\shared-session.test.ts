import { describe, expect, it, vi } from "vitest";
import {
  TuiSharedSessionBridge,
  buildStudyDeepLink,
  parsePendingActivity,
  parseStudyDeepLink,
  serializePendingActivity,
  type PendingActivityStore,
} from "../src/tui/shared-session.js";

function store(): PendingActivityStore {
  let value: string | undefined;
  return { load: () => value, save: (next) => { value = next; }, clear: () => { value = undefined; } };
}

const nextStep = { sessionId: "s", sessionVersion: 4, profileRevision: 3, pathVersion: 2, completed: false } as const;

describe("W5-D2 shared TUI session", () => {
  it("round-trips only safe pending activity fields", () => {
    const pending = { sessionId: "s", sessionVersion: 4, profileRevision: 3, activityId: "a", attemptId: "t", draftVersion: 2, savedAt: "2026-08-19T00:00:00.000Z" };
    expect(parsePendingActivity(serializePendingActivity(pending))).toEqual(pending);
    expect(() => parsePendingActivity(JSON.stringify({ ...pending, answer: "secret" }))).toThrow();
  });

  it("creates and validates localhost deep links without private fields", () => {
    const link = buildStudyDeepLink("http://localhost:4173/anything", { sessionId: "s", nodeId: "n", activityId: "a" });
    expect(link).toBe("http://localhost:4173/study?sessionId=s&nodeId=n&activityId=a");
    expect(parseStudyDeepLink(link)).toEqual({ sessionId: "s", nodeId: "n", activityId: "a" });
    expect(() => buildStudyDeepLink("https://localhost:4173", { sessionId: "s" })).toThrow();
    expect(() => parseStudyDeepLink(`${link}&answer=secret`)).toThrow();
  });

  it("persists pending state, bootstraps through the facade, and clears it", async () => {
    const saved = store();
    const getNextStep = vi.fn().mockResolvedValue(nextStep);
    const bridge = new TuiSharedSessionBridge({ getNextStep }, saved, () => new Date("2026-08-19T00:00:00.000Z"));
    const pending = bridge.savePending({ sessionId: "s", sessionVersion: 4, profileRevision: 3, nodeId: "n", activityId: "a" });
    expect(bridge.loadPending()).toEqual(pending);
    await expect(bridge.restorePending(pending, { sessionId: "s", sessionVersion: 4, profileRevision: 3, pathVersion: 2 })).resolves.toEqual(nextStep);
    expect(getNextStep).toHaveBeenCalledWith({ sessionId: "s", sessionVersion: 4, profileRevision: 3, pathVersion: 2 });
    bridge.clearPending();
    expect(bridge.loadPending()).toBeUndefined();
  });

  it("drops malformed persisted state instead of exposing it to TUI", () => {
    const saved = store();
    saved.save(JSON.stringify({ sessionId: "s", sessionVersion: 1, profileRevision: 3, savedAt: "x", hostPath: "C:\\secret" }));
    const bridge = new TuiSharedSessionBridge({ getNextStep: vi.fn() }, saved);
    expect(bridge.loadPending()).toBeUndefined();
    expect(saved.load()).toBeUndefined();
  });
});
