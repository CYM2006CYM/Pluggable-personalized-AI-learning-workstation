import type {
  GetNextStepInput,
  LearningRuntimeFacade,
  NextStepOutput,
} from "../contracts/facade.js";

const PENDING_KEYS = [
  "sessionId",
  "sessionVersion",
  "profileRevision",
  "nodeId",
  "activityId",
  "attemptId",
  "draftVersion",
  "savedAt",
] as const;

export interface PendingActivityState {
  sessionId: string;
  sessionVersion: number;
  profileRevision: number;
  nodeId?: string;
  activityId?: string;
  attemptId?: string;
  draftVersion?: number;
  savedAt: string;
}

export interface PendingActivityStore {
  load(): string | undefined;
  save(value: string): void;
  clear(): void;
}

export interface SafeStudyLink {
  sessionId: string;
  nodeId?: string;
  activityId?: string;
}

function isIdentifier(value: unknown): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= 200 && !/[\\/\0\r\n]/.test(value);
}

function isVersion(value: unknown): value is number {
  return typeof value === "number" && Number.isInteger(value) && value >= 0;
}

function assertLinkPart(value: string, field: string): void {
  if (!isIdentifier(value)) throw new Error(`Invalid ${field}`);
}

export function parsePendingActivity(value: string): PendingActivityState {
  let parsed: unknown;
  try {
    parsed = JSON.parse(value);
  } catch {
    throw new Error("Invalid pending activity JSON");
  }
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Invalid pending activity");
  const record = parsed as Record<string, unknown>;
  for (const key of Object.keys(record)) if (!(PENDING_KEYS as readonly string[]).includes(key)) throw new Error("Unknown pending activity field");
  if (!isIdentifier(record.sessionId) || !isVersion(record.sessionVersion) || !isVersion(record.profileRevision) || !isIdentifier(record.savedAt)) {
    throw new Error("Invalid pending activity binding");
  }
  for (const key of ["nodeId", "activityId", "attemptId"] as const) {
    if (record[key] !== undefined && !isIdentifier(record[key])) throw new Error(`Invalid ${key}`);
  }
  if (record.draftVersion !== undefined && !isVersion(record.draftVersion)) throw new Error("Invalid draftVersion");
  return record as unknown as PendingActivityState;
}

export function serializePendingActivity(state: PendingActivityState): string {
  parsePendingActivity(JSON.stringify(state));
  return JSON.stringify(state);
}

export function buildStudyDeepLink(baseUrl: string, link: SafeStudyLink): string {
  const url = new URL(baseUrl);
  if (url.protocol !== "http:" || !["localhost", "127.0.0.1"].includes(url.hostname)) throw new Error("Deep links must target localhost");
  if (url.username || url.password || url.hash) throw new Error("Deep link base URL contains unsafe data");
  assertLinkPart(link.sessionId, "sessionId");
  if (link.nodeId !== undefined) assertLinkPart(link.nodeId, "nodeId");
  if (link.activityId !== undefined) assertLinkPart(link.activityId, "activityId");
  url.pathname = "/study";
  url.search = "";
  url.searchParams.set("sessionId", link.sessionId);
  if (link.nodeId !== undefined) url.searchParams.set("nodeId", link.nodeId);
  if (link.activityId !== undefined) url.searchParams.set("activityId", link.activityId);
  return url.toString();
}

export function parseStudyDeepLink(value: string): SafeStudyLink {
  const url = new URL(value);
  if (url.protocol !== "http:" || !["localhost", "127.0.0.1"].includes(url.hostname) || url.pathname !== "/study" || url.username || url.password || url.hash) {
    throw new Error("Unsafe study deep link");
  }
  const allowed = new Set(["sessionId", "nodeId", "activityId"]);
  for (const key of url.searchParams.keys()) if (!allowed.has(key)) throw new Error("Unknown deep link field");
  const sessionId = url.searchParams.get("sessionId");
  const nodeId = url.searchParams.get("nodeId") ?? undefined;
  const activityId = url.searchParams.get("activityId") ?? undefined;
  if (sessionId === null) throw new Error("Deep link requires sessionId");
  assertLinkPart(sessionId, "sessionId");
  if (nodeId !== undefined) assertLinkPart(nodeId, "nodeId");
  if (activityId !== undefined) assertLinkPart(activityId, "activityId");
  return { sessionId, ...(nodeId === undefined ? {} : { nodeId }), ...(activityId === undefined ? {} : { activityId }) };
}

export class TuiSharedSessionBridge {
  constructor(
    private readonly facade: Pick<LearningRuntimeFacade, "getNextStep">,
    private readonly store: PendingActivityStore,
    private readonly now: () => Date = () => new Date(),
  ) {}

  async bootstrap(input: GetNextStepInput): Promise<NextStepOutput> {
    return this.facade.getNextStep(input);
  }

  savePending(state: Omit<PendingActivityState, "savedAt">): PendingActivityState {
    const next = { ...state, savedAt: this.now().toISOString() };
    this.store.save(serializePendingActivity(next));
    return next;
  }

  loadPending(): PendingActivityState | undefined {
    const raw = this.store.load();
    if (raw === undefined) return undefined;
    try {
      return parsePendingActivity(raw);
    } catch {
      this.store.clear();
      return undefined;
    }
  }

  clearPending(): void {
    this.store.clear();
  }

  async restorePending(pending: PendingActivityState, current: GetNextStepInput): Promise<NextStepOutput> {
    if (pending.sessionId !== current.sessionId || pending.sessionVersion !== current.sessionVersion || pending.profileRevision !== current.profileRevision) {
      return this.bootstrap(current);
    }
    return this.bootstrap(current);
  }
}
