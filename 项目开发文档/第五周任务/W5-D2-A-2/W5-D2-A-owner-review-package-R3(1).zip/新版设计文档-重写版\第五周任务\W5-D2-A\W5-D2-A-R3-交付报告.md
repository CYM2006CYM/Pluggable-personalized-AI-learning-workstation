# W5-D2-A-R3 交付报告

合同：`W5-C1/W5-R1`。正式基线：`677f54c609ef3bfbe78ff6d37f6b432e9c68ff4d`。

当前状态：`NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`。本报告只提交负责人复核候选，不构成上传锁、正式上游或 W5-D2 通过授权。

## 整改结论

- `A-R3-01`：pending 增加 `pathVersion`；恢复读取现行 Bootstrap 与当前步骤；session/path/revision/session-not-found/深链失败返回明确状态；真实 `StudyTuiGateway` 入口已验证。
- `A-R3-02`：TUI 写入透传既有 Facade CAS；冲突后重新 Bootstrap；正式适配器证明相同输入重放、不同输入幂等冲突，且只有一个 Attempt、Evidence 和路径版本。
- `A-R3-03`：R3 proposed、Manifest、ZIP 重建并执行精确集合、字节数、SHA-256、嵌套 ZIP 和禁止目录机械检查。
- `A-R3-04`：十项命令均登记完整命令、cwd、UTC、自然退出码、stdout/stderr 字节数和 SHA-256；历史失败与最终复验分开保留。

## 合同环境与门禁

负责人给出的 `C:/Users/win11/...` 路径在本机不存在。R3 在本机临时目录建立版本等价环境并如实记录实际路径：Node `v22.23.1`、npm `10.9.8`、Python `3.13.7`、Pandas `3.0.5`、`PYTHONNOUSERSITE=1`。

- A 定向：2 files / 29 passed / 0 failed。
- 受影响回归：4 files / 39 passed / 0 failed。
- 全量 Vitest：89 files / 782 passed / 0 failed / 1 skipped。
- typecheck、docs、Web build、extension smoke、release、verify：PASS。
- `git diff --check`：自然退出码 0；stderr 仅保留 CRLF-to-LF 提示，无 whitespace error。

R2 的 `748 passed / 25 failed / 1 skipped` 保留为原始机器缺少 Pandas 的历史环境失败；R3 首次定向夹具失败、验证脚本 Unicode 启动失败、聚合外层超时和首次包审计分隔符误报也全部保留，未覆盖或改写为首次 PASS。

## 边界与限制

本候选只声明 A 侧实现和接口交接完成。真实跨端闭环、E 页面/Worker 接入、B seal、C 正式服务、服务重启联调和 V5-1/V5-3/V5-4 仍属于 D4。未运行真实模型，不声明 `LIVE_MODEL_PASS`。

R3 未修改 `src/web`、C evaluator、B Profile/revision/seal/环境锁、D 材料、SDK、依赖、gold、hidden tests、Rubric 或 reference solution。完整已知限制与未证明能力见 `d2-known-limitations.json`。

## 文件绑定

最终拟提交集合、逐文件字节数和 SHA-256 见同包 `proposed-files.txt` 与 `sha256-manifest.json`。Manifest 仅排除自身摘要；ZIP 内文件集合与 proposed 精确相等。ZIP 和 sidecar 哈希在打包后写入外层交付回报，不反向写入包内文件，避免循环摘要。
