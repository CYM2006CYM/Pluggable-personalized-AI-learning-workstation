# 岗位 A W5-D2 R3 交接单

状态：`NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`。

合同为 `W5-C1/W5-R1`，正式基线为 `baseHead=677f54c609ef3bfbe78ff6d37f6b432e9c68ff4d`。本文件描述未提交候选，不是正式上游，也不表示 W5-D2 已获得负责人通过。

## A 侧实现与入口

`src/tui/shared-session.ts` 提供 `TuiSharedSessionBridge` 和 `TuiSharedSessionEntry`。桥接器只消费既有 `AppBootstrapFacade` 与 `LearningRuntimeFacade` 的恢复视图、`getNextStep`、活动恢复、草稿保存和正式提交方法，不读取仓储，也不建立第二套 Facade 或提交协议。

真实 `StudyTuiGateway.prepareSharedWebActivity()` 消费 `TuiSharedSessionEntry`，完成“读取服务端当前步骤 -> 保存安全 pending -> 生成 localhost 深链”的 A 侧调用链。E 可以在正式提交生成后导入该入口；A 不修改页面、API client 或 Worker。

## Pending、深链与恢复

pending 字段固定为 `sessionId/sessionVersion/profileRevision/pathVersion/nodeId/activityId/attemptId/draftVersion/savedAt`。`attemptId` 与 `draftVersion` 必须同时出现；未知字段、答案、Rubric、hidden tests、reference solution、宿主路径和路径正文均被拒绝。

深链仅允许 `http://localhost` 或 `http://127.0.0.1` 的 `/study`，参数仅为单份 `sessionId/nodeId/activityId`。未知或重复参数、认证信息、fragment、绝对路径、换行和非 localhost 地址均被拒绝。

恢复先通过 `AppBootstrapFacade` 读取最新服务端恢复视图，再使用该视图中的版本调用 `getNextStep`。合法绑定返回 `restored`；陈旧 session/path 返回明确冲突；revision 不一致、session 不存在、活动错配或无恢复视图返回 `resume_from_web`。任何分支都不会调用 `startSession` 或使用客户端旧快照继续提交。

## CAS、幂等和副作用边界

TUI 草稿与正式提交原样传递既有 `requestId/sessionVersion/profileRevision/attemptId/draftVersion`。冲突后重新读取 Bootstrap，绝不覆盖服务端较新状态。同一正式提交输入重放首次结果；相同幂等键但不同代码返回 `idempotency_conflict`。正式适配器回归证明重放和冲突后仍只有一个 Attempt、一个 Evidence 和原路径版本。

pending、深链、恢复和公开预览本身不新增 Attempt、Evidence、KnowledgeState、mastery 或路径进度。只有既有正式提交成功且 `committed=true` 时清理 pending。

## D2 与 D4 边界

本候选只声明“A 侧实现和接口交接完成”。真实 Web/TUI 跨端闭环、页面接入、Worker、服务重启联调、正式 B seal/C 服务/E 页面绑定以及 V5-1/V5-3/V5-4 属于 D4。本轮未运行真实模型，不声明 `LIVE_MODEL_PASS`。

完整命令结果、环境实际路径、历史失败归因、日志哈希、精确候选清单和逐文件哈希见同包验证材料。正式 commit 生成并经负责人授权后，才可作为 E 的上游。
