# W5-D3-C 验证报告

## 结论

本候选仅形成 D3 环境实测和故障证据，不能解释为 Pyodide 启用、双后端测量或 W5 GO。Node 正式提交路径继续由既有 `PythonProcessCodeEvaluationAdapter` 承担；Pyodide 按负责人裁决为 `NOT_RUN / PYODIDE_CANDIDATE_UNAVAILABLE`。

## 公开输入

`node-public-runs.json` 记录 10 组正式 revision 3 公开 starterCode 派生输入，每组 3 次真实 Node/Python 运行，共 30 次；每组含输入 SHA-256、activityId、revision、状态、verdict、score、错误码、环境/资产绑定和字段一致性。

## 故障矩阵

`fault-matrix.json` 记录真实超时、输出限制、Windows `taskkill /T /F`、临时目录清理、磁盘写失败边界、环境不匹配、版本冲突、幂等、重启后 prepared 状态和准备失败。所有条目均记录无正式事实、无敏感字段命中。评测器超时夹具两次未形成可归因的 `evaluator_timeout`，均保留为 `runner_crash` 历史，不冒充通过。

## 环境建议

`environment-field-mapping.json` 向 B 提供字段、实测命令、证据引用和判定依据；C 不修改 Profile 环境锁或 revision seal。`pyodideVersion=null`，`networkIsolation=false`，`reliableMemoryLimit=false`。

## 历史失败与边界

- 首次 D3 测试因新副本未安装既有依赖而出现 `vitest not recognized`；归因为依赖安装缺失。
- 首次 `typecheck` 因 D3 测试辅助函数类型过窄失败，随后仅修复测试类型并通过。
- 评测器超时夹具两次实际表现为 `runner_crash`，如实保留。
- D3 不修改 A/B/D/E，不安装 Pyodide，不修改 SDK、依赖、锁文件或 seal。
