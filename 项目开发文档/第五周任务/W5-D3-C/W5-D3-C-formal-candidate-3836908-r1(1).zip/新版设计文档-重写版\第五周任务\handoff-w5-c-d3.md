# W5-D3 C 交接单

## 状态

合同：W5-C1 / W5-R1  
基线：`383690831a8b3de42dad58795e71f218678f6fbc`  
裁决：`W5-D64-PYODIDE-1`  
结论：`PYODIDE_DISABLED_WITH_NODE_FALLBACK`  
`PYODIDE_ENABLED=false`，`LIVE_MODEL=LIVE_NOT_RUN`  
当前权限：`NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_GRANTED`

## 上游绑定

- E D2 提交：`590985af616861e503ee30f2bf56c6392b0055f7`
- E D2 包 SHA-256：`b88d3c9c0eab9d7c4e783180c33e0cc6790b352a17fbc6beb5e3c5e2e84462d0`
- revision 3 环境锁 SHA-256：`59917d1528d031f46a1e76359d99628e810f2dfa78a92d66e03386c860fbaf43`
- revision 3 `assetTreeSha256`：`ccff2e2afdabaad262baeaa498b527438fcadeec1ddf5e198289f8404071e85d`
- revision 2：逐字节不变

## D3 结果

- 10 组真实公开输入，Node 每组连续 3 次，共 30 次；逐组结果和 SHA-256 在 `node-public-runs.json`。
- 10 组 Pyodide 均登记 `status=NOT_RUN`、`errorCode=PYODIDE_CANDIDATE_UNAVAILABLE`，未写入双后端 PASS。
- Node 结果字段一致组数：10/10；敏感字段命中：0。
- 故障矩阵覆盖 learner timeout、output limit、Windows 进程树终止、临时目录清理、磁盘写失败边界、环境/版本/资产冲突、幂等重放、服务重启后 prepared 状态重建及 `/run`/`/submit` 边界。
- 评测器夹具错误归因历史保留：两次尝试产生 `runner_crash`，未伪装成 `evaluator_timeout`。

## 环境字段建议

`environment-field-mapping.json` 仅为交付 B 的结构化建议，不直接修改环境锁或 seal。未证明能力为 `false`，不写 `measured_dual_backend`。

## 门禁与证据

已运行并应在命令结果中登记：D3 定向 Node 测量、D3 故障测试、`typecheck`。其余门禁需在本合同环境继续运行并原样记录；首次缺少 vitest 失败保留为依赖未安装环境失败，不改写为源码失败。

## 权限边界

C 未修改 A/B/D/E、Profile 环境锁、revision seal、revision 2、SDK、依赖、公共合同或 Pyodide 裁决。未执行 commit、push，未申请上传锁。审计派生文件在交付包中标记 `AUDIT_ONLY / NOT_FOR_GIT`。
