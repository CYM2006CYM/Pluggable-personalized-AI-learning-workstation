import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { describe, expect, it } from "vitest";
import type { ActivityResult } from "../src/domain/v2-types.js";
import { PythonProcessCodeEvaluationAdapter } from "../src/infrastructure/python-process-evaluation-adapter.js";

const projectRoot = resolve(import.meta.dirname, "..");
const profileRoot = resolve(projectRoot, "fixtures/profiles/pandas-cleaning-revision-3-draft");
const outputPath = resolve(projectRoot, "scripts/w5-c-d3/node-public-runs.json");
const formalHashes: Readonly<Record<string, string>> = {
  "act-inspect-dataframe": "737b0d6ae618f98b5c3e7bd5b67c2f5342559decd7436dbed57a046ef4c97be6",
  "act-missing": "1a42dfe66391ea56d11b7c8b525ac2da19146c3fc7d4401a3439e6b7b793125b",
  "act-duplicates": "dd88d60ef3320f7eba10fbba7cddc76ee96859e3f7fd7f7a9139fe9ed96d4886",
  "act-types": "cfa703b189cb49cfa2e56ce3b0790a0412e58c996c82aa93ca459596d71c1880",
  "act-practical": "7731912ed0f6ec7596cbfbf3b7d029a3d354503c4b28a6ddcf623493df9c74a9",
};

function sha256(value: string): string {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

function findPython(): string {
  const command = process.platform === "win32" ? "where.exe" : "which";
  return execFileSync(command, ["python"], { encoding: "utf8" }).split(/\r?\n/u).find(Boolean) ?? "python";
}

function publicVariant(starterCode: string, variant: "starter" | "public-pass-edit"): string {
  if (variant === "starter") return starterCode;
  const marker = "# TODO_BEGIN\n";
  if (!starterCode.includes(marker)) return `${starterCode}\n# public-pass-edit\n`;
  return starterCode.replace(marker, `${marker}    clean_df = df.copy()\n`);
}

function publicResult(result: ActivityResult) {
  return {
    executionStatus: result.executionStatus,
    verdict: result.verdict,
    ...(result.score === undefined ? {} : { score: result.score }),
    ...(result.errorKind === undefined ? {} : { errorKind: result.errorKind }),
    ...(result.errorCode === undefined ? {} : { errorCode: result.errorCode }),
    evaluatorVersion: result.evaluatorVersion,
    environmentHash: result.environmentHash,
    assetBundleHash: result.assetBundleHash,
    ...(result.dimensionResults === undefined ? {} : { dimensionResults: result.dimensionResults }),
  };
}

describe("W5 D3 C Node authoritative public-input measurement", () => {
  it("runs ten public inputs three times and records Pyodide as NOT_RUN", async () => {
    const activitiesDocument = JSON.parse(await readFile(resolve(profileRoot, "activities/learning-activities.json"), "utf8")) as {
      activities: Array<{ activityId: string; kind: string; profileRevision: number; templateVersion: string; environmentRef?: string; starterCode?: string }>;
    };
    const environment = JSON.parse(await readFile(resolve(profileRoot, "environments/environment-lock.json"), "utf8")) as {
      environmentId: string; environmentHash: string; evaluatorVersion: string; prototypeEvidenceRef: string;
    };
    const adapter = new PythonProcessCodeEvaluationAdapter({ profileRoot, pythonExecutable: findPython() });
    const inputs = Object.keys(formalHashes).flatMap((activityId) => (["starter", "public-pass-edit"] as const).map((variant) => ({ activityId, variant })));
    const groups = [];
    for (const [index, descriptor] of inputs.entries()) {
      const activity = activitiesDocument.activities.find((item) => item.activityId === descriptor.activityId);
      expect(activity?.starterCode).toBeTypeOf("string");
      const code = publicVariant(activity!.starterCode!, descriptor.variant);
      const inputId = `w5-d3-public-${String(index + 1).padStart(2, "0")}`;
      const prepared = await adapter.prepare({
        activity: {
          activityId: activity!.activityId,
          kind: activity!.kind as "code_completion" | "coding_practical",
          profileRevision: activity!.profileRevision,
          templateVersion: activity!.templateVersion,
          environmentRef: activity!.environmentRef!,
        },
        profileRevision: activity!.profileRevision,
        taskVersion: activity!.templateVersion,
        mode: "submit",
        environment: {
          environmentId: environment.environmentId,
          status: "measured_node_submit",
          environmentHash: environment.environmentHash,
          prototypeEvidenceRef: environment.prototypeEvidenceRef,
        },
        assetBundleHash: formalHashes[activity!.activityId]!,
      });
      const runs = [];
      for (let repeat = 1; repeat <= 3; repeat += 1) {
        const startedAt = new Date().toISOString();
        const started = performance.now();
        const result = await adapter.run({
          requestId: `${inputId}-run-${repeat}`,
          attemptId: `${inputId}-attempt-${repeat}`,
          prepared,
          code,
        }, new AbortController().signal);
        runs.push({
          repeat,
          startedAt,
          endedAt: new Date().toISOString(),
          elapsed_ms: Math.round((performance.now() - started) * 1000) / 1000,
          result: publicResult(result),
        });
      }
      const signatures = runs.map((run) => JSON.stringify(run.result));
      const serialized = JSON.stringify(runs);
      groups.push({
        inputId,
        inputSource: `revision-3 activities/learning-activities.json#${activity!.activityId}.starterCode`,
        inputSummary: descriptor.variant === "starter" ? "public starter code" : "public starter code with deterministic clean_df copy edit",
        inputSha256: sha256(code),
        activityId: activity!.activityId,
        profileRevision: activity!.profileRevision,
        nodeRunCount: runs.length,
        runs,
        nodeFieldsIdentical: signatures.every((signature) => signature === signatures[0]),
        adapterVersion: "PythonProcessCodeEvaluationAdapter",
        evaluatorVersion: environment.evaluatorVersion,
        pyodide: { status: "NOT_RUN", errorCode: "PYODIDE_CANDIDATE_UNAVAILABLE", elapsed_ms: null },
        sensitiveFieldMatch: /hidden|rubric|reference.solution|answer.key|correct.answer|api.key|[A-Za-z]:[\\/]/iu.test(serialized),
      });
    }
    const evidence = {
      schemaVersion: 1,
      contract: "W5-C1/W5-R1",
      ownerDecision: "W5-D64-PYODIDE-1",
      pyodideDecision: "PYODIDE_DISABLED_WITH_NODE_FALLBACK",
      generatedAt: new Date().toISOString(),
      profileRevision: 3,
      nodeEnvironmentHash: environment.environmentHash,
      groups,
      summary: {
        inputGroups: groups.length,
        nodeRuns: groups.reduce((sum, group) => sum + group.nodeRunCount, 0),
        identicalGroups: groups.filter((group) => group.nodeFieldsIdentical).length,
        pyodideNotRunGroups: groups.filter((group) => group.pyodide.status === "NOT_RUN").length,
        sensitiveMatches: groups.filter((group) => group.sensitiveFieldMatch).length,
      },
    };
    expect(evidence.summary).toEqual({ inputGroups: 10, nodeRuns: 30, identicalGroups: 10, pyodideNotRunGroups: 10, sensitiveMatches: 0 });
    await mkdir(dirname(outputPath), { recursive: true });
    await writeFile(outputPath, `${JSON.stringify(evidence, null, 2)}\n`, "utf8");
  }, 180_000);
});
