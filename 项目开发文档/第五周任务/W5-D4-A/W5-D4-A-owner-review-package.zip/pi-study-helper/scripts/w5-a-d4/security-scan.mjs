import { readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptRoot = dirname(fileURLToPath(import.meta.url));
const appRoot = resolve(scriptRoot, "../..");
const workspaceRoot = resolve(appRoot, "..");
const proposed = (await readFile(resolve(scriptRoot, "proposed-files.txt"), "utf8"))
  .split(/\r?\n/u).map((item) => item.trim()).filter(Boolean);
const findings = [];
const forbiddenPaths = [
  /assessments\/(?:private|hidden)\//iu,
  /reference[-_ ]solutions?\//iu,
  /node_modules\//iu,
  /\.demo-(?:data|build)\//iu,
];
const hostPaths = /(?:[A-Za-z]:\\Users\\|[A-Za-z]:\/Users\/|\/home\/[^/]+\/)/u;
for (const path of proposed) {
  if (forbiddenPaths.some((pattern) => pattern.test(path))) findings.push({ path, reason: "forbidden_candidate_path" });
  const text = await readFile(resolve(workspaceRoot, path), "utf8");
  if (hostPaths.test(text)) findings.push({ path, reason: "host_absolute_path" });
}
const result = { schemaVersion: 1, status: findings.length === 0 ? "PASS" : "FAIL", scannedFiles: proposed.length, findings };
await writeFile(resolve(scriptRoot, "security-scan.json"), `${JSON.stringify(result, null, 2)}\n`, "utf8");
if (findings.length > 0) process.exitCode = 1;
