import { createHash } from "node:crypto";
import { cp, mkdir, mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const scriptRoot = dirname(fileURLToPath(import.meta.url));
const appRoot = resolve(scriptRoot, "../..");
const workspaceRoot = resolve(appRoot, "..");
const deliveryRoot = resolve(workspaceRoot, "新版设计文档-重写版/第五周任务/W5-D4-A");
const zipPath = resolve(deliveryRoot, "W5-D4-A-owner-review-package.zip");
const sidecarPath = `${zipPath}.sha256`;
const temporary = await mkdtemp(resolve(tmpdir(), "w5-a-d4-assemble-"));
const stage = resolve(temporary, "stage");
const extracted = resolve(temporary, "extracted");

async function files(root, current = root) {
  const values = [];
  for (const entry of await readdir(current, { withFileTypes: true })) {
    const absolute = resolve(current, entry.name);
    if (entry.isDirectory()) values.push(...await files(root, absolute));
    else values.push(relative(root, absolute).split(sep).join("/"));
  }
  return values;
}

try {
  await mkdir(stage, { recursive: true });
  await mkdir(extracted, { recursive: true });
  await mkdir(deliveryRoot, { recursive: true });
  const proposed = (await readFile(resolve(scriptRoot, "proposed-files.txt"), "utf8"))
    .split(/\r?\n/u).map((item) => item.trim()).filter(Boolean).sort();
  for (const path of proposed) {
    const target = resolve(stage, path);
    await mkdir(dirname(target), { recursive: true });
    await cp(resolve(workspaceRoot, path), target);
  }
  const packed = spawnSync("tar.exe", ["-a", "-cf", zipPath, ...[...new Set(proposed.map((path) => path.split("/", 1)[0]))]], { cwd: stage, encoding: "utf8" });
  if (packed.status !== 0) throw new Error(`ZIP assembly failed: ${packed.stderr}`);
  const zipBytes = await readFile(zipPath);
  const zipSha256 = createHash("sha256").update(zipBytes).digest("hex");
  await writeFile(sidecarPath, `${zipSha256}  W5-D4-A-owner-review-package.zip\n`, "ascii");
  const unpacked = spawnSync("tar.exe", ["-xf", zipPath, "-C", extracted], { encoding: "utf8" });
  if (unpacked.status !== 0) throw new Error(`ZIP extraction failed: ${unpacked.stderr}`);
  const actual = (await files(extracted)).sort();
  if (JSON.stringify(actual) !== JSON.stringify(proposed)) throw new Error("ZIP/proposed file set mismatch");
  console.log(JSON.stringify({ status: "PASS", zipPath: "新版设计文档-重写版/第五周任务/W5-D4-A/W5-D4-A-owner-review-package.zip", zipBytes: zipBytes.byteLength, zipSha256, files: actual.length }));
} finally {
  const rel = relative(tmpdir(), temporary);
  if (rel === "" || rel.startsWith(`..${sep}`) || resolve(tmpdir(), rel) !== temporary) throw new Error("Unsafe temporary cleanup target");
  await rm(temporary, { recursive: true, force: true });
}
