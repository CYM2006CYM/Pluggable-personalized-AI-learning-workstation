import { createHash } from "node:crypto";
import { execFileSync, spawnSync } from "node:child_process";
import { writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptRoot = dirname(fileURLToPath(import.meta.url));
const appRoot = resolve(scriptRoot, "../..");
const outputPath = resolve(scriptRoot, "command-results.json");
const emptyHash = createHash("sha256").update("").digest("hex");

function hash(value) {
  return createHash("sha256").update(value).digest("hex");
}

function version(file, args) {
  const executable = file.endsWith(".cmd") ? process.env.ComSpec ?? "cmd.exe" : file;
  const prepared = file.endsWith(".cmd") ? ["/d", "/s", "/c", file, ...args] : args;
  try { return execFileSync(executable, prepared, { cwd: appRoot, encoding: "utf8" }).trim(); }
  catch { return "UNAVAILABLE"; }
}

function testCounts(text) {
  const files = text.match(/Test Files\s+(?:(\d+) failed\s*\|\s*)?(\d+) passed(?:\s*\((\d+)\))?/u);
  const tests = text.match(/Tests\s+(?:(\d+) failed\s*\|\s*)?(\d+) passed(?:\s*\|\s*(\d+) skipped)?/u);
  if (!files && !tests) return undefined;
  return {
    files: { passed: Number(files?.[2] ?? 0), failed: Number(files?.[1] ?? 0), total: Number(files?.[3] ?? (Number(files?.[1] ?? 0) + Number(files?.[2] ?? 0))) },
    tests: { passed: Number(tests?.[2] ?? 0), failed: Number(tests?.[1] ?? 0), skipped: Number(tests?.[3] ?? 0) },
  };
}

const commands = [
  ["d4_cross_end", "npm.cmd", ["test", "--", "tests/w5-a-d4-cross-end.test.ts", "--maxWorkers=1"]],
  ["d4_showcases", "npm.cmd", ["test", "--", "tests/w5-a-d4-showcase-paths.test.ts", "--maxWorkers=1"]],
  ["affected_regression", "npm.cmd", ["test", "--", "tests/shared-session.test.ts", "tests/shared-web-extension-entry.test.ts", "tests/web/real-api.test.ts", "--maxWorkers=1"]],
  ["formal_node_contract", "npm.cmd", ["test", "--", "tests/w5-formal-bundle-revision-binding.test.ts", "--maxWorkers=1"]],
  ["full_test", "npm.cmd", ["test", "--", "--maxWorkers=1"]],
  ["typecheck", "npm.cmd", ["run", "typecheck"]],
  ["check_docs", "npm.cmd", ["run", "check:docs"]],
  ["build_web", "npm.cmd", ["run", "build:web"]],
  ["smoke_extension", "npm.cmd", ["run", "smoke:extension"]],
  ["check_release", "npm.cmd", ["run", "check:release"]],
  ["verify", "npm.cmd", ["run", "verify"]],
  ["git_diff_check", "git", ["diff", "--check"]],
];

const results = [];
for (const [id, file, args] of commands) {
  const startedAt = new Date().toISOString();
  const executable = file.endsWith(".cmd") ? process.env.ComSpec ?? "cmd.exe" : file;
  const prepared = file.endsWith(".cmd") ? ["/d", "/s", "/c", file, ...args] : args;
  const child = spawnSync(executable, prepared, { cwd: appRoot, encoding: "buffer", env: { ...process.env, PYTHONNOUSERSITE: "1" }, maxBuffer: 64 * 1024 * 1024 });
  const endedAt = new Date().toISOString();
  const stdout = child.stdout ?? Buffer.alloc(0);
  const stderr = child.stderr ?? Buffer.alloc(0);
  const combined = Buffer.concat([stdout, stderr]).toString("utf8");
  results.push({
    id,
    command: [file, ...args].join(" "),
    cwd: "<repo>/pi-study-helper",
    startedAt,
    endedAt,
    exitCode: child.status,
    signal: child.signal,
    spawnError: child.error?.message,
    stdout: { bytes: stdout.byteLength, sha256: stdout.byteLength === 0 ? emptyHash : hash(stdout) },
    stderr: { bytes: stderr.byteLength, sha256: stderr.byteLength === 0 ? emptyHash : hash(stderr) },
    ...(testCounts(combined) === undefined ? {} : { counts: testCounts(combined) }),
  });
}

const python = process.env.PI_PYTHON_EXECUTABLE ?? "python";
const environment = {
  node: process.version,
  npm: version("npm.cmd", ["--version"]),
  pythonCommand: python,
  python: version(python, ["--version"]),
  pandas: version(python, ["-c", "import pandas; print(pandas.__version__)"]),
  pythonNoUserSite: "1",
};
const contractMatch = environment.node === "v22.23.1"
  && environment.npm === "10.9.8"
  && environment.python.includes("3.13.7")
  && environment.pandas === "3.0.5";
await writeFile(outputPath, `${JSON.stringify({
  schemaVersion: 1,
  candidate: "W5-D4-A",
  baseHead: "a0d5a37116a6c67f009ca19e313501d9eed96f78",
  capturedAt: new Date().toISOString(),
  environment,
  contractEnvironmentMatch: contractMatch,
  attribution: contractMatch
    ? "Commands ran in the W5 contract environment."
    : "Commands ran in the current non-contract environment; Python/Node formal conclusions remain NOT_VERIFIED even when unrelated commands pass. An earlier capture attempt produced spawnSync npm.cmd EINVAL for every npm command and was replaced by this cmd.exe-compatible rerun.",
  commands: results,
}, null, 2)}\n`, "utf8");
process.exitCode = results.some((item) => item.exitCode !== 0) ? 1 : 0;
