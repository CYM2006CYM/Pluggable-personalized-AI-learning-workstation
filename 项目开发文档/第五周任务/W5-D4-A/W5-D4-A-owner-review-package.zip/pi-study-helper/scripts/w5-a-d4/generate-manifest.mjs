import { createHash } from "node:crypto";
import { readFile, stat, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptRoot = dirname(fileURLToPath(import.meta.url));
const appRoot = resolve(scriptRoot, "../..");
const workspaceRoot = resolve(appRoot, "..");
const manifestPath = "pi-study-helper/scripts/w5-a-d4/sha256-manifest.json";
const proposed = (await readFile(resolve(scriptRoot, "proposed-files.txt"), "utf8"))
  .split(/\r?\n/u).map((item) => item.trim()).filter(Boolean);
if (new Set(proposed).size !== proposed.length || !proposed.includes(manifestPath)) throw new Error("proposed-files must be unique and include the Manifest");
const files = [];
for (const path of proposed.filter((item) => item !== manifestPath).sort()) {
  const absolute = resolve(workspaceRoot, path);
  const bytes = await readFile(absolute);
  files.push({ path, bytes: (await stat(absolute)).size, sha256: createHash("sha256").update(bytes).digest("hex") });
}
await writeFile(resolve(workspaceRoot, manifestPath), `${JSON.stringify({
  schemaVersion: 2,
  candidate: "W5-D4-A",
  baseHead: "a0d5a37116a6c67f009ca19e313501d9eed96f78",
  selfExcluded: true,
  files,
}, null, 2)}\n`, "utf8");
