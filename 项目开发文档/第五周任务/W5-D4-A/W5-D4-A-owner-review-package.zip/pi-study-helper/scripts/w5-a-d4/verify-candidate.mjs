import { createHash } from "node:crypto";
import { readFile, stat } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptRoot = dirname(fileURLToPath(import.meta.url));
const workspaceRoot = resolve(scriptRoot, "../../..");
const manifestPath = "pi-study-helper/scripts/w5-a-d4/sha256-manifest.json";
const proposed = (await readFile(resolve(scriptRoot, "proposed-files.txt"), "utf8"))
  .split(/\r?\n/u).map((item) => item.trim()).filter(Boolean).sort();
const manifest = JSON.parse(await readFile(resolve(workspaceRoot, manifestPath), "utf8"));
const expected = proposed.filter((item) => item !== manifestPath);
const actual = manifest.files.map((item) => item.path).sort();
if (JSON.stringify(expected) !== JSON.stringify(actual) || manifest.selfExcluded !== true) throw new Error("proposed/Manifest set mismatch");
for (const item of manifest.files) {
  const absolute = resolve(workspaceRoot, item.path);
  const bytes = await readFile(absolute);
  const digest = createHash("sha256").update(bytes).digest("hex");
  if ((await stat(absolute)).size !== item.bytes || digest !== item.sha256) throw new Error(`Manifest mismatch: ${item.path}`);
}
console.log(`PASS ${manifest.files.length} manifest entries; selfExcluded=${manifestPath}`);
