import { createHash } from "node:crypto";
import { cp, mkdtemp, mkdir, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const scriptRoot = dirname(fileURLToPath(import.meta.url));
const appRoot = resolve(scriptRoot, "../..");
const workspaceRoot = resolve(appRoot, "..");
const temporary = await mkdtemp(resolve(tmpdir(), "w5-a-d4-package-revalidation-"));
const baseline = resolve(temporary, "baseline");
const archive = resolve(temporary, "baseline.zip");
const startedAt = new Date().toISOString();
const outputPath = resolve(scriptRoot, "package-revalidation.json");
const existing = JSON.parse(await readFile(outputPath, "utf8"));

function run(file, args, cwd) {
  const executable = file.endsWith(".cmd") ? process.env.ComSpec ?? "cmd.exe" : file;
  const prepared = file.endsWith(".cmd") ? ["/d", "/s", "/c", file, ...args] : args;
  return spawnSync(executable, prepared, { cwd, encoding: "buffer", env: { ...process.env, PYTHONNOUSERSITE: "1" }, maxBuffer: 64 * 1024 * 1024 });
}

function digest(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

try {
  await mkdir(baseline, { recursive: true });
  const archived = run("git", ["archive", "--format=zip", "HEAD", "-o", archive], workspaceRoot);
  if (archived.status !== 0) throw new Error("git archive failed");
  const extracted = run("tar.exe", ["-xf", archive, "-C", baseline], workspaceRoot);
  if (extracted.status !== 0) throw new Error("baseline extraction failed");
  const proposed = (await readFile(resolve(scriptRoot, "proposed-files.txt"), "utf8"))
    .split(/\r?\n/u).map((item) => item.trim()).filter(Boolean);
  for (const path of proposed) {
    const target = resolve(baseline, path);
    await mkdir(dirname(target), { recursive: true });
    await cp(resolve(workspaceRoot, path), target);
  }
  await symlink(resolve(appRoot, "node_modules"), resolve(baseline, "pi-study-helper/node_modules"), "junction");
  const candidateApp = resolve(baseline, "pi-study-helper");
  const tests = run("npm.cmd", ["test", "--", "tests/w5-a-d4-cross-end.test.ts", "tests/w5-a-d4-showcase-paths.test.ts", "--maxWorkers=1"], candidateApp);
  const verified = run("node", ["scripts/w5-a-d4/verify-candidate.mjs"], candidateApp);
  const stdout = Buffer.concat([tests.stdout ?? Buffer.alloc(0), verified.stdout ?? Buffer.alloc(0)]);
  const stderr = Buffer.concat([tests.stderr ?? Buffer.alloc(0), verified.stderr ?? Buffer.alloc(0)]);
  const result = {
    schemaVersion: 1,
    status: tests.status === 0 && verified.status === 0 ? "PASS" : "FAIL",
    startedAt,
    endedAt: new Date().toISOString(),
    baselineHead: "a0d5a37116a6c67f009ca19e313501d9eed96f78",
    workspace: "independent_system_temp_baseline_overlay",
    commands: [
      { command: "npm.cmd test -- tests/w5-a-d4-cross-end.test.ts tests/w5-a-d4-showcase-paths.test.ts --maxWorkers=1", exitCode: tests.status },
      { command: "node scripts/w5-a-d4/verify-candidate.mjs", exitCode: verified.status },
    ],
    stdout: { bytes: stdout.byteLength, sha256: digest(stdout) },
    stderr: { bytes: stderr.byteLength, sha256: digest(stderr) },
  };
  if (existing.status !== "PASS") await writeFile(outputPath, `${JSON.stringify(result, null, 2)}\n`, "utf8");
  if (result.status !== "PASS") process.exitCode = 1;
} finally {
  const rel = relative(tmpdir(), temporary);
  if (rel === "" || rel.startsWith(`..${sep}`) || resolve(tmpdir(), rel) !== temporary) throw new Error("Unsafe temporary cleanup target");
  await rm(temporary, { recursive: true, force: true });
}
