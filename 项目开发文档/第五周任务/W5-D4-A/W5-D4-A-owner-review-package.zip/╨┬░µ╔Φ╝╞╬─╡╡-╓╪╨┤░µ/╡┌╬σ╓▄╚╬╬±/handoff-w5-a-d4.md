# 岗位 A W5-D4 交接单

状态：`READY_FOR_OWNER_CONTRACT_ENV_REVALIDATION / NOT_COMMITTED / NOT_PUSHED / uploadLock=NOT_REQUESTED`。

合同为 `W5-C1/W5-R1`，唯一基线为 `a0d5a37116a6c67f009ca19e313501d9eed96f78`。本文件描述未提交候选，不是 C 或 E 可直接消费的正式上游，也不声明整体 W5 GO。

## 正式上游绑定

- A D2：`127a71cce4a8423327fb5ce75d31294252b92a0b`
- E D2：`590985af616861e503ee30f2bf56c6392b0055f7`
- C D3：`6acc56fa03986797be54156af639a905c2e74a64`
- B D3/当前基线：`a0d5a37116a6c67f009ca19e313501d9eed96f78`
- revision 3 seal：`ccff2e2afdabaad262baeaa498b527438fcadeec1ddf5e198289f8404071e85d`
- environment lock SHA-256：`59917d1528d031f46a1e76359d99628e810f2dfa78a92d66e03386c860fbaf43`
- Pyodide：`PYODIDE_DISABLED_WITH_NODE_FALLBACK`
- `LIVE_MODEL=LIVE_NOT_RUN`

## 跨端闭环

`TuiSharedSessionBridge.readActivityAttempt()` 是本轮唯一生产代码补充。它使用当前安全恢复视图中的 session/version/revision 调用既有 `LearningRuntimeFacade.getActivityAttempt()`，不读取仓储、不扩展公共合同、不建立第二套 Facade。

两条定向轨迹均使用正式 `createDemoRuntime`、正式 HTTP 路由、`TuiSharedSessionEntry` 和共享干净数据目录：

1. TUI 读取当前步骤并生成 pending/deep link，Web 打开并提交 quiz；关闭服务并重建 runtime 后，TUI 读取同一 session、Attempt 和下一步。
2. Web 打开活动，TUI 从服务端恢复视图读取同一 draft Attempt 并正式提交；Web 刷新后读取同一 submitted Attempt，提交成功后 pending 被清理。

测试只比较公开恢复视图和安全 Attempt DTO。pending、深链、刷新和恢复不会创建替代 session 或额外正式事实；只有正式提交推进 sessionVersion、Attempt、Evidence 和路径活动进度。

## 三案例 PathEngine 输出

B 的三个输入先按 LF 规范 Git blob 字节复算输入 SHA-256。Windows CRLF 检出只在读取时规范化用于绑定校验，不修改 B 文件。每个案例在两个独立干净目录中经正式组合根执行固定诊断、PathEngine 建路、确认和下一步读取，语义输出及路径摘要两次一致。

三组机械差异计数为 `32 / 12 / 21`，均超过每对至少三项。差异来自实际 KnowledgeState、scaffold、reason codes、Evidence 充分性和安全路径节点；未复制 B 的 expected-differences，也未手工写入路径。

实际路径、KnowledgeState、状态和输入/输出/path SHA-256 位于 `pi-study-helper/scripts/w5-a-d4/showcase-path-results.json`，两两差异位于 `showcase-differences.json`。

## 验证结果与环境归因

当前机器实际环境为 Node `v24.18.0`、npm `11.16.0`、Python `3.11.9`、Pandas 不可用、`PYTHONNOUSERSITE=1`，不匹配合同环境。

- D4 跨端：1 文件 / 2 测试 PASS。
- D4 三案例：1 文件 / 1 测试 PASS。
- 受影响恢复/Extension/HTTP：3 文件 / 21 测试 PASS。
- typecheck、docs、Web build、extension smoke、release、`git diff --check`：exit 0。
- 当前机器全量：102 文件中 95 PASS / 7 FAIL；806 测试 PASS / 30 FAIL / 1 skipped。
- 当前机器 `verify`：因同一全量 Python evaluator 失败退出 1。
- revision 3 正式 Node 合同测试：3 PASS / 2 FAIL；本机无 Pandas，不形成 V5-3 合同结论。

上述失败保留为当前非合同机器事实。C D3 的合同环境正式 PASS 作为上游绑定保留，但未伪写成 A 本机独立复验。负责人需在 Node `22.23.1`、npm `10.9.8`、Python `3.13.7`、Pandas `3.0.5`、`PYTHONNOUSERSITE=1` 下复验正式 Node 和全量门禁，之后才能决定上传锁。

## 边界

本轮未修改 `src/web`、C evaluator、B Profile/revision/seal/environment lock、D 材料、SDK、依赖、锁文件、gold、hidden tests、Rubric 或 reference solution。A 只声明 V5-1/V5-4 的 A 责任证据通过和 V5-3 的上游绑定/本机未验证状态，不声明页面关闭态、完整 V5 或 W5 GO。
