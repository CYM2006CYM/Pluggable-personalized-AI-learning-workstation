# 岗位A第二周 D1-D3：V2-4/V2-5修复包复验要求

## 基线与状态

- 合同：`W2-C2 / W2-R5`
- 固定 `W2_START_COMMIT`：`f343a6c1c630f362f4686e6f6b0f50c6577d5562`
- 实际工作基线：`f16399089938f79d07ff6a4dafacb8442cdb91d5`
- 当前状态：`V2-4_PENDING_E_REVERIFY / V2-5_PENDING_E_REVERIFY`
- 本包未提交、未推送、未申请上传锁；旧包审计结论不得替代本包复验。

## 本次修复

1. 诊断逐题提交增加进程内会话级互斥，覆盖requestId扫描、首次题目检查、判分和写入。并发提交同题不同requestId时只允许首次成功，后续返回`diagnostic_answer_conflict`；相同requestId相同内容并发保持幂等。
2. 临时事务候选增加格式版本、原始提交输入和可复算`inputHash`。`commit`重试和`recover`在发布前从当前正式快照重新构建预期事务，闭合Evidence、KnowledgeState、LearnerDiagnostic、版本、响应、提交标记、哈希和路径安全。
3. JSON合法但语义损坏、缺少原始输入或哈希无法闭合的候选进入`quarantine`，不得推进`latest.json`或公开任何正式状态。

## E复验要求

1. 复算外层sidecar及包内`MANIFEST.sha256`。
2. 以`f163990...`建立独立工作树，只读覆盖本包文件。
3. 执行`npm.cmd ci`、`npm.cmd run typecheck`、6个V2重点测试、全量测试、`npm.cmd run verify`和`git diff --check`。
4. V2-4重点检查同题并发首次结果不可覆盖、并发幂等和跨题requestId内容绑定。
5. V2-5重点检查合法候选可恢复，以及哈希、Evidence路径、KnowledgeState、Diagnostic、版本、snapshot/response闭合损坏均进入隔离区且正式快照不变。
6. 分别出具V2-4/V2-5结论、真实测试项数、失败文件、复现步骤和是否阻止A申请上传锁。

## A作者验证

- 聚焦2文件：23/23 PASS。
- 6个V2重点文件：45/45 PASS。
- 全量测试：36个文件、387/387 PASS。
- `typecheck`、`verify`、`check:docs`、`smoke:extension`、`check:release`和`git diff --check`：PASS。

## 边界

本包不包含B/C/D/E文件，不修改Pandas资产、依赖、锁文件及20、21、27、28号权威文档，不实现或调用PathEngine/buildPath。
